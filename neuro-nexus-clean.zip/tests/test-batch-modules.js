/**
 * test-batch-modules.js — Tests für Batch 1-3 Module
 *
 * Testet: WorkingMemory, CohesionCore, RewardSystem,
 *         MoodStateMachine, dnaArchetypes, EchoMemory,
 *         ExternalStimuli, EnergyModel, MultiAgentHub
 */

// ─── Test Framework (minimal) ───────────────────────────────────────
let passed = 0, failed = 0;
const failures = [];

function assert(condition, message) {
  if (condition) {
    passed++;
  } else {
    failed++;
    failures.push(message);
    console.log(`  ❌ FAIL: ${message}`);
  }
}

function assertApprox(actual, expected, tolerance, message) {
  assert(Math.abs(actual - expected) < tolerance, `${message} (got ${actual}, expected ~${expected})`);
}

// ─── Mock Simulation ────────────────────────────────────────────────
function createMockSim(overrides = {}) {
  const events = {
    _listeners: {},
    on(event, cb) {
      if (!this._listeners[event]) this._listeners[event] = new Set();
      this._listeners[event].add(cb);
      return () => this.off(event, cb);
    },
    off(event, cb) {
      if (this._listeners[event]) this._listeners[event].delete(cb);
    },
    emit(event, data) {
      if (this._listeners[event]) {
        for (const cb of this._listeners[event]) {
          try { cb(data); } catch(e) {}
        }
      }
    },
    clear() { this._listeners = {}; }
  };

  return {
    events,
    world: {
      age: 0,
      growthStage: "genesis",
      clusters: [],
      edges: [],
      bridgeEdges: [],
      scars: [],
      centerX: 400,
      centerY: 300,
      minSide: 600,
      currentTime: 0,
      ...overrides.world
    },
    personality: {
      curiosity: 0.7, caution: 0.3, resilience: 0.6, rhythm: 0.5,
      sensitivity: 0.6, plasticity: 0.7, attachment: 0.5, volatility: 0.4,
      ...overrides.personality
    },
    memory: { autonomousMoments: 0, events: [], strongestTrace: 0, clusterPairActivity: {} },
    ...overrides
  };
}

// ─── 1. dnaArchetypes Tests ─────────────────────────────────────────
console.log("\n━━━ dnaArchetypes ━━━");

const { computeDnaAxes, classifyAxis, resolveArchetype, analyzeDna, ARCHETYPES } =
  await import("../simulation/dnaArchetypes.js");

// computeDnaAxes
let axes = computeDnaAxes({ curiosity: 0.8, plasticity: 0.7, caution: 0.2, sensitivity: 0.6, attachment: 0.5, volatility: 0.3, rhythm: 0.6, resilience: 0.7 });
assert(axes.exploration > 0.6, "High curiosity+plasticity → high exploration");
assert(axes.dynamism < 0.5, "Low volatility + high rhythm → low dynamism");

axes = computeDnaAxes({ curiosity: 0.1, plasticity: 0.1, caution: 0.9, sensitivity: 0.2, attachment: 0.2, volatility: 0.9, rhythm: 0.1, resilience: 0.1 });
assert(axes.exploration < 0.3, "Low curiosity + high caution → low exploration");
assert(axes.dynamism > 0.7, "High volatility + low rhythm → high dynamism");

// classifyAxis
assert(classifyAxis(0.8) === "high", "0.8 → high");
assert(classifyAxis(0.2) === "low", "0.2 → low");
assert(classifyAxis(0.5) === "mid", "0.5 → mid");

// resolveArchetype
const arch = resolveArchetype({ exploration: 0.8, resonance: 0.7, dynamism: 0.8 });
assert(arch.id === "pioneer", "High all → Pioneer archetype");
const arch2 = resolveArchetype({ exploration: 0.2, resonance: 0.2, dynamism: 0.2 });
assert(arch2.id === "stone", "Low all → Stone archetype");

// analyzeDna
const dna = analyzeDna({ curiosity: 0.8, plasticity: 0.7, caution: 0.2, sensitivity: 0.8, attachment: 0.7, volatility: 0.7, rhythm: 0.3, resilience: 0.3 });
assert(dna.archetype !== null, "analyzeDna returns archetype");
assert(dna.classified !== null, "analyzeDna returns classified axes");

// 12 archetypes exist
assert(Object.keys(ARCHETYPES).length === 12, "12 archetypes defined");

// ─── 2. WorkingMemory Tests ─────────────────────────────────────────
console.log("\n━━━ WorkingMemory ━━━");

const { WorkingMemory } = await import("../simulation/consciousness/WorkingMemory.js");
let sim = createMockSim();
let wm = new WorkingMemory(sim);

// Ingest signals
wm._ingest({ type: "signal", channel: "external", salience: 0.7 });
wm._ingest({ type: "growth", channel: "structural", salience: 0.5 });
assert(wm.getActive().length === 2, "2 items in working memory");
assert(wm.totalSalience > 1.0, "Total salience > 1.0 for 2 items");

// Miller's 7±2 — max 7 items
for (let i = 0; i < 10; i++) {
  wm._ingest({ type: "pulse", channel: "internal", salience: 0.1 });
}
assert(wm.getActive().length <= 7, "Working memory capped at 7 items");

// Update — decay
const beforeDecay = wm.totalSalience;
wm.update(0.1);
assert(wm.totalSalience < beforeDecay, "Salience decays after update");

wm.destroy();

// ─── 3. CohesionCore Tests ──────────────────────────────────────────
console.log("\n━━━ CohesionCore ━━━");

const { CohesionCore } = await import("../simulation/consciousness/CohesionCore.js");
sim = createMockSim();
let cc = new CohesionCore(sim);

// Identity Stabilizer
cc._stabilize({ to: "aware" });
assert(cc._identityBuffer.length === 1, "Identity buffer has 1 entry");
assert(cc.stableState === "aware", "Stable state is 'aware' after first change");

// Fill buffer with oscillating states (3-way oscillation → no 60% majority)
const states = ["aware", "reactive", "reflective"];
for (let i = 0; i < 6; i++) {
  cc._stabilize({ to: states[i % 3] });
}
assert(cc._suppressedChanges > 0, "Oscillating changes were suppressed");

// Narrative Compression
cc._bufferEvent({ text: "Neuron spawn", emotion: "growth", type: "story" });
cc._bufferEvent({ text: "Synapse formed", emotion: "connection", type: "story" });
assert(cc._eventBuffer.length === 2, "2 events buffered for compression");

cc.destroy();

// ─── 4. RewardSystem Tests ──────────────────────────────────────────
console.log("\n━━━ RewardSystem ━━━");

const { RewardSystem } = await import("../simulation/systems/RewardSystem.js");
sim = createMockSim({
  emotionEngine: {
    getSnapshot: () => ({
      dominant: { emotion: "joy", intensity: 0.8, valence: +1 },
      emotions: { joy: 0.8 },
      mood: 0.5
    })
  },
  world: { age: 100, edges: [
    { activityGlow: 0.3, identityTrace: 0.5, weight: 0.5 },
    { activityGlow: 0.01, identityTrace: 0.1, weight: 0.3 }
  ]}
});
let rs = new RewardSystem(sim);

// Process RPE — high prediction error + positive emotion = positive surprise (RPE)
// expected = 1 - 0.5 = 0.5, actual = 0.5 + 0.8*0.5 = 0.9, delta = 0.4 (positive!)
rs._processRPE(0.5, {});
assert(rs.getLastRPE().delta > 0, "Positive RPE delta (unexpected good outcome)");
assert(rs.dopamine > 0.45, "Dopamine boosted after positive RPE");
assert(rs.getLastRPE().delta !== 0, "Last RPE recorded");

// Check Hebbian reinforcement
const reinforcedEdge = sim.world.edges[0];
assert(reinforcedEdge.identityTrace > 0.5, "Active edge was reinforced by positive RPE");

rs.destroy();

// ─── 5. MoodStateMachine Tests ──────────────────────────────────────
console.log("\n━━━ MoodStateMachine ━━━");

const { MoodStateMachine, MoodState } = await import("../simulation/systems/MoodStateMachine.js");
sim = createMockSim({
  consciousness: { selfModel: { selfModel: { coherence: 0.7 } } }
});
let msm = new MoodStateMachine(sim);

assert(msm.getMood() === MoodState.CALM, "Initial mood is CALM");
assert(msm.getMoodLabel() === "Ruhig", "Mood label is 'Ruhig'");

// Simulate signal activity to trigger transition to EXCITED
sim.world.age = 20;
for (let i = 0; i < 100; i++) {
  sim.events.emit("signal:injected", {});
  msm.update(0.5);
}
// After enough signal activity + hold time, should transition
assert(msm.getMood() !== MoodState.CALM || msm._holdTime > 0, "Mood processing signals");

msm.destroy();

// ─── 6. EchoMemory Tests ────────────────────────────────────────────
console.log("\n━━━ EchoMemory ━━━");

const { EchoMemory } = await import("../simulation/systems/EchoMemory.js");
sim = createMockSim({
  episodicMemory: { resonanceSearch: () => [] }
});
let em = new EchoMemory(sim);

// Store a pattern
em._checkEcho({ emotion: "wonder", category: "milestone", text: "Neuron spawned in genesis", timestamp: 50 });
assert(em._patternHistory.length === 1, "First pattern stored");

// Simulate time passage + similar event → echo
sim.world.age = 80;
em._checkEcho({ emotion: "wonder", category: "milestone", text: "Neuron spawned in genesis core", timestamp: 80 });
assert(em.getActiveEchos().length > 0, "Echo detected for similar pattern");

em.destroy();

// ─── 7. EnergyModel Tests ───────────────────────────────────────────
console.log("\n━━━ EnergyModel ━━━");

const { EnergyModel } = await import("../simulation/systems/EnergyModel.js");
sim = createMockSim();
let en = new EnergyModel(sim);

assert(en.getEnergy() === 1.0, "Initial energy is full (1.0)");
assert(en.getGrowthMultiplier() === 1.0, "Full energy → growth multiplier 1.0");

// Simulate energy drain
for (let i = 0; i < 500; i++) {
  sim.events.emit("growth:nodeAdded", {});
  en.update(0.033);
}
assert(en.getEnergy() < 0.9, "Energy decreased after growth events");
assert(en.getGrowthMultiplier() < 1.0, "Lower energy → reduced growth multiplier");

en.destroy();

// ─── 8. ExternalStimuli Tests ───────────────────────────────────────
console.log("\n━━━ ExternalStimuli ━━━");

const { ExternalStimuli } = await import("../simulation/systems/ExternalStimuli.js");
sim = createMockSim({
  signalSystem: { inject: () => {} },
  rng: { range: (a, b) => (a + b) / 2, chance: (p) => p < 0.5, int: (a, b) => a }
});
let es = new ExternalStimuli(sim);

// Before age 10: no stimuli
sim.world.age = 5;
es.update(1.0);
assert(es.getSnapshot().stimulusCount === 0, "No stimuli before age 10");

// After age 10: stimuli start
sim.world.age = 15;
for (let i = 0; i < 500; i++) {
  es.update(1.0);
}
assert(es.getSnapshot().stimulusCount > 0, "Stimuli generated after age 10");

es.destroy();

// ─── 9. MultiAgentHub Tests ─────────────────────────────────────────
console.log("\n━━━ MultiAgentHub ━━━");

const { MultiAgentHub } = await import("../simulation/systems/MultiAgentHub.js");
sim = createMockSim({
  signalSystem: { inject: () => {} },
  rng: { range: (a, b) => (a + b) / 2, chance: (p) => p < 0.5, int: (a, b) => a }
});
let mah = new MultiAgentHub(sim);

assert(mah.getConnectedAgents().length === 0, "No connected agents initially");

// Register agent
mah.registerAgent({ id: "test-agent", name: "TestAgent" });
assert(mah.getConnectedAgents().length === 1, "1 agent after registration");

mah.unregisterAgent("test-agent");
assert(mah.getConnectedAgents().length === 0, "0 agents after unregistration");

mah.destroy();

// ─── Results ────────────────────────────────────────────────────────
console.log("\n═══════════════════════════════════════════════════════════");
console.log(`  Results: ${passed} passed, ${failed} failed`);
if (failures.length > 0) {
  console.log("  Failures:");
  failures.forEach(f => console.log(`    • ${f}`));
}
console.log("═══════════════════════════════════════════════════════════");
process.exit(failed > 0 ? 1 : 0);
