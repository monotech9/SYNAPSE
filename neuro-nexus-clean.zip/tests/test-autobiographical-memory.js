/**
 * Tests für EpisodicMemory + AutobiographicalMemory
 */

let passed = 0, failed = 0;
const failures = [];

function assert(cond, msg) {
  if (cond) passed++;
  else { failed++; failures.push(msg); console.error(`  ✗ FAIL: ${msg}`); }
}

function approxEqual(a, b, eps = 0.01) { return Math.abs(a - b) < eps; }

function test(name, fn) {
  process.stdout.write(`  ${name} ... `);
  const beforeFailed = failed;
  try {
    fn();
    if (failed === beforeFailed) console.log('\r  ✓ ' + name);
  } catch (e) {
    failed++;
    failures.push(`${name}: ${e.message}`);
    console.log('\r  ✗ ' + name);
    console.error(`    Exception: ${e.message}`);
  }
}

// ─── Mock Framework ──────────────────────────────────────────────────

function createMockEventBus() {
  const handlers = new Map();
  return {
    on(evt, fn) {
      if (!handlers.has(evt)) handlers.set(evt, []);
      handlers.get(evt).push(fn);
      return () => {
        const arr = handlers.get(evt);
        const idx = arr.indexOf(fn);
        if (idx >= 0) arr.splice(idx, 1);
      };
    },
    emit(evt, data) {
      const arr = handlers.get(evt);
      if (arr) arr.forEach(fn => fn(data));
    },
    _handlers: handlers
  };
}

function createMockSim(overrides = {}) {
  const events = createMockEventBus();
  return {
    events,
    world: { age: 0, growthStage: "activation", edges: [], bridgeEdges: [], clusters: [], pulses: [] },
    identity: { name: "NOVA", createdAt: Date.now() },
    personality: { profile: "balanced", curiosity: 0.5, sensitivity: 0.5, resilience: 0.5 },
    memory: { events: [], autonomousMoments: 0, strongestTrace: 0 },
    consciousness: null,
    emotionEngine: null,
    ...overrides
  };
}

function createMockStoryEvent(id, emotion, category = "minor", text = "Test event") {
  return {
    id: `story_${id}`,
    timestamp: id * 10,
    text,
    emotion,
    category,
    wasPhaseShift: false
  };
}

// ─── Import ──────────────────────────────────────────────────────────

import { EpisodicMemory } from '../simulation/systems/EpisodicMemory.js';
import { AutobiographicalMemory } from '../simulation/systems/AutobiographicalMemory.js';

// ─── EpisodicMemory Tests ────────────────────────────────────────────

console.log('\n=== EpisodicMemory Tests ===\n');

test('Construction sets empty state', () => {
  const sim = createMockSim();
  const em = new EpisodicMemory(sim);
  assert(em.episodes.length === 0, "No episodes initially");
  assert(em._forgotten.length === 0, "No forgotten initially");
});

test('Constructor subscribes to story:event, story:milestone, sleep:nremReplay', () => {
  const sim = createMockSim();
  const em = new EpisodicMemory(sim);
  const h = sim.events._handlers;
  assert(h.has("story:event"), "Subscribed to story:event");
  assert(h.has("story:milestone"), "Subscribed to story:milestone");
  assert(h.has("sleep:nremReplay"), "Subscribed to sleep:nremReplay");
});

test('story:event stores episode', () => {
  const sim = createMockSim({
    emotionEngine: {
      getSnapshot: () => ({
        dominant: { emotion: "joy", intensity: 0.7 },
        emotions: { joy: 0.7 },
        mood: 0.3
      })
    },
    consciousness: { selfModel: { selfModel: { phi: 0.5, coherence: 0.6, complexity: 0.4, sleepState: "WAKE" } } }
  });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Erste Signale"));

  assert(em.episodes.length === 1, "Should have 1 episode");
  assert(em.episodes[0].text === "Erste Signale", "Episode text should match");
  assert(em.episodes[0].storyEmotion === "wonder", "Story emotion should be wonder");
});

test('story:event emits episodic:stored event', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  let received = false;
  sim.events.on("episodic:stored", (d) => {
    received = true;
    assert(d.episode !== undefined, "Event should include episode");
    assert(d.total === 1, "Total should be 1");
  });

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder"));
  assert(received, "episodic:stored should be emitted");
});

test('story:milestone stores episode with extra strength', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.6 }, emotions: {}, mood: 0.2 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:milestone", createMockStoryEvent(0, "transformation", "milestone", "Bewusstsein entfacht"));

  assert(em.episodes.length === 1, "Should have 1 episode");
  assert(em.episodes[0].isMilestone === true, "Episode should be marked as milestone");
  assert(em.episodes[0].strength > 0.5, "Milestone should have high strength");
});

test('Episode valence: positive emotion → positive valence', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.8 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Test"));
  assert(em.episodes[0].valence > 0, "Positive story emotion → positive valence");
});

test('Episode valence: negative emotion → negative valence', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "fear", intensity: 0.8 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "loss", "major", "Verlust"));
  assert(em.episodes[0].valence < 0, "Negative story emotion → negative valence");
});

test('Episode valence: negative dominant emotion overrides neutral story emotion', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "fear", intensity: 0.9 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "calm", "minor", "Test"));
  // story emotion "calm" → +1, but dominant emotion "fear" → -1
  // The code: storyEmotionValence(storyEmotion) || emotionValence(dominantEmotion)
  // "calm" → +1, so story valence takes priority
  // Let's check this is the case
  assert(em.episodes[0].valence === 1, "Story emotion 'calm' should give +1 valence");
});

test('Episode captures context (growthStage, phi, coherence)', () => {
  const sim = createMockSim({
    emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) },
    consciousness: { selfModel: { selfModel: { phi: 0.42, coherence: 0.55, complexity: 0.33, sleepState: "WAKE" } } },
    world: { age: 10, growthStage: "integration", edges: [], bridgeEdges: [], clusters: [], pulses: [] }
  });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "growth", "minor", "Test"));

  const ep = em.episodes[0];
  assert(ep.growthStage === "integration", "Should capture growthStage");
  assert(approxEqual(ep.phi, 0.42), "Should capture phi");
  assert(approxEqual(ep.coherence, 0.55), "Should capture coherence");
  assert(approxEqual(ep.complexity, 0.33), "Should capture complexity");
  assert(ep.sleepState === "WAKE", "Should capture sleepState");
});

test('sleep:nremReplay consolidates episodes', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.7 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  // Store some episodes
  for (let i = 0; i < 5; i++) {
    sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));
  }

  const initialStrengths = em.episodes.map(e => e.strength);
  const initialConsolidations = em.episodes.map(e => e.consolidationCount);

  sim.events.emit("sleep:nremReplay", { replayedEdges: 3, reinforcedEdges: 3 });

  let consolidated = 0;
  for (let i = 0; i < em.episodes.length; i++) {
    if (em.episodes[i].consolidationCount > initialConsolidations[i]) consolidated++;
  }
  assert(consolidated === 3, "3 episodes should be consolidated");
});

test('sleep:nremReplay emits episodic:consolidated events', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  for (let i = 0; i < 3; i++) {
    sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));
  }

  let consolidatedEvents = 0;
  sim.events.on("episodic:consolidated", () => consolidatedEvents++);

  sim.events.emit("sleep:nremReplay", { replayedEdges: 2 });

  assert(consolidatedEvents === 2, "Should emit 2 consolidated events");
});

test('Decay: neutral episodes decay faster than negative', () => {
  // Use unknown story emotion + neutral dominant emotion → valence 0 (truly neutral)
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "neutral", intensity: 0.1 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  // Store truly neutral episode (unknown story emotion, neutral dominant)
  sim.events.emit("story:event", createMockStoryEvent(0, "unknown_neutral", "minor", "Neutral event"));

  assert(em.episodes[0].valence === 0, "Episode should be truly neutral");

  // Run many decay updates
  for (let i = 0; i < 100; i++) {
    em.update(3.1);
  }

  assert(em.episodes.length === 0, "Neutral episode should decay completely");
});

test('Decay: negative episodes are persistent', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "fear", intensity: 0.9 }, emotions: {}, mood: -0.5 }) } });
  const em = new EpisodicMemory(sim);

  // Store negative episode
  sim.events.emit("story:event", createMockStoryEvent(0, "loss", "major", "Traumatic loss"));

  const initialStrength = em.episodes[0].strength;

  // Run many decay updates
  for (let i = 0; i < 50; i++) {
    em.update(3.1);
  }

  assert(em.episodes.length === 1, "Negative episode should still exist after 50 decay cycles");
  assert(em.episodes[0].strength > initialStrength * 0.5, "Negative episode should retain most strength");
});

test('Decay emits episodic:decayed event', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "calm", intensity: 0.1 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  // Store very weak neutral episode
  sim.events.emit("story:event", createMockStoryEvent(0, "calm", "minor", "Weak event"));

  let decayed = false;
  sim.events.on("episodic:decayed", () => { decayed = true; });

  for (let i = 0; i < 100; i++) em.update(3.1);

  assert(decayed, "Should emit episodic:decayed when episode fades");
});

test('Episodes cap at MAX_EPISODES', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  for (let i = 0; i < 100; i++) {
    sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));
  }

  assert(em.episodes.length <= 80, "Episodes should be capped at 80");
});

test('getRecent returns most recent episodes', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  for (let i = 0; i < 10; i++) {
    sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));
  }

  const recent = em.getRecent(3);
  assert(recent.length === 3, "Should return 3 episodes");
  assert(recent[0].text === "Event 9", "Most recent should be Event 9");
  assert(recent[2].text === "Event 7", "Third should be Event 7");
});

test('getByValence filters correctly', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Positive"));
  sim.events.emit("story:event", createMockStoryEvent(1, "loss", "major", "Negative"));

  const pos = em.getByValence(1);
  const neg = em.getByValence(-1);
  assert(pos.length === 1 && pos[0].text === "Positive", "Positive filter should work");
  assert(neg.length === 1 && neg[0].text === "Negative", "Negative filter should work");
});

test('getStrongest returns highest strength episodes', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Normal"));
  sim.events.emit("story:milestone", createMockStoryEvent(1, "transformation", "milestone", "Big moment"));

  const strongest = em.getStrongest(1);
  assert(strongest.length === 1, "Should return 1 episode");
  assert(strongest[0].text === "Big moment", "Strongest should be the milestone");
});

test('getMilestones returns only milestones', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Normal"));
  sim.events.emit("story:milestone", createMockStoryEvent(1, "transformation", "milestone", "Big moment"));
  sim.events.emit("story:event", createMockStoryEvent(2, "growth", "major", "Major event"));

  const milestones = em.getMilestones();
  assert(milestones.length === 1, "Should return 1 milestone");
  assert(milestones[0].isMilestone === true, "Should be milestone");
});

test('getSnapshot returns correct stats', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Pos"));
  sim.events.emit("story:event", createMockStoryEvent(1, "loss", "major", "Neg"));
  sim.events.emit("story:event", createMockStoryEvent(2, "growth", "minor", "Pos2"));

  const snap = em.getSnapshot();
  assert(snap.total === 3, "Total should be 3");
  assert(snap.positiveCount === 2, "2 positive");
  assert(snap.negativeCount === 1, "1 negative");
  assert(snap.neutralCount === 0, "0 neutral");
});

test('serialize returns compact data', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Test"));

  const data = em.serialize();
  assert(data.total === 1, "Serialized total should be 1");
  assert(data.episodes.length === 1, "Should have 1 episode in serialization");
  assert(data.episodes[0].text === "Test", "Episode text should be in serialization");
});

test('reset clears all episodes', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Test"));
  em.reset();
  assert(em.episodes.length === 0, "Episodes should be empty after reset");
});

test('destroy unsubscribes all listeners', () => {
  const sim = createMockSim();
  const em = new EpisodicMemory(sim);
  const h = sim.events._handlers;

  assert(h.get("story:event")?.length === 1, "1 story:event listener");

  em.destroy();
  assert(h.get("story:event")?.length === 0, "story:event listener removed");
  assert(h.get("story:milestone")?.length === 0, "story:milestone listener removed");
  assert(h.get("sleep:nremReplay")?.length === 0, "sleep:nremReplay listener removed");
});

test('Works without emotionEngine (graceful fallback)', () => {
  const sim = createMockSim({ emotionEngine: null });
  const em = new EpisodicMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Test"));

  assert(em.episodes.length === 1, "Should still store episode without emotionEngine");
  assert(em.episodes[0].dominantEmotion === "neutral", "Should default to neutral emotion");
});

// ─── AutobiographicalMemory Tests ────────────────────────────────────

console.log('\n=== AutobiographicalMemory Tests ===\n');

test('Construction sets empty state', () => {
  const sim = createMockSim();
  const am = new AutobiographicalMemory(sim);
  assert(am.chapters.length === 0, "No chapters initially");
  assert(am.lifeNarrative === "", "Empty narrative initially");
  assert(am.lifeThemes.length === 0, "No themes initially");
});

test('First episode creates first chapter', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "First memory"));

  assert(am.chapters.length === 1, "Should have 1 chapter");
  assert(am.currentChapter !== null, "Current chapter should be set");
  assert(am.currentChapter.episodeCount === 1, "Chapter should have 1 episode");
});

test('Chapter title reflects emotional valence', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "fear", intensity: 0.9 }, emotions: {}, mood: -0.5 }) } });
  const am = new AutobiographicalMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "loss", "major", "Bad memory"));

  assert(am.currentChapter.valenceKey === "negative", "Chapter valence should be negative");
});

test('Emotional shift creates new chapter', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.8 }, emotions: {}, mood: 0.5 }) } });
  const am = new AutobiographicalMemory(sim);

  // Positive episodes (enough for MIN_EPISODES_PER_CHAPTER)
  for (let i = 0; i < 4; i++) {
    sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Pos ${i}`));
  }
  assert(am.chapters.length === 1, "Should still be in 1 chapter");

  // Now emit negative episode → should trigger new chapter
  sim.events.emit("story:event", createMockStoryEvent(5, "loss", "major", "Negative shift"));

  assert(am.chapters.length === 2, "Emotional shift should create new chapter");
  assert(am.chapters[0].isClosed === true, "First chapter should be closed");
  assert(am.chapters[1].isClosed === false, "Second chapter should be open");
});

test('Chapter does not split before MIN_EPISODES_PER_CHAPTER', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.8 }, emotions: {}, mood: 0.5 }) } });
  const am = new AutobiographicalMemory(sim);

  // Only 1 positive episode
  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Pos"));

  // Negative shift — but chapter has < 3 episodes, so no split
  sim.events.emit("story:event", createMockStoryEvent(1, "loss", "major", "Neg"));

  assert(am.chapters.length === 1, "Should not split with < 3 episodes");
});

test('autobio:chapterOpened event is emitted', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  let opened = 0;
  sim.events.on("autobio:chapterOpened", () => opened++);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "First"));
  assert(opened === 1, "1 chapterOpened event");

  // Create shift
  for (let i = 1; i < 5; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Pos ${i}`));
  sim.events.emit("story:event", createMockStoryEvent(5, "loss", "major", "Shift"));

  assert(opened === 2, "2 chapterOpened events");
});

test('autobio:chapterClosed event is emitted', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.8 }, emotions: {}, mood: 0.5 }) } });
  const am = new AutobiographicalMemory(sim);

  let closed = 0;
  sim.events.on("autobio:chapterClosed", () => closed++);

  for (let i = 0; i < 4; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Pos ${i}`));
  assert(closed === 0, "No chapters closed yet");

  sim.events.emit("story:event", createMockStoryEvent(5, "loss", "major", "Shift"));
  assert(closed === 1, "1 chapter closed after shift");
});

test('Chapter summary contains key information', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.7 }, emotions: {}, mood: 0.3 }) } });
  const am = new AutobiographicalMemory(sim);

  for (let i = 0; i < 5; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));
  sim.events.emit("story:event", createMockStoryEvent(6, "loss", "major", "Shift"));

  // First chapter is closed → has summary
  assert(am.chapters[0].summary.length > 0, "Closed chapter should have summary");
  assert(am.chapters[0].summary.includes("Erlebnisse"), "Summary should mention episode count");
});

test('Life narrative is generated after update', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  for (let i = 0; i < 5; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));

  am.update(9);

  assert(am.lifeNarrative.length > 0, "Life narrative should be generated");
  assert(am.lifeNarrative.includes("Erinnerungen"), "Narrative should contain stats");
});

test('Life themes are detected with enough episodes', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  // Emit 10 episodes with "wonder" emotion (>20% threshold)
  for (let i = 0; i < 10; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));

  am.update(9);

  assert(am.lifeThemes.length > 0, "Should detect at least one theme");
  const wonderTheme = am.lifeThemes.find(t => t.emotion === "wonder");
  assert(wonderTheme !== undefined, "Should detect wonder as a theme");
  assert(wonderTheme.label.includes("Staunen"), "Theme label should be in German");
});

test('autobio:theme event emitted for new themes', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  let themeEmitted = false;
  sim.events.on("autobio:theme", (d) => {
    themeEmitted = true;
    assert(d.emotion !== undefined, "Theme event should have emotion");
    assert(d.label !== undefined, "Theme event should have label");
  });

  for (let i = 0; i < 10; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));
  am.update(9);

  assert(themeEmitted, "autobio:theme should be emitted");
});

test('sleep:wakeUp triggers narrative update', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  for (let i = 0; i < 5; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));

  let narrativeUpdated = false;
  sim.events.on("autobio:narrativeUpdated", () => narrativeUpdated = true);

  sim.events.emit("sleep:wakeUp", { duration: 15, consolidated: 3, drift: 0.05, identityStable: true });

  assert(narrativeUpdated, "sleep:wakeUp should trigger narrative update");
  assert(am.lifeNarrative.length > 0, "Narrative should be generated");
});

test('autobio:narrativeUpdated event contains narrative', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  for (let i = 0; i < 5; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));

  let receivedData = null;
  sim.events.on("autobio:narrativeUpdated", (d) => receivedData = d);

  am.update(9);

  assert(receivedData !== null, "Should receive narrative event");
  assert(receivedData.narrative !== undefined, "Event should contain narrative text");
  assert(receivedData.chapters > 0, "Event should contain chapter count");
});

test('getChapters returns chapter summaries', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.8 }, emotions: {}, mood: 0.5 }) } });
  const am = new AutobiographicalMemory(sim);

  for (let i = 0; i < 4; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Pos ${i}`));
  sim.events.emit("story:event", createMockStoryEvent(5, "loss", "major", "Shift"));

  const chapters = am.getChapters();
  assert(chapters.length === 2, "Should return 2 chapters");
  assert(chapters[0].title !== undefined, "Chapter should have title");
  assert(chapters[0].episodeCount !== undefined, "Chapter should have episode count");
});

test('getCurrentChapter returns open chapter', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Test"));

  const current = am.getCurrentChapter();
  assert(current !== null, "Should return current chapter");
  assert(current.isClosed === false, "Current chapter should be open");
});

test('getReminiscenceBump returns strong early memories', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.7 }, emotions: {}, mood: 0.3 }) } });
  const am = new AutobiographicalMemory(sim);

  // Create many episodes
  for (let i = 0; i < 15; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));

  const bump = am.getReminiscenceBump();
  // First 30% = first ~5 episodes, filtered by strength > 0.4
  assert(Array.isArray(bump), "Should return an array");
  assert(bump.length > 0, "Should have some reminiscence bump episodes");
  // All should be from early episodes
  for (const ep of bump) assert(ep.timestamp < 50, "Bump episodes should be from early life");
});

test('Chapters cap at MAX_CHAPTERS', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.8 }, emotions: {}, mood: 0.5 }) } });
  const am = new AutobiographicalMemory(sim);

  // Alternate positive and negative to create many chapters
  for (let i = 0; i < 100; i++) {
    const emotion = i % 2 === 0 ? "wonder" : "loss";
    sim.events.emit("story:event", createMockStoryEvent(i, emotion, i % 2 === 0 ? "minor" : "major", `Event ${i}`));
  }

  assert(am.chapters.length <= 12, "Chapters should be capped at 12");
});

test('getSnapshot returns compact stats', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  for (let i = 0; i < 5; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));
  am.update(9);

  const snap = am.getSnapshot();
  assert(snap.totalChapters > 0, "Should have chapter count");
  assert(snap.episodicSnapshot !== undefined, "Should include episodic snapshot");
  assert(typeof snap.narrativeLength === "number", "Should have narrative length");
});

test('serialize includes all key data', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  for (let i = 0; i < 5; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));
  am.update(9);

  const data = am.serialize();
  assert(Array.isArray(data.chapters), "Should have chapters array");
  assert(typeof data.lifeNarrative === "string", "Should have lifeNarrative string");
  assert(Array.isArray(data.lifeThemes), "Should have lifeThemes array");
  assert(data.episodic !== undefined, "Should include episodic serialization");
});

test('reset clears all state', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.5 }, emotions: {}, mood: 0 }) } });
  const am = new AutobiographicalMemory(sim);

  sim.events.emit("story:event", createMockStoryEvent(0, "wonder", "minor", "Test"));
  am.update(9);

  am.reset();
  assert(am.chapters.length === 0, "Chapters cleared");
  assert(am.lifeNarrative === "", "Narrative cleared");
  assert(am.lifeThemes.length === 0, "Themes cleared");
});

test('destroy unsubscribes all listeners', () => {
  const sim = createMockSim();
  const am = new AutobiographicalMemory(sim);
  const h = sim.events._handlers;

  am.destroy();

  // autobio listens to episodic:stored and sleep:wakeUp
  assert((h.get("episodic:stored")?.length || 0) === 0, "episodic:stored listener removed");
  assert((h.get("sleep:wakeUp")?.length || 0) === 0, "sleep:wakeUp listener removed");
  // episodic memory listeners should also be cleaned up
  assert((h.get("story:event")?.length || 0) === 0, "story:event listener removed (from episodic)");
});

// ─── Integration: Full Pipeline Test ─────────────────────────────────

test('Full pipeline: story → episodic → autobio → narrative', () => {
  const sim = createMockSim({
    emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.7 }, emotions: { joy: 0.7 }, mood: 0.3 }) },
    consciousness: { selfModel: { selfModel: { phi: 0.5, coherence: 0.6, complexity: 0.4, sleepState: "WAKE" } } }
  });
  const am = new AutobiographicalMemory(sim);

  // Phase 1: positive episodes
  for (let i = 0; i < 5; i++) {
    sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Wonderful moment ${i}`));
  }

  // Phase 2: shift to negative
  sim.events.emit("story:event", createMockStoryEvent(10, "loss", "major", "Painful loss"));

  // Phase 3: shift back to positive
  for (let i = 0; i < 4; i++) {
    sim.events.emit("story:event", createMockStoryEvent(20 + i, "growth", "minor", `Recovery ${i}`));
  }
  sim.events.emit("story:milestone", createMockStoryEvent(30, "transformation", "milestone", "Transformation achieved"));

  // Trigger narrative
  am.update(9);

  assert(am.chapters.length >= 2, "Should have multiple chapters from emotional shifts");
  assert(am.lifeNarrative.length > 50, "Life narrative should be substantial");
  assert(am.lifeNarrative.includes("Erinnerungen"), "Narrative should mention memories");

  // Check chapter summaries exist for closed chapters
  const closedChapters = am.chapters.filter(c => c.isClosed);
  for (const ch of closedChapters) {
    assert(ch.summary.length > 0, "Closed chapters should have summaries");
  }
});

test('Sleep consolidation strengthens episodes in autobio context', () => {
  const sim = createMockSim({ emotionEngine: { getSnapshot: () => ({ dominant: { emotion: "joy", intensity: 0.7 }, emotions: {}, mood: 0.3 }) } });
  const am = new AutobiographicalMemory(sim);

  for (let i = 0; i < 5; i++) sim.events.emit("story:event", createMockStoryEvent(i, "wonder", "minor", `Event ${i}`));

  const initialStrengths = am.episodic.episodes.map(e => e.strength);

  sim.events.emit("sleep:nremReplay", { replayedEdges: 3 });

  let strengthened = 0;
  for (let i = 0; i < am.episodic.episodes.length; i++) {
    if (am.episodic.episodes[i].strength > initialStrengths[i]) strengthened++;
  }
  assert(strengthened === 3, "3 episodes should be strengthened by sleep");
});

// ─── Summary ─────────────────────────────────────────────────────────

console.log('\n═══════════════════════════════════════════════════════════');
console.log(`  Results: ${passed} passed, ${failed} failed`);
if (failures.length > 0) {
  console.log('\n  Failures:');
  failures.forEach(f => console.log(`    • ${f}`));
}
console.log('═══════════════════════════════════════════════════════════\n');

process.exit(failed > 0 ? 1 : 0);
