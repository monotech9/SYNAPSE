/**
 * StoryMappingEngine — Unit Tests
 *
 * Run: node src/test/test-story-engine.js
 *
 * Testet:
 *  - Event-Mapping (ED-Signals → Narrative Templates)
 *  - Emotionale Valenz
 *  - Timeline / Lebensereignis-Historie
 *  - Chapter-Generierung
 *  - EventBus Integration
 *  - Variation (keine unmittelbare Wiederholung)
 */

import { StoryMappingEngine, StoryEventType, EmotionTag } from "../simulation/systems/StoryMappingEngine.js";
import { EmergenceDetector, EmergenceLevel } from "../simulation/systems/EmergenceDetector.js";
import { EventBus } from "../simulation/EventBus.js";

let passed = 0, failed = 0;

function assert(condition, message) {
  if (condition) {
    passed++;
  } else {
    failed++;
    console.error(`  ❌ FAIL: ${message}`);
  }
}

// ─── Mock Node ───────────────────────────────────────────────────────

function makeNode(index, activation, phase = 0, birthProgress = 1) {
  return { index, activation, phase, birthProgress };
}

// ─── Mock RNG ────────────────────────────────────────────────────────

function makeMockRng() {
  let seed = 12345;
  return {
    int: (min, max) => { seed = (seed * 16807) % 2147483647; return min + (seed % (max - min + 1)); },
    range: (min, max) => { seed = (seed * 16807) % 2147483647; return min + (seed / 2147483647) * (max - min); },
    chance: (p) => { seed = (seed * 16807) % 2147483647; return (seed / 2147483647) < p; }
  };
}

// ─── Mock Simulation ─────────────────────────────────────────────────

function makeMockSimulation(nodes = [], edges = [], age = 0) {
  const events = new EventBus();
  const rng = makeMockRng();
  const world = {
    age,
    clusters: nodes.length > 0 ? [{ nodes }] : [],
    edges
  };
  const identity = { name: "AURORA", createdAt: Date.now() };
  return { events, world, rng, identity };
}

// ─── Helper: Simuliere ein ED-Event direkt ───────────────────────────

function emitEDEvent(sim, level, signals) {
  sim.events.emit("emergence:detected", {
    timestamp: sim.world.age,
    epoch: Math.floor(sim.world.age),
    score: 0.7,
    level,
    signals,
    interpretation: "test"
  });
}

// ─── Test 1: CRITICAL_SPIKE → Milestone + Awakening ──────────────────

function testCriticalSpike() {
  console.log("\n📖 Test 1: CRITICAL_SPIKE → Milestone mit Awakening-Emotion");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);

  const engine = new StoryMappingEngine(sim);

  emitEDEvent(sim, "CRITICAL_SPIKE", {
    avalanche: 0.8, sync: 0.85, structureDrift: 0.1,
    entropy: 0.5, branching: 1.0, miDrift: 0.5,
    activeCount: 10, totalNodes: 10, totalEdges: 5
  });

  const last = engine.getLastEvent();
  assert(last !== null, "Sollte ein Event generiert haben");
  assert(last.category === StoryEventType.MILESTONE, `Kategorie sollte MILESTONE sein, got ${last.category}`);
  assert(last.emotion === EmotionTag.AWAKENING, `Emotion sollte AWAKENING sein, got ${last.emotion}`);
  assert(last.text.includes("AURORA"), `Text sollte den Namen enthalten, got "${last.text}"`);
  console.log(`  → "${last.text}"`);
  console.log(`  → emotion: ${last.emotion}, category: ${last.category} ✓`);
}

// ─── Test 2: PHASE_SHIFT + Structure Drift → Transformation ──────────

function testPhaseShiftStructure() {
  console.log("\n📖 Test 2: PHASE_SHIFT + Structure Drift → Major + Transformation");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim);

  emitEDEvent(sim, "PHASE_SHIFT", {
    avalanche: 0.3, sync: 0.2, structureDrift: 0.55,
    entropy: 0.4, branching: 1.2, miDrift: 0.3,
    activeCount: 8, totalNodes: 10, totalEdges: 5
  });

  const last = engine.getLastEvent();
  assert(last.category === StoryEventType.MAJOR, `Kategorie sollte MAJOR sein, got ${last.category}`);
  assert(last.emotion === EmotionTag.TRANSFORMATION, `Emotion sollte TRANSFORMATION sein, got ${last.emotion}`);
  console.log(`  → "${last.text}"`);
  console.log(`  → emotion: ${last.emotion}, category: ${last.category} ✓`);
}

// ─── Test 3: PHASE_SHIFT + Novelty (Entropy↑ + MI↓) → Wonder ─────────

function testPhaseShiftNovelty() {
  console.log("\n📖 Test 3: PHASE_SHIFT + Novelty → Major + Wonder");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim);

  emitEDEvent(sim, "PHASE_SHIFT", {
    avalanche: 0.2, sync: 0.1, structureDrift: 0.15,
    entropy: 0.8, branching: 1.3, miDrift: 0.2,
    activeCount: 9, totalNodes: 10, totalEdges: 5
  });

  const last = engine.getLastEvent();
  assert(last.category === StoryEventType.MAJOR, `Kategorie sollte MAJOR sein, got ${last.category}`);
  assert(last.emotion === EmotionTag.WONDER, `Emotion sollte WONDER sein, got ${last.emotion}`);
  console.log(`  → "${last.text}"`);
  console.log(`  → emotion: ${last.emotion}, category: ${last.category} ✓`);
}

// ─── Test 4: TRANSITION + Avalanche → Minor + Tension ────────────────

function testTransitionAvalanche() {
  console.log("\n📖 Test 4: TRANSITION + Avalanche → Minor + Tension");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim);

  emitEDEvent(sim, "TRANSITION", {
    avalanche: 0.7, sync: 0.1, structureDrift: 0.1,
    entropy: 0.5, branching: 1.1, miDrift: 0.4,
    activeCount: 8, totalNodes: 10, totalEdges: 5
  });

  const last = engine.getLastEvent();
  assert(last.category === StoryEventType.MINOR, `Kategorie sollte MINOR sein, got ${last.category}`);
  assert(last.emotion === EmotionTag.TENSION, `Emotion sollte TENSION sein, got ${last.emotion}`);
  console.log(`  → "${last.text}"`);
  console.log(`  → emotion: ${last.emotion}, category: ${last.category} ✓`);
}

// ─── Test 5: TRANSITION + Low Entropy → Calm/Focus ───────────────────

function testTransitionFocus() {
  console.log("\n📖 Test 5: TRANSITION + Low Entropy → Minor + Calm");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim);

  emitEDEvent(sim, "TRANSITION", {
    avalanche: 0.1, sync: 0.1, structureDrift: 0.1,
    entropy: 0.15, branching: 0.9, miDrift: 0.5,
    activeCount: 3, totalNodes: 10, totalEdges: 5
  });

  const last = engine.getLastEvent();
  assert(last.emotion === EmotionTag.CALM, `Emotion sollte CALM sein, got ${last.emotion}`);
  console.log(`  → "${last.text}"`);
  console.log(`  → emotion: ${last.emotion} ✓`);
}

// ─── Test 6: EventBus story:event wird gefeuert ──────────────────────

function testEventBus() {
  console.log("\n📖 Test 6: EventBus — story:event und story:milestone werden gefeuert");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim);

  let storyEvents = 0;
  let milestoneEvents = 0;
  sim.events.on("story:event", () => storyEvents++);
  sim.events.on("story:milestone", () => milestoneEvents++);

  emitEDEvent(sim, "CRITICAL_SPIKE", {
    avalanche: 0.8, sync: 0.85, structureDrift: 0.1,
    entropy: 0.5, branching: 1.0, miDrift: 0.5,
    activeCount: 10, totalNodes: 10, totalEdges: 5
  });

  assert(storyEvents === 1, `Sollte 1 story:event feuern, got ${storyEvents}`);
  assert(milestoneEvents === 1, `Sollte 1 story:milestone feuern, got ${milestoneEvents}`);
  console.log(`  → story events: ${storyEvents}, milestones: ${milestoneEvents} ✓`);
}

// ─── Test 7: Timeline wächst und wird begrenzt ───────────────────────

function testTimelineGrowth() {
  console.log("\n📖 Test 7: Timeline — wächst und wird auf maxEvents begrenzt");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim, { maxEvents: 5 });

  for (let i = 0; i < 8; i++) {
    sim.world.age = 100 + i * 2;
    emitEDEvent(sim, "TRANSITION", {
      avalanche: 0.4, sync: 0.2, structureDrift: 0.3,
      entropy: 0.6, branching: 1.1, miDrift: 0.3,
      activeCount: 7, totalNodes: 10, totalEdges: 5
    });
  }

  assert(engine.timeline.length === 5, `Timeline sollte auf 5 begrenzt sein, got ${engine.timeline.length}`);
  console.log(`  → timeline length: ${engine.timeline.length} (max: 5) ✓`);
}

// ─── Test 8: Variation — keine unmittelbare Template-Wiederholung ────

function testVariation() {
  console.log("\n📖 Test 8: Variation — aufeinanderfolgende Events nutzen unterschiedliche Templates");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, 0));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim);

  const texts = [];
  for (let i = 0; i < 3; i++) {
    sim.world.age = 100 + i * 5;
    emitEDEvent(sim, "CRITICAL_SPIKE", {
      avalanche: 0.8, sync: 0.85, structureDrift: 0.1,
      entropy: 0.5, branching: 1.0, miDrift: 0.5,
      activeCount: 10, totalNodes: 10, totalEdges: 5
    });
    texts.push(engine.getLastEvent().text);
  }

  // Mindestens zwei unterschiedliche Texte
  const unique = new Set(texts);
  assert(unique.size >= 2, `Sollte mindestens 2 unterschiedliche Texte haben, got ${unique.size} unique von ${texts.length}`);
  console.log(`  → ${unique.size} unique texts von ${texts.length} events ✓`);
  for (const t of texts) console.log(`    "${t}"`);
}

// ─── Test 9: Chapter-Generierung ─────────────────────────────────────

function testChapters() {
  console.log("\n📖 Test 9: Chapters — Timeline wird in emotionale Phasen geteilt");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim);

  // Erste Phase: Calm
  sim.world.age = 100;
  emitEDEvent(sim, "TRANSITION", {
    avalanche: 0.1, sync: 0.1, structureDrift: 0.1,
    entropy: 0.15, branching: 0.9, miDrift: 0.5,
    activeCount: 3, totalNodes: 10, totalEdges: 5
  });

  // Zweite Phase: Tension
  sim.world.age = 110;
  emitEDEvent(sim, "TRANSITION", {
    avalanche: 0.7, sync: 0.1, structureDrift: 0.1,
    entropy: 0.5, branching: 1.1, miDrift: 0.4,
    activeCount: 8, totalNodes: 10, totalEdges: 5
  });
  sim.world.age = 115;
  emitEDEvent(sim, "TRANSITION", {
    avalanche: 0.7, sync: 0.1, structureDrift: 0.1,
    entropy: 0.5, branching: 1.1, miDrift: 0.4,
    activeCount: 8, totalNodes: 10, totalEdges: 5
  });

  const chapters = engine.getChapters();
  assert(chapters.length >= 2, `Sollte mindestens 2 Chapter haben, got ${chapters.length}`);
  assert(chapters[0].emotion !== chapters[1].emotion, "Chapter sollten unterschiedliche Emotionen haben");
  console.log(`  → ${chapters.length} chapters:`);
  for (const ch of chapters) {
    console.log(`    [${ch.startAge.toFixed(0)}–${ch.endAge.toFixed(0)}s] ${ch.emotion} (${ch.eventCount} events)`);
  }
  console.log(`  ✓`);
}

// ─── Test 10: Emotional Balance ──────────────────────────────────────

function testEmotionalBalance() {
  console.log("\n📖 Test 10: Emotional Balance — dominante Emotion wird erkannt");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim);

  // 3x Calm, 1x Tension
  for (let i = 0; i < 3; i++) {
    sim.world.age = 100 + i * 5;
    emitEDEvent(sim, "TRANSITION", {
      avalanche: 0.1, sync: 0.1, structureDrift: 0.1,
      entropy: 0.15, branching: 0.9, miDrift: 0.5,
      activeCount: 3, totalNodes: 10, totalEdges: 5
    });
  }
  sim.world.age = 120;
  emitEDEvent(sim, "TRANSITION", {
    avalanche: 0.7, sync: 0.1, structureDrift: 0.1,
    entropy: 0.5, branching: 1.1, miDrift: 0.4,
    activeCount: 8, totalNodes: 10, totalEdges: 5
  });

  const balance = engine.getEmotionalBalance();
  assert(balance.total === 4, `Total sollte 4 sein, got ${balance.total}`);
  assert(balance.dominant === EmotionTag.CALM, `Dominant sollte CALM sein (3 von 4), got ${balance.dominant}`);
  console.log(`  → dominant: ${balance.dominant}, total: ${balance.total}, distribution: ${JSON.stringify(balance.distribution)} ✓`);
}

// ─── Test 11: Reset ──────────────────────────────────────────────────

function testReset() {
  console.log("\n📖 Test 11: Reset — Timeline wird geleert");
  const nodes = [];
  for (let i = 0; i < 10; i++) nodes.push(makeNode(i, 0.5, i * 0.3));
  const sim = makeMockSimulation(nodes, [], 100);
  const engine = new StoryMappingEngine(sim);

  emitEDEvent(sim, "TRANSITION", {
    avalanche: 0.4, sync: 0.2, structureDrift: 0.3,
    entropy: 0.6, branching: 1.1, miDrift: 0.3,
    activeCount: 7, totalNodes: 10, totalEdges: 5
  });

  assert(engine.timeline.length > 0, "Timeline sollte Daten haben vor Reset");
  engine.reset();
  assert(engine.timeline.length === 0, "Timeline sollte leer sein nach Reset");
  assert(engine.lastEmotion === null, "lastEmotion sollte null sein nach Reset");
  console.log(`  → Reset erfolgreich ✓`);
}

// ─── Test 12: End-to-End mit EmergenceDetector ───────────────────────

function testEndToEnd() {
  console.log("\n📖 Test 12: End-to-End — EmergenceDetector → StoryMappingEngine");
  const nodes = [];
  for (let i = 0; i < 30; i++) {
    nodes.push(makeNode(i, 0.7, i * 0.05));  // hohe Aktivität, ähnliche Phasen
  }
  const edges = [];
  for (let i = 0; i < 20; i++) {
    edges.push({ a: nodes[i], b: nodes[(i + 1) % 30], birthProgress: 1 });
  }
  const sim = makeMockSimulation(nodes, edges, 5);

  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1, coolDown: 0.1 });
  const story = new StoryMappingEngine(sim);

  // Erste Sample: Baseline
  ed.update(0.2);

  // Zweite Sample: Drastische Strukturänderung
  sim.world.edges = [];
  for (let i = 0; i < 20; i++) {
    sim.world.edges.push({ a: nodes[i], b: nodes[(i + 7) % 30], birthProgress: 1 });
  }
  // Erhöhe Sync
  for (let i = 0; i < 30; i++) nodes[i].phase = 0.1;
  sim.world.age = 5.2;
  ed.update(0.2);

  // Story sollte mindestens ein Event haben (wenn ED detektiert hat)
  if (story.timeline.length > 0) {
    const last = story.getLastEvent();
    assert(last.text !== undefined, "Story-Event sollte Text haben");
    assert(last.emotion !== undefined, "Story-Event sollte Emotion haben");
    assert(last.category !== undefined, "Story-Event sollte Kategorie haben");
    console.log(`  → ${story.timeline.length} story events generiert`);
    console.log(`  → Last: "${last.text}"`);
    console.log(`  → emotion: ${last.emotion}, category: ${last.category} ✓`);
  } else {
    // ED hat vielleicht nicht detektiert (coolDown, threshold) — auch ok
    console.log(`  → Keine Detection in diesem Run (threshold nicht erreicht) — ok ✓`);
  }
}

// ─── Run all tests ───────────────────────────────────────────────────

console.log("═══════════════════════════════════════════════════════════");
console.log("  StoryMappingEngine — Unit Tests");
console.log("═══════════════════════════════════════════════════════════");

testCriticalSpike();
testPhaseShiftStructure();
testPhaseShiftNovelty();
testTransitionAvalanche();
testTransitionFocus();
testEventBus();
testTimelineGrowth();
testVariation();
testChapters();
testEmotionalBalance();
testReset();
testEndToEnd();

console.log("\n═══════════════════════════════════════════════════════════");
console.log(`  Results: ${passed} passed, ${failed} failed`);
console.log("═══════════════════════════════════════════════════════════");

process.exit(failed > 0 ? 1 : 0);
