/**
 * EpochLogWidget — Unit Tests
 *
 * Run: node src/test/test-epoch-log-widget.js
 *
 * Testet:
 *  - Direkte API: addLog, addEpoch (backward compat mit HudPanel)
 *  - EventBus Integration: mount → story:event, story:milestone
 *  - Keyword-Highlighting (Plain-Text vs HTML)
 *  - Sim-Zeit vs Real-Zeit Formatierung
 *  - Limitierung (maxLogs, maxEpochs)
 *  - Lifecycle: pause, resume, reset, destroy
 *  - Badge-Zähler
 */

// ─── Minimal DOM Mock (kein jsdep nötig) ─────────────────────────────

function mockElement(id) {
  const el = {
    id,
    _children: [],
    _innerHTML: '',
    _className: '',
    textContent: '',
    classList: {
      _classes: new Set(),
      add(c) { this._classes.add(c); },
      remove(c) { this._classes.delete(c); },
      contains(c) { return this._classes.has(c); },
      toggle(c) { this._classes.has(c) ? this._classes.delete(c) : this._classes.add(c); }
    },
    get className() { return this._className; },
    set className(v) {
      this._className = v;
      // Sync classList from className string
      this.classList._classes = new Set(v.split(/\s+/).filter(Boolean));
    },
    get innerHTML() { return this._innerHTML; },
    set innerHTML(v) {
      this._innerHTML = v;
      if (v === '') this._children = [];
    },
    querySelectorAll(sel) {
      if (sel.startsWith('.')) {
        const cls = sel.slice(1).split(':')[0]; // strip pseudo-selectors
        return this._children.filter(c => c.classList.contains(cls));
      }
      return [];
    },
    querySelector(sel) {
      if (sel.startsWith('.')) {
        const cls = sel.slice(1).split(':')[0];
        return this._children.find(c => c.classList.contains(cls)) || null;
      }
      return null;
    },
    prepend(child) {
      child._parent = this;
      this._children.unshift(child);
    },
    appendChild(child) {
      child._parent = this;
      this._children.push(child);
    },
    removeChild(child) {
      const idx = this._children.indexOf(child);
      if (idx >= 0) this._children.splice(idx, 1);
      return child;
    },
    get children() { return this._children; },
    get firstChild() { return this._children[0] || null; },
    get lastChild() { return this._children[this._children.length - 1] || null; },
    scrollTop: 0,
    get scrollHeight() { return this._children.length * 20; }
  };
  return el;
}

function mockDocument() {
  const elements = {};
  return {
    getElementById(id) {
      if (!elements[id]) elements[id] = mockElement(id);
      return elements[id];
    },
    createElement(tag) {
      return mockElement(tag);
    },
    _elements: elements
  };
}

// ─── EventBus Mock ───────────────────────────────────────────────────

function mockEventBus() {
  const listeners = new Map();
  return {
    on(event, cb) {
      if (!listeners.has(event)) listeners.set(event, new Set());
      listeners.get(event).add(cb);
      return () => listeners.get(event)?.delete(cb);
    },
    emit(event, data) {
      const set = listeners.get(event);
      if (set) for (const cb of set) cb(data);
    },
    _listeners: listeners
  };
}

// ─── Test Harness ────────────────────────────────────────────────────

let passed = 0, failed = 0;

function assert(condition, message) {
  if (condition) { passed++; }
  else { failed++; console.error(`  ❌ FAIL: ${message}`); }
}

// ─── Tests ───────────────────────────────────────────────────────────

// Mock document globally
globalThis.document = mockDocument();

import { EpochLogWidget } from "../widgets/EpochLogWidget.js";

// Test 1: Constructor mit DOM IDs
function testConstructor() {
  console.log("\n📐 Test 1: Constructor — DOM IDs werden aufgelöst");
  const w = new EpochLogWidget('logFeed', 'epochLog', 'logCountBadge');
  assert(w.feedContainer !== null, "feedContainer sollte nicht null sein");
  assert(w.epochContainer !== null, "epochContainer sollte nicht null sein");
  assert(w.badge !== null, "badge sollte nicht null sein");
  assert(w.totalEvents === 0, "totalEvents sollte 0 sein");
  console.log("  → Widget initialisiert ✓");
}

// Test 2: addLog mit HTML (backward compat)
function testAddLogHtml() {
  console.log("\n📐 Test 2: addLog mit HTML — kein doppeltes Highlighting");
  const w = new EpochLogWidget('logFeed2', 'epochLog2', 'logCountBadge2');
  w.addLog('<span class="log-hl-pulse">IMPULS:</span> Signal injiziert.', 42.5);

  assert(w.feedContainer.children.length === 1, "Sollte 1 Log-Eintrag haben");
  assert(w.totalEvents === 1, "totalEvents sollte 1 sein");

  const item = w.feedContainer.children[0];
  assert(item.classList.contains('newest'), "Item sollte 'newest' Klasse haben");
  assert(item.innerHTML.includes('IMPULS'), "HTML sollte erhalten bleiben");
  // Da bereits HTML → kein doppeltes Highlighting
  assert(!item.innerHTML.includes('<span class="log-hl-pulse"><span'), "Sollte nicht doppelt highlighten");
  console.log(`  → Log hinzugefügt, HTML erhalten, Sim-Zeit: [00:42] ✓`);
}

// Test 3: addLog mit Plain-Text → Highlighting
function testAddLogPlainText() {
  console.log("\n📐 Test 3: addLog mit Plain-Text → Keyword-Highlighting");
  const w = new EpochLogWidget('logFeed3', 'epochLog3', 'logCountBadge3');
  w.addLog('Eine neue Verbindung entsteht im Netzwerk.', 10);

  const item = w.feedContainer.children[0];
  assert(item.innerHTML.includes('<span class="log-hl-synapse">Verbindung</span>'), "Verbindung sollte gehighlightet sein");
  assert(item.innerHTML.includes('<span class="log-hl-stage">Netzwerk</span>'), "Netzwerk sollte gehighlightet sein");
  console.log(`  → Plain-Text gehighlightet ✓`);
}

// Test 4: addEpoch
function testAddEpoch() {
  console.log("\n📐 Test 4: addEpoch — Timeline-Eintrag");
  const w = new EpochLogWidget('logFeed4', 'epochLog4', 'logCountBadge4');
  w.addEpoch("Genesis", "Netzwerk initialisiert", "milestone", 5);

  assert(w.epochContainer.children.length === 1, "Sollte 1 Epoch-Eintrag haben");
  const entry = w.epochContainer.children[0];
  assert(entry.classList.contains('epoch-entry--latest'), "Sollte 'latest' Klasse haben");
  assert(entry.innerHTML.includes('epoch-node--milestone'), "Sollte milestone node sein");
  assert(entry.innerHTML.includes('Genesis'), "Sollte Label enthalten");
  console.log(`  → Epoch mit milestone-Typ hinzugefügt ✓`);
}

// Test 5: addEpoch mit boolean type (backward compat)
function testAddEpochBoolean() {
  console.log("\n📐 Test 5: addEpoch mit boolean type — backward compat");
  const w = new EpochLogWidget('logFeed5', 'epochLog5', 'logCountBadge5');
  w.addEpoch("Event", "Beschreibung", true, 20);
  const entry = w.epochContainer.children[0];
  assert(entry.innerHTML.includes('epoch-node--milestone'), "true sollte als milestone interpretiert werden");

  w.addEpoch("Event2", "Beschreibung2", false, 25);
  const entry2 = w.epochContainer.children[1];
  assert(entry2.innerHTML.includes('epoch-node--event'), "false sollte als event interpretiert werden");
  console.log(`  → Boolean type korrekt konvertiert ✓`);
}

// Test 6: EventBus Integration — story:event
function testStoryEvent() {
  console.log("\n📐 Test 6: EventBus — story:event wird im Feed angezeigt");
  const bus = mockEventBus();
  const w = new EpochLogWidget('logFeed6', 'epochLog6', 'logCountBadge6');
  w.mount(bus);

  bus.emit('story:event', {
    text: 'Ein Moment der Klarheit. AURORA spürt sich selbst.',
    emotion: 'awakening',
    timestamp: 137,
    category: 'milestone'
  });

  assert(w.feedContainer.children.length === 1, "Sollte 1 Log-Eintrag haben");
  const item = w.feedContainer.children[0];
  assert(item.innerHTML.includes('ERWACHEN'), "Sollte Emotion-Label 'ERWACHEN' haben");
  assert(item.innerHTML.includes('AURORA'), "Sollte Netzwerknamen enthalten");
  assert(item.innerHTML.includes('log-hl-story'), "Sollte Story-Highlight-Klasse haben");
  console.log(`  → story:event im Feed: "ERWACHEN ... AURORA spürt sich selbst" ✓`);
}

// Test 7: EventBus Integration — story:milestone
function testStoryMilestone() {
  console.log("\n📐 Test 7: EventBus — story:milestone wird in Timeline angezeigt");
  const bus = mockEventBus();
  const w = new EpochLogWidget('logFeed7', 'epochLog7', 'logCountBadge7');
  w.mount(bus);

  bus.emit('story:milestone', {
    text: 'Die Regionen atmen gemeinsam. Ein Bewusstseinsmoment.',
    emotion: 'awakening',
    timestamp: 200,
    category: 'milestone'
  });

  assert(w.epochContainer.children.length === 1, "Sollte 1 Epoch-Eintrag haben");
  const entry = w.epochContainer.children[0];
  assert(entry.innerHTML.includes('epoch-node--milestone'), "Sollte milestone node sein");
  console.log(`  → story:milestone in Timeline ✓`);
}

// Test 8: Limitierung maxLogs
function testMaxLogs() {
  console.log("\n📐 Test 8: Limitierung — maxLogs wird eingehalten");
  const w = new EpochLogWidget('logFeed8', 'epochLog8', 'logCountBadge8');
  w.maxLogs = 5;

  for (let i = 0; i < 10; i++) {
    w.addLog(`Log ${i}`, i * 10);
  }

  assert(w.feedContainer.children.length === 5, `Sollte auf 5 begrenzt sein, got ${w.feedContainer.children.length}`);
  console.log(`  → ${w.feedContainer.children.length} Einträge (max 5) ✓`);
}

// Test 9: Pause/Resume
function testPauseResume() {
  console.log("\n📐 Test 9: Pause/Resume — pausiertes Widget ignoriert Events");
  const w = new EpochLogWidget('logFeed9', 'epochLog9', 'logCountBadge9');

  w.pause();
  w.addLog("Sollte ignoriert werden", 1);
  assert(w.feedContainer.children.length === 0, "Pausesiertes Widget sollte nichts hinzufügen");

  w.resume();
  w.addLog("Sollte hinzugefügt werden", 2);
  assert(w.feedContainer.children.length === 1, "Nach resume sollte hinzugefügt werden");
  console.log(`  → Pause/Resume funktioniert ✓`);
}

// Test 10: Reset
function testReset() {
  console.log("\n📐 Test 10: Reset — alle Einträge gelöscht");
  const w = new EpochLogWidget('logFeed10', 'epochLog10', 'logCountBadge10');
  w.addLog("Test", 1);
  w.addEpoch("Test", "Detail", "milestone", 2);

  w.reset();

  assert(w.feedContainer.children.length === 0, "Feed sollte leer sein");
  assert(w.epochContainer.children.length === 0, "Timeline sollte leer sein");
  assert(w.totalEvents === 0, "totalEvents sollte 0 sein");
  console.log(`  → Reset erfolgreich ✓`);
}

// Test 11: Destroy — EventBus-Listener abgemeldet
function testDestroy() {
  console.log("\n📐 Test 11: Destroy — EventBus-Listener werden abgemeldet");
  const bus = mockEventBus();
  const w = new EpochLogWidget('logFeed11', 'epochLog11', 'logCountBadge11');
  w.mount(bus);

  // Vorher: Events kommen durch
  bus.emit('story:event', { text: 'Test', emotion: 'calm', timestamp: 1 });
  assert(w.feedContainer.children.length === 1, "Vor destroy: Event sollte ankommen");

  w.destroy();

  // Nachher: Events kommen nicht mehr durch
  bus.emit('story:event', { text: 'Test2', emotion: 'calm', timestamp: 2 });
  assert(w.feedContainer.children.length === 0, "Nach destroy: Feed sollte leer sein (reset)");
  assert(!bus._listeners.get('story:event') || bus._listeners.get('story:event').size === 0, "Listener sollte abgemeldet sein");
  console.log(`  → Destroy erfolgreich, Listener abgemeldet ✓`);
}

// Test 12: Badge-Zähler
function testBadge() {
  console.log("\n📐 Test 12: Badge — Zähler inkrementiert korrekt");
  const w = new EpochLogWidget('logFeed12', 'epochLog12', 'logCountBadge12');

  w.addLog("Log 1", 1);
  w.addLog("Log 2", 2);
  w.addEpoch("Epoch", "Detail", "milestone", 3);

  assert(w.totalEvents === 3, `totalEvents sollte 3 sein, got ${w.totalEvents}`);
  assert(w.badge.textContent === '3', `Badge sollte '3' zeigen, got '${w.badge.textContent}'`);

  w.reset();
  assert(w.badge.textContent === '0', "Badge sollte nach reset '0' zeigen");
  console.log(`  → Badge: ${w.badge.textContent} (vorher 3) ✓`);
}

// Test 13: total getter (backward compat)
function testTotalGetter() {
  console.log("\n📐 Test 13: total getter — backward compat mit HudPanel");
  const w = new EpochLogWidget('logFeed13', 'epochLog13', 'logCountBadge13');
  w.addLog("Test", 1);
  assert(w.total === 1, `total sollte 1 sein, got ${w.total}`);
  console.log(`  → total: ${w.total} ✓`);
}

// ─── Run all tests ───────────────────────────────────────────────────

console.log("═══════════════════════════════════════════════════════════");
console.log("  EpochLogWidget — Unit Tests");
console.log("═══════════════════════════════════════════════════════════");

testConstructor();
testAddLogHtml();
testAddLogPlainText();
testAddEpoch();
testAddEpochBoolean();
testStoryEvent();
testStoryMilestone();
testMaxLogs();
testPauseResume();
testReset();
testDestroy();
testBadge();
testTotalGetter();

console.log("\n═══════════════════════════════════════════════════════════");
console.log(`  Results: ${passed} passed, ${failed} failed`);
console.log("═══════════════════════════════════════════════════════════");

process.exit(failed > 0 ? 1 : 0);
