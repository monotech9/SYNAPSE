/**
 * SleepCycle — Unit Tests
 *
 * Run: node src/test/test-sleep-cycle.js
 *
 * Testet:
 *  - Constructor / Initial State
 *  - WAKE → Sleep Trigger (Energie, Zyklus, Mood)
 *  - NREM: Replay (Hebbian Reinforcement), Downscaling, Fatigue Restore
 *  - REM: Generatives Replay, Dream Walks, Creative Links
 *  - WAKING_UP: Drift Calculation, Identity Correction
 *  - Personality-Modulation
 *  - Events: stateChange, nremReplay, remDream, wakeUp, tick
 *  - Force Sleep / Force Wake
 *  - Snapshot API
 *  - Reset
 */

import { SleepCycle, SleepState } from "../simulation/systems/SleepCycle.js";
import { EventBus } from "../simulation/EventBus.js";

let passed = 0, failed = 0;

function assert(condition, message) {
  if (condition) { passed++; }
  else { failed++; console.error(`  ❌ FAIL: ${message}`); }
}

// ─── Mock Simulation ─────────────────────────────────────────────────

function makeMockSimulation(opts = {}) {
  const events = new EventBus();

  // Mock Clusters
  const clusters = opts.clusters || [
    { id: "c1", state: "active", activityMemory: 0.3, nodes: [{ cluster: null }], center: () => ({x:0,y:0}) },
    { id: "c2", state: "active", activityMemory: 0.4, nodes: [{ cluster: null }], center: () => ({x:1,y:0}) },
    { id: "c3", state: "active", activityMemory: 0.2, nodes: [{ cluster: null }], center: () => ({x:0,y:1}) }
  ];

  // Mock Nodes (need cluster reference)
  const nodes = [];
  for (let i = 0; i < 6; i++) {
    nodes.push({
      activation: 0.1,
      charge: 0.1,
      cluster: clusters[i % clusters.length],
      setActivation(v) { this.activation = Math.max(this.activation, v); }
    });
  }
  clusters.forEach((c, i) => { c.nodes = [nodes[i], nodes[i + 3]]; });

  // Mock Edges
  const edges = opts.edges || [
    { a: nodes[0], b: nodes[1], weight: 0.5, identityTrace: 0.3, bridge: false, fatigue: 0.6, fatigueGlow: 0.5, traceAge: 5 },
    { a: nodes[1], b: nodes[2], weight: 0.4, identityTrace: 0.2, bridge: false, fatigue: 0.3, fatigueGlow: 0.3, traceAge: 3 },
    { a: nodes[2], b: nodes[3], weight: 0.6, identityTrace: 0.5, bridge: false, fatigue: 0.2, fatigueGlow: 0.2, traceAge: 10 },
    { a: nodes[3], b: nodes[4], weight: 0.3, identityTrace: 0.1, bridge: false, fatigue: 0.8, fatigueGlow: 0.7, traceAge: 2 },
    { a: nodes[0], b: nodes[4], weight: 0.7, identityTrace: 0.8, bridge: true, fatigue: 0.1, fatigueGlow: 0.1, traceAge: 20 }
  ];

  // Mock Personality
  const personality = opts.personality || {
    curiosity: 0.5, caution: 0.5, resilience: 0.5,
    rhythm: 0.5, sensitivity: 0.5, plasticity: 0.5,
    attachment: 0.5, volatility: 0.5
  };

  // Mock EmotionEngine
  const emotionEngine = opts.emotionEngine || {
    mood: 0,
    getSnapshot: () => ({ emotions: {}, dominant: { emotion: "calm" }, mood: 0, modulation: {}, reward: {}, history: [] })
  };

  const world = {
    age: opts.age || 10,
    clusters,
    edges,
    nodes,
    scars: opts.scars || [],
    memory: { clusterPairActivity: {} }
  };

  return {
    events, world, personality, emotionEngine,
    totalNodeCount: () => opts.totalNodes || nodes.length,
    rng: { range: (a, b) => a + Math.random() * (b - a) }
  };
}

// ─── Test 1: Constructor ────────────────────────────────────────────

function testConstructor() {
  console.log("\n🌙 Test 1: Constructor — Initial State WAKE");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);

  assert(cycle.state === SleepState.WAKE, `State sollte WAKE sein, got ${cycle.state}`);
  assert(cycle._sleepCount === 0, "sleepCount sollte 0 sein");
  assert(cycle._totalSleepTime === 0, "totalSleepTime sollte 0 sein");
  assert(!cycle.isSleeping(), "isSleeping sollte false sein");
  console.log(`  → State: ${cycle.state}, sleepCount: ${cycle._sleepCount} ✓`);
}

// ─── Test 2: Sleep Trigger — Low Energy ─────────────────────────────

function testSleepTriggerEnergy() {
  console.log("\n🌙 Test 2: Sleep Trigger — niedrige Energie");
  const sim = makeMockSimulation({
    clusters: [
      { id: "c1", state: "active", activityMemory: 0.05, nodes: [], center: () => ({x:0,y:0}) }
    ]
  });
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;  // Sofortiger Schlaf möglich
  cycle.config.cycleInterval = 999;  // Zyklus nicht relevant

  let stateChanges = 0;
  sim.events.on("sleep:stateChange", () => stateChanges++);

  cycle.update(0.1);

  assert(cycle.state === SleepState.NREM, `Sollte NREM sein nach low energy trigger, got ${cycle.state}`);
  assert(stateChanges === 1, `Sollte 1 stateChange event haben, got ${stateChanges}`);
  console.log(`  → State: ${cycle.state}, events: ${stateChanges} ✓`);
}

// ─── Test 3: Sleep Trigger — Cycle Interval ─────────────────────────

function testSleepTriggerCycle() {
  console.log("\n🌙 Test 3: Sleep Trigger — Zyklus-Intervall erreicht");
  const sim = makeMockSimulation({
    clusters: [
      { id: "c1", state: "active", activityMemory: 0.8, nodes: [], center: () => ({x:0,y:0}) }
    ]
  });
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.cycleInterval = 2;  // Kurzes Intervall
  cycle.config.energyThreshold = 0;  // Energie nicht als Trigger

  cycle.update(1.0);  // Noch nicht Zyklus bereit
  assert(cycle.state === SleepState.WAKE, "Sollte noch WAKE sein vor Zyklus");

  cycle.update(1.5);  // Zyklus erreicht (1.0 + 1.5 = 2.5 > 2)
  assert(cycle.state === SleepState.NREM, `Sollte NREM sein nach Zyklus, got ${cycle.state}`);
  console.log(`  → State nach 2.5s: ${cycle.state} ✓`);
}

// ─── Test 4: NREM Replay — Hebbian Reinforcement ────────────────────

function testNremReplay() {
  console.log("\n🌙 Test 4: NREM Replay — identityTrace wird verstärkt");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 2;
  cycle.config.nremReplayCount = 5;

  const traceBefore = sim.world.edges[0].identityTrace;
  const weightBefore = sim.world.edges[0].weight;

  cycle.update(0.1);  // Enter Sleep
  cycle.update(2.0);  // NREM ablaufen lassen

  // Mindestens eine Kante sollte verstärkt worden sein
  const totalTraceAfter = sim.world.edges.reduce((s, e) => s + e.identityTrace, 0);
  const totalTraceBefore = 0.3 + 0.2 + 0.5 + 0.1 + 0.8; // Original values
  assert(totalTraceAfter > totalTraceBefore,
    `Total identityTrace sollte steigen: ${totalTraceBefore.toFixed(3)} → ${totalTraceAfter.toFixed(3)}`);
  assert(cycle._dream.nremReinforced > 0, `nremReinforced sollte > 0 sein, got ${cycle._dream.nremReinforced}`);
  console.log(`  → Trace total: ${totalTraceBefore.toFixed(2)} → ${totalTraceAfter.toFixed(2)}, reinforced: ${cycle._dream.nremReinforced} ✓`);
}

// ─── Test 5: NREM Synaptic Downscaling ──────────────────────────────

function testDownscaling() {
  console.log("\n🌙 Test 5: NREM Synaptic Downscaling — non-bridge Gewichte sinken");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 2;

  // Non-bridge edge weights vor dem Schlaf
  const nonBridgeBefore = sim.world.edges.filter(e => !e.bridge).map(e => e.weight);
  const bridgeBefore = sim.world.edges.filter(e => e.bridge).map(e => e.weight);

  cycle.update(0.1);  // Enter Sleep
  cycle.update(2.0);  // NREM (triggert downscaling in der 2. Hälfte)

  const nonBridgeAfter = sim.world.edges.filter(e => !e.bridge).map(e => e.weight);
  const bridgeAfter = sim.world.edges.filter(e => e.bridge).map(e => e.weight);

  // Downscaling sollte auf non-bridge angewendet worden sein (Replay verstärkt auch,
  // aber downscaling reduziert — wir prüfen dass downscaling ausgeführt wurde)
  assert(cycle._dream.nremDownscaled > 0, `nremDownscaled sollte > 0 sein, got ${cycle._dream.nremDownscaled}`);
  // Mindestens eine non-bridge Kante sollte reduziert worden sein
  let reduced = 0;
  for (let i = 0; i < nonBridgeBefore.length; i++) {
    if (nonBridgeAfter[i] < nonBridgeBefore[i]) reduced++;
  }
  assert(reduced > 0, `Mindestens 1 non-bridge weight sollte sinken, got ${reduced}`);

  // Bridge should NOT change
  assert(bridgeAfter[0] === bridgeBefore[0], `Bridge weight sollte unverändert sein: ${bridgeBefore[0]} → ${bridgeAfter[0]}`);
  assert(cycle._dream.nremDownscaled > 0, `nremDownscaled sollte > 0 sein`);
  console.log(`  → Downscaled: ${cycle._dream.nremDownscaled} edges, reduced: ${reduced}, bridge unchanged ✓`);
}

// ─── Test 6: NREM Fatigue Restore ───────────────────────────────────

function testFatigueRestore() {
  console.log("\n🌙 Test 6: NREM Fatigue Restore — Fatigue wird abgebaut");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 4;
  cycle.config.nremFatigueRestore = 0.9;

  const fatigueBefore = sim.world.edges[0].fatigue;
  assert(fatigueBefore > 0.3, `Fatigue sollte > 0.3 sein vor Schlaf, got ${fatigueBefore}`);

  cycle.update(0.1);  // Enter Sleep
  cycle.update(4.0);  // NREM voll durchlaufen

  const fatigueAfter = sim.world.edges[0].fatigue;
  assert(fatigueAfter < fatigueBefore, `Fatigue sollte sinken: ${fatigueBefore.toFixed(3)} → ${fatigueAfter.toFixed(3)}`);
  console.log(`  → Fatigue: ${fatigueBefore.toFixed(3)} → ${fatigueAfter.toFixed(3)} ✓`);
}

// ─── Test 7: REM Dream Walks ────────────────────────────────────────

function testRemDreamWalks() {
  console.log("\n🌙 Test 7: REM Dream Walks — Traum-Sequenzen werden generiert");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 1;
  cycle.config.remDuration = 2;
  cycle.config.remWalkSteps = 6;

  let dreamEvents = 0;
  sim.events.on("sleep:remDream", () => dreamEvents++);

  cycle.update(0.1);  // Enter Sleep (NREM)
  cycle.update(1.0);  // NREM done → REM
  cycle.update(2.0);  // REM ablaufen lassen

  assert(dreamEvents > 0, `Sollte dream events haben, got ${dreamEvents}`);
  assert(cycle._dream.remDreams.length >= 0, "remDreams sollte existieren");
  assert(cycle.state === SleepState.WAKING_UP || cycle.state === SleepState.WAKE,
    `Sollte WAKING_UP oder WAKE sein nach REM, got ${cycle.state}`);
  console.log(`  → Dream events: ${dreamEvents}, state: ${cycle.state} ✓`);
}

// ─── Test 8: REM Creative Dreams ────────────────────────────────────

function testRemCreativeLinks() {
  console.log("\n🌙 Test 8: REM Creative Dreams — neue Verbindungen werden gebildet");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 0.5;
  cycle.config.remDuration = 5;  // Länger für mehr Dreams
  cycle.config.remWalkSteps = 20;
  cycle.config.remNewLinkProb = 0.8;  // Hohe Wahrscheinlichkeit
  cycle.config.remCreativeThreshold = 0.3;  // Niedrige Schwelle

  const pairActivityBefore = Object.keys(sim.world.memory.clusterPairActivity).length;

  cycle.update(0.1);  // Enter Sleep
  cycle.update(0.5);  // NREM
  cycle.update(5.0);  // REM

  const pairActivityAfter = Object.keys(sim.world.memory.clusterPairActivity).length;
  assert(pairActivityAfter > pairActivityBefore || cycle._dream.remNewConnections > 0,
    `Sollte neue clusterPairActivity oder newConnections haben: pairs ${pairActivityBefore}→${pairActivityAfter}, connections ${cycle._dream.remNewConnections}`);
  console.log(`  → PairActivity: ${pairActivityBefore} → ${pairActivityAfter}, newConnections: ${cycle._dream.remNewConnections} ✓`);
}

// ─── Test 9: Wake-Up Drift Calculation ──────────────────────────────

function testDriftCalculation() {
  console.log("\n🌙 Test 9: Wake-Up — Drift wird berechnet");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 1;
  cycle.config.remDuration = 1;
  cycle.config.wakeUpDuration = 1;

  let wakeUpEvent = null;
  sim.events.on("sleep:wakeUp", (d) => wakeUpEvent = d);

  cycle.update(0.1);  // Enter Sleep
  cycle.update(1.0);  // NREM
  cycle.update(1.0);  // REM
  cycle.update(1.0);  // WAKING_UP → WAKE

  assert(wakeUpEvent !== null, "Sollte wakeUp event haben");
  assert(typeof wakeUpEvent.drift === "number", `Drift sollte number sein, got ${typeof wakeUpEvent.drift}`);
  assert(wakeUpEvent.drift >= 0 && wakeUpEvent.drift <= 1, `Drift sollte 0-1 sein, got ${wakeUpEvent.drift}`);
  assert(typeof wakeUpEvent.consolidated === "number", "Consolidated sollte number sein");
  assert(typeof wakeUpEvent.identityStable === "boolean", "identityStable sollte boolean sein");
  console.log(`  → Drift: ${wakeUpEvent.drift.toFixed(3)}, consolidated: ${wakeUpEvent.consolidated}, stable: ${wakeUpEvent.identityStable} ✓`);
}

// ─── Test 10: Full Cycle WAKE → NREM → REM → WAKE ──────────────────

function testFullCycle() {
  console.log("\n🌙 Test 10: Full Cycle — WAKE → NREM → REM → WAKING_UP → WAKE");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 1;
  cycle.config.remDuration = 1;
  cycle.config.wakeUpDuration = 1;

  const states = [];
  sim.events.on("sleep:stateChange", (d) => states.push(d.to));

  assert(cycle.state === SleepState.WAKE, "Sollte WAKE starten");

  cycle.update(0.1);  // → NREM
  assert(cycle.state === SleepState.NREM, `Sollte NREM sein, got ${cycle.state}`);

  cycle.update(1.0);  // → REM
  assert(cycle.state === SleepState.REM, `Sollte REM sein, got ${cycle.state}`);

  cycle.update(1.0);  // → WAKING_UP
  assert(cycle.state === SleepState.WAKING_UP, `Sollte WAKING_UP sein, got ${cycle.state}`);

  cycle.update(1.0);  // → WAKE
  assert(cycle.state === SleepState.WAKE, `Sollte WAKE sein, got ${cycle.state}`);

  assert(states.length >= 4, `Sollte mindestens 4 state changes haben, got ${states.length}`);
  assert(states[0] === SleepState.NREM, "Erster Wechsel → NREM");
  assert(states[1] === SleepState.REM, "Zweiter Wechsel → REM");
  assert(states.includes(SleepState.WAKING_UP), "Sollte WAKING_UP in states haben");
  assert(states[states.length - 1] === SleepState.WAKE, "Letzter Wechsel → WAKE");
  assert(cycle._sleepCount === 1, `sleepCount sollte 1 sein, got ${cycle._sleepCount}`);
  console.log(`  → States: ${states.join(" → ")}, sleepCount: ${cycle._sleepCount} ✓`);
}

// ─── Test 11: Personality Modulation ────────────────────────────────

function testPersonalityModulation() {
  console.log("\n🌙 Test 11: Personality Modulation — Parameter werden angepasst");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);

  const originalReinforce = cycle.config.nremReinforceAmount;
  const originalRemProb = cycle.config.remNewLinkProb;

  sim.events.emit("personality:drift", {
    resilience: 0.9,
    volatility: 0.8,
    sensitivity: 0.2
  });

  // Resilience 0.9 → mehr reinforcement
  assert(cycle.config.nremReinforceAmount > originalReinforce,
    `nremReinforceAmount sollte steigen: ${originalReinforce} → ${cycle.config.nremReinforceAmount}`);
  // Volatility 0.8 → mehr REM links
  assert(cycle.config.remNewLinkProb > originalRemProb,
    `remNewLinkProb sollte steigen: ${originalRemProb} → ${cycle.config.remNewLinkProb}`);
  // Sensitivity 0.2 → höhere energy threshold (weniger sensibel = höhere Schwelle)
  // 0.25 - 0.2 * 0.15 = 0.22, original was 0.15
  assert(cycle.config.energyThreshold > 0.15,
    `energyThreshold sollte steigen bei low sensitivity: ${cycle.config.energyThreshold}`);
  console.log(`  → Reinforce: ${originalReinforce.toFixed(3)} → ${cycle.config.nremReinforceAmount.toFixed(3)}, ` +
    `REM prob: ${originalRemProb.toFixed(3)} → ${cycle.config.remNewLinkProb.toFixed(3)} ✓`);
}

// ─── Test 12: Mood Accelerates Sleep ────────────────────────────────

function testMoodSleep() {
  console.log("\n🌙 Test 12: Negativer Mood beschleunigt Schlaf-Bereitschaft");
  const sim = makeMockSimulation({
    clusters: [
      { id: "c1", state: "active", activityMemory: 0.3, nodes: [], center: () => ({x:0,y:0}) }
    ],
    emotionEngine: {
      mood: -0.5,  // Negativer Mood
      getSnapshot: () => ({ mood: -0.5 })
    }
  });
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.cycleInterval = 999;
  cycle.config.energyThreshold = 0.25;  // Energie ist 0.3, also normalerweise kein Schlaf

  // Mit mood -0.5: effective threshold = 0.25 + 0.5 * 0.3 = 0.4 → 0.3 < 0.4 → Schlaf!
  cycle.update(0.1);

  assert(cycle.state === SleepState.NREM, `Negativer Mood sollte Schlaf triggern, got ${cycle.state}`);
  console.log(`  → State: ${cycle.state} (mood: -0.5, energy: 0.3, threshold: 0.25+0.15=0.40) ✓`);
}

// ─── Test 13: Events ────────────────────────────────────────────────

function testEvents() {
  console.log("\n🌙 Test 13: Events — tick, stateChange, nremReplay, remDream, wakeUp");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 1;
  cycle.config.remDuration = 1;
  cycle.config.wakeUpDuration = 1;

  const eventTypes = new Set();
  sim.events.on("sleep:tick", () => eventTypes.add("tick"));
  sim.events.on("sleep:stateChange", () => eventTypes.add("stateChange"));
  sim.events.on("sleep:nremReplay", () => eventTypes.add("nremReplay"));
  sim.events.on("sleep:remDream", () => eventTypes.add("remDream"));
  sim.events.on("sleep:wakeUp", () => eventTypes.add("wakeUp"));

  // Full cycle
  cycle.update(0.1);
  cycle.update(1.0);
  cycle.update(1.0);
  cycle.update(1.0);

  assert(eventTypes.has("tick"), "Sollte tick event haben");
  assert(eventTypes.has("stateChange"), "Sollte stateChange event haben");
  assert(eventTypes.has("nremReplay"), "Sollte nremReplay event haben");
  assert(eventTypes.has("remDream"), "Sollte remDream event haben");
  assert(eventTypes.has("wakeUp"), "Sollte wakeUp event haben");
  console.log(`  → Events: ${[...eventTypes].join(", ")} ✓`);
}

// ─── Test 14: Force Sleep / Force Wake ──────────────────────────────

function testForceSleepWake() {
  console.log("\n🌙 Test 14: Force Sleep / Force Wake");
  const sim = makeMockSimulation({
    clusters: [
      { id: "c1", state: "active", activityMemory: 0.9, nodes: [], center: () => ({x:0,y:0}) }
    ]
  });
  const cycle = new SleepCycle(sim);

  assert(cycle.state === SleepState.WAKE, "Sollte WAKE sein");

  const result = cycle.forceSleep();
  assert(result === true, "forceSleep sollte true zurückgeben");
  assert(cycle.state === SleepState.NREM, `Sollte NREM sein nach forceSleep, got ${cycle.state}`);

  const result2 = cycle.forceWake();
  assert(result2 === true, "forceWake sollte true zurückgeben");
  assert(cycle.state === SleepState.WAKE, `Sollte WAKE sein nach forceWake, got ${cycle.state}`);

  // Force sleep wenn schon nicht WAKE → false
  cycle.forceSleep();
  const result3 = cycle.forceSleep();
  assert(result3 === false, "forceSleep im Sleep sollte false sein");

  console.log(`  → forceSleep: ✓, forceWake: ✓, double-force: rejected ✓`);
}

// ─── Test 15: Snapshot API ──────────────────────────────────────────

function testSnapshot() {
  console.log("\n🌙 Test 15: Snapshot — vollständiger Zustand");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);

  const snap = cycle.getSnapshot();

  assert(typeof snap.state === "string", "Snapshot sollte state string haben");
  assert(typeof snap.sleepCount === "number", "Snapshot sollte sleepCount haben");
  assert(typeof snap.energy === "number", "Snapshot sollte energy haben");
  assert(typeof snap.config === "object", "Snapshot sollte config haben");
  assert(typeof snap.nremReplayed === "number", "Snapshot sollte nremReplayed haben");
  assert(typeof snap.remDreams === "number", "Snapshot sollte remDreams haben");
  console.log(`  → Snapshot keys: ${Object.keys(snap).join(", ")} ✓`);
}

// ─── Test 16: Multiple Sleep Cycles ─────────────────────────────────

function testMultipleCycles() {
  console.log("\n🌙 Test 16: Multiple Sleep Cycles — sleepCount zählt hoch");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 0.5;
  cycle.config.remDuration = 0.5;
  cycle.config.wakeUpDuration = 0.5;

  for (let i = 0; i < 3; i++) {
    cycle.update(0.1);  // Enter Sleep
    cycle.update(0.5);  // NREM
    cycle.update(0.5);  // REM
    cycle.update(0.5);  // WAKING_UP → WAKE
  }

  assert(cycle._sleepCount === 3, `sleepCount sollte 3 sein, got ${cycle._sleepCount}`);
  assert(cycle.state === SleepState.WAKE, "Sollte WAKE sein nach 3 Zyklen");
  assert(cycle._totalSleepTime > 0, "totalSleepTime sollte > 0 sein");
  console.log(`  → sleepCount: ${cycle._sleepCount}, totalSleep: ${cycle._totalSleepTime.toFixed(1)}s ✓`);
}

// ─── Test 17: Reset ─────────────────────────────────────────────────

function testReset() {
  console.log("\n🌙 Test 17: Reset — alle Zustände gelöscht");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 0.5;
  cycle.config.remDuration = 0.5;
  cycle.config.wakeUpDuration = 0.5;

  // Run one cycle
  cycle.update(0.1);
  cycle.update(0.5);
  cycle.update(0.5);
  cycle.update(0.5);

  assert(cycle._sleepCount > 0, "sleepCount sollte > 0 sein vor reset");

  cycle.reset();

  assert(cycle.state === SleepState.WAKE, "State sollte WAKE sein nach reset");
  assert(cycle._sleepCount === 0, "sleepCount sollte 0 sein nach reset");
  assert(cycle._totalSleepTime === 0, "totalSleepTime sollte 0 sein nach reset");
  assert(cycle._dream.remDreams.length === 0, "remDreams sollte leer sein nach reset");
  console.log(`  → Reset successful ✓`);
}

// ─── Test 18: Bridge Edges Protected ────────────────────────────────

function testBridgeProtection() {
  console.log("\n🌙 Test 18: Bridge-Kanten werden beim Downscaling geschützt");
  const sim = makeMockSimulation();
  const cycle = new SleepCycle(sim);
  cycle.config.minWakeTime = 0;
  cycle.config.energyThreshold = 0;
  cycle.config.cycleInterval = 0;
  cycle.config.nremDuration = 1;

  const bridgeEdge = sim.world.edges.find(e => e.bridge);
  const bridgeWeightBefore = bridgeEdge.weight;
  const bridgeTraceBefore = bridgeEdge.identityTrace;

  cycle.update(0.1);
  cycle.update(1.0);

  assert(bridgeEdge.weight === bridgeWeightBefore,
    `Bridge weight sollte unverändert sein: ${bridgeWeightBefore} → ${bridgeEdge.weight}`);
  assert(bridgeEdge.identityTrace === bridgeTraceBefore,
    `Bridge identityTrace sollte unverändert sein: ${bridgeTraceBefore} → ${bridgeEdge.identityTrace}`);
  console.log(`  → Bridge weight: ${bridgeWeightBefore} → ${bridgeEdge.weight}, trace: ${bridgeTraceBefore} → ${bridgeEdge.identityTrace} ✓`);
}

// ─── Run all tests ───────────────────────────────────────────────────

console.log("═══════════════════════════════════════════════════════════");
console.log("  SleepCycle — Unit Tests");
console.log("═══════════════════════════════════════════════════════════");

testConstructor();
testSleepTriggerEnergy();
testSleepTriggerCycle();
testNremReplay();
testDownscaling();
testFatigueRestore();
testRemDreamWalks();
testRemCreativeLinks();
testDriftCalculation();
testFullCycle();
testPersonalityModulation();
testMoodSleep();
testEvents();
testForceSleepWake();
testSnapshot();
testMultipleCycles();
testReset();
testBridgeProtection();

console.log("\n═══════════════════════════════════════════════════════════");
console.log(`  Results: ${passed} passed, ${failed} failed`);
console.log("═══════════════════════════════════════════════════════════");

process.exit(failed > 0 ? 1 : 0);
