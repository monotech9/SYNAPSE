/**
 * EmergenceDetector — Unit Tests
 *
 * Run: node src/test/test-emergence-detector.js
 *
 * Testet alle sechs Metriken, Score-Kombination, Klassifizierung
 * und Event-Emission mit einem Mock-Simulation-Objekt.
 */

import { EmergenceDetector, EmergenceLevel } from "../simulation/systems/EmergenceDetector.js";
import { EventBus } from "../simulation/EventBus.js";

// ─── Test Harness ────────────────────────────────────────────────────

let passed = 0, failed = 0;

function assert(condition, message) {
  if (condition) {
    passed++;
  } else {
    failed++;
    console.error(`  ❌ FAIL: ${message}`);
  }
}

function assertApprox(actual, expected, tolerance, message) {
  assert(Math.abs(actual - expected) <= tolerance, `${message} (got ${actual}, expected ~${expected}, tol ${tolerance})`);
}

// ─── Mock Node ───────────────────────────────────────────────────────

function makeNode(index, activation, phase = 0, birthProgress = 1) {
  return { index, activation, phase, birthProgress };
}

// ─── Mock Simulation ─────────────────────────────────────────────────

function makeMockSimulation(nodes = [], edges = [], age = 0) {
  const events = new EventBus();
  const world = {
    age,
    clusters: nodes.length > 0 ? [{ nodes }] : [],
    edges
  };
  return { events, world };
}

// ─── Test 1: Shannon Entropy über Aktivitätsverteilung ───────────────

function testEntropyUniform() {
  console.log("\n📐 Test 1: Entropy — uniforme Verteilung → max Entropy");
  const nodes = [];
  for (let i = 0; i < 10; i++) {
    nodes.push(makeNode(i, 0.1 + i * 0.08, i * 0.6));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2); // trigger sample

  const result = ed.history[0];
  assert(result !== undefined, "Sample sollte in History sein");
  // Uniforme Verteilung über 8 Bins → hohe normalisierte Entropy
  assert(result.signals.entropy > 0.7, `Entropy sollte hoch sein bei uniformer Verteilung, got ${result.signals.entropy}`);
  console.log(`  → Entropy: ${result.signals.entropy.toFixed(3)} ✓`);
}

function testEntropyPeak() {
  console.log("\n📐 Test 2: Entropy — alle Nodes gleich → niedrige Entropy");
  const nodes = [];
  for (let i = 0; i < 10; i++) {
    nodes.push(makeNode(i, 0.5, i * 0.6));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2);

  const result = ed.history[0];
  // Alle im selben Bin → minimale Entropy
  assert(result.signals.entropy < 0.15, `Entropy sollte niedrig sein bei identischen Werten, got ${result.signals.entropy}`);
  console.log(`  → Entropy: ${result.signals.entropy.toFixed(3)} ✓`);
}

// ─── Test 3: Synchronization ─────────────────────────────────────────

function testSyncAligned() {
  console.log("\n📐 Test 3: Sync — alle Nodes gleiche Phase → Sync ≈ 1");
  const nodes = [];
  for (let i = 0; i < 8; i++) {
    nodes.push(makeNode(i, 0.5, 0)); // alle Phase = 0
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2);

  const result = ed.history[0];
  assertApprox(result.signals.sync, 1.0, 0.01, "Sync sollte ≈1 sein bei gleicher Phase");
  console.log(`  → Sync: ${result.signals.sync.toFixed(3)} ✓`);
}

function testSyncRandom() {
  console.log("\n📐 Test 4: Sync — zufällige Phasen → Sync < 0.5");
  const nodes = [];
  for (let i = 0; i < 20; i++) {
    nodes.push(makeNode(i, 0.5, (i * 2.39996) % (Math.PI * 2))); // goldener Winkel → gut verteilt
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2);

  const result = ed.history[0];
  assert(result.signals.sync < 0.35, `Sync sollte niedrig sein bei zufälligen Phasen, got ${result.signals.sync}`);
  console.log(`  → Sync: ${result.signals.sync.toFixed(3)} ✓`);
}

// ─── Test 5: Avalanche Index ─────────────────────────────────────────

function testAvalanche() {
  console.log("\n📐 Test 5: Avalanche — alle Nodes aktiv → hoher AI");
  const nodes = [];
  for (let i = 0; i < 20; i++) {
    nodes.push(makeNode(i, 0.6, i * 0.3));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1, activationThreshold: 0.15 });

  ed.update(0.2);

  const result = ed.history[0];
  assert(result.signals.avalanche > 0.9, `AI sollte hoch sein wenn alle Nodes aktiv, got ${result.signals.avalanche}`);
  assert(result.signals.activeCount === 20, `activeCount sollte 20 sein, got ${result.signals.activeCount}`);
  console.log(`  → AI: ${result.signals.avalanche.toFixed(3)}, active: ${result.signals.activeCount} ✓`);
}

function testAvalancheLow() {
  console.log("\n📐 Test 6: Avalanche — kaum aktive Nodes → niedriger AI");
  const nodes = [];
  for (let i = 0; i < 20; i++) {
    nodes.push(makeNode(i, 0.02, i * 0.3)); // alle unter Threshold
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2);

  const result = ed.history[0];
  assert(result.signals.avalanche < 0.05, `AI sollte niedrig sein, got ${result.signals.avalanche}`);
  assert(result.signals.activeCount === 0, `activeCount sollte 0 sein, got ${result.signals.activeCount}`);
  console.log(`  → AI: ${result.signals.avalanche.toFixed(3)}, active: ${result.signals.activeCount} ✓`);
}

// ─── Test 7: Structure Drift ─────────────────────────────────────────

function testStructureDrift() {
  console.log("\n📐 Test 7: Structure Drift — neue Kanten → SD > 0");
  const nodes = [];
  for (let i = 0; i < 6; i++) {
    nodes.push(makeNode(i, 0.4, i * 0.5));
  }

  // Erste Sample: 3 Kanten
  const edges1 = [
    { a: nodes[0], b: nodes[1], birthProgress: 1 },
    { a: nodes[1], b: nodes[2], birthProgress: 1 },
    { a: nodes[2], b: nodes[3], birthProgress: 1 }
  ];

  const sim = makeMockSimulation(nodes, edges1, 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  // Erste Sample — kein prev state, SD = 0
  ed.update(0.2);
  assert(ed.history[0].signals.structureDrift === 0, "Erste Sample: SD sollte 0 sein (kein prev state)");

  // Zweite Sample: eine Kante entfernt, eine neue dazu
  sim.world.edges = [
    { a: nodes[0], b: nodes[1], birthProgress: 1 },
    { a: nodes[1], b: nodes[2], birthProgress: 1 },
    { a: nodes[3], b: nodes[4], birthProgress: 1 } // neu, alte (2,3) entfernt
  ];
  sim.world.age = 5.2;

  ed.update(0.2);

  const sd = ed.history[1].signals.structureDrift;
  assert(sd > 0.3, `Structure Drift sollte >0.3 sein bei 1/3 Kantenwechsel, got ${sd}`);
  console.log(`  → SD: ${sd.toFixed(3)} ✓`);
}

// ─── Test 8: Branching Ratio ─────────────────────────────────────────

function testBranchingRatio() {
  console.log("\n📐 Test 8: Branching Ratio — Aktivität verdoppelt → σ ≈ 2");

  // Sample 1: 5 aktive von 10
  const nodes = [];
  for (let i = 0; i < 10; i++) {
    nodes.push(makeNode(i, i < 5 ? 0.5 : 0.05, i * 0.5));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1, activationThreshold: 0.15 });

  ed.update(0.2); // Sample 1

  // Sample 2: alle 10 aktiv
  for (const node of nodes) node.activation = 0.5;
  sim.world.age = 5.2;

  ed.update(0.2); // Sample 2

  const result = ed.history[1];
  assertApprox(result.signals.branching, 2.0, 0.01, "σ sollte ≈2 sein (10/5)");
  console.log(`  → σ: ${result.signals.branching.toFixed(3)} ✓`);
}

// ─── Test 9: Mutual Information ──────────────────────────────────────

function testMutualInformation() {
  console.log("\n📐 Test 9: MI Drift — identische Zustände → hohe MI");

  const nodes = [];
  for (let i = 0; i < 12; i++) {
    nodes.push(makeNode(i, 0.1 + i * 0.06, i * 0.4));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2); // Sample 1

  // Keine Änderung — gleiche Aktivierungen
  sim.world.age = 5.2;
  ed.update(0.2); // Sample 2

  const result = ed.history[1];
  // Bei identischen Werten: range ≈ 0 → MI = 0 (Spezialfall)
  // Aber: hier sind die Werte nicht alle gleich (i * 0.06), also MI hoch
  assert(result.signals.miDrift > 0.5, `MI sollte hoch sein bei stabilen Mustern, got ${result.signals.miDrift}`);
  console.log(`  → MI: ${result.signals.miDrift.toFixed(3)} ✓`);
}

function testMILow() {
  console.log("\n📐 Test 10: MI Drift — dekorellierte Zufallswerte → niedrigere MI als identisch");

  // Hinweis: Eine perfekte Permutation (z.B. umgekehrte Reihenfolge) ergibt
  // hohe MI, weil die t→t-1 Beziehung deterministisch bleibt. Echte
  // "Bedeutungsverschiebung" entsteht erst, wenn die Beziehung ZUFÄLLIG wird.

  const nodes = [];
  for (let i = 0; i < 30; i++) {
    nodes.push(makeNode(i, 0.1 + i * 0.025, i * 0.4));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2); // Sample 1

  // Referenz: identische Werte → MI = 1.0 (Perfekte Korrelation)
  const sim2 = makeMockSimulation(nodes.map(n => makeNode(n.index, n.activation, n.phase)), [], 5);
  const ed2 = new EmergenceDetector(sim2, { sampleInterval: 0.1 });
  ed2.update(0.2);
  sim2.world.age = 5.2;
  ed2.update(0.2);
  const miIdentical = ed2.history[1].signals.miDrift;

  // Jetzt: komplett zufällige Neuzuweisung (kein systematischer Zusammenhang)
  // Shuffe die Aktivierungswerte random über die Nodes
  const shuffled = nodes.map(n => n.activation).sort(() => Math.random() - 0.5);
  for (let i = 0; i < 30; i++) {
    nodes[i].activation = shuffled[i];
  }
  sim.world.age = 5.2;
  ed.update(0.2); // Sample 2

  const result = ed.history[1];
  // MI bei zufälliger Zuweisung sollte deutlich niedriger sein als bei identischen Werten
  assert(result.signals.miDrift < miIdentical,
    `MI bei Shuffle (${result.signals.miDrift.toFixed(3)}) sollte < MI bei identisch (${miIdentical.toFixed(3)}) sein`);
  console.log(`  → MI shuffled: ${result.signals.miDrift.toFixed(3)} < MI identical: ${miIdentical.toFixed(3)} ✓`);
}

// ─── Test 11: Klassifizierung ────────────────────────────────────────

function testClassificationStable() {
  console.log("\n📐 Test 11: Klassifizierung — ruhiges System → STABLE");
  const nodes = [];
  for (let i = 0; i < 10; i++) {
    nodes.push(makeNode(i, 0.03, (i * 2.39996) % (Math.PI * 2)));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2);

  assert(ed.lastLevel === EmergenceLevel.STABLE, `Level sollte STABLE sein, got ${ed.lastLevel}`);
  console.log(`  → Level: ${ed.lastLevel} ✓`);
}

function testClassificationPhaseShift() {
  console.log("\n📐 Test 12: Klassifizierung — hohes Aktivitäts-Level → PHASE_SHIFT");
  const nodes = [];
  for (let i = 0; i < 30; i++) {
    nodes.push(makeNode(i, 0.7, i * 0.1)); // hohe Aktivität, ähnliche Phasen
  }
  // Viele Kanten für Structure Drift
  const edges = [];
  for (let i = 0; i < 20; i++) {
    edges.push({ a: nodes[i], b: nodes[(i + 1) % 30], birthProgress: 1 });
  }
  const sim = makeMockSimulation(nodes, edges, 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2); // Erste Sample (baseline)
  // Ändere Kanten drastisch
  sim.world.edges = [];
  for (let i = 0; i < 20; i++) {
    sim.world.edges.push({ a: nodes[i], b: nodes[(i + 5) % 30], birthProgress: 1 });
  }
  sim.world.age = 5.2;
  ed.update(0.2); // Zweite Sample

  assert(ed.lastLevel !== EmergenceLevel.STABLE, `Level sollte ≥ TRANSITION sein, got ${ed.lastLevel}`);
  console.log(`  → Level: ${ed.lastLevel}, Score: ${ed.lastScore.toFixed(3)} ✓`);
}

// ─── Test 13: Event Emission ─────────────────────────────────────────

function testEventEmission() {
  console.log("\n📐 Test 13: EventBus — emergence:score wird bei jedem Sample gefeuert");
  const nodes = [];
  for (let i = 0; i < 10; i++) {
    nodes.push(makeNode(i, 0.3, i * 0.5));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  let scoreEvents = 0;
  let detectedEvents = 0;
  let phaseShiftEvents = 0;

  sim.events.on("emergence:score", () => scoreEvents++);
  sim.events.on("emergence:detected", () => detectedEvents++);
  sim.events.on("emergence:phaseShift", () => phaseShiftEvents++);

  ed.update(0.2); // Sample 1
  ed.update(0.2); // Sample 2

  assert(scoreEvents === 2, `Sollte 2 score-Events geben, got ${scoreEvents}`);
  console.log(`  → score events: ${scoreEvents} ✓`);

  // Jetzt hohe Aktivität für detection
  for (const node of nodes) node.activation = 0.8;
  sim.world.age = 5.6;
  ed.update(0.2); // Sample 3 — sollte detecten

  // Mindestens eines der detection events sollte gefeuert haben
  // (abhängig vom Score)
  console.log(`  → detected events: ${detectedEvents}, phaseShift: ${phaseShiftEvents}`);
}

// ─── Test 14: Cool-Down ──────────────────────────────────────────────

function testCoolDown() {
  console.log("\n📐 Test 14: Cool-Down — keine Event-Spam bei kontinuierlich hohem Score");
  const nodes = [];
  for (let i = 0; i < 20; i++) {
    nodes.push(makeNode(i, 0.7, i * 0.05));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.5, coolDown: 3.0 });

  let detectedCount = 0;
  sim.events.on("emergence:detected", () => detectedCount++);

  // 5 Samples im Abstand von 0.5s → Age steigt um 0.5 pro Sample
  for (let s = 0; s < 6; s++) {
    sim.world.age = 5 + s * 0.5;
    ed.update(0.6);
  }

  // Bei coolDown=3.0 und Samples alle 0.5s: max 1-2 detections in 3s
  assert(detectedCount <= 3, `Cool-Down sollte detections limitieren, got ${detectedCount}`);
  console.log(`  → detections in 3s: ${detectedCount} ✓`);
}

// ─── Test 15: Reset ──────────────────────────────────────────────────

function testReset() {
  console.log("\n📐 Test 15: Reset — alle Zustände werden gelöscht");
  const nodes = [];
  for (let i = 0; i < 10; i++) {
    nodes.push(makeNode(i, 0.5, i * 0.3));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2); // Sample
  assert(ed.history.length > 0, "History sollte Daten haben vor Reset");

  ed.reset();

  assert(ed.history.length === 0, "History sollte leer sein nach Reset");
  assert(ed._hasPrevState === false, "hasPrevState sollte false sein nach Reset");
  assert(ed.stats.totalSamples === 0, "stats sollten zurückgesetzt sein");
  assert(ed.lastScore === 0, "lastScore sollte 0 sein nach Reset");
  console.log(`  → Reset erfolgreich ✓`);
}

// ─── Test 16: getSnapshot API ────────────────────────────────────────

function testSnapshot() {
  console.log("\n📐 Test 16: getSnapshot — API liefert vollständigen Zustand");
  const nodes = [];
  for (let i = 0; i < 8; i++) {
    nodes.push(makeNode(i, 0.4, i * 0.4));
  }
  const sim = makeMockSimulation(nodes, [], 5);
  const ed = new EmergenceDetector(sim, { sampleInterval: 0.1 });

  ed.update(0.2);

  const snap = ed.getSnapshot();
  assert(snap.score !== undefined, "Snapshot sollte score haben");
  assert(snap.level !== undefined, "Snapshot sollte level haben");
  assert(snap.stats !== undefined, "Snapshot sollte stats haben");
  assert(Array.isArray(snap.recent), "Snapshot sollte recent array haben");
  assert(snap.recent.length > 0, "Snapshot sollte mindestens 1 recent entry haben");
  assert(snap.weights !== undefined, "Snapshot sollte weights haben");
  console.log(`  → Snapshot: score=${snap.score.toFixed(3)}, level=${snap.level}, recent=${snap.recent.length} ✓`);
}

// ─── Run all tests ───────────────────────────────────────────────────

console.log("═══════════════════════════════════════════════════════════");
console.log("  EmergenceDetector — Unit Tests");
console.log("═══════════════════════════════════════════════════════════");

testEntropyUniform();
testEntropyPeak();
testSyncAligned();
testSyncRandom();
testAvalanche();
testAvalancheLow();
testStructureDrift();
testBranchingRatio();
testMutualInformation();
testMILow();
testClassificationStable();
testClassificationPhaseShift();
testEventEmission();
testCoolDown();
testReset();
testSnapshot();

console.log("\n═══════════════════════════════════════════════════════════");
console.log(`  Results: ${passed} passed, ${failed} failed`);
console.log("═══════════════════════════════════════════════════════════");

process.exit(failed > 0 ? 1 : 0);
