/**
 * EmotionEngine — Unit Tests
 *
 * Run: node src/test/test-emotion-engine.js
 *
 * Testet:
 *  - OCC Appraisal: Events → Emotion Intensities
 *  - Decay: Emotionen klingen ab
 *  - Personality-Modulation: sensitivity/resilience
 *  - Dominante Emotion Wechsel + EventBus
 *  - System Modulation (fear→threshold, curiosity→noise, etc.)
 *  - Chain-of-Emotion History
 *  - Mood (langsame Hintergrund-Valenz)
 *  - Reward-Prediction-Error
 *  - Story Echo (emotionale Resonanz)
 *  - Reset
 */

import { EmotionEngine, EmotionType } from "../simulation/systems/EmotionEngine.js";
import { EventBus } from "../simulation/EventBus.js";

let passed = 0, failed = 0;

function assert(condition, message) {
  if (condition) { passed++; }
  else { failed++; console.error(`  ❌ FAIL: ${message}`); }
}

// ─── Mock Personality ────────────────────────────────────────────────

function makeMockPersonality(overrides = {}) {
  return {
    curiosity: 0.5, caution: 0.5, resilience: 0.5,
    rhythm: 0.5, sensitivity: 0.5, plasticity: 0.5,
    attachment: 0.5, volatility: 0.5,
    ...overrides
  };
}

// ─── Mock Simulation ─────────────────────────────────────────────────

function makeMockSimulation(opts = {}) {
  const events = new EventBus();
  const world = {
    age: 0,
    maturity: 0,
    growthStage: "genesis",
    clusters: opts.clusters || [{ state: "active", activityMemory: 0.3, nodes: [] }],
    edges: opts.edges || [],
    bridgeEdges: opts.bridgeEdges || [],
    pulses: opts.pulses || [],
    scars: opts.scars || [],
    pointerEnergy: 0,
    nodes: opts.nodes || []
  };
  const personality = makeMockPersonality(opts.personality || {});
  return {
    events, world, personality,
    totalNodeCount: () => opts.totalNodes || 10,
    diagnosticCounters: { internalEdgesAdded: 0 }
  };
}

// ─── Test 1: Constructor — alle Emotionen initialisiert ─────────────

function testConstructor() {
  console.log("\n🧠 Test 1: Constructor — alle 14 Emotionen initialisiert");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  const emotionKeys = Object.keys(engine.emotions);
  assert(emotionKeys.length === 14, `Sollte 14 Emotionen haben, got ${emotionKeys.length}`);
  assert(emotionKeys.includes(EmotionType.JOY), "Sollte JOY haben");
  assert(emotionKeys.includes(EmotionType.FEAR), "Sollte FEAR haben");
  assert(emotionKeys.includes(EmotionType.WONDER), "Sollte WONDER haben");

  // Alle初始 0
  for (const [k, v] of Object.entries(engine.emotions)) {
    assert(v === 0, `Emotion ${k} sollte 0 sein, got ${v}`);
  }

  assert(engine.dominantEmotion === EmotionType.CALM, "Dominant sollte CALM sein initial");
  assert(engine.mood === 0, "Mood sollte 0 sein initial");
  console.log(`  → 14 emotions, all initialized ✓`);
}

// ─── Test 2: Appraisal — growth:nodeAdded → JOY + PRIDE ─────────────

function testGrowthAppraisal() {
  console.log("\n🧠 Test 2: Appraisal — growth:nodeAdded → JOY + PRIDE");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  sim.events.emit("growth:nodeAdded", { node: {} });

  assert(engine.emotions[EmotionType.JOY] > 0, "JOY sollte > 0 sein");
  assert(engine.emotions[EmotionType.PRIDE] > 0, "PRIDE sollte > 0 sein");
  assert(engine.emotions[EmotionType.JOY] > engine.emotions[EmotionType.PRIDE], "JOY sollte > PRIDE sein");
  console.log(`  → JOY: ${engine.emotions[EmotionType.JOY].toFixed(3)}, PRIDE: ${engine.emotions[EmotionType.PRIDE].toFixed(3)} ✓`);
}

// ─── Test 3: Appraisal — scar:created → FEAR + DISTRESS ─────────────

function testScarAppraisal() {
  console.log("\n🧠 Test 3: Appraisal — scar:created → FEAR + DISTRESS");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  sim.events.emit("scar:created", { scar: {} });

  assert(engine.emotions[EmotionType.FEAR] > 0.1, `FEAR sollte > 0.1 sein, got ${engine.emotions[EmotionType.FEAR]}`);
  assert(engine.emotions[EmotionType.DISTRESS] > 0.08, `DISTRESS sollte > 0.08, got ${engine.emotions[EmotionType.DISTRESS]}`);
  console.log(`  → FEAR: ${engine.emotions[EmotionType.FEAR].toFixed(3)}, DISTRESS: ${engine.emotions[EmotionType.DISTRESS].toFixed(3)} ✓`);
}

// ─── Test 4: Decay — Emotionen klingen über Zeit ab ─────────────────

function testDecay() {
  console.log("\n🧠 Test 4: Decay — Emotionen klingen ab");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  // JOY auf 0.5 setzen
  sim.events.emit("growth:nodeAdded", {});
  sim.events.emit("growth:nodeAdded", {});
  sim.events.emit("growth:nodeAdded", {});
  sim.events.emit("growth:nodeAdded", {});
  sim.events.emit("growth:nodeAdded", {});
  sim.events.emit("growth:nodeAdded", {});

  const joyBefore = engine.emotions[EmotionType.JOY];
  assert(joyBefore > 0.2, `JOY sollte hoch sein vor Decay, got ${joyBefore}`);

  // 5 Sekunden Update
  engine.update(5.0);

  const joyAfter = engine.emotions[EmotionType.JOY];
  assert(joyAfter < joyBefore, `JOY sollte abgeklingt sein: ${joyBefore.toFixed(3)} → ${joyAfter.toFixed(3)}`);
  console.log(`  → JOY: ${joyBefore.toFixed(3)} → ${joyAfter.toFixed(3)} after 5s ✓`);
}

// ─── Test 5: Personality-Modulation — sensitivity ───────────────────

function testSensitivity() {
  console.log("\n🧠 Test 5: Personality — sensitivity moduliert Impuls-Stärke");
  const simLow = makeMockSimulation({ personality: { sensitivity: 0.1, resilience: 0.5 } });
  const simHigh = makeMockSimulation({ personality: { sensitivity: 0.9, resilience: 0.5 } });

  const engineLow = new EmotionEngine(simLow);
  const engineHigh = new EmotionEngine(simHigh);

  simLow.events.emit("scar:created", {});
  simHigh.events.emit("scar:created", {});

  const fearLow = engineLow.emotions[EmotionType.FEAR];
  const fearHigh = engineHigh.emotions[EmotionType.FEAR];
  assert(fearHigh > fearLow, `High sensitivity sollte mehr FEAR ergeben: ${fearHigh.toFixed(3)} > ${fearLow.toFixed(3)}`);
  console.log(`  → FEAR low-sens: ${fearLow.toFixed(3)}, high-sens: ${fearHigh.toFixed(3)} ✓`);
}

// ─── Test 6: Personality-Modulation — resilience (decay) ────────────

function testResilience() {
  console.log("\n🧠 Test 6: Personality — resilience beschleunigt Decay");
  const simLow = makeMockSimulation({ personality: { sensitivity: 0.5, resilience: 0.1 } });
  const simHigh = makeMockSimulation({ personality: { sensitivity: 0.5, resilience: 0.9 } });

  const engineLow = new EmotionEngine(simLow);
  const engineHigh = new EmotionEngine(simHigh);

  // Gleicher Impuls
  simLow.events.emit("scar:created", {});
  simHigh.events.emit("scar:created", {});

  const fearBeforeLow = engineLow.emotions[EmotionType.FEAR];
  const fearBeforeHigh = engineHigh.emotions[EmotionType.FEAR];

  // 2 Sekunden Decay — kurz genug dass nicht alles auf 0 abklingt
  engineLow.update(2.0);
  engineHigh.update(2.0);

  const fearAfterLow = engineLow.emotions[EmotionType.FEAR];
  const fearAfterHigh = engineHigh.emotions[EmotionType.FEAR];

  // High resilience → schnellerer Decay
  const decayLow = fearBeforeLow - fearAfterLow;
  const decayHigh = fearBeforeHigh - fearAfterHigh;
  assert(decayHigh > decayLow, `High resilience sollte schneller decayen: ${decayHigh.toFixed(4)} > ${decayLow.toFixed(4)}`);
  console.log(`  → Decay low-res: ${decayLow.toFixed(4)}, high-res: ${decayHigh.toFixed(4)} ✓`);
}

// ─── Test 7: Dominante Emotion + EventBus ───────────────────────────

function testDominantEmotion() {
  console.log("\n🧠 Test 7: Dominante Emotion wechselt → EventBus feuert");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  let changeEvents = 0;
  sim.events.on("emotion:change", () => changeEvents++);

  // Viel JOY
  for (let i = 0; i < 10; i++) sim.events.emit("growth:nodeAdded", {});

  engine.update(0.3); // Trigger dominant update

  assert(engine.dominantEmotion === EmotionType.JOY, `Dominant sollte JOY sein, got ${engine.dominantEmotion}`);
  assert(changeEvents > 0, `Sollte emotion:change gefeuert haben, got ${changeEvents}`);
  console.log(`  → Dominant: ${engine.dominantEmotion}, changes: ${changeEvents} ✓`);
}

// ─── Test 8: System Modulation — FEAR → threshold ↑ ─────────────────

function testFearModulation() {
  console.log("\n🧠 Test 8: System Modulation — FEAR erhöht firingThreshold");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  const thresholdBefore = engine.modulation.firingThresholdMultiplier;
  assert(thresholdBefore === 1.0, `Threshold sollte 1.0 sein initial, got ${thresholdBefore}`);

  // FEAR erzeugen
  sim.events.emit("scar:created", {});
  sim.events.emit("scar:created", {});
  sim.events.emit("scar:created", {});

  engine.update(0.3); // Update modulation

  const thresholdAfter = engine.modulation.firingThresholdMultiplier;
  assert(thresholdAfter > 1.0, `Threshold sollte > 1.0 sein mit FEAR, got ${thresholdAfter}`);
  console.log(`  → Threshold: ${thresholdBefore.toFixed(3)} → ${thresholdAfter.toFixed(3)} ✓`);
}

// ─── Test 9: System Modulation — CURIOSITY → noise ↑ ────────────────

function testCuriosityModulation() {
  console.log("\n🧠 Test 9: System Modulation — CURIOSITY erhöht explorationNoise");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  const noiseBefore = engine.modulation.explorationNoiseMultiplier;
  assert(noiseBefore === 1.0, `Noise sollte 1.0 sein initial, got ${noiseBefore}`);

  // CURIOSITY erzeugen
  for (let i = 0; i < 5; i++) sim.events.emit("signal:injected", {});

  engine.update(0.3);

  const noiseAfter = engine.modulation.explorationNoiseMultiplier;
  assert(noiseAfter > 1.0, `Noise sollte > 1.0 sein mit CURIOSITY, got ${noiseAfter}`);
  console.log(`  → Noise: ${noiseBefore.toFixed(3)} → ${noiseAfter.toFixed(3)} ✓`);
}

// ─── Test 10: Chain-of-Emotion History ──────────────────────────────

function testEmotionHistory() {
  console.log("\n🧠 Test 10: Chain-of-Emotion — Historie wird aufgezeichnet");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  // Phase 1: JOY dominant
  for (let i = 0; i < 10; i++) sim.events.emit("growth:nodeAdded", {});
  engine.update(0.3);

  // Phase 2: FEAR dominant
  for (let i = 0; i < 10; i++) sim.events.emit("scar:created", {});
  engine.update(0.3);

  const history = engine.getHistory();
  assert(history.length >= 2, `History sollte >= 2 Einträge haben, got ${history.length}`);
  assert(history[0].emotion !== history[history.length - 1].emotion, "Erste und letzte Emotion sollten unterschiedlich sein");
  console.log(`  → History: ${history.length} entries`);
  for (const h of history) console.log(`    [${h.timestamp.toFixed(1)}s] ${h.emotion} (${h.intensity.toFixed(3)})`);
  console.log(`  ✓`);
}

// ─── Test 11: Mood — langsame Hintergrund-Valenz ────────────────────

function testMood() {
  console.log("\n🧠 Test 11: Mood — Hintergrund-Valenz bewegt sich langsam");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  assert(engine.mood === 0, "Mood sollte 0 sein initial");

  // Viele positive Emotionen
  for (let i = 0; i < 10; i++) sim.events.emit("growth:nodeAdded", {});
  for (let i = 0; i < 5; i++) sim.events.emit("network:bridgeCreated", {});

  // Mood update braucht 5s
  engine.update(6.0);

  assert(engine.mood > 0, `Mood sollte > 0 sein nach positiven Events, got ${engine.mood}`);
  console.log(`  → Mood: ${engine.mood.toFixed(3)} (positive) ✓`);

  // Negative Emotionen
  for (let i = 0; i < 20; i++) sim.events.emit("scar:created", {});
  engine.update(11.0); // 2x mood update

  assert(engine.mood < 0.2, `Mood sollte negativer sein nach negativen Events, got ${engine.mood}`);
  console.log(`  → Mood: ${engine.mood.toFixed(3)} (shifted negative) ✓`);
}

// ─── Test 12: Reward-Prediction-Error ───────────────────────────────

function testRPE() {
  console.log("\n🧠 Test 12: Reward-Prediction-Error — positive RPE → JOY");
  const sim = makeMockSimulation({ totalNodes: 5, edges: [], bridgeEdges: [], scars: [] });
  // Expected reward startet bei 0.5 — wir brauchen deutlich mehr Wachstum für positive RPE
  const engine = new EmotionEngine(sim);

  const initialJoy = engine.emotions[EmotionType.JOY];

  // System wächst stark (more nodes → higher reward > 0.5)
  sim.totalNodeCount = () => 80;
  sim.world.edges = new Array(100).fill({});
  sim.world.bridgeEdges = [{}, {}, {}];

  // Trigger periodic appraisal
  engine.update(0.3);

  const finalJoy = engine.emotions[EmotionType.JOY];
  assert(finalJoy > initialJoy, `JOY sollte steigen durch positive RPE: ${initialJoy.toFixed(3)} → ${finalJoy.toFixed(3)}`);

  const rpe = engine.getRewardState();
  assert(rpe.expected > 0.1, `Expected reward sollte > 0.1 sein, got ${rpe.expected}`);
  console.log(`  → JOY: ${initialJoy.toFixed(3)} → ${finalJoy.toFixed(3)}, expected: ${rpe.expected.toFixed(3)} ✓`);
}

// ─── Test 13: Emotion Spike Event ───────────────────────────────────

function testSpikeEvent() {
  console.log("\n🧠 Test 13: emotion:spike — wenn Emotion 0.7 überschreitet");
  const sim = makeMockSimulation({ personality: { sensitivity: 0.9, resilience: 0.5 } });
  const engine = new EmotionEngine(sim);

  let spikes = 0;
  let lastSpike = null;
  sim.events.on("emotion:spike", (d) => { spikes++; lastSpike = d; });

  // Sehr viele Scar-Events um FEAR über 0.7 zu treiben
  for (let i = 0; i < 20; i++) sim.events.emit("scar:created", {});

  assert(spikes > 0, `Sollte mindestens 1 spike haben, got ${spikes}`);
  // Beide können spike — FEAR und DISTRESS werden beide durch scars getriggert
  assert(lastSpike.emotion === EmotionType.FEAR || lastSpike.emotion === EmotionType.DISTRESS,
    `Spike sollte FEAR oder DISTRESS sein, got ${lastSpike.emotion}`);
  assert(lastSpike.intensity >= 0.7, `Spike intensity sollte >= 0.7 sein, got ${lastSpike.intensity}`);
  console.log(`  → Spikes: ${spikes}, last: ${lastSpike.emotion} at ${lastSpike.intensity.toFixed(3)} ✓`);
}

// ─── Test 14: Story Echo — story:event erzeugt emotionalen Echo ─────

function testStoryEcho() {
  console.log("\n🧠 Test 14: Story Echo — story:event erzeugt emotionale Resonanz");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  sim.events.emit("story:event", {
    text: "Ein Moment der Klarheit.",
    emotion: "awakening",
    edScore: 0.8,
    timestamp: 10
  });

  assert(engine.emotions[EmotionType.WONDER] > 0, `WONDER sollte > 0 sein nach awakening story echo`);
  console.log(`  → WONDER: ${engine.emotions[EmotionType.WONDER].toFixed(3)} ✓`);

  sim.events.emit("story:event", {
    text: "Verlust.",
    emotion: "loss",
    edScore: 0.7,
    timestamp: 15
  });

  assert(engine.emotions[EmotionType.DISTRESS] > 0, `DISTRESS sollte > 0 sein nach loss story echo`);
  console.log(`  → DISTRESS: ${engine.emotions[EmotionType.DISTRESS].toFixed(3)} ✓`);
}

// ─── Test 15: Emergence → Wonder ────────────────────────────────────

function testEmergenceWonder() {
  console.log("\n🧠 Test 15: Emergence detected → WONDER");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  sim.events.emit("emergence:detected", {
    level: "PHASE_SHIFT",
    score: 0.65,
    signals: { structureDrift: 0.5, avalanche: 0.3 },
    epoch: 10
  });

  assert(engine.emotions[EmotionType.WONDER] > 0.1, `WONDER sollte > 0.1 sein, got ${engine.emotions[EmotionType.WONDER]}`);

  // CRITICAL_SPIKE → additional hope + pride
  const wonderBefore = engine.emotions[EmotionType.WONDER];
  sim.events.emit("emergence:detected", {
    level: "CRITICAL_SPIKE",
    score: 0.9,
    signals: { sync: 0.8, branching: 1.0 },
    epoch: 15
  });

  assert(engine.emotions[EmotionType.HOPE] > 0, `HOPE sollte > 0 sein nach CRITICAL_SPIKE`);
  assert(engine.emotions[EmotionType.PRIDE] > 0, `PRIDE sollte > 0 sein nach CRITICAL_SPIKE`);
  assert(engine.emotions[EmotionType.WONDER] > wonderBefore, `WONDER sollte weiter steigen`);
  console.log(`  → WONDER: ${engine.emotions[EmotionType.WONDER].toFixed(3)}, HOPE: ${engine.emotions[EmotionType.HOPE].toFixed(3)}, PRIDE: ${engine.emotions[EmotionType.PRIDE].toFixed(3)} ✓`);
}

// ─── Test 16: Periodic Appraisal — low activity → calm ──────────────

function testPeriodicCalm() {
  console.log("\n🧠 Test 16: Periodic Appraisal — niedrige Aktivität → CALM");
  const sim = makeMockSimulation({
    totalNodes: 20,
    pulses: [],
    clusters: [{ state: "active", activityMemory: 0.1, nodes: new Array(20).fill({}) }]
  });
  const engine = new EmotionEngine(sim);

  engine.update(0.3); // Trigger periodic appraisal

  assert(engine.emotions[EmotionType.CALM] > 0, `CALM sollte > 0 sein bei niedriger Aktivität, got ${engine.emotions[EmotionType.CALM]}`);
  console.log(`  → CALM: ${engine.emotions[EmotionType.CALM].toFixed(3)} ✓`);
}

// ─── Test 17: Snapshot API ──────────────────────────────────────────

function testSnapshot() {
  console.log("\n🧠 Test 17: Snapshot — vollständiger Zustand");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  sim.events.emit("growth:nodeAdded", {});
  engine.update(0.3);

  const snap = engine.getSnapshot();

  assert(typeof snap.emotions === "object", "Snapshot sollte emotions object haben");
  assert(typeof snap.dominant === "object", "Snapshot sollte dominant object haben");
  assert(typeof snap.mood === "number", "Snapshot sollte mood number haben");
  assert(typeof snap.modulation === "object", "Snapshot sollte modulation object haben");
  assert(Array.isArray(snap.history), "Snapshot sollte history array haben");
  assert(typeof snap.reward === "object", "Snapshot sollte reward object haben");
  console.log(`  → Snapshot complete: ${Object.keys(snap).join(", ")} ✓`);
}

// ─── Test 18: Reset ─────────────────────────────────────────────────

function testReset() {
  console.log("\n🧠 Test 18: Reset — alle Zustände gelöscht");
  const sim = makeMockSimulation();
  const engine = new EmotionEngine(sim);

  sim.events.emit("scar:created", {});
  sim.events.emit("growth:nodeAdded", {});
  engine.update(0.1); // Kurzes Update — kein vollständiger Decay

  assert(engine.emotions[EmotionType.FEAR] > 0, `FEAR sollte > 0 sein vor reset, got ${engine.emotions[EmotionType.FEAR]}`);
  assert(engine.mood !== 0 || engine.emotions[EmotionType.JOY] > 0, "State sollte nicht leer sein");

  engine.reset();

  for (const [k, v] of Object.entries(engine.emotions)) {
    assert(v === 0, `Emotion ${k} sollte 0 sein nach reset, got ${v}`);
  }
  assert(engine.mood === 0, "Mood sollte 0 sein nach reset");
  assert(engine.emotionHistory.length === 0, "History sollte leer sein nach reset");
  console.log(`  → Reset successful ✓`);
}

// ─── Run all tests ───────────────────────────────────────────────────

console.log("═══════════════════════════════════════════════════════════");
console.log("  EmotionEngine — Unit Tests");
console.log("═══════════════════════════════════════════════════════════");

testConstructor();
testGrowthAppraisal();
testScarAppraisal();
testDecay();
testSensitivity();
testResilience();
testDominantEmotion();
testFearModulation();
testCuriosityModulation();
testEmotionHistory();
testMood();
testRPE();
testSpikeEvent();
testStoryEcho();
testEmergenceWonder();
testPeriodicCalm();
testSnapshot();
testReset();

console.log("\n═══════════════════════════════════════════════════════════");
console.log(`  Results: ${passed} passed, ${failed} failed`);
console.log("═══════════════════════════════════════════════════════════");

process.exit(failed > 0 ? 1 : 0);
