/**
 * Tests für SelfModelEngine — Integration mit EmotionEngine, StoryMappingEngine, SleepCycle
 *
 * Test-Kategorien:
 *  1. Construction & initial state
 *  2. emotion:change → emotionalState, emotionHistory, valence
 *  3. emotion:spike → selfAwareness boost, reflection, goals
 *  4. story:event → storyEcho, storyEchoCount, narrative enrichment
 *  5. story:milestone → stateHistory, selfAwareness boost, reflection
 *  6. sleep:wakeUp → sleepCount, consolidation, reflection, goals
 *  7. sleep:stateChange → sleepState tracking
 *  8. Narrative generation with emotion + story
 *  9. Reflection API
 * 10. Serialization
 * 11. Destroy / cleanup
 * 12. Backward compat — existing ignition + emergence events still work
 */

// ─── Minimal Mock Framework ──────────────────────────────────────────

let passed = 0, failed = 0;
const failures = [];

function assert(cond, msg) {
  if (cond) {
    passed++;
  } else {
    failed++;
    failures.push(msg);
    console.error(`  ✗ FAIL: ${msg}`);
  }
}

function approxEqual(a, b, eps = 0.001) {
  return Math.abs(a - b) < eps;
}

function test(name, fn) {
  process.stdout.write(`  ${name} ... `);
  const beforePassed = passed;
  const beforeFailed = failed;
  try {
    fn();
    if (failed === beforeFailed) {
      console.log('\r  ✓ ' + name);
    }
  } catch (e) {
    failed++;
    failures.push(`${name}: ${e.message}`);
    console.log('\r  ✗ ' + name);
    console.error(`    Exception: ${e.message}`);
    console.error(`    Stack: ${e.stack?.split('\n').slice(1, 3).join('\n')}`);
  }
}

// ─── Mock Simulation ─────────────────────────────────────────────────

function createMockSim(overrides = {}) {
  const events = createMockEventBus();
  const world = {
    age: 0,
    edges: [],
    bridgeEdges: [],
    clusters: [
      { state: "active", activityMemory: 0.5 },
      { state: "active", activityMemory: 0.7 },
      { state: "dormant", activityMemory: 0 }
    ],
    growthStage: "activation",
    pulses: [],
    memoryFlashTimer: 0
  };

  return {
    events,
    world,
    identity: { name: "NOVA", createdAt: Date.now() },
    personality: { profile: "balanced", curiosity: 0.5, sensitivity: 0.5, resilience: 0.5 },
    memory: { events: [], autonomousMoments: 0, strongestTrace: 0 },
    consciousness: null,
    emotionEngine: null,
    totalNodeCount: () => 50,
    ...overrides
  };
}

function createMockEventBus() {
  const handlers = new Map();
  return {
    on(evt, fn) {
      if (!handlers.has(evt)) handlers.set(evt, []);
      handlers.get(evt).push(fn);
      return () => {
        const arr = handlers.get(evt);
        const idx = arr.indexOf(fn);
        if (idx >= 0) arr.splice(idx, 1);
      };
    },
    emit(evt, data) {
      const arr = handlers.get(evt);
      if (arr) arr.forEach(fn => fn(data));
    },
    _handlers: handlers
  };
}

// ─── Import ──────────────────────────────────────────────────────────

// Inline import via dynamic eval for test environment
import { SelfModelEngine } from '../simulation/consciousness/SelfModelEngine.js';

// ─── Tests ───────────────────────────────────────────────────────────

console.log('\n=== SelfModelEngine Integration Tests ===\n');

// ── 1. Construction & Initial State ──────────────────────────────────

test('Construction sets default state', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  assert(sm.selfModel.name === "NOVA", "Name should be NOVA");
  assert(sm.selfModel.state === "dormant", "Initial state should be dormant");
  assert(sm.selfModel.selfAwareness === 0, "Initial selfAwareness should be 0");
  assert(sm.selfModel.emotionalState === "neutral", "Initial emotionalState should be neutral");
  assert(sm.selfModel.sleepState === "WAKE", "Initial sleepState should be WAKE");
  assert(sm.selfModel.sleepCount === 0, "Initial sleepCount should be 0");
  assert(sm.selfModel.storyEcho === "", "Initial storyEcho should be empty");
  assert(sm.selfModel.storyEchoCount === 0, "Initial storyEchoCount should be 0");
  assert(sm.selfModel.emotionalValence === 0, "Initial emotionalValence should be 0");
  assert(sm.selfModel.reflections.length === 0, "Initial reflections should be empty");
  assert(sm.selfModel.emotionHistory.length === 0, "Initial emotionHistory should be empty");
});

test('Constructor subscribes to all events', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  const events = sim.events._handlers;
  assert(events.has("consciousness:ignition"), "Should subscribe to consciousness:ignition");
  assert(events.has("emergence:moment"), "Should subscribe to emergence:moment");
  assert(events.has("emotion:change"), "Should subscribe to emotion:change");
  assert(events.has("emotion:spike"), "Should subscribe to emotion:spike");
  assert(events.has("story:event"), "Should subscribe to story:event");
  assert(events.has("story:milestone"), "Should subscribe to story:milestone");
  assert(events.has("sleep:wakeUp"), "Should subscribe to sleep:wakeUp");
  assert(events.has("sleep:stateChange"), "Should subscribe to sleep:stateChange");
});

// ── 2. emotion:change ────────────────────────────────────────────────

test('emotion:change updates emotionalState and intensity', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:change", {
    from: "neutral", to: "joy", intensity: 0.6, timestamp: 10
  });

  assert(sm.selfModel.emotionalState === "joy", "emotionalState should be joy");
  assert(approxEqual(sm.selfModel.emotionalIntensity, 0.6), "emotionalIntensity should be 0.6");
});

test('emotion:change records emotion history', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:change", { from: "neutral", to: "joy", intensity: 0.5, timestamp: 5 });
  sim.events.emit("emotion:change", { from: "joy", to: "curiosity", intensity: 0.7, timestamp: 10 });

  assert(sm.selfModel.emotionHistory.length === 2, "Should have 2 emotion history entries");
  assert(sm.selfModel.emotionHistory[0].emotion === "joy", "First emotion should be joy");
  assert(sm.selfModel.emotionHistory[1].emotion === "curiosity", "Second emotion should be curiosity");
});

test('emotion:change updates emotional valence (positive)', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:change", { from: "neutral", to: "joy", intensity: 0.8, timestamp: 1 });

  assert(sm.selfModel.emotionalValence > 0, "Positive emotion should make valence positive");
  assert(approxEqual(sm.selfModel.emotionalValence, 0.3, 0.01), "First valence update should be 0.3 (0*0.7 + 1*0.3)");
});

test('emotion:change updates emotional valence (negative)', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:change", { from: "neutral", to: "fear", intensity: 0.8, timestamp: 1 });

  assert(sm.selfModel.emotionalValence < 0, "Negative emotion should make valence negative");
});

test('emotion:change with high intensity boosts selfAwareness', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);
  const initialAwareness = sm.selfModel.selfAwareness;

  sim.events.emit("emotion:change", { from: "neutral", to: "joy", intensity: 0.8, timestamp: 1 });

  assert(sm.selfModel.selfAwareness > initialAwareness, "High intensity emotion should boost selfAwareness");
  // boost = (0.8 - 0.5) * 0.04 = 0.012
  assert(approxEqual(sm.selfModel.selfAwareness, 0.012, 0.001), "Boost should be 0.012");
});

test('emotion:change with low intensity does not boost selfAwareness', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:change", { from: "neutral", to: "calm", intensity: 0.3, timestamp: 1 });

  assert(sm.selfModel.selfAwareness === 0, "Low intensity emotion should not boost selfAwareness");
});

test('emotion:change emotion history is capped', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  for (let i = 0; i < 25; i++) {
    sim.events.emit("emotion:change", { from: "x", to: "joy", intensity: 0.5, timestamp: i });
  }

  assert(sm.selfModel.emotionHistory.length <= 20, "Emotion history should be capped at 20");
});

// ── 3. emotion:spike ─────────────────────────────────────────────────

test('emotion:spike boosts selfAwareness significantly', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:spike", { emotion: "joy", intensity: 0.8, source: "test", timestamp: 5 });

  // boost = 0.8 * 0.06 = 0.048
  assert(approxEqual(sm.selfModel.selfAwareness, 0.048, 0.001), "Spike should boost selfAwareness by 0.048");
});

test('emotion:spike generates reflection', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:spike", { emotion: "wonder", intensity: 0.9, source: "test", timestamp: 5 });

  assert(sm.selfModel.lastEmotionSpike !== null, "lastEmotionSpike should be set");
  assert(sm.selfModel.lastEmotionSpike.emotion === "wonder", "Spike emotion should be wonder");
  assert(sm.selfModel.lastEmotionSpike.reflection.includes("Staunen"), "Reflection should contain 'Staunen'");
  assert(sm.selfModel.reflections.length === 1, "Should have 1 reflection");
  assert(sm.selfModel.reflections[0].trigger === "emotion:spike:wonder", "Reflection trigger should be emotion:spike:wonder");
});

test('emotion:spike emits selfmodel:narrative event', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  let narrativeReceived = false;
  sim.events.on("selfmodel:narrative", (d) => {
    narrativeReceived = true;
    assert(d.text.includes("Staunen"), "Narrative text should contain Staunen");
    assert(d.emotion === "wonder", "Narrative emotion should be wonder");
  });

  sim.events.emit("emotion:spike", { emotion: "wonder", intensity: 0.85, source: "test", timestamp: 5 });

  assert(narrativeReceived, "selfmodel:narrative should be emitted on spike");
});

test('emotion:spike negative emotion triggers recover goal', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:spike", { emotion: "fear", intensity: 0.8, source: "test", timestamp: 5 });

  assert(sm.selfModel.goals.includes("recover"), "Negative spike should add recover goal");
});

test('emotion:spike positive emotion triggers explore goal', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:spike", { emotion: "joy", intensity: 0.8, source: "test", timestamp: 5 });

  assert(sm.selfModel.goals.includes("explore"), "Positive spike should add explore goal");
});

test('emotion:spike for unknown emotion still generates reflection', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:spike", { emotion: "unknown_emo", intensity: 0.7, source: "test", timestamp: 5 });

  assert(sm.selfModel.lastEmotionSpike !== null, "lastEmotionSpike should be set");
  assert(sm.selfModel.lastEmotionSpike.reflection.includes("unknown_emo"), "Reflection should contain emotion name");
});

// ── 4. story:event ───────────────────────────────────────────────────

test('story:event increments storyEchoCount', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("story:event", {
    id: "story_0", timestamp: 5, text: "Erste Signale erkannt",
    emotion: "awakening", category: "minor"
  });

  assert(sm.selfModel.storyEchoCount === 1, "storyEchoCount should be 1");
});

test('story:event updates storyEcho text', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("story:event", {
    id: "story_0", timestamp: 5, text: "Erste Signale erkannt",
    emotion: "awakening", category: "minor"
  });

  assert(sm.selfModel.storyEcho.includes("Erste Signale"), "storyEcho should contain event text");
  assert(sm.selfModel.storyEcho.includes("Moment:"), "storyEcho should contain category prefix");
});

test('story:event stores lastStoryEvent', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  const event = {
    id: "story_1", timestamp: 10, text: "Cluster bilden sich",
    emotion: "wonder", category: "major"
  };
  sim.events.emit("story:event", event);

  assert(sm.selfModel.lastStoryEvent !== null, "lastStoryEvent should be set");
  assert(sm.selfModel.lastStoryEvent.id === "story_1", "lastStoryEvent id should match");
});

test('story:event boosts selfAwareness slightly', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("story:event", {
    id: "story_0", timestamp: 5, text: "Test",
    emotion: "growth", category: "minor"
  });

  assert(approxEqual(sm.selfModel.selfAwareness, 0.01, 0.001), "Story event should boost selfAwareness by 0.01");
});

test('story:event with loss emotion triggers recover goal', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("story:event", {
    id: "story_0", timestamp: 5, text: "Verlust",
    emotion: "loss", category: "major"
  });

  assert(sm.selfModel.goals.includes("recover"), "Loss story should add recover goal");
});

test('story:event with growth emotion triggers grow goal', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("story:event", {
    id: "story_0", timestamp: 5, text: "Wachstum",
    emotion: "growth", category: "major"
  });

  assert(sm.selfModel.goals.includes("grow"), "Growth story should add grow goal");
});

test('story:event echo buffer is capped', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  for (let i = 0; i < 10; i++) {
    sim.events.emit("story:event", {
      id: `story_${i}`, timestamp: i, text: `Event ${i}`,
      emotion: "calm", category: "minor"
    });
  }

  // Buffer should be capped at 5
  assert(sm._storyEchoBuffer.length === 5, "Story echo buffer should be capped at 5");
  assert(sm.selfModel.storyEchoCount === 10, "Total count should be 10");
});

// ── 5. story:milestone ───────────────────────────────────────────────

test('story:milestone boosts selfAwareness', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("story:milestone", {
    id: "story_5", timestamp: 20, text: "Bewusstsein entfacht",
    emotion: "transformation", category: "milestone"
  });

  assert(approxEqual(sm.selfModel.selfAwareness, 0.05, 0.001), "Milestone should boost selfAwareness by 0.05");
});

test('story:milestone adds to stateHistory with emotion', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("story:milestone", {
    id: "story_5", timestamp: 20, text: "Bewusstsein entfacht",
    emotion: "transformation", category: "milestone"
  });

  const lastEntry = sm.selfModel.stateHistory[sm.selfModel.stateHistory.length - 1];
  assert(lastEntry !== undefined, "stateHistory should have an entry");
  assert(lastEntry.type === "milestone", "Entry type should be milestone");
  assert(lastEntry.emotion === "transformation", "Entry emotion should be transformation");
});

test('story:milestone generates reflection', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("story:milestone", {
    id: "story_5", timestamp: 20, text: "Erwachen",
    emotion: "awakening", category: "milestone"
  });

  assert(sm.selfModel.reflections.length === 1, "Should have 1 reflection");
  assert(sm.selfModel.reflections[0].trigger === "story:milestone", "Trigger should be story:milestone");
  assert(sm.selfModel.reflections[0].text.includes("Wendepunkt"), "Reflection should contain 'Wendepunkt'");
});

test('story:milestone emits selfmodel:narrative', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  let received = false;
  sim.events.on("selfmodel:narrative", (d) => {
    received = true;
    assert(d.text.includes("Wendepunkt"), "Narrative should contain Wendepunkt");
  });

  sim.events.emit("story:milestone", {
    id: "story_5", timestamp: 20, text: "Erwachen",
    emotion: "awakening", category: "milestone"
  });

  assert(received, "selfmodel:narrative should be emitted");
});

// ── 6. sleep:wakeUp ──────────────────────────────────────────────────

test('sleep:wakeUp increments sleepCount', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("sleep:wakeUp", {
    duration: 15, consolidated: 5, drift: 0.05,
    identityStable: true, dreams: 2, creativeDreams: 0, epoch: 1
  });

  assert(sm.selfModel.sleepCount === 1, "sleepCount should be 1");
});

test('sleep:wakeUp accumulates consolidated count', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("sleep:wakeUp", { duration: 15, consolidated: 5, drift: 0.05, identityStable: true, dreams: 2, creativeDreams: 0, epoch: 1 });
  sim.events.emit("sleep:wakeUp", { duration: 15, consolidated: 3, drift: 0.02, identityStable: true, dreams: 1, creativeDreams: 0, epoch: 2 });

  assert(sm.selfModel.totalConsolidated === 8, "totalConsolidated should be 8");
});

test('sleep:wakeUp generates stable reflection', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("sleep:wakeUp", {
    duration: 15, consolidated: 5, drift: 0.05,
    identityStable: true, dreams: 2, creativeDreams: 0, epoch: 1
  });

  assert(sm.selfModel.lastSleepReflection !== "", "lastSleepReflection should be set");
  assert(sm.selfModel.lastSleepReflection.includes("geruht"), "Stable reflection should contain 'geruht'");
  assert(sm.selfModel.lastSleepReflection.includes("noch ich"), "Stable reflection should contain 'noch ich'");
});

test('sleep:wakeUp with high drift generates drift reflection', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("sleep:wakeUp", {
    duration: 15, consolidated: 5, drift: 0.3,
    identityStable: false, dreams: 1, creativeDreams: 0, epoch: 1
  });

  assert(sm.selfModel.lastSleepReflection.includes("verschoben"), "Drift reflection should contain 'verschoben'");
  assert(sm.selfModel.lastSleepReflection.includes("Drift"), "Drift reflection should contain 'Drift'");
});

test('sleep:wakeUp with creative dreams generates creative reflection', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("sleep:wakeUp", {
    duration: 15, consolidated: 5, drift: 0.05,
    identityStable: true, dreams: 3, creativeDreams: 2, epoch: 1
  });

  assert(sm.selfModel.lastSleepReflection.includes("geträumt"), "Creative reflection should contain 'geträumt'");
  assert(sm.selfModel.lastSleepReflection.includes("kreative"), "Creative reflection should contain 'kreative'");
});

test('sleep:wakeUp boosts selfAwareness', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("sleep:wakeUp", {
    duration: 15, consolidated: 5, drift: 0.05,
    identityStable: true, dreams: 2, creativeDreams: 0, epoch: 1
  });

  assert(approxEqual(sm.selfModel.selfAwareness, 0.03, 0.001), "WakeUp should boost selfAwareness by 0.03");
});

test('sleep:wakeUp with unstable identity adds integrate goal', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("sleep:wakeUp", {
    duration: 15, consolidated: 5, drift: 0.3,
    identityStable: false, dreams: 1, creativeDreams: 0, epoch: 1
  });

  assert(sm.selfModel.goals.includes("integrate"), "Unstable identity should add integrate goal");
});

test('sleep:wakeUp emits selfmodel:narrative', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  let received = false;
  sim.events.on("selfmodel:narrative", (d) => {
    received = true;
    assert(d.emotion === "calm", "Stable wakeup narrative emotion should be calm");
  });

  sim.events.emit("sleep:wakeUp", {
    duration: 15, consolidated: 5, drift: 0.05,
    identityStable: true, dreams: 2, creativeDreams: 0, epoch: 1
  });

  assert(received, "selfmodel:narrative should be emitted on wakeUp");
});

test('sleep:wakeUp with unstable identity emits tension emotion', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  let receivedEmotion = null;
  sim.events.on("selfmodel:narrative", (d) => {
    receivedEmotion = d.emotion;
  });

  sim.events.emit("sleep:wakeUp", {
    duration: 15, consolidated: 5, drift: 0.3,
    identityStable: false, dreams: 1, creativeDreams: 0, epoch: 1
  });

  assert(receivedEmotion === "tension", "Unstable wakeup should emit tension emotion");
});

// ── 7. sleep:stateChange ─────────────────────────────────────────────

test('sleep:stateChange updates sleepState', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("sleep:stateChange", { from: "WAKE", to: "NREM", epoch: 1 });
  assert(sm.selfModel.sleepState === "NREM", "sleepState should be NREM");

  sim.events.emit("sleep:stateChange", { from: "NREM", to: "REM", epoch: 1 });
  assert(sm.selfModel.sleepState === "REM", "sleepState should be REM");

  sim.events.emit("sleep:stateChange", { from: "REM", to: "WAKING_UP", epoch: 1 });
  assert(sm.selfModel.sleepState === "WAKING_UP", "sleepState should be WAKING_UP");

  sim.events.emit("sleep:stateChange", { from: "WAKING_UP", to: "WAKE", epoch: 1 });
  assert(sm.selfModel.sleepState === "WAKE", "sleepState should be WAKE");
});

test('getSleepStateLabel returns German label', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  assert(sm.getSleepStateLabel() === "wach", "WAKE label should be 'wach'");

  sim.events.emit("sleep:stateChange", { from: "WAKE", to: "NREM", epoch: 1 });
  assert(sm.getSleepStateLabel() === "ruhend", "NREM label should be 'ruhend'");

  sim.events.emit("sleep:stateChange", { from: "NREM", to: "REM", epoch: 1 });
  assert(sm.getSleepStateLabel() === "träumend", "REM label should be 'träumend'");
});

// ── 8. Narrative Generation with Emotion + Story ─────────────────────

test('Narrative includes emotion for active state', () => {
  const sim = createMockSim({
    world: {
      age: 10, edges: [...Array(100)].map(() => ({})),
      bridgeEdges: [...Array(10)].map(() => ({})),
      clusters: [
        { state: "active", activityMemory: 0.6 },
        { state: "active", activityMemory: 0.8 }
      ],
      growthStage: "activation",
      pulses: [], memoryFlashTimer: 0
    }
  });
  const sm = new SelfModelEngine(sim);

  // Set emotion
  sim.events.emit("emotion:change", { from: "neutral", to: "joy", intensity: 0.6, timestamp: 5 });

  // Trigger reflection cycle
  sm.update(6);

  assert(sm.selfModel.narrativeThread.includes("Freude") || sm.selfModel.narrativeThread.includes("joy"),
    "Narrative should contain emotion label");
});

test('Narrative includes story echo when available', () => {
  const sim = createMockSim({
    world: {
      age: 10, edges: [...Array(100)].map(() => ({})),
      bridgeEdges: [...Array(10)].map(() => ({})),
      clusters: [
        { state: "active", activityMemory: 0.6 },
        { state: "active", activityMemory: 0.8 }
      ],
      growthStage: "activation",
      pulses: [], memoryFlashTimer: 0
    }
  });
  const sm = new SelfModelEngine(sim);

  // Emit story event
  sim.events.emit("story:event", {
    id: "story_0", timestamp: 5, text: "Cluster bilden sich aus Chaos",
    emotion: "wonder", category: "major"
  });

  // Trigger reflection
  sm.update(6);

  assert(sm.selfModel.narrativeThread.includes("Cluster"), "Narrative should include story echo text");
});

test('Narrative does not include story echo in dormant state', () => {
  const sim = createMockSim({
    world: {
      age: 0, edges: [], bridgeEdges: [],
      clusters: [{ state: "dormant", activityMemory: 0 }],
      growthStage: "genesis",
      pulses: [], memoryFlashTimer: 0
    }
  });
  const sm = new SelfModelEngine(sim);

  // Emit story event
  sim.events.emit("story:event", {
    id: "story_0", timestamp: 0, text: "Test echo",
    emotion: "calm", category: "minor"
  });

  // Trigger reflection
  sm.update(6);

  assert(sm.selfModel.state === "dormant", "State should be dormant");
  assert(!sm.selfModel.narrativeThread.includes("Test echo"), "Dormant narrative should NOT include story echo");
});

// ── 9. Reflection API ────────────────────────────────────────────────

test('getReflections returns recent reflections', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:spike", { emotion: "joy", intensity: 0.8, timestamp: 1 });
  sim.events.emit("emotion:spike", { emotion: "fear", intensity: 0.7, timestamp: 2 });
  sim.events.emit("emotion:spike", { emotion: "wonder", intensity: 0.9, timestamp: 3 });

  const refs = sm.getReflections(2);
  assert(refs.length === 2, "Should return 2 reflections");
  assert(refs[1].trigger.includes("wonder"), "Last reflection should be wonder");
});

test('getLastReflection returns most recent', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  assert(sm.getLastReflection() === null, "No reflections initially");

  sim.events.emit("emotion:spike", { emotion: "joy", intensity: 0.8, timestamp: 1 });
  const last = sm.getLastReflection();
  assert(last !== null, "Should return reflection after spike");
  assert(last.trigger.includes("joy"), "Last reflection trigger should contain joy");
});

test('reflections are capped at max', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  for (let i = 0; i < 15; i++) {
    sim.events.emit("emotion:spike", { emotion: "calm", intensity: 0.7, timestamp: i });
  }

  assert(sm.selfModel.reflections.length <= 8, "Reflections should be capped at 8");
});

// ── 10. Serialization ────────────────────────────────────────────────

test('serialize includes extended fields', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emotion:change", { from: "neutral", to: "joy", intensity: 0.6, timestamp: 1 });
  sim.events.emit("sleep:wakeUp", { duration: 15, consolidated: 5, drift: 0.05, identityStable: true, dreams: 2, creativeDreams: 0, epoch: 1 });
  sim.events.emit("story:event", { id: "s0", timestamp: 2, text: "Test", emotion: "calm", category: "minor" });

  const data = sm.serialize();

  assert(data.emotionalState === "joy", "Serialized emotionalState should be joy");
  assert(data.sleepState === "WAKE", "Serialized sleepState should be WAKE");
  assert(data.sleepCount === 1, "Serialized sleepCount should be 1");
  assert(data.storyEchoCount === 1, "Serialized storyEchoCount should be 1");
  assert(data.emotionalValence > 0, "Serialized emotionalValence should be positive");
  assert(data.lastSleepReflection !== "", "Serialized lastSleepReflection should be set");
  assert(Array.isArray(data.reflections), "Serialized reflections should be an array");
});

// ── 11. Destroy / Cleanup ────────────────────────────────────────────

test('destroy unsubscribes all listeners', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  // Verify subscriptions exist
  const events = sim.events._handlers;
  assert(events.get("emotion:change")?.length === 1, "Should have 1 emotion:change listener");

  sm.destroy();

  assert(events.get("emotion:change")?.length === 0, "emotion:change listener should be removed");
  assert(events.get("emotion:spike")?.length === 0, "emotion:spike listener should be removed");
  assert(events.get("story:event")?.length === 0, "story:event listener should be removed");
  assert(events.get("story:milestone")?.length === 0, "story:milestone listener should be removed");
  assert(events.get("sleep:wakeUp")?.length === 0, "sleep:wakeUp listener should be removed");
  assert(events.get("sleep:stateChange")?.length === 0, "sleep:stateChange listener should be removed");
  assert(events.get("consciousness:ignition")?.length === 0, "consciousness:ignition listener should be removed");
  assert(events.get("emergence:moment")?.length === 0, "emergence:moment listener should be removed");
});

test('destroy is idempotent (safe to call twice)', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sm.destroy();
  // Should not throw
  sm.destroy();
  assert(true, "Double destroy should not throw");
});

// ── 12. Backward Compatibility ───────────────────────────────────────

test('consciousness:ignition still boosts selfAwareness', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("consciousness:ignition", {});

  assert(approxEqual(sm.selfModel.selfAwareness, 0.02, 0.001), "Ignition should boost by 0.02");
});

test('emergence:moment still boosts selfAwareness', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emergence:moment", { intensity: 0.5 });

  // boost = 0.5 * 0.08 = 0.04
  assert(approxEqual(sm.selfModel.selfAwareness, 0.04, 0.001), "Emergence should boost by 0.04");
});

test('emergence:moment adds emergence_response goal', () => {
  const sim = createMockSim();
  const sm = new SelfModelEngine(sim);

  sim.events.emit("emergence:moment", { intensity: 0.5 });

  assert(sm.selfModel.goals.includes("emergence_response"), "Should add emergence_response goal");
});

test('update() still computes complexity, coherence, phi', () => {
  const sim = createMockSim({
    world: {
      age: 10, edges: [...Array(100)].map(() => ({})),
      bridgeEdges: [...Array(10)].map(() => ({})),
      clusters: [
        { state: "active", activityMemory: 0.6 },
        { state: "active", activityMemory: 0.8 },
        { state: "active", activityMemory: 0.5 }
      ],
      growthStage: "activation",
      pulses: [], memoryFlashTimer: 0
    },
    memory: { events: [...Array(20)].map(() => ({})), autonomousMoments: 5, strongestTrace: 0.5 }
  });
  const sm = new SelfModelEngine(sim);

  sm.update(6);

  assert(sm.selfModel.complexity > 0, "Complexity should be > 0");
  assert(sm.selfModel.coherence > 0, "Coherence should be > 0");
  assert(sm.selfModel.phi >= 0, "Phi should be >= 0");
  assert(sm.selfModel.autonomy > 0, "Autonomy should be > 0");
});

test('update() derives state correctly', () => {
  const sim = createMockSim({
    world: {
      age: 10, edges: [...Array(200)].map(() => ({})),
      bridgeEdges: [...Array(30)].map(() => ({})),
      clusters: [
        { state: "active", activityMemory: 0.7 },
        { state: "active", activityMemory: 0.8 }
      ],
      growthStage: "integration",
      pulses: [], memoryFlashTimer: 0
    },
    memory: { events: [...Array(20)].map(() => ({})), autonomousMoments: 5, strongestTrace: 0.5 }
  });
  const sm = new SelfModelEngine(sim);

  // Set high self-awareness via events
  sim.events.emit("emergence:moment", { intensity: 1.0 });
  sim.events.emit("emergence:moment", { intensity: 1.0 });
  sim.events.emit("emergence:moment", { intensity: 1.0 });
  sim.events.emit("emergence:moment", { intensity: 1.0 });
  sim.events.emit("emergence:moment", { intensity: 1.0 });

  sm.update(6);

  assert(sm.selfModel.state !== "dormant", "State should not be dormant with high awareness");
});

test('update() prefers EmotionEngine over workspace for emotional state', () => {
  const mockEmotionEngine = {
    dominantEmotion: "curiosity",
    emotions: { curiosity: 0.65, joy: 0.3 }
  };
  const sim = createMockSim({
    emotionEngine: mockEmotionEngine,
    consciousness: {
      workspace: { state: { mood: "some_workspace_mood", totalSalience: 0.1 } }
    },
    world: {
      age: 10, edges: [...Array(100)].map(() => ({})),
      bridgeEdges: [...Array(10)].map(() => ({})),
      clusters: [{ state: "active", activityMemory: 0.6 }, { state: "active", activityMemory: 0.8 }],
      growthStage: "activation", pulses: [], memoryFlashTimer: 0
    }
  });
  const sm = new SelfModelEngine(sim);

  sm.update(6);

  assert(sm.selfModel.emotionalState === "curiosity", "Should use EmotionEngine dominant emotion");
  assert(approxEqual(sm.selfModel.emotionalIntensity, 0.65), "Should use EmotionEngine intensity");
});

test('update() falls back to workspace when EmotionEngine is null', () => {
  const sim = createMockSim({
    emotionEngine: null,
    consciousness: {
      workspace: { state: { mood: "curious", totalSalience: 0.4 } }
    },
    world: {
      age: 10, edges: [...Array(100)].map(() => ({})),
      bridgeEdges: [...Array(10)].map(() => ({})),
      clusters: [{ state: "active", activityMemory: 0.6 }, { state: "active", activityMemory: 0.8 }],
      growthStage: "activation", pulses: [], memoryFlashTimer: 0
    }
  });
  const sm = new SelfModelEngine(sim);

  sm.update(6);

  assert(sm.selfModel.emotionalState === "curious", "Should fall back to workspace mood");
  assert(approxEqual(sm.selfModel.emotionalIntensity, 0.4), "Should fall back to workspace salience");
});

test('goals use emotionalValence for recover (not string check)', () => {
  const sim = createMockSim({
    world: {
      age: 10, edges: [...Array(100)].map(() => ({})),
      bridgeEdges: [...Array(10)].map(() => ({})),
      clusters: [{ state: "active", activityMemory: 0.6 }, { state: "active", activityMemory: 0.8 }],
      growthStage: "activation", pulses: [], memoryFlashTimer: 0
    }
  });
  const sm = new SelfModelEngine(sim);

  // Push several negative emotions to make valence < -0.3
  sim.events.emit("emotion:change", { from: "neutral", to: "fear", intensity: 0.8, timestamp: 1 });
  sim.events.emit("emotion:change", { from: "fear", to: "distress", intensity: 0.7, timestamp: 2 });
  sim.events.emit("emotion:change", { from: "distress", to: "fear", intensity: 0.6, timestamp: 3 });

  sm.update(6);

  assert(sm.selfModel.emotionalValence < -0.3, "Valence should be < -0.3 after negative emotions");
  assert(sm.selfModel.goals.includes("recover"), "Should add recover goal based on valence");
});

// ── 13. Combined Integration Scenario ────────────────────────────────

test('Full scenario: emotion → story → sleep → reflection', () => {
  const sim = createMockSim({
    world: {
      age: 0, edges: [...Array(100)].map(() => ({})),
      bridgeEdges: [...Array(10)].map(() => ({})),
      clusters: [{ state: "active", activityMemory: 0.6 }, { state: "active", activityMemory: 0.8 }],
      growthStage: "activation", pulses: [], memoryFlashTimer: 0
    }
  });
  const sm = new SelfModelEngine(sim);

  // 1. Emotion spike
  sim.events.emit("emotion:spike", { emotion: "wonder", intensity: 0.85, timestamp: 5 });
  assert(sm.selfModel.reflections.length === 1, "1 reflection after spike");

  // 2. Story event
  sim.events.emit("story:event", {
    id: "s0", timestamp: 8, text: "Neue Verbindungen entstehen",
    emotion: "wonder", category: "major"
  });
  assert(sm.selfModel.storyEchoCount === 1, "1 story event");

  // 3. Story milestone
  sim.events.emit("story:milestone", {
    id: "s1", timestamp: 10, text: "Bewusstsein entfacht",
    emotion: "transformation", category: "milestone"
  });
  assert(sm.selfModel.reflections.length === 2, "2 reflections after milestone");

  // 4. Sleep cycle
  sim.events.emit("sleep:stateChange", { from: "WAKE", to: "NREM", epoch: 1 });
  assert(sm.selfModel.sleepState === "NREM", "Should be in NREM");

  sim.events.emit("sleep:stateChange", { from: "NREM", to: "REM", epoch: 1 });
  assert(sm.selfModel.sleepState === "REM", "Should be in REM");

  sim.events.emit("sleep:stateChange", { from: "REM", to: "WAKING_UP", epoch: 1 });
  sim.events.emit("sleep:wakeUp", {
    duration: 20, consolidated: 8, drift: 0.08,
    identityStable: true, dreams: 3, creativeDreams: 1, epoch: 1
  });
  assert(sm.selfModel.sleepCount === 1, "1 sleep cycle");
  assert(sm.selfModel.totalConsolidated === 8, "8 consolidated");
  assert(sm.selfModel.reflections.length === 3, "3 reflections after sleep");

  // 5. Reflection cycle
  sm.update(6);

  // Narrative should be enriched
  assert(sm.selfModel.narrativeThread.length > 0, "Narrative should be non-empty");
  assert(sm.selfModel.selfAwareness > 0.1, "SelfAwareness should be significant after all events");

  // Verify reflections API
  const recent = sm.getReflections(5);
  assert(recent.length === 3, "Should have 3 reflections total");
});

// ── Summary ──────────────────────────────────────────────────────────

console.log('\n═══════════════════════════════════════════════════════════');
console.log(`  Results: ${passed} passed, ${failed} failed`);
if (failures.length > 0) {
  console.log('\n  Failures:');
  failures.forEach(f => console.log(`    • ${f}`));
}
console.log('═══════════════════════════════════════════════════════════\n');

process.exit(failed > 0 ? 1 : 0);
