# Neuro Nexus

A living neural network simulation with consciousness, memory, emotion, and self-awareness systems.

## Quick Start

```bash
python3 start.py
# → http://localhost:8080
# → http://localhost:8080?debug=true  (debug overlay)
```

## Project Structure

```
neuro-nexus/
├── index.html
├── src/
│   ├── main.js                 Bootstrap entry
│   ├── app.js                  App factory (Core, HUD, Worker, Resize)
│   ├── config.js               Global configuration
│   ├── persistence.js          Save/load state
│   ├── viewport.js             Viewport utilities
│   ├── debug-bootstrap.js      Debug mode loader (?debug=true)
│   │
│   ├── styles/                 ← All CSS in one place
│   │   ├── base.css            CSS reset, theme variables, canvas base
│   │   ├── debug.css           Debug overlay styles
│   │   ├── hud.css             Aggregator — @imports all HUD layers
│   │   ├── hud-base/           Glass-panel, sidebar, widgets shell
│   │   ├── hud-structure/      Glance-bar, tabs, dock, game menu
│   │   ├── hud-v14/            v14 design tokens & component styles
│   │   ├── hud-v15/            v15 layout overhaul
│   │   └── hud-v16/            v16 Nova — active final layer
│   │
│   ├── audio/
│   │   └── AmbientAudio.js
│   │
│   ├── content/
│   │   └── narrative.js
│   │
│   ├── diagnostics/
│   │   ├── DiagnosticsRecorder.js
│   │   ├── TelemetryCollector.js
│   │   ├── SnapshotProvider.js
│   │   ├── DebugOverlay.js
│   │   └── DebugControls.js
│   │
│   ├── input/
│   │   ├── PointerController.js
│   │   └── GestureRecognizer.js
│   │
│   ├── render/
│   │   ├── CanvasRenderer.js
│   │   ├── RenderState.js
│   │   └── layers/             Per-layer canvas renderers
│   │
│   ├── simulation/
│   │   ├── NeuroSimulation.js  Main simulation class
│   │   ├── SimulationLoop.js   RAF loop
│   │   ├── SimulationWorker.js Web Worker entry
│   │   ├── WorkerManager.js    Worker bridge
│   │   ├── systemFactory.js    Wires all systems together
│   │   ├── EventBus.js
│   │   ├── SpatialGrid.js
│   │   ├── CameraController.js
│   │   ├── EdgeManager.js
│   │   ├── InteractionHandler.js
│   │   ├── identity.js / memory.js / personality.js
│   │   ├── dnaArchetypes.js / clusterRoles.js / clusterMetrics.js
│   │   ├── growthStages.js / growthScheduler.js
│   │   ├── entities/           Node, Edge, Cluster data models
│   │   ├── consciousness/      Higher-order cognitive systems
│   │   └── systems/            Domain-specific systems (see below)
│   │       ├── emotion/        index.js + EmotionEngine, Appraiser, Modulation, Mood
│   │       ├── memory/         index.js + Episodic, Autobiographical, Echo
│   │       ├── narrative/      index.js + NarrativeGenerator, StoryMapping, Chapters
│   │       ├── sleep/          index.js + SleepCycle, DreamEngine
│   │       ├── network/        index.js + NetworkBuilder, Pruning, Bridge, Cluster
│   │       ├── lifecycle/      index.js + LifecycleLoop, Heartbeat, Growth, UpdateLoop
│   │       ├── emergence/      index.js + EmergenceSystem, Detector
│   │       ├── energy/         index.js + EnergyModel, PulseEngine, Reward, Signal
│   │       └── external/       index.js + ExternalStimuli, MultiAgent, Scars
│   │
│   ├── ui/
│   │   ├── ConsciousnessHUD.js
│   │   ├── HudPanel.js
│   │   ├── HudDataUpdater.js
│   │   ├── HudFrameLoop.js
│   │   ├── HudDomMap.js
│   │   ├── HudWidgetManager.js
│   │   ├── HudNavigationController.js
│   │   ├── HudSelfModel.js
│   │   ├── HudEventDetector.js
│   │   ├── ObserverMode.js
│   │   ├── ResonanceLabel.js
│   │   ├── TooltipSystem.js
│   │   ├── DataExchange.js
│   │   ├── hudConstants.js / hudUtils.js
│   │   ├── constants/          UI constants (colors, labels, tooltips)
│   │   ├── controllers/        Menu, Settings, Drawer, Tabs, Dock
│   │   └── updaters/           Per-metric DOM updaters
│   │       ├── BaseUpdater.js
│   │       ├── registry.js
│   │       ├── consciousness/  index.js + 10 updaters
│   │       ├── memory/         index.js + EchoMemory, MemoryRings
│   │       ├── emotion/        index.js + Emotion, DnaArchetype
│   │       ├── vitals/         index.js + Vitality, Energy, Glance, Ticker…
│   │       ├── widgets/        index.js + Gauge, Heatmap, PhaseArc
│   │       └── nav/            index.js + NavPanel, Telemetry
│   │
│   ├── utils/
│   │   ├── math.js
│   │   └── random.js
│   │
│   └── widgets/                Canvas-based widget components
│       ├── BaseWidget.js
│       └── ...13 widgets
│
├── tests/                      Unit tests (not loaded at runtime)
└── docs/                       Architecture & HUD documentation
```

## CSS Architecture

All CSS lives in `src/styles/`. Entry point for HTML: `styles/base.css` + `styles/hud.css`.

`hud.css` loads all HUD layers in cascade order:

| Layer | Folder | Files |
|-------|--------|-------|
| Basis | `hud-base/` | hud-base, hud-widgets, hud-sidebar-core/features/mobile |
| Struktur | `hud-structure/` | glance-tabs, dock-ticker, nova-gamemenu, overlays-protocol, extensions |
| v14 Design | `hud-v14/` | tokens, sidebar, widgets, dock, gamemenu, consistency |
| v15 Layout | `hud-v15/` | global, tabs, misc |
| v16 Nova *(final)* | `hud-v16/` | tokens, base, sidebar, components, responsive |

## Simulation Systems

Each domain in `src/simulation/systems/` has an `index.js` barrel export:

```js
import { EmotionEngine, MoodStateMachine } from './systems/emotion/index.js';
import { SleepCycle }                      from './systems/sleep/index.js';
```

## HUD Updaters

Each updater group in `src/ui/updaters/` has an `index.js` barrel export:

```js
import { ConsciousnessStateUpdater, PhiUpdater } from './updaters/consciousness/index.js';
import { EmotionUpdater }                        from './updaters/emotion/index.js';
```
