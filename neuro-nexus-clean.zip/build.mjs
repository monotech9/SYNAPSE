#!/usr/bin/env node
/**
 * NeuroNexus Build System
 * Bundling, Minification, Tree-Shaking, Source Maps
 */

import esbuild from 'esbuild';
import { visualizer } from 'esbuild-plugin-visualizer';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Parse CLI arguments
const args = process.argv.slice(2);
const isProduction = args.includes('--minify');
const shouldAnalyze = args.includes('--analyze');
const shouldWatch = args.includes('--watch');

const buildConfig = {
  entryPoints: ['src/main.js'],
  bundle: true,
  minify: isProduction,
  sourcemap: !isProduction ? 'linked' : false,
  outfile: 'dist/app.js',
  target: ['es2020'],
  format: 'esm',
  platform: 'browser',
  splitting: false,
  logLevel: 'info',
  external: [],
  define: {
    'process.env.NODE_ENV': `"${isProduction ? 'production' : 'development'}"`,
    'process.env.VERSION': `"${JSON.stringify(require('./package.json').version)}"`,
  },
  plugins: shouldAnalyze
    ? [
        visualizer({
          open: true,
          title: 'NeuroNexus Bundle Analysis',
        }),
      ]
    : [],
  // Optimizations
  treeShaking: true,
  drop: isProduction ? ['console', 'debugger'] : [],
};

async function build() {
  try {
    // Ensure dist directory exists
    if (!fs.existsSync('dist')) {
      fs.mkdirSync('dist', { recursive: true });
    }

    // Copy HTML
    fs.copyFileSync('index.html', 'dist/index.html');

    // Copy styles
    if (fs.existsSync('src/styles')) {
      const stylesPath = 'dist/styles';
      if (!fs.existsSync(stylesPath)) fs.mkdirSync(stylesPath, { recursive: true });
      
      // Recursively copy styles
      const copyDir = (src, dest) => {
        fs.readdirSync(src).forEach((file) => {
          const srcPath = path.join(src, file);
          const destPath = path.join(dest, file);
          if (fs.statSync(srcPath).isDirectory()) {
            if (!fs.existsSync(destPath)) fs.mkdirSync(destPath);
            copyDir(srcPath, destPath);
          } else {
            fs.copyFileSync(srcPath, destPath);
          }
        });
      };
      copyDir('src/styles', stylesPath);
    }

    // Main bundle
    console.log(`\n🔨 Building NeuroNexus ${isProduction ? 'PRODUCTION' : 'DEVELOPMENT'}...`);
    const result = await esbuild.build(buildConfig);

    // Bundle stats
    if (result.metafile) {
      const outputs = result.metafile.outputs;
      const appJs = outputs['dist/app.js'];
      if (appJs) {
        const bytes = appJs.bytes;
        const kb = (bytes / 1024).toFixed(2);
        console.log(`✅ Built: dist/app.js (${kb} KB)`);
      }
    }

    // Copy worker if exists
    if (fs.existsSync('src/simulation/SimulationWorker.js')) {
      await esbuild.build({
        entryPoints: ['src/simulation/SimulationWorker.js'],
        bundle: true,
        minify: isProduction,
        outfile: 'dist/worker.js',
        target: ['es2020'],
        format: 'esm',
        platform: 'browser',
      });
      console.log(`✅ Built: dist/worker.js (worker)`);
    }

    console.log(`\n✨ Build complete! ${isProduction ? '[MINIFIED]' : '[DEV]'}`);

    if (shouldAnalyze) {
      console.log('📊 Bundle analysis opened in browser...');
    }
  } catch (error) {
    console.error('❌ Build failed:', error.message);
    process.exit(1);
  }
}

// Watch mode
if (shouldWatch) {
  const ctx = await esbuild.context(buildConfig);
  await ctx.watch();
  console.log('👀 Watching for changes...');
} else {
  await build();
}
