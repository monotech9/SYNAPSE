/**
 * app.js — Modularer Bootstrap für Neuro Nexus.
 *
 * Aufgeteilt in einzelne Bootstrap-Funktionen für Testbarkeit:
 *  - bootstrapCore()       : Canvas, Simulation, Renderer, Input, Audio
 *  - bootstrapHud()        : HUD-Panel, Telemetrie, Observer-Mode, Anti-FOUC
 *  - bootstrapWorker()     : Optionaler Web Worker
 *  - bootstrapAccessibility: prefers-reduced-motion
 *  - bootstrapResize()     : Viewport-Resize-Handling
 *  - bootstrapPersistence(): Save/Load Lifecycle
 *  - createFrameLoop()     : Zentrale rAF-Loop
 */

import { PointerController } from "./input/PointerController.js";
import { CanvasRenderer } from "./render/CanvasRenderer.js";
import { NeuroSimulation } from "./simulation/NeuroSimulation.js";
import { SimulationLoop } from "./simulation/SimulationLoop.js";
import { readViewport, resizeCanvas } from "./viewport.js";
import { CONFIG } from "./config.js";
import { AmbientAudio } from "./audio/AmbientAudio.js";
import { WorkerManager } from "./simulation/WorkerManager.js";
import { ResonanceLabel } from "./ui/ResonanceLabel.js";
import { TelemetryCollector } from "./diagnostics/TelemetryCollector.js";
import { ObserverMode } from "./ui/ObserverMode.js";
import { HudPanel } from "./ui/HudPanel.js";

export function createNeuroNexusApp(options = {}) {
  const canvas = document.getElementById("neuroCanvas");
  const signatureElement = document.getElementById("signature");
  const context = canvas?.getContext("2d", { alpha: true });

  if (!canvas || !signatureElement || !context) {
    throw new Error("Neuro Nexus konnte Canvas oder UI-Elemente nicht initialisieren.");
  }

  preventIosBrowserGestures();

  const core = bootstrapCore(canvas, context, signatureElement);
  const { simulation, renderer, pointerController, audio, simLoop } = core;

  const hud = bootstrapHud(simulation, simLoop, options);
  const { hudPanel, telemetry, observerMode } = hud;

  const worker = bootstrapWorker(simulation, audio);

  bootstrapAccessibility(simulation);

  const resize = bootstrapResize(canvas, context, simulation, worker);

  bootstrapPersistence(simulation, worker);

  const speedFactor = readSpeedFactor();

  const frameLoop = createFrameLoop({
    simLoop, renderer, resonanceLabel: hud.resonanceLabel,
    telemetry, hudPanel, observerMode,
    speedFactor, options, simulation, worker
  });

  resize();
  simulation.ensureClusters();

  const app = {
    canvas, context, simulation, renderer, pointerController, audio,
    workerManager: worker.manager, simLoop, telemetry, observerMode,
    hudPanel, heartbeat: simulation.heartbeatSystem,
    resize, stop() {
      frameLoop.stop();
      if (worker.manager.enabled) worker.manager.terminate();
    }
  };

  if (typeof options.afterCreate === "function") {
    options.afterCreate(app);
  }

  frameLoop.start();

  return app;
}


function bootstrapCore(canvas, context, signatureElement) {
  const simulation = new NeuroSimulation();
  const renderer = new CanvasRenderer(simulation, context, signatureElement);
  const pointerController = new PointerController(canvas, simulation);
  const audio = new AmbientAudio(simulation);
  simulation.audio = audio;
  const simLoop = new SimulationLoop(simulation, { hz: 30 });
  return { simulation, renderer, pointerController, audio, simLoop };
}

function bootstrapHud(simulation, simLoop, options) {
  const resonanceLabel = new ResonanceLabel();
  const telemetry = new TelemetryCollector(simulation, simLoop);
  // telemetry.mountPanel() — floating panel entfernt, Telemetrie ist jetzt im Game-Menu

  const observerMode = new ObserverMode({
    onActivate: () => {
      if (simulation.audio?.enabled) simulation.audio.playObserverModeEnter?.();
    }
  });

  const hudPanel = new HudPanel(simulation, telemetry, observerMode);
  try {
    hudPanel.start();
  } catch (startErr) {
    console.error("[Neuro Nexus] HUD-Initialisierung fehlgeschlagen:", startErr);
  }
  // is-ready IMMER setzen — selbst bei start()-Fehler soll der HUD sichtbar sein
  const wrapper = document.querySelector(".hud-wrapper");
  if (wrapper) wrapper.classList.add("is-ready");
  const drawerToggle = document.getElementById("drawerToggle");
  if (drawerToggle) drawerToggle.classList.add("is-ready");

  return { hudPanel, telemetry, observerMode, resonanceLabel };
}

function bootstrapWorker(simulation, audio) {
  const manager = new WorkerManager();
  let initialized = false;

  const useWorker = (() => {
    try {
      const params = new URLSearchParams(location.search);
      return params.get("worker") === "1" && typeof Worker !== "undefined";
    } catch { return false; }
  })();

  if (useWorker) {
    const workerUrl = new URL("./simulation/SimulationWorker.js", import.meta.url).href;
    manager.init(workerUrl).then((ok) => {
      if (ok) {
        manager.sendInit({
          seed: simulation.persistentState.seed,
          rngState: simulation.rng.getState(),
          identity: simulation.identity,
          memory: simulation.memory,
          growth: simulation.world.growthStage,
          age: simulation.world.age
        });
        manager.onStageChange((event) => {
          if (audio.enabled) audio.playStageTransition(event);
        });
        initialized = true;
        console.info("[Neuro Nexus] Web Worker aktiv — Simulation läuft im Background-Thread.");
      }
    });
  }

  return {
    manager,
    get initialized() { return initialized; },
    get ready() { return initialized && manager.ready; }
  };
}

function bootstrapAccessibility(simulation) {
  const reduceMotion = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduceMotion) {
    simulation.personality = Object.freeze({
      ...simulation.personality,
      driftMultiplier: 0,
      spontaneousEnergyMultiplier: simulation.personality.spontaneousEnergyMultiplier * 0.4,
      pulseSpeedMultiplier: simulation.personality.pulseSpeedMultiplier * 0.6
    });
    CONFIG.ambientSignalMax = 0.3;
    CONFIG.ambientSignalMin = 2.5;
    console.info("[Neuro Nexus] prefers-reduced-motion erkannt — Animationen reduziert.");
  }
}

function bootstrapResize(canvas, context, simulation, worker) {
  function resize() {
    const viewport = readViewport();
    resizeCanvas(canvas, context, viewport);
    simulation.resize(viewport.width, viewport.height, viewport.dpr);
    if (worker.ready) {
      worker.manager.sendResize(viewport.width, viewport.height, viewport.dpr);
    }
  }
  window.addEventListener("resize", resize, { passive: true });
  if (window.visualViewport) {
    window.visualViewport.addEventListener("resize", resize, { passive: true });
  }
  return resize;
}

function bootstrapPersistence(simulation, worker) {
  function saveState() {
    if (worker.ready) worker.manager.save();
    simulation.save();
  }
  window.addEventListener("beforeunload", saveState);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) saveState();
  });
  window.addEventListener("pagehide", saveState);
}

function readSpeedFactor() {
  try {
    const params = new URLSearchParams(location.search);
    const raw = Number(params.get("speed") || "1");
    return raw > 0 && raw <= 16 ? raw : 1;
  } catch { return 1; }
}

function createFrameLoop({ simLoop, renderer, resonanceLabel, telemetry, hudPanel, observerMode, speedFactor, options, simulation }) {
  let previousTime = performance.now();
  let rafId = 0;
  let frameErrorCount = 0;

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      simLoop.reset();
      previousTime = performance.now();
    }
  });

  function frame(now) {
    try {
      const frameMs = now - previousTime;
      const realDt = Math.max(0, Math.min(frameMs / 1000, 0.1)) * speedFactor;
      previousTime = now;

      simLoop.advance(realDt);

      const timeSeconds = now / 1000;
      renderer.render(timeSeconds);
      resonanceLabel.update(now, simulation);

      telemetry.onFrame(now, frameMs);
      hudPanel.onFrame(now, frameMs);
      observerMode.update(realDt);

      if (typeof options.onFrame === "function") {
        options.onFrame({ now, frameMs, realDt, timeSeconds, simulation, renderer, simLoop, telemetry });
      }
    } catch (err) {
      frameErrorCount += 1;
      const msg = err?.message || String(err);
      const stack = err?.stack || "(kein Stack)";
      console.error("Neuro Nexus frame error #" + frameErrorCount + ":", msg, "\nStack:", stack);
      // Nach 3 Fehlern stoppen — nicht 10x den Main-Thread blockieren
      if (frameErrorCount >= 3) {
        console.error("Neuro Nexus: Frame-Fehler Limit erreicht — Animation gestoppt. HUD bleibt bedienbar.");
        // HUD sichtbar lassen auch wenn Animation stoppt
        const wrapper = document.querySelector(".hud-wrapper");
        if (wrapper) wrapper.classList.add("is-ready");
        const dt = document.getElementById("drawerToggle");
        if (dt) dt.classList.add("is-ready");
        return;
      }
    }
    rafId = requestAnimationFrame(frame);
  }

  return {
    start() { rafId = requestAnimationFrame(frame); },
    stop() { if (rafId) cancelAnimationFrame(rafId); rafId = 0; }
  };
}

function preventIosBrowserGestures() {
  const prevent = (event) => event.preventDefault();
  document.addEventListener("gesturestart", prevent, { passive: false });
  document.addEventListener("gesturechange", prevent, { passive: false });
  document.addEventListener("gestureend", prevent, { passive: false });
}
