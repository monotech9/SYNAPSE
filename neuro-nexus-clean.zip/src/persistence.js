import { clamp, hashString } from "./utils/math.js";
import { CONFIG, FORCE_FRESH_SESSION_KEY, LEGACY_STORAGE_KEYS, STORAGE_KEY } from "./config.js";

const DIAGNOSTIC_STORAGE_KEYS = [
  "neuroNexus:lastDiagnosticsReport",
  "neuro-nexus-diagnostics.lastReport",
  "neuro-nexus:lastDiagnosticsReport"
];

export function createInitialState() {
  // Seed-Sharing: ?seed=12345 in der URL reproduziert ein spezifisches Netzwerk
  const urlSeed = (() => {
    try {
      const params = new URLSearchParams(globalThis.location?.search || "");
      const raw = params.get("seed");
      return raw ? Number(raw) >>> 0 : null;
    } catch { return null; }
  })();

  const seedSource =
    urlSeed !== null
      ? String(urlSeed)
      : globalThis.crypto && globalThis.crypto.getRandomValues
        ? String(globalThis.crypto.getRandomValues(new Uint32Array(1))[0])
        : String(Date.now() + Math.random());

  return {
    seed: urlSeed !== null ? urlSeed : hashString(seedSource),
    accumulatedAge: 0,
    createdAt: Date.now(),
    lastSeenAt: Date.now(),
    interactionCount: 0,
    rngState: null,
    identity: null,
    memory: null,
    growth: null,
    relationship: null
  };
}

export function loadPersistentState() {
  try {
    if (globalThis.NEURO_NEXUS_DEBUG_LAB) {
      clearNeuroNexusStorage();
      return createInitialState();
    }

    if (shouldForceFreshStart()) {
      clearNeuroNexusStorage();
      consumeFreshStartFlag();
      return createInitialState();
    }

    const raw = readStoredState();
    if (!raw) return createInitialState();

    const parsed = JSON.parse(raw);

    if (
      typeof parsed !== "object" ||
      parsed === null ||
      typeof parsed.seed !== "number" ||
      typeof parsed.accumulatedAge !== "number"
    ) {
      return createInitialState();
    }

    const offlineSeconds = clamp((Date.now() - Number(parsed.lastSeenAt || Date.now())) / 1000, 0, 30);

    return {
      seed: parsed.seed >>> 0,
      accumulatedAge: clamp(parsed.accumulatedAge + offlineSeconds * 0.04, 0, CONFIG.maturitySeconds),
      createdAt: Number(parsed.createdAt || Date.now()),
      lastSeenAt: Date.now(),
      interactionCount: Number(parsed.interactionCount || 0),
      rngState: Number.isFinite(parsed.rngState) ? (parsed.rngState >>> 0) : null,
      identity: typeof parsed.identity === "object" && parsed.identity !== null ? parsed.identity : null,
      memory: typeof parsed.memory === "object" && parsed.memory !== null ? parsed.memory : null,
      growth: typeof parsed.growth === "object" && parsed.growth !== null ? parsed.growth : null,
      relationship: typeof parsed.relationship === "object" && parsed.relationship !== null ? parsed.relationship : null
    };
  } catch {
    return createInitialState();
  }
}

export function savePersistentState(persistentState, age, identity, memory, growth, relationship = null) {
  try {
    if (globalThis.NEURO_NEXUS_SKIP_SAVE || globalThis.NEURO_NEXUS_DEBUG_NO_PERSIST || globalThis.NEURO_NEXUS_DEBUG_LAB) return;

    persistentState.accumulatedAge = age;
    persistentState.lastSeenAt = Date.now();
    persistentState.identity = identity;
    persistentState.memory = memory;
    persistentState.growth = growth;
    persistentState.relationship = relationship;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(persistentState));
    removeLegacyStorageKeys();
  } catch {
    // Simulation bleibt auch ohne localStorage funktionsfähig.
  }
}

export function resetPersistentState() {
  try {
    globalThis.NEURO_NEXUS_SKIP_SAVE = true;
    markFreshStartForNextLoad();
    clearNeuroNexusStorage();
  } catch {
    // Reset bleibt best-effort, falls localStorage blockiert ist.
  }
}

function clearNeuroNexusStorage() {
  if (globalThis.NEURO_NEXUS_DEBUG_FRESH_BOOT || globalThis.NEURO_NEXUS_FORCE_FRESH_START) {
    hardClearStorage(localStorage);
    hardClearStorage(sessionStorage, { keepForceFreshFlag: true });
    return;
  }

  removeKnownStorageKeys();
  removeMatchingNeuroNexusKeys(localStorage);
  removeMatchingNeuroNexusKeys(sessionStorage, { keepForceFreshFlag: true });
}

function markFreshStartForNextLoad() {
  try {
    sessionStorage.setItem(FORCE_FRESH_SESSION_KEY, String(Date.now()));
  } catch {
    // Session storage ist optional.
  }
}

function shouldForceFreshStart() {
  try {
    if (globalThis.NEURO_NEXUS_FORCE_FRESH_START) return true;

    const url = new URL(globalThis.location?.href || "http://localhost/");
    if (url.searchParams.get("freshStart") === "1") return true;
    if (url.searchParams.get("reset") === "1") return true;

    return sessionStorage.getItem(FORCE_FRESH_SESSION_KEY) !== null;
  } catch {
    return false;
  }
}

function consumeFreshStartFlag() {
  try {
    sessionStorage.removeItem(FORCE_FRESH_SESSION_KEY);
  } catch {
    // Optional.
  }
}

function readStoredState() {
  const current = localStorage.getItem(STORAGE_KEY);
  if (current) return current;

  for (const key of LEGACY_STORAGE_KEYS) {
    const legacy = localStorage.getItem(key);
    if (legacy) return legacy;
  }

  return null;
}

function removeKnownStorageKeys() {
  localStorage.removeItem(STORAGE_KEY);

  for (const key of LEGACY_STORAGE_KEYS) {
    localStorage.removeItem(key);
  }

  for (const key of DIAGNOSTIC_STORAGE_KEYS) {
    localStorage.removeItem(key);
  }
}

function removeLegacyStorageKeys() {
  for (const key of LEGACY_STORAGE_KEYS) {
    localStorage.removeItem(key);
  }
}

function hardClearStorage(storage, options = {}) {
  if (!storage) return;

  const keepForceFreshFlag = options.keepForceFreshFlag === true;
  const freshValue = keepForceFreshFlag ? storage.getItem(FORCE_FRESH_SESSION_KEY) : null;

  try {
    storage.clear();
  } catch {
    const keys = [];
    for (let index = 0; index < storage.length; index += 1) {
      const key = storage.key(index);
      if (key) keys.push(key);
    }
    for (const key of keys) {
      storage.removeItem(key);
    }
  }

  if (keepForceFreshFlag && freshValue !== null) {
    try { storage.setItem(FORCE_FRESH_SESSION_KEY, freshValue); } catch { /* optional */ }
  }
}

function removeMatchingNeuroNexusKeys(storage, options = {}) {
  if (!storage) return;

  const keepForceFreshFlag = options.keepForceFreshFlag === true;
  const keys = [];

  for (let index = 0; index < storage.length; index += 1) {
    const key = storage.key(index);
    if (!key) continue;

    const normalized = key.toLowerCase();
    const isNeuroNexusKey =
      normalized.includes("neuro-nexus") ||
      normalized.includes("neuronexus") ||
      normalized.includes("neuro nexus");

    if (!isNeuroNexusKey) continue;
    if (keepForceFreshFlag && key === FORCE_FRESH_SESSION_KEY) continue;

    keys.push(key);
  }

  for (const key of keys) {
    storage.removeItem(key);
  }
}
