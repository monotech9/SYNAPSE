import { CLUSTER_TYPES } from "../../config.js";
import { ClusterStates } from "../../simulation/clusterRoles.js";
import { clamp, lerp, rgba } from "../../utils/math.js";
import { blendRgb } from "./BackgroundRenderer.js";
import { MemoryFilamentRenderer } from "./MemoryFilamentRenderer.js";

/**
 * EdgeRenderer — zeichnet Kanten in zwei Passen (base + glow).
 *
 * Memory-Filamente und der preferred-edge Cache liegen im
 * MemoryFilamentRenderer, der vom CanvasRenderer nach den
 * Base-Passen aufgerufen wird.
 */
export class EdgeRenderer {
  constructor(renderer) {
    this.renderer = renderer;
    this.memoryFilaments = new MemoryFilamentRenderer(renderer);
  }

  get ctx() { return this.renderer.ctx; }
  get simulation() { return this.renderer.simulation; }

  drawEdges(timeSeconds) {
    const { ctx } = this;
    const preferredEdges = this.memoryFilaments.getPreferredEdgeStrengths();

    ctx.save();
    ctx.lineCap = "round";

    const edgeData = this._collectEdgeData(timeSeconds, preferredEdges);

    // Pass 1: Base Edges (source-over)
    for (const data of edgeData) {
      this._drawBaseEdge(data, timeSeconds);
    }

    // Pass 2: Glowing Edges (lighter)
    ctx.globalCompositeOperation = "lighter";
    for (const data of edgeData) {
      this._drawGlowEdge(data, timeSeconds);
    }

    ctx.restore();
  }

  _collectEdgeData(timeSeconds, preferredEdges) {
    const edgeData = [];

    for (const edge of this.simulation.world.edges) {
      const edgeBirth = edge.birthEase();
      const nodeBirth = Math.min(edge.a.birthEase(), edge.b.birthEase());
      const birth = edgeBirth * nodeBirth;

      if (birth <= 0.01) continue;

      const a = this.simulation.getCachedNodePosition(edge.a, timeSeconds);
      const b = this.simulation.getCachedNodePosition(edge.b, timeSeconds);
      const typeConfig = CLUSTER_TYPES[edge.dominantType()];

      const activity = clamp((edge.a.activation + edge.b.activation) * 0.5, 0, 1);
      const visualActivity = clamp(edge.activityGlow ?? edge.visualActivity ?? 0, 0, 1);
      const visibleActivity = Math.max(activity, visualActivity * 0.78);

      const drawEnd = {
        x: lerp(a.x, b.x, birth),
        y: lerp(a.y, b.y, birth)
      };

      const trace = clamp(edge.traceGlow ?? edge.identityTrace ?? 0, 0, 1);
      const pathStrength = preferredEdges.get(edge) || 0;
      const pathPulseGlow = clamp(edge.pathGlow ?? edge.pathPulseGlow ?? 0, 0, 1);
      const traceGlow = pathStrength > 0 ? trace : trace * 0.22;

      let ageFade = 1;
      if (this.simulation.world.age > 120 && trace < 0.08 && !edge.bridge && edge.dominantType() !== "memory") {
        ageFade = Math.max(0.1, trace / 0.08);
      }

      const stateAlpha = (edge.a.cluster.state === ClusterStates.DORMANT || edge.b.cluster.state === ClusterStates.DORMANT ? 0.48 : 1) * ageFade;
      const seedlingBoost = edge.a.cluster.state === ClusterStates.SEEDLING || edge.b.cluster.state === ClusterStates.SEEDLING ? 0.82 : 1;

      edgeData.push({
        edge, a, drawEnd, birth, typeConfig,
        visibleActivity, traceGlow, visualActivity, pathPulseGlow,
        pathStrength, stateAlpha, seedlingBoost
      });
    }

    return edgeData;
  }

  _drawBaseEdge(data, timeSeconds) {
    const { ctx } = this;
    const { edge, a, drawEnd, birth, typeConfig, visibleActivity, traceGlow, visualActivity, pathStrength, stateAlpha, seedlingBoost } = data;

    const fatigueDim = 1 - (edge.fatigueGlow || 0) * 0.5;
    const afterglow = edge.afterglow || 0;
    const baseAlpha = (edge.bridge ? 0.038 : 0.064) * fatigueDim;
    const activeAlpha = visibleActivity * edge.weight * (edge.bridge ? 0.16 : 0.28) * fatigueDim;

    // Afterglow: frisch aktive Verbindungen glühen schwach nach
    const afterglowAlpha = afterglow * (edge.bridge ? 0.04 : 0.06);

    ctx.strokeStyle = rgba(typeConfig.rgb, (baseAlpha + activeAlpha + afterglowAlpha + traceGlow * (edge.bridge ? 0.024 : 0.04) + visualActivity * (edge.bridge ? 0.016 : 0.028) + pathStrength * 0.02) * birth * stateAlpha * seedlingBoost);
    ctx.lineWidth = (
      edge.bridge
        ? 0.22 + edge.weight * 0.32 + visibleActivity * 0.18 + traceGlow * 0.12 + pathStrength * 0.16 + afterglow * 0.14
        : 0.32 + edge.weight * 0.38 + visibleActivity * 0.34 + traceGlow * 0.18 + pathStrength * 0.21 + afterglow * 0.18
    ) * lerp(0.45, 1, birth);

    this._strokeEdgePath(edge, a, drawEnd, timeSeconds, birth);
  }

  _drawGlowEdge(data, timeSeconds) {
    const { ctx } = this;
    const { edge, a, drawEnd, birth, typeConfig, traceGlow, visualActivity, pathPulseGlow, stateAlpha, seedlingBoost } = data;

    const afterglow = edge.afterglow || 0;
    if (traceGlow <= 0.018 && visualActivity <= 0.045 && pathPulseGlow <= 0.04 && afterglow <= 0.05) return;

    const edgeFatigue = edge.fatigueGlow || 0;
    const warmBlend = edgeFatigue > 0.3 ? edgeFatigue * 0.6 : 0;
    const glowRgb = warmBlend > 0
      ? blendRgb(typeConfig.softRgb, [255, 170, 80], warmBlend)
      : typeConfig.softRgb;
    const glowAlpha = ((edge.bridge ? 0.012 : 0.024) + traceGlow * (edge.bridge ? 0.07 : 0.105) + visualActivity * (edge.bridge ? 0.038 : 0.058) + pathPulseGlow * 0.052 + afterglow * (edge.bridge ? 0.028 : 0.04)) * (1 - edgeFatigue * 0.3);

    ctx.strokeStyle = rgba(glowRgb, glowAlpha * birth * stateAlpha * seedlingBoost);
    ctx.lineWidth = (edge.bridge ? 0.78 : 1.02) + traceGlow * (edge.bridge ? 0.62 : 1.08) + visualActivity * (edge.bridge ? 0.44 : 0.62) + pathPulseGlow * 0.62 + afterglow * (edge.bridge ? 0.3 : 0.4);
    this._strokeEdgePath(edge, a, drawEnd, timeSeconds, birth);
  }

  _strokeEdgePath(edge, start, end, timeSeconds, birth) {
    const { ctx } = this;

    ctx.beginPath();
    ctx.moveTo(start.x, start.y);

    if (edge.bridge) {
      const midX = (start.x + end.x) * 0.5 + Math.sin(timeSeconds * 0.18 + edge.phase) * 12 * birth;
      const midY = (start.y + end.y) * 0.5 + Math.cos(timeSeconds * 0.15 + edge.phase) * 9 * birth;
      ctx.quadraticCurveTo(midX, midY, end.x, end.y);
    } else {
      ctx.lineTo(end.x, end.y);
    }

    ctx.stroke();
  }

  edgePoint(edge, start, end, t, timeSeconds, birth) {
    return this.memoryFilaments._edgePoint(edge, start, end, t, timeSeconds, birth);
  }

  getPreferredEdgeStrengths() {
    return this.memoryFilaments.getPreferredEdgeStrengths();
  }

  drawMemoryFilaments(timeSeconds) {
    return this.memoryFilaments.drawMemoryFilaments(timeSeconds);
  }
}
