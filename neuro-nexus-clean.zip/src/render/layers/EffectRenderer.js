import { CLUSTER_TYPES } from "../../config.js";
import { clamp, ease, lerp, rgba } from "../../utils/math.js";

/**
 * EffectRenderer — zeichnet Pulse (Signal-Schwänze), injizierte Wellen
 * und Interaktions-Visualisierungen (Drag-Linien).
 */
export class EffectRenderer {
  constructor(renderer) {
    this.renderer = renderer;
  }

  get ctx() { return this.renderer.ctx; }
  get simulation() { return this.renderer.simulation; }

  drawPulses(timeSeconds) {
    const { ctx } = this;

    ctx.save();
    ctx.lineCap = "round";
    ctx.globalCompositeOperation = "lighter";

    for (const pulse of this.simulation.world.pulses) {
      const from = this.simulation.getCachedNodePosition(pulse.from, timeSeconds);
      const to = this.simulation.getCachedNodePosition(pulse.to, timeSeconds);
      const typeConfig = CLUSTER_TYPES[pulse.edge.dominantType()];
      const t = ease(clamp(pulse.t, 0, 1));

      const p = this.simulation.personality;
      // Tail length: High caution -> longer tail (stable). High volatility -> shorter tail (nervous).
      const tailLength = clamp(0.22 + p.caution * 0.1 - p.volatility * 0.1, 0.1, 0.4);
      // Longer tail (0.22 vs 0.18) makes the signal direction more readable:
      // you can see where it came from and where it's heading.
      const tail = clamp(t - tailLength, 0, 1);

      const x1 = lerp(from.x, to.x, tail);
      const y1 = lerp(from.y, to.y, tail);
      const x2 = lerp(from.x, to.x, t);
      const y2 = lerp(from.y, to.y, t);

      const gradient = ctx.createLinearGradient(x1, y1, x2, y2);
      gradient.addColorStop(0, rgba(typeConfig.softRgb, 0));
      // Spark/volatile networks have brighter, more nervous pulses.
      const visualBoost = (pulse.visualOnly ? 0.12 : 0.22) + p.volatility * 0.15;
      gradient.addColorStop(0.55, rgba(typeConfig.softRgb, 0.38 + pulse.strength * 0.34 + visualBoost));
      gradient.addColorStop(1, rgba(typeConfig.softRgb, pulse.visualOnly ? 0.13 : 0.1));

      ctx.strokeStyle = gradient;
      ctx.lineWidth = pulse.edge.bridge ? 0.88 + pulse.strength * 0.64 : 1.04 + pulse.strength * 1.08;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }

    ctx.restore();
  }

  drawInjectedWaves() {
    const { ctx } = this;

    ctx.save();
    ctx.lineWidth = 1;
    ctx.globalCompositeOperation = "lighter";

    for (const wave of this.simulation.world.injectedWaves) {
      const progress = clamp(wave.age / wave.life, 0, 1);
      const alpha = (1 - progress) * 0.34 * wave.strength;
      const radius = wave.radius * (0.18 + progress * 1.32);
      const rgb = wave.rgb || [95, 190, 255];

      ctx.strokeStyle = rgba(rgb, alpha);
      ctx.beginPath();
      ctx.arc(wave.x, wave.y, radius, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.restore();
  }

  drawInteractions(timeSeconds) {
    const { ctx } = this;
    const world = this.simulation.world;

    if (world.activeDragLine) {
      const { startNode, currentPoint } = world.activeDragLine;
      const start = this.simulation.getCachedNodePosition(startNode, timeSeconds);
      // currentPoint is in screen coordinates, convert to scene
      const end = this.simulation.screenToScene(currentPoint);

      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.lineCap = "round";
      ctx.setLineDash([6, 6]);

      // Outer glow
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(150, 220, 255, 0.3)";
      ctx.beginPath();
      ctx.moveTo(start.x, start.y);
      ctx.lineTo(end.x, end.y);
      ctx.stroke();

      // Inner line
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = "rgba(220, 250, 255, 0.9)";
      ctx.stroke();

      ctx.restore();
    }
  }
}
