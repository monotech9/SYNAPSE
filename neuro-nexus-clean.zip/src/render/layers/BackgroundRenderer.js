import {CLUSTER_TYPES} from "../../config.js";
import { ClusterStates } from "../../simulation/clusterRoles.js";
import { dominantBehaviorLabel } from "../../simulation/personality.js";
import { rgba } from "../../utils/math.js";

/** Mischt zwei RGB-Farbkanäle linear zu `t` Anteil der zweiten Farbe. */
export function blendRgb(rgbA, rgbB, t) {
  return [
    Math.round(rgbA[0] + (rgbB[0] - rgbA[0]) * t),
    Math.round(rgbA[1] + (rgbB[1] - rgbA[1]) * t),
    Math.round(rgbA[2] + (rgbB[2] - rgbA[2]) * t)
  ];
}

/**
 * BackgroundRenderer — zeichnet Hintergrund-Gradient, Cluster-Atmosphäre-Ringe,
 * Vignette und das Signatur-Label.
 */
export class BackgroundRenderer {
  constructor(renderer) {
    this.renderer = renderer;
    this._bgGradient = null;
    this._vignetteGradient = null;
    this._gradientViewportKey = "";
  }

  get ctx() { return this.renderer.ctx; }
  get simulation() { return this.renderer.simulation; }

  drawBackground(timeSeconds) {
    const { ctx } = this;
    const world = this.simulation.world;

    ctx.clearRect(0, 0, world.width, world.height);

    // Background-Gradient cachen — nur bei Resize neu erzeugen
    const viewportKey = `${world.width}x${world.height}x${world.minSide}`;
    if (!this._bgGradient || this._gradientViewportKey !== viewportKey) {
      this._bgGradient = ctx.createRadialGradient(
        world.centerX,
        world.centerY,
        world.minSide * 0.04,
        world.centerX,
        world.centerY,
        world.minSide * 0.88
      );
      this._bgGradient.addColorStop(0, "rgba(0, 40, 100, 0.045)");
      this._bgGradient.addColorStop(0.42, "rgba(0, 18, 50, 0.030)");
      this._bgGradient.addColorStop(1, "rgba(0, 0, 0, 0.18)");
      this._vignetteGradient = null; // auch Vignette neu erzeugen
      this._gradientViewportKey = viewportKey;
    }

    ctx.fillStyle = this._bgGradient;
    ctx.fillRect(0, 0, world.width, world.height);

    // Herzschlag-Hintergrundpuls: ein subtiler, netzwerkweiter Atem,
    // der vom Zustand des Netzwerks getrieben wird.
    const heartbeat = this.simulation._simulation?.heartbeatSystem;
    if (heartbeat && heartbeat.backgroundPulse > 0.01) {
      const pulseAlpha = heartbeat.backgroundPulse * 0.04;
      const pulseRadius = world.minSide * (0.3 + heartbeat.backgroundPulse * 0.4);
      const pulseGrad = ctx.createRadialGradient(
        world.centerX, world.centerY, 0,
        world.centerX, world.centerY, pulseRadius
      );
      pulseGrad.addColorStop(0, `rgba(20, 70, 140, ${pulseAlpha * 0.4})`);
      pulseGrad.addColorStop(0.6, `rgba(10, 30, 70, ${pulseAlpha * 0.2})`);
      pulseGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = pulseGrad;
      ctx.fillRect(0, 0, world.width, world.height);
    }

    ctx.save();
    ctx.globalAlpha = 0.14;
    ctx.lineWidth = 1;

    for (const cluster of world.clusters) {
      const center = cluster.center(timeSeconds);
      const typeConfig = CLUSTER_TYPES[cluster.type];
      const birth = cluster.birthEase();
      const stateAlpha = cluster.state === ClusterStates.DORMANT ? 0.42 : cluster.state === ClusterStates.SEEDLING ? 0.74 : 1;

      for (let i = 0; i < 4; i += 1) {
        const stagePulse = 1 + cluster.activityMemory * 0.18 + cluster.memoryStrength * 0.28;
        const rhythm = this.simulation.personality.rhythm;
        const breath = cluster.breath ? cluster.breath(timeSeconds) : 1;
        const radius = cluster.pixelRadius * birth * stagePulse * breath * (1.05 + i * 0.36 + Math.sin(timeSeconds * (0.15 * (0.5 + rhythm * 1.0)) + i + cluster.phase) * 0.02);

        ctx.strokeStyle = rgba(typeConfig.rgb, (0.078 - i * 0.011) * birth * stateAlpha);
        ctx.beginPath();
        ctx.ellipse(
          center.x,
          center.y,
          radius * 1.14,
          radius * 0.86,
          cluster.rotation + i * 0.18,
          0,
          Math.PI * 2
        );
        ctx.stroke();
      }
    }

    ctx.restore();
  }

  drawVignette() {
    const { ctx } = this;
    const world = this.simulation.world;

    // Vignette-Gradient cachen — nur bei Resize neu erzeugen
    if (!this._vignetteGradient) {
      this._vignetteGradient = ctx.createRadialGradient(
        world.centerX,
        world.centerY,
        world.minSide * 0.18,
        world.centerX,
        world.centerY,
        world.minSide * 0.96
      );
      this._vignetteGradient.addColorStop(0, "rgba(0, 0, 0, 0)");
      this._vignetteGradient.addColorStop(0.62, "rgba(0, 0, 0, 0.045)");
      this._vignetteGradient.addColorStop(1, "rgba(0, 0, 0, 0.68)");
    }

    ctx.fillStyle = this._vignetteGradient;
    ctx.fillRect(0, 0, world.width, world.height);
  }

  updateSignature() {
    const world = this.simulation.world;
    const activeClusters = world.clusters.length;
    const resonance = world.clusters.reduce((sum, cluster) => sum + cluster.activityMemory, 0) / Math.max(1, activeClusters);
    const stateLabel = dominantBehaviorLabel(this.simulation.personality, world, this.simulation.memory);

    const heartbeat = this.simulation._simulation?.heartbeatSystem;
    const heartbeatLabel = heartbeat ? ` · ${heartbeat.stateLabel}` : "";
    this.renderer.signatureElement.textContent = `${this.simulation.identity.name} · ${stateLabel}${heartbeatLabel}`;
    this.renderer.signatureElement.classList.toggle(
      "is-awake",
      resonance > 0.18 || world.pointerEnergy > 0.18 || this.simulation.memory.autonomousMoments > 0
    );
  }
}
