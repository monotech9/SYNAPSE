/**
 * HologramRenderer v3
 * Hologramme sind NICHT permanent. Sie erscheinen kurz (3-5s) fuer
 * den aktivsten Cluster und blenden dann aus. Max 2 gleichzeitig.
 * Bei manuellem Impuls wird sofort eins getriggert (via window event).
 */
export class HologramRenderer {
  constructor(renderer) {
    this.renderer = renderer;
    this._holograms = [];
    this._lastSpawn = -99999;
    this._spawnInterval = 9000;
    this._maxHolograms = 2;

    // Listen for manual impulse
    window.addEventListener("neuro:impulse", () => {
      this._spawnHologram(performance.now(), true);
    });
  }

  get ctx()        { return this.renderer.ctx; }
  get simulation() { return this.renderer.simulation; }

  _sceneToScreen(x, y) {
    const world = this.simulation.world;
    const cam   = this.simulation.camera;
    return {
      x: world.centerX + cam.offsetX + (x - world.centerX) * cam.scale,
      y: world.centerY + cam.offsetY + (y - world.centerY) * cam.scale,
    };
  }

  _pickCluster() {
    const world    = this.simulation.world;
    const clusters = world.clusters.filter(c => c.state !== "dormant" && c.nodes.length > 1);
    if (!clusters.length) return null;
    const existing = new Set(this._holograms.map(h => h.clusterId));
    const available = clusters.filter(c => !existing.has(c.id));
    if (!available.length) return null;
    return available.sort((a, b) => b.activityMemory - a.activityMemory)[0];
  }

  _spawnHologram(now, force = false) {
    if (!force && this._holograms.length >= this._maxHolograms) return;
    const cl = this._pickCluster();
    if (!cl) return;
    const side = Math.random() < 0.5 ? -1 : 1;
    this._holograms.push({
      clusterId: cl.id,
      clusterRef: cl,
      born: now,
      life:    3200 + Math.random() * 1800,
      fadeIn:  350,
      fadeOut: 700,
      offsetX: side * (34 + Math.random() * 26),
      offsetY: -42 - Math.random() * 18,
    });
  }

  update(now) {
    // Auto-spawn (infrequent)
    if (now - this._lastSpawn > this._spawnInterval) {
      this._lastSpawn = now;
      if (this._holograms.length < this._maxHolograms) {
        this._spawnHologram(now);
      }
    }
    // Cleanup expired
    for (let i = this._holograms.length - 1; i >= 0; i--) {
      const h = this._holograms[i];
      if ((now - h.born) > h.life + h.fadeOut) {
        this._holograms.splice(i, 1);
      }
    }
  }

  draw(timeSeconds, now) {
    if (!this._holograms.length) return;
    const ctx   = this.ctx;
    const world = this.simulation.world;
    if (!world || !world.clusters.length) return;

    ctx.save();
    for (const h of this._holograms) {
      const cl  = h.clusterRef;
      if (!cl || cl.state === "dormant") continue;

      const age = now - h.born;
      let alpha;
      if (age < h.fadeIn)        alpha = age / h.fadeIn;
      else if (age > h.life)     alpha = Math.max(0, 1 - (age - h.life) / h.fadeOut);
      else                       alpha = 1;
      alpha = Math.min(1, Math.max(0, alpha)) * 0.86;
      if (alpha < 0.02) continue;

      const center = cl.center(world.currentTime);
      const sc = this._sceneToScreen(center.x, center.y);
      const lx = sc.x + h.offsetX;
      const ly = sc.y + h.offsetY;

      // Dashed connector
      ctx.save();
      ctx.globalAlpha = alpha * 0.42;
      ctx.strokeStyle = "rgba(42,184,255,0.7)";
      ctx.lineWidth = 0.7;
      ctx.setLineDash([3, 4]);
      ctx.beginPath();
      ctx.moveTo(sc.x, sc.y);
      ctx.quadraticCurveTo((sc.x+lx)/2, (sc.y+ly)/2+5, lx, ly);
      ctx.stroke();
      ctx.restore();

      // Pulse dot at cluster
      const pulse = 0.5 + 0.5 * Math.sin(timeSeconds * 5 + h.clusterId);
      ctx.save();
      ctx.globalAlpha = alpha * 0.7;
      ctx.fillStyle = `rgba(42,184,255,${(0.3+pulse*0.35).toFixed(2)})`;
      ctx.shadowColor = "#2ab8ff"; ctx.shadowBlur = 4;
      ctx.beginPath(); ctx.arc(sc.x, sc.y, 2.2 + pulse, 0, Math.PI*2); ctx.fill();
      ctx.restore();

      // Label box
      ctx.save();
      ctx.font = '700 8px "SF Mono",ui-monospace,monospace';
      ctx.textBaseline = "middle"; ctx.textAlign = "center";
      const name  = this._clusterName(cl);
      const line2 = `RES ${Math.round(cl.memoryStrength*100)}%  ACT ${Math.round(cl.activityMemory*100)}%`;
      const bw = Math.max(ctx.measureText(name).width, ctx.measureText(line2).width) + 14;
      const bh = 27;

      ctx.globalAlpha = alpha * 0.76;
      ctx.fillStyle = "rgba(3,10,24,0.87)";
      ctx.strokeStyle = "rgba(42,184,255,0.22)"; ctx.lineWidth = 0.8;
      this._roundRect(ctx, lx-bw/2, ly-bh/2, bw, bh, 5);
      ctx.fill(); ctx.stroke();

      ctx.globalAlpha = alpha;
      ctx.fillStyle = "rgba(195,222,255,0.92)";
      ctx.font = '700 8px "SF Mono",ui-monospace,monospace';
      ctx.fillText(name, lx, ly-5);
      ctx.fillStyle = "rgba(110,165,215,0.65)";
      ctx.font = '500 7px "SF Mono",ui-monospace,monospace';
      ctx.fillText(line2, lx, ly+6);
      ctx.restore();
    }
    ctx.restore();
  }

  _clusterName(cl) {
    const N = { genesis:"Genesis-Core", exploration:"Exploration",
                stable:"Stabiler Cl.", memory:"Ged\u00e4chtnis", relay:"Relay-Hub" };
    const id = (typeof cl.id === "number" && isFinite(cl.id)) ? (cl.id % 256) : 0;
    return `${N[cl.type]||cl.role||"Cluster"} #${id.toString(16).toUpperCase().padStart(2,"0")}`;
  }
  _roundRect(ctx,x,y,w,h,r) {
    ctx.beginPath();
    ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.quadraticCurveTo(x+w,y,x+w,y+r);
    ctx.lineTo(x+w,y+h-r); ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
    ctx.lineTo(x+r,y+h); ctx.quadraticCurveTo(x,y+h,x,y+h-r);
    ctx.lineTo(x,y+r); ctx.quadraticCurveTo(x,y,x+r,y); ctx.closePath();
  }
}
