import { CLUSTER_TYPES, CONFIG } from "../../config.js";
import { ClusterStates } from "../../simulation/clusterRoles.js";
import { clamp, lerp, rgba } from "../../utils/math.js";

/**
 * NodeRenderer — zeichnet Cluster-Glow-Felder, Nodes mit Bloom,
 * Thermal-Shimmer und Scar-Effekten, sowie den Pointer-Resonanz-Ring.
 */
export class NodeRenderer {
  constructor(renderer) {
    this.renderer = renderer;
  }

  get ctx() { return this.renderer.ctx; }
  get simulation() { return this.renderer.simulation; }

  drawClusterFields(timeSeconds) {
    for (const cluster of this.simulation.world.clusters) {
      this._drawClusterGlow(cluster, timeSeconds);
    }
    this._drawPointerResonanceRing(timeSeconds);
  }

  _drawClusterGlow(cluster, timeSeconds) {
    const { ctx } = this;
    const typeConfig = CLUSTER_TYPES[cluster.type];
    const center = cluster.center(timeSeconds);
    const activity = clamp(cluster.activityMemory, 0, 1);
    const birth = cluster.birthEase();
    const stateAlpha = cluster.state === ClusterStates.DORMANT ? 0.42 : cluster.state === ClusterStates.SEEDLING ? 0.68 : 1;

    // Atembewegung: subtile Skalierung des Glow-Feldes
    const breath = cluster.breath ? cluster.breath(timeSeconds) : 1;
    const glowRadius = cluster.pixelRadius * 1.45 * birth * breath;

    const glow = ctx.createRadialGradient(
      center.x, center.y, 0,
      center.x, center.y, glowRadius
    );

    const memoryGlow = clamp(cluster.memoryStrength, 0, 1);
    glow.addColorStop(0, rgba(typeConfig.rgb, (0.078 + activity * 0.09 + memoryGlow * 0.06) * birth * stateAlpha));
    glow.addColorStop(0.42, rgba(typeConfig.rgb, (0.034 + activity * 0.052 + memoryGlow * 0.038) * birth * stateAlpha));
    glow.addColorStop(1, rgba(typeConfig.rgb, 0));

    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(center.x, center.y, glowRadius, 0, Math.PI * 2);
    ctx.fill();
  }

  _drawPointerResonanceRing(timeSeconds) {
    const { ctx } = this;
    const world = this.simulation.world;
    if (world.pointerEnergy <= 0.1) return;

    // Finde den Cluster mit der höchsten Aktivierung
    let strongestCluster = null;
    let strongestActivity = 0;
    for (const cluster of world.clusters) {
      if (cluster.state === ClusterStates.DORMANT) continue;
      if (cluster.activityMemory > strongestActivity) {
        strongestActivity = cluster.activityMemory;
        strongestCluster = cluster;
      }
    }
    if (!strongestCluster) return;

    const center = strongestCluster.center(timeSeconds);
    const typeConfig = CLUSTER_TYPES[strongestCluster.type];
    const ringAlpha = clamp(world.pointerEnergy * 0.4, 0, 0.35);
    const ringRadius = strongestCluster.pixelRadius * 1.15 * strongestCluster.birthEase();
    const pulse = 1 + Math.sin(timeSeconds * 2.5) * 0.04;

    ctx.save();
    ctx.globalCompositeOperation = "lighter";

    // Äußerer Ring
    ctx.strokeStyle = `rgba(${typeConfig.rgb[0]},${typeConfig.rgb[1]},${typeConfig.rgb[2]},${ringAlpha})`;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(center.x, center.y, ringRadius * pulse, 0, Math.PI * 2);
    ctx.stroke();

    // Innerer, hellerer Ring
    ctx.strokeStyle = `rgba(${typeConfig.rgb[0]},${typeConfig.rgb[1]},${typeConfig.rgb[2]},${ringAlpha * 0.6})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(center.x, center.y, ringRadius * pulse * 0.92, 0, Math.PI * 2);
    ctx.stroke();

    ctx.restore();
  }

  drawNodes(timeSeconds) {
    const { ctx } = this;

    ctx.save();
    ctx.globalCompositeOperation = "source-over";

    for (const cluster of this.simulation.world.clusters) {
      const typeConfig = CLUSTER_TYPES[cluster.type];

      for (const node of cluster.nodes) {
        this._drawNode(node, cluster, typeConfig, timeSeconds);
      }
    }

    ctx.restore();
  }

  _drawNode(node, cluster, typeConfig, timeSeconds) {
    const { ctx } = this;
    const position = this.simulation.getCachedNodePosition(node, timeSeconds);
    const activation = clamp(node.activation, 0, 1);
    const birth = node.birthEase();

    if (birth <= 0.01) return;

    const stateAlpha = cluster.state === ClusterStates.DORMANT ? 0.46 : cluster.state === ClusterStates.SEEDLING ? 0.78 : 1;
    const inactiveAlpha = node.isCore ? 0.26 : 0.085;
    const visualImpact = clamp(node.visualImpact || 0, 0, 1.4);
    const visibleAlpha = (inactiveAlpha + activation * 0.74 + visualImpact * 0.18) * birth * stateAlpha;
    const birthSpark = (1 - birth) * 0.34 + visualImpact * 0.16;

    const radius = (
      node.isCore
        ? 5.4 + activation * 7.2 + visualImpact * 1.6
        : 2.05 + node.mass * 0.66 + activation * 3.7 + visualImpact * 0.8
    ) * lerp(0.2, 1, birth);

    // Thermal shimmer
    const thermalLoad = clamp(node.thermalLoad || 0, 0, 1);
    const scarLevel = clamp(node.scarLevel || 0, 0, 1);
    if (thermalLoad > 0.6) {
      this._drawThermalShimmer(position, radius, thermalLoad, birth, cluster.type);
    }

    // Bloom
    const p = this.simulation.personality;
    if (activation > CONFIG.bloomThreshold || birth < 0.85) {
      this._drawBloom(position, radius, activation, birthSpark, birth, typeConfig, p);
    }

    // Thermal color blend
    const effectiveHeat = Math.max(thermalLoad > 0.3 ? (thermalLoad - 0.3) * 0.52 : 0, scarLevel * 0.45);
    if (effectiveHeat > 0) {
      this._drawHeatBlend(position, radius, effectiveHeat, visibleAlpha, cluster.type, typeConfig);
    }

    // Core node body
    ctx.fillStyle = rgba(typeConfig.softRgb, visibleAlpha);
    ctx.beginPath();
    ctx.arc(position.x, position.y, radius, 0, Math.PI * 2);
    ctx.fill();

    // Bright center
    ctx.fillStyle = `rgba(238, 250, 255, ${(0.18 + activation * 0.42 + visualImpact * 0.16) * birth * stateAlpha})`;
    ctx.beginPath();
    ctx.arc(position.x, position.y, Math.max(0.7, radius * 0.23), 0, Math.PI * 2);
    ctx.fill();
  }

  _drawThermalShimmer(position, radius, thermalLoad, birth, clusterType) {
    const { ctx } = this;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const shimmerRadius = radius * (3.8 + thermalLoad * 1.8);
    const shimmerRgb = clusterType === "memory" ? [255, 160, 60] : [255, 190, 80];

    ctx.fillStyle = rgba(shimmerRgb, (thermalLoad - 0.6) * 0.38 * birth);
    ctx.beginPath();
    ctx.arc(position.x, position.y, shimmerRadius * 0.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = rgba(shimmerRgb, (thermalLoad - 0.6) * 0.12 * birth);
    ctx.beginPath();
    ctx.arc(position.x, position.y, shimmerRadius, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  _drawBloom(position, radius, activation, birthSpark, birth, typeConfig, personality) {
    const { ctx } = this;
    const bloomRadius = radius * (2.5 + activation * 1.25 + birthSpark * 3.2) * (0.7 + personality.sensitivity * 0.6);

    ctx.fillStyle = rgba(typeConfig.softRgb, 0.2 * activation + birthSpark);
    ctx.beginPath();
    ctx.arc(position.x, position.y, bloomRadius * 0.38, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = rgba(typeConfig.rgb, 0.09 * activation + birthSpark * 0.46);
    ctx.beginPath();
    ctx.arc(position.x, position.y, bloomRadius, 0, Math.PI * 2);
    ctx.fill();
  }

  _drawHeatBlend(position, radius, effectiveHeat, visibleAlpha, clusterType, typeConfig) {
    const { ctx } = this;
    const warmRgb = clusterType === "memory" ? typeConfig.softRgb : [255, 200, 110];
    const blendAlpha = effectiveHeat * visibleAlpha;
    ctx.fillStyle = rgba(warmRgb, blendAlpha);
    ctx.beginPath();
    ctx.arc(position.x, position.y, radius, 0, Math.PI * 2);
    ctx.fill();
  }
}
