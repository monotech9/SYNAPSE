import { CLUSTER_TYPES } from "../../config.js";
import { ClusterStates } from "../../simulation/clusterRoles.js";
import { clamp, ease, lerp, rgba } from "../../utils/math.js";

/**
 * MemoryFilamentRenderer — zeichnet Memory-Filamente (bevorzugte Pfade)
 * mit wandernden Beads und verwaltet den Pro-Frame Cache für
 * getPreferredEdgeStrengths.
 *
 * Wird vom EdgeRenderer nach den Base+Glow-Passen aufgerufen.
 */
export class MemoryFilamentRenderer {
  constructor(renderer) {
    this.renderer = renderer;
    // Pro-Frame Cache — wird sonst mehrfach pro Frame berechnet
    this._cache = null;
    this._cacheFrame = -1;
  }

  get ctx() { return this.renderer.ctx; }
  get simulation() { return this.renderer.simulation; }

  /**
   * Liefert die stärksten bevorzugten Kanten für diese Frame.
   * Gecacht pro Frame (simulation.world.age).
   */
  getPreferredEdgeStrengths() {
    const currentFrame = this.simulation.world.age;
    if (this._cacheFrame === currentFrame && this._cache) {
      return this._cache;
    }

    const edges = this.simulation.world.edges.filter((edge) => {
      if (edge.bridge || edge.birthProgress < 0.58) return false;
      if (edge.a.cluster.state === ClusterStates.DORMANT || edge.b.cluster.state === ClusterStates.DORMANT) return false;
      return (edge.preferredPathScore || 0) > 0.15 || (edge.identityTrace || 0) > 0.12;
    });

    if (!edges.length) {
      this._cache = new Map();
      this._cacheFrame = currentFrame;
      return this._cache;
    }

    const strongestScore = Math.max(...edges.map((edge) => edge.preferredPathScore || 0));
    const threshold = Math.max(0.18, strongestScore * 0.46);
    const selected = edges
      .filter((edge) => (edge.preferredPathScore || 0) >= threshold)
      .sort((a, b) => (b.preferredPathScore || 0) - (a.preferredPathScore || 0))
      .slice(0, 3);

    const result = new Map();
    for (const [index, edge] of selected.entries()) {
      const score = clamp(edge.preferredPathScore || 0, 0, 1);
      const pathGlow = clamp(edge.pathGlow ?? edge.pathPulseGlow ?? 0, 0, 1);
      result.set(edge, clamp(0.22 + score * 0.58 + pathGlow * 0.18 - index * 0.06, 0.15, 0.86));
    }

    this._cache = result;
    this._cacheFrame = currentFrame;
    return result;
  }

  drawMemoryFilaments(timeSeconds) {
    const preferredEdges = this.getPreferredEdgeStrengths();
    if (preferredEdges.size === 0) return;

    const { ctx } = this;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.lineCap = "round";

    const p = this.simulation.personality;
    const attachmentBoost = 0.5 + p.attachment * 1.0;

    for (const [edge, strength] of preferredEdges.entries()) {
      const a = this.simulation.getCachedNodePosition(edge.a, timeSeconds);
      const b = this.simulation.getCachedNodePosition(edge.b, timeSeconds);
      const typeConfig = CLUSTER_TYPES[edge.dominantType()];
      const birth = edge.birthEase() * Math.min(edge.a.birthEase(), edge.b.birthEase());
      if (birth <= 0.01) continue;

      const smoothedPathGlow = clamp(edge.pathGlow ?? edge.pathPulseGlow ?? 0, 0, 1);

      // Basis-Pfad mit Attachment-Modulation + sanftes Pulsing
      const pulseMod = 1 + Math.sin(timeSeconds * 0.3 + edge.phase) * 0.08 * strength;
      ctx.strokeStyle = rgba(typeConfig.softRgb, (0.11 + strength * 0.14 + smoothedPathGlow * 0.065) * birth * attachmentBoost * pulseMod);
      ctx.lineWidth = (0.72 + strength * 0.88) * attachmentBoost * pulseMod;
      this._strokePath(edge, a, b, timeSeconds, birth);

      // Wandernde Beads auf starken Pfaden
      if (strength > 0.78) {
        this._drawBead(edge, a, b, timeSeconds, birth, strength, smoothedPathGlow, typeConfig);
      }
    }

    ctx.restore();
  }

  _drawBead(edge, a, b, timeSeconds, birth, strength, smoothedPathGlow, typeConfig) {
    const { ctx } = this;
    const t = (timeSeconds * (0.095 + strength * 0.055) + edge.phase * 0.07) % 1;
    const eased = ease(t);
    const point = this._edgePoint(edge, a, b, eased, timeSeconds, birth);
    const radius = 0.95 + strength * 0.84 + smoothedPathGlow * 0.42;

    // Schnelle Approximation eines radialen Gradients mit überlappenden Kreisen
    ctx.fillStyle = rgba(typeConfig.softRgb, 0.24 * birth);
    ctx.beginPath();
    ctx.arc(point.x, point.y, radius * 2.8, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = rgba(typeConfig.rgb, 0.12 * birth);
    ctx.beginPath();
    ctx.arc(point.x, point.y, radius * 4.4, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = rgba([238, 250, 255], 0.34 * birth);
    ctx.beginPath();
    ctx.arc(point.x, point.y, radius, 0, Math.PI * 2);
    ctx.fill();
  }

  _edgePoint(edge, start, end, t, timeSeconds, birth) {
    if (!edge.bridge) {
      return { x: lerp(start.x, end.x, t), y: lerp(start.y, end.y, t) };
    }
    const midX = (start.x + end.x) * 0.5 + Math.sin(timeSeconds * 0.18 + edge.phase) * 12 * birth;
    const midY = (start.y + end.y) * 0.5 + Math.cos(timeSeconds * 0.15 + edge.phase) * 9 * birth;
    const inv = 1 - t;
    return {
      x: inv * inv * start.x + 2 * inv * t * midX + t * t * end.x,
      y: inv * inv * start.y + 2 * inv * t * midY + t * t * end.y
    };
  }

  _strokePath(edge, start, end, timeSeconds, birth) {
    const { ctx } = this;
    ctx.beginPath();
    ctx.moveTo(start.x, start.y);

    if (edge.bridge) {
      const midX = (start.x + end.x) * 0.5 + Math.sin(timeSeconds * 0.18 + edge.phase) * 12 * birth;
      const midY = (start.y + end.y) * 0.5 + Math.cos(timeSeconds * 0.15 + edge.phase) * 9 * birth;
      ctx.quadraticCurveTo(midX, midY, end.x, end.y);
    } else {
      ctx.lineTo(end.x, end.y);
    }

    ctx.stroke();
  }
}
