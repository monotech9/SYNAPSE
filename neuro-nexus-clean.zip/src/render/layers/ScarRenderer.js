/**
 * ScarRenderer — zeichnet Narben als geisterhafte Schatten ehemaliger Verbindungen.
 *
 * Narben sind extrem schwach sichtbar — wie Fossilien oder alte Narben auf der Haut.
 * Wenn eine Narbe "echot", leuchtet sie kurz heller auf.
 *
 * Der Renderer liest die Narben aus dem ScarSystem und zeichnet sie
 * als dünne, fast unsichtbare Linien mit gelegentlichen Echo-Glows.
 */
import { CLUSTER_TYPES } from "../../config.js";
import { rgba } from "../../utils/math.js";

export class ScarRenderer {
  constructor(renderer) {
    this.renderer = renderer;
  }

  get ctx() { return this.renderer.ctx; }
  get simulation() { return this.renderer.simulation; }

  /**
   * Zeichnet alle Narben. Wird innerhalb der Camera-Transform aufgerufen.
   * @param {number} timeSeconds — aktuelle Zeit für Echo-Animation
   */
  drawScars(timeSeconds) {
    const scars = this.simulation._simulation?.scarSystem?.scars;
    if (!scars || scars.length === 0) return;

    const ctx = this.ctx;

    for (const scar of scars) {
      const baseAlpha = scar.opacity * 0.04; // extrem schwach
      const echoBoost = scar.echoGlow * 0.15;
      const totalAlpha = baseAlpha + echoBoost;

      if (totalAlpha < 0.002) continue;

      // Farbe: Mischung aus den ehemaligen Cluster-Typen
      const typeA = CLUSTER_TYPES[scar.typeA] || CLUSTER_TYPES.exploration;
      const rgb = [
        Math.round((typeA.rgb[0] + 60) / 2),
        Math.round((typeA.rgb[1] + 60) / 2),
        Math.round((typeA.rgb[2] + 60) / 2)
      ];

      // Basis-Linie: extrem dünn und transparent
      ctx.beginPath();
      ctx.moveTo(scar.ax, scar.ay);
      ctx.lineTo(scar.bx, scar.by);
      ctx.strokeStyle = rgba(rgb, totalAlpha);
      ctx.lineWidth = 0.3 + scar.echoGlow * 1.5;
      ctx.stroke();

      // Echo: ein hellerer, pulsierender Glow
      if (scar.echoGlow > 0.01) {
        const echoAlpha = scar.echoGlow * 0.12;
        ctx.beginPath();
        ctx.moveTo(scar.ax, scar.ay);
        ctx.lineTo(scar.bx, scar.by);
        ctx.strokeStyle = rgba(typeA.softRgb || rgb, echoAlpha);
        ctx.lineWidth = 1.5 + scar.echoGlow * 3;
        ctx.stroke();

        // Echo-Points an den Endpunkten: geisterhafte Punkte
        const pointRadius = 2 + scar.echoGlow * 4;
        const pointAlpha = scar.echoGlow * 0.2;

        ctx.beginPath();
        ctx.arc(scar.ax, scar.ay, pointRadius, 0, Math.PI * 2);
        ctx.fillStyle = rgba(typeA.softRgb || rgb, pointAlpha);
        ctx.fill();

        ctx.beginPath();
        ctx.arc(scar.bx, scar.by, pointRadius, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
}
