import { BackgroundRenderer } from "./layers/BackgroundRenderer.js";
import { EdgeRenderer } from "./layers/EdgeRenderer.js";
import { NodeRenderer } from "./layers/NodeRenderer.js";
import { EffectRenderer } from "./layers/EffectRenderer.js";
import { ScarRenderer } from "./layers/ScarRenderer.js";
import { HologramRenderer } from "./layers/HologramRenderer.js";
import { RenderState } from "./RenderState.js";

/**
 * CanvasRenderer — Orchestrator fuer das Canvas-Rendering.
 *
 * Delegiert an spezialisierte Sub-Renderer:
 *  - BackgroundRenderer: Hintergrund-Gradient, Atmosphaere-Ringe, Vignette, Signatur
 *  - NodeRenderer: Cluster-Glow-Felder, Nodes mit Bloom/Thermal/Scars
 *  - EdgeRenderer: Kanten (Base + Glow), Memory-Filamente mit Beads
 *  - EffectRenderer: Pulse, injizierte Wellen, Drag-Interaktionen
 *  - ScarRenderer: Narben und Heilungs-Spuren
 *  - HologramRenderer: Diegetische Node-Hologramme (schwebende Telemetrie-Labels)
 *
 * Der Renderer greift ueber RenderState auf die Simulation zu — niemals direkt.
 * Der Renderpfad enthaelt keine Spiellogik (kein simulation.update(), etc.).
 */
export class CanvasRenderer {
  constructor(simulation, context, signatureElement) {
    this.state = new RenderState(simulation);
    this.ctx = context;
    this.signatureElement = signatureElement;

    this.background = new BackgroundRenderer(this);
    this.edges = new EdgeRenderer(this);
    this.nodes = new NodeRenderer(this);
    this.effects = new EffectRenderer(this);
    this.scars = new ScarRenderer(this);
    this.holograms = new HologramRenderer(this);

    this._now = performance.now();
  }

  // Convenience: sub-renderers access this.simulation for backward compat
  // but all reads go through RenderState
  get simulation() { return this.state; }

  render(timeSeconds) {
    const world = this.state.world;
    const now = performance.now();
    this._now = now;

    // Node-Positionen einmal pro Frame cachen
    this.state.cacheNodePositions(timeSeconds);

    this.ctx.setTransform(world.dpr, 0, 0, world.dpr, 0, 0);

    this.background.drawBackground(timeSeconds);

    this.beginCameraTransform();
    this.nodes.drawClusterFields(timeSeconds);
    this.edges.drawEdges(timeSeconds);
    this.edges.drawMemoryFilaments(timeSeconds);
    this.scars.drawScars(timeSeconds);
    this.effects.drawPulses(timeSeconds);
    this.nodes.drawNodes(timeSeconds);
    this.effects.drawInteractions(timeSeconds);
    this.endCameraTransform();

    // Hologramme im Screen-Space (nach Camera-Transform)
    this.holograms.update(now);
    this.holograms.draw(timeSeconds, now);

    this.background.drawVignette();
    this.background.updateSignature();
  }

  beginCameraTransform() {
    const { camera, world } = this.state;

    this.ctx.save();
    this.ctx.translate(world.centerX + camera.offsetX, world.centerY + camera.offsetY);
    this.ctx.scale(camera.scale, camera.scale);
    this.ctx.translate(-world.centerX, -world.centerY);
  }

  endCameraTransform() {
    this.ctx.restore();
  }
}
