/**
 * RenderState — Read-Only-Schnittstelle zwischen Simulation und Renderer.
 *
 * Der Renderer bekommt RenderState statt der rohen Simulation. Das stellt
 * sicher, dass der Renderpfad keine Spiellogik ausführen kann — RenderState
 * exponiert nur Daten, keine Mutation-Methoden.
 *
 * Zusätzlich verwaltet RenderState den Node-Position-Cache, der früher
 * in der Simulation lag. Der Cache ist ein rein visuelles Konzept und
 * gehört daher zum Renderer, nicht zur Simulation.
 */
export class RenderState {
  constructor(simulation) {
    this._simulation = simulation;
    this._positionCache = new Map();
    this._cacheTime = -1;
  }

  // ─── World data (read-only) ──────────────────────────────────────

  get world() { return this._simulation.world; }
  get camera() { return this._simulation.camera; }
  get personality() { return this._simulation.personality; }
  get identity() { return this._simulation.identity; }
  get memory() { return this._simulation.memory; }

  // ─── Node position cache (owned by renderer, not simulation) ─────

  /**
   * Füllt den Position-Cache für diesen Frame.
   * Wird vom CanvasRenderer einmal pro render()-Aufruf aufgerufen.
   */
  cacheNodePositions(timeSeconds) {
    if (this._cacheTime === timeSeconds && this._positionCache.size > 0) return;
    const cache = this._positionCache;
    cache.clear();
    for (const cluster of this._simulation.world.clusters) {
      for (const node of cluster.nodes) {
        cache.set(node, node.position(timeSeconds));
      }
    }
    this._cacheTime = timeSeconds;
  }

  /**
   * Liest eine gecachte Node-Position.
   * Fällt auf node.position(timeSeconds) zurück, falls der Cache leer ist.
   */
  getCachedNodePosition(node, timeSeconds) {
    const cached = this._positionCache.get(node);
    if (cached) return cached;
    return node.position(timeSeconds);
  }

  // ─── Read-only helpers (no mutation) ─────────────────────────────

  screenToScene(point) {
    return this._simulation.screenToScene(point);
  }

  totalNodeCount() {
    return this._simulation.totalNodeCount();
  }
}
