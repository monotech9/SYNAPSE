/**
 * Deterministischer RNG auf Basis von mulberry32.
 *
 * Unterschied zum alten LCG:
 * - Bessere statistische Qualität (volle 32-Bit-Ausgabe, kein Modulo-Bias)
 * - Zustandslos in dem Sinne, dass `state` den vollständigen RNG-Zustand
 *   darstellt und serialisiert werden kann → nach save/reload wird der
 *   exakt gleiche Zufallsstrom fortgesetzt, statt beim Seed-Ursprung neu zu
 *   beginnen.
 *
 * Persistenz: NeuroSimulation speichert `rng.state` im persistentState und
 * übergibt ihn als optionales zweites Argument an den Konstruktor.
 */
export class Random {
  constructor(seed, state = null) {
    // seed dient nur zur Initialisierung falls kein gespeicherter state vorliegt
    this.seed = seed >>> 0;
    // state ist der eigentliche laufende Zustand – bei erstem Start == seed
    this.state = (state !== null && Number.isFinite(state)) ? (state >>> 0) : (seed >>> 0);
  }

  next() {
    // mulberry32
    let s = (this.state + 0x6D2B79F5) >>> 0;
    this.state = s;
    s = Math.imul(s ^ (s >>> 15), s | 1);
    s ^= s + Math.imul(s ^ (s >>> 7), s | 61);
    return ((s ^ (s >>> 14)) >>> 0) / 4294967296;
  }

  range(min, max) {
    return min + (max - min) * this.next();
  }

  int(min, maxInclusive) {
    return Math.floor(this.range(min, maxInclusive + 1));
  }

  chance(probability) {
    return this.next() < probability;
  }

  /** Aktuellen Zustand serialisieren (zum Einlagern in persistentState). */
  getState() {
    return this.state;
  }
}
