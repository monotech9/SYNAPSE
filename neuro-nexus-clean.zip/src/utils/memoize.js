/**
 * Memoization & Caching Utilities
 * 
 * High-performance caching solutions for expensive computations.
 * Includes:
 * - Simple memoization
 * - TTL-based caching
 * - LRU cache
 * - Weak map caching (for objects)
 */

/**
 * Simple memoization with size limit and TTL
 */
export function memoize(fn, { maxSize = 500, ttl = 5000, keyGen } = {}) {
  const cache = new Map();
  const timestamps = new Map();

  const getKey = keyGen || ((args) => JSON.stringify(args));

  return function memoized(...args) {
    const key = getKey(args);
    const now = Date.now();
    const cached = cache.get(key);
    const cachedTime = timestamps.get(key);

    // Return cached if valid
    if (cached !== undefined && now - cachedTime < ttl) {
      return cached;
    }

    // Compute and cache
    const result = fn.apply(this, args);
    cache.set(key, result);
    timestamps.set(key, now);

    // Evict oldest if size exceeded
    if (cache.size > maxSize) {
      const oldest = Math.min(...Array.from(timestamps.values()));
      const oldestKey = Array.from(timestamps.keys()).find(
        (k) => timestamps.get(k) === oldest
      );
      cache.delete(oldestKey);
      timestamps.delete(oldestKey);
    }

    return result;
  };
}

/**
 * LRU (Least Recently Used) Cache
 */
export class LRUCache {
  constructor(maxSize = 100) {
    this.maxSize = maxSize;
    this.cache = new Map();
  }

  get(key) {
    if (!this.cache.has(key)) return undefined;

    // Move to end (most recently used)
    const value = this.cache.get(key);
    this.cache.delete(key);
    this.cache.set(key, value);

    return value;
  }

  set(key, value) {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    }

    this.cache.set(key, value);

    // Evict least recently used if size exceeded
    if (this.cache.size > this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
  }

  has(key) {
    return this.cache.has(key);
  }

  clear() {
    this.cache.clear();
  }

  get size() {
    return this.cache.size;
  }

  entries() {
    return Array.from(this.cache.entries());
  }
}

/**
 * TTL-based cache
 */
export class TTLCache {
  constructor(ttl = 5000) {
    this.ttl = ttl;
    this.cache = new Map();
    this.timestamps = new Map();
    this.timers = new Map();
  }

  get(key) {
    const now = Date.now();
    const cachedTime = this.timestamps.get(key);

    if (cachedTime && now - cachedTime >= this.ttl) {
      this.delete(key);
      return undefined;
    }

    return this.cache.get(key);
  }

  set(key, value) {
    // Clear old timer
    if (this.timers.has(key)) {
      clearTimeout(this.timers.get(key));
    }

    this.cache.set(key, value);
    this.timestamps.set(key, Date.now());

    // Set auto-expiry
    const timer = setTimeout(() => this.delete(key), this.ttl);
    this.timers.set(key, timer);
  }

  delete(key) {
    if (this.timers.has(key)) {
      clearTimeout(this.timers.get(key));
    }
    this.cache.delete(key);
    this.timestamps.delete(key);
    this.timers.delete(key);
  }

  has(key) {
    const now = Date.now();
    const cachedTime = this.timestamps.get(key);
    return cachedTime && now - cachedTime < this.ttl;
  }

  clear() {
    for (const timer of this.timers.values()) {
      clearTimeout(timer);
    }
    this.cache.clear();
    this.timestamps.clear();
    this.timers.clear();
  }

  get size() {
    return this.cache.size;
  }
}

/**
 * WeakMap-based caching for objects
 * Automatically garbage collects when objects are freed
 */
export class ObjectCache {
  constructor() {
    this.cache = new WeakMap();
  }

  get(obj) {
    return this.cache.get(obj);
  }

  set(obj, value) {
    this.cache.set(obj, value);
  }

  has(obj) {
    return this.cache.has(obj);
  }

  delete(obj) {
    // WeakMap doesn't support delete, but object will be GC'd
    return true;
  }
}

/**
 * Debounce function calls
 */
export function debounce(fn, delay = 300) {
  let timeoutId = null;

  return function debounced(...args) {
    if (timeoutId) {
      clearTimeout(timeoutId);
    }

    timeoutId = setTimeout(() => {
      fn.apply(this, args);
      timeoutId = null;
    }, delay);
  };
}

/**
 * Throttle function calls
 */
export function throttle(fn, delay = 300) {
  let lastCallTime = 0;
  let timeoutId = null;

  return function throttled(...args) {
    const now = Date.now();

    if (now - lastCallTime >= delay) {
      fn.apply(this, args);
      lastCallTime = now;
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
    } else {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        fn.apply(this, args);
        lastCallTime = Date.now();
        timeoutId = null;
      }, delay - (now - lastCallTime));
    }
  };
}

/**
 * Batch updates for expensive operations
 */
export class BatchProcessor {
  constructor(processFn, batchSize = 100, delay = 16) {
    this.processFn = processFn;
    this.batchSize = batchSize;
    this.delay = delay;
    this.queue = [];
    this.timeoutId = null;
  }

  add(item) {
    this.queue.push(item);

    if (this.queue.length >= this.batchSize) {
      this.flush();
    } else if (!this.timeoutId) {
      this.timeoutId = setTimeout(() => this.flush(), this.delay);
    }
  }

  addMultiple(items) {
    this.queue.push(...items);

    if (this.queue.length >= this.batchSize) {
      this.flush();
    } else if (!this.timeoutId) {
      this.timeoutId = setTimeout(() => this.flush(), this.delay);
    }
  }

  flush() {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }

    if (this.queue.length > 0) {
      const batch = this.queue.splice(0, this.batchSize);
      this.processFn(batch);

      if (this.queue.length > 0) {
        this.timeoutId = setTimeout(() => this.flush(), this.delay);
      }
    }
  }

  clear() {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }
    this.queue = [];
  }

  get size() {
    return this.queue.length;
  }
}

/**
 * Cached selector factory
 * For use with state management
 */
export function createSelector(...inputSelectors) {
  const memoizedSelector = memoize((inputs) => {
    const lastInputs = createSelector._lastInputs ?? [];
    const lastResult = createSelector._lastResult;

    const inputsChanged = !inputsEqual(lastInputs, inputs);

    if (inputsChanged) {
      createSelector._lastInputs = inputs;
      createSelector._lastResult = inputs;
      return inputs;
    }

    return lastResult;
  });

  return (state) => {
    const inputs = inputSelectors.map((selector) => selector(state));
    return memoizedSelector(inputs);
  };
}

/**
 * Compare two arrays for equality
 */
function inputsEqual(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

/**
 * Performance-conscious memoization
 * Tracks cache hits/misses
 */
export class InstrumentedCache {
  constructor(fn, options = {}) {
    this.fn = fn;
    this.cache = new Map();
    this.timestamps = new Map();
    this.stats = {
      hits: 0,
      misses: 0,
      evictions: 0,
    };
    this.maxSize = options.maxSize ?? 500;
    this.ttl = options.ttl ?? 5000;
  }

  get(key) {
    const now = Date.now();
    const cachedTime = this.timestamps.get(key);

    if (
      this.cache.has(key) &&
      cachedTime &&
      now - cachedTime < this.ttl
    ) {
      this.stats.hits++;
      return this.cache.get(key);
    }

    this.stats.misses++;
    return undefined;
  }

  set(key, value) {
    this.cache.set(key, value);
    this.timestamps.set(key, Date.now());

    if (this.cache.size > this.maxSize) {
      const oldest = Math.min(...Array.from(this.timestamps.values()));
      const oldestKey = Array.from(this.timestamps.keys()).find(
        (k) => this.timestamps.get(k) === oldest
      );
      this.cache.delete(oldestKey);
      this.timestamps.delete(oldestKey);
      this.stats.evictions++;
    }
  }

  getStats() {
    const total = this.stats.hits + this.stats.misses;
    return {
      ...this.stats,
      total,
      hitRate: total > 0 ? (this.stats.hits / total * 100).toFixed(2) + '%' : 'N/A',
      size: this.cache.size,
    };
  }

  clear() {
    this.cache.clear();
    this.timestamps.clear();
  }
}
