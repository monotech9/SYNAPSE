/**
 * PhaseSpaceWidget — Kognitiver Phasenraum (Chaos-Attraktor)
 *
 * Quadratischer Canvas-Plot. Eine feine, leuchtende Linie zieht
 * chaotische Kreise (ähnlich Lorenz-Attraktor).
 * - Ruhiges Netzwerk → kleine, stabile Orbits im Zentrum
 * - Hohe Aktivität / Impulse → chaotischer Ausbruch nach außen
 *
 * X-Achse: Cluster-Aktivitäts-Varianz (Alpha-Band)
 * Y-Achse: Puls-Frequenz (Gamma-Band)
 *
 * Erbt von BaseWidget für Lifecycle-Management.
 */
import { BaseWidget } from "./BaseWidget.js";

const TRAIL_MAX = 180;  // Punkte im Trail

export class PhaseSpaceWidget extends BaseWidget {
  constructor(canvas) {
    super(canvas);
    this._trail = [];        // { x, y } in normalisierten Koordinaten (-1..1)
    this._px = 0; this._py = 0;
    this._vx = 0; this._vy = 0;
    this._energy = 0;        // Gesamtenergie (0=ruhig, 1=chaotisch)
    this._tick = 0;
  }

  /**
   * Wird von HudPanel aufgerufen mit Simulationsdaten.
   * @param {number} pulseRatio  - 0..1, Anteil aktiver Pulse
   * @param {number} chaosVar    - 0..1, Varianz der Cluster-Aktivität
   * @param {number} coherence   - 0..1, System-Kohärenz
   */
  update(pulseRatio, chaosVar, coherence) {
    if (this.isPaused) return;

    // Attraktor-Dynamik: zwei gekoppelte Oszillatoren + Chaos-Term
    const dt = 0.05;
    const sigma = 0.8 + this._energy * 3.5;   // Chaotizität
    const rho = 0.3 + coherence * 0.4;        // Pull-to-center

    // Lorenz-artige Vereinfachung im 2D
    const dx = sigma * (this._py - this._px);
    const dy = this._px * (rho - this._energy * 2) - this._py;

    this._vx = this._vx * 0.85 + dx * dt * 0.3;
    this._vy = this._vy * 0.85 + dy * dt * 0.3;

    // Externe Energie aus Simulation
    const extForce = pulseRatio * 0.4 + chaosVar * 0.3;
    this._vx += (Math.random() - 0.5) * extForce * 0.15;
    this._vy += (Math.random() - 0.5) * extForce * 0.15;

    // Damping zum Zentrum bei niedriger Energie
    const pull = (1 - this._energy) * 0.02;
    this._vx -= this._px * pull;
    this._vy -= this._py * pull;

    this._px += this._vx;
    this._py += this._vy;

    // Clamp
    const maxV = 1.2;
    this._px = Math.max(-maxV, Math.min(maxV, this._px));
    this._py = Math.max(-maxV, Math.min(maxV, this._py));

    // Energie-Update (smoothed)
    const targetEnergy = pulseRatio * 0.5 + chaosVar * 0.5;
    this._energy = this._energy * 0.92 + targetEnergy * 0.08;

    // Trail punkt hinzufügen
    this._trail.push({ x: this._px, y: this._py });
    if (this._trail.length > TRAIL_MAX) this._trail.shift();

    this._tick++;
  }

  draw(now) {
    if (!this.ctx || this.isPaused) return;
    if (this._checkPendingResize()) return;
    const ctx = this.ctx;
    const w = this._W, h = this._H;
    if (w === 0) return;

    const cx = w / 2, cy = h / 2;
    const scale = Math.min(w, h) * 0.42;

    // Hintergrund mit Trail-Fade
    ctx.fillStyle = "rgba(2, 8, 22, 0.12)";
    ctx.fillRect(0, 0, w, h);

    // Baseline-Raster (signalisiert Betriebsbereitschaft)
    this._drawGrid(ctx, w, h);

    // Achsen-Kreuz (sehr dezent)
    ctx.strokeStyle = "rgba(60, 140, 230, 0.08)";
    ctx.lineWidth = 0.5;
    ctx.beginPath();
    ctx.moveTo(cx - scale * 1.1, cy); ctx.lineTo(cx + scale * 1.1, cy);
    ctx.moveTo(cx, cy - scale * 1.1); ctx.lineTo(cx, cy + scale * 1.1);
    ctx.stroke();

    // Rand (quadratischer Plot)
    ctx.strokeStyle = "rgba(60, 140, 230, 0.12)";
    ctx.strokeRect(cx - scale * 1.05, cy - scale * 1.05, scale * 2.1, scale * 2.1);

    // Trail zeichnen — leuchtende Linie mit Alpha-Gradient
    if (this._trail.length < 2) return;

    const n = this._trail.length;
    for (let i = 1; i < n; i++) {
      const p0 = this._trail[i - 1];
      const p1 = this._trail[i];
      const t = i / n;  // 0 (alt) → 1 (neu)
      const alpha = t * t * 0.7;
      const energyColor = this._energy;

      // Farbe: cyan (ruhig) → magenta/weiß (chaotisch)
      const r = Math.round(42 + energyColor * 213);   // 42→255
      const g = Math.round(184 - energyColor * 84);   // 184→100
      const b = Math.round(255 - energyColor * 55);   // 255→200

      ctx.strokeStyle = `rgba(${r},${g},${b},${alpha})`;
      ctx.lineWidth = 0.5 + t * 1.0;
      ctx.beginPath();
      ctx.moveTo(cx + p0.x * scale, cy + p0.y * scale);
      ctx.lineTo(cx + p1.x * scale, cy + p1.y * scale);
      ctx.stroke();
    }

    // Aktueller Punkt — leuchtender Kopf
    const head = this._trail[n - 1];
    const hx = cx + head.x * scale;
    const hy = cy + head.y * scale;

    const headGlow = ctx.createRadialGradient(hx, hy, 0, hx, hy, 6);
    headGlow.addColorStop(0, `rgba(120, 220, 255, ${0.4 + this._energy * 0.4})`);
    headGlow.addColorStop(1, "rgba(42, 184, 255, 0)");
    ctx.fillStyle = headGlow;
    ctx.beginPath();
    ctx.arc(hx, hy, 6, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = `rgba(180, 240, 255, ${0.6 + this._energy * 0.3})`;
    ctx.beginPath();
    ctx.arc(hx, hy, 1.5, 0, Math.PI * 2);
    ctx.fill();
  }


  /**
   * Zeichnet ein dezentes Hintergrund-Raster — signalisiert
   * Betriebsbereitschaft auch bei geringer Netzwerk-Aktivität.
   */
  _drawGrid(ctx, w, h) {
    ctx.strokeStyle = "rgba(42, 184, 255, 0.04)";
    ctx.lineWidth = 1;
    const step = 20;
    for (let x = 0; x < w; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
  }
}