/**
 * BaseWidget — Einheitliches Lifecycle-Interface für alle Widgets.
 *
 * Jedes Widget erbt von BaseWidget und bekommt:
 *  - ResizeObserver mit DPR-Scaling
 *  - pause() / resume() für Akku-Schonung
 *  - destroy() mit cleanup (disconnect, cancelAnimationFrame)
 *  - isPaused Flag
 *  - _pendingResize: falls Canvas noch unsichtbar ist (display:none / height:0),
 *    wird der Resize verzögert und beim nächsten draw()-Aufruf nachgeholt
 */
export class BaseWidget {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx    = canvas?.getContext("2d") || null;
    this.isPaused = false;
    this._rafId   = null;
    this._ro      = null;
    this._W = 0; this._H = 0;
    this._dpr     = 1;
    this._pendingResize = false;

    if (canvas && typeof ResizeObserver !== "undefined") {
      this._resizeRafId = null;
      this._ro = new ResizeObserver(() => {
        // Defer auf den nächsten Frame: das direkte Setzen von
        // canvas.width/height *innerhalb* des ResizeObserver-Callbacks
        // löst sofort eine weitere Notification aus (Canvas-Resize zählt
        // selbst als Resize) → "ResizeObserver loop completed with
        // undelivered notifications". Durch rAF läuft resize() erst nach
        // Abschluss des aktuellen Notification-Zyklus.
        if (this._resizeRafId) return;
        this._resizeRafId = requestAnimationFrame(() => {
          this._resizeRafId = null;
          this.resize();
        });
      });
      // Observe both canvas AND parent — covers more layout situations
      this._ro.observe(canvas);
      if (canvas.parentElement) this._ro.observe(canvas.parentElement);
    }
  }

  /**
   * DPR-aware Resize.
   * Wenn Canvas unsichtbar (w/h === 0), setzt _pendingResize = true
   * damit draw() es beim nächsten sichtbaren Frame nachholen kann.
   */
  resize() {
    const el = this.canvas;
    if (!el) return;
    const dpr = window.devicePixelRatio || 1;
    const w = el.clientWidth, h = el.clientHeight;

    if (w === 0 || h === 0) {
      this._pendingResize = true;
      return;
    }

    this._pendingResize = false;
    const pw = Math.round(w * dpr), ph = Math.round(h * dpr);
    if (el.width !== pw || el.height !== ph) {
      el.width = pw; el.height = ph;
      this.ctx?.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    this._W = w; this._H = h; this._dpr = dpr;
  }

  /** Nimmt neue Simulationsdaten entgegen */
  update(/* ...data */) {}

  /** Zeichnet das Widget */
  draw(/* now */) {}

  /**
   * Am Anfang von draw() aufrufen.
   * Gibt true zurück wenn Canvas noch kein Layout hat → Frame überspringen.
   */
  _checkPendingResize() {
    if (!this._pendingResize) return false;
    this.resize();
    return this._W === 0;
  }

  pause() {
    this.isPaused = true;
    if (this._rafId) {
      cancelAnimationFrame(this._rafId);
      this._rafId = null;
    }
  }

  /** Resume + sofortiger Resize (Drawer/Tab könnte gerade aufgegangen sein) */
  resume() {
    if (!this.isPaused) return;
    this.isPaused = false;
    requestAnimationFrame(() => this.resize());
  }

  destroy() {
    this.pause();
    if (this._resizeRafId) {
      cancelAnimationFrame(this._resizeRafId);
      this._resizeRafId = null;
    }
    if (this._ro) {
      this._ro.disconnect();
      this._ro = null;
    }
    this.canvas = null;
    this.ctx = null;
  }
}
