/**
 * EmotionWidget — Radiales Emotion-Radar + Mood-Anzeige
 *
 * Visualisiert den aktuellen emotionalen Zustand des Systems:
 *  - 14 radiale Bars (eine pro Emotion), Länge = Intensität (0–1)
 *  - Positive Emotionen in der oberen Hälfte, negative in der unteren
 *  - Dominante Emotion wird hervorgehoben (glow + label)
 *  - Mood als zentraler Indikator (Farbverlauf rot ↔ grün)
 *  - Smooth interpolation (Werte ändern sich fließend, nicht springend)
 *
 * Erbt von BaseWidget für Lifecycle-Management.
 */
import { BaseWidget } from "./BaseWidget.js";

// ─── Emotion Layout ──────────────────────────────────────────────────

// Positive (obere Hälfte, clockwise von links): 8 Emotionen
// Negative (untere Hälfte, clockwise von rechts): 6 Emotionen
const EMOTION_LAYOUT = [
  // Positive (Winkel 180° → 360°, also obere Hälfte)
  { key: "joy",            label: "Freude",       valence: +1, color: "#ffd166" },
  { key: "hope",           label: "Hoffnung",     valence: +1, color: "#7fffaa" },
  { key: "pride",          label: "Stolz",        valence: +1, color: "#ff9e5e" },
  { key: "love",           label: "Zuneigung",    valence: +1, color: "#ff6b9d" },
  { key: "wonder",         label: "Staunen",      valence: +1, color: "#c478ff" },
  { key: "calm",           label: "Ruhe",         valence: +1, color: "#66ffdb" },
  { key: "satisfaction",   label: "Befriedigung", valence: +1, color: "#a8e6cf" },
  { key: "curiosity",      label: "Neugier",      valence: +1, color: "#48ffa3" },
  // Negative (Winkel 0° → 180°, untere Hälfte)
  { key: "distress",       label: "Kummer",       valence: -1, color: "#6a7a8a" },
  { key: "fear",           label: "Angst",        valence: -1, color: "#ff7878" },
  { key: "disappointment", label: "Enttäuschung", valence: -1, color: "#8a7a6a" },
  { key: "shame",          label: "Scham",        valence: -1, color: "#9a6a8a" },
  { key: "dislike",        label: "Abneigung",    valence: -1, color: "#7a8a6a" },
  { key: "tension",        label: "Spannung",     valence: -1, color: "#ffaa44" }
];

const LERP_RATE = 0.12; // Smooth interpolation speed
const MIN_BAR_LENGTH = 0.04; // Minimum visible bar (auch bei 0 ein kleiner Punkt)

export class EmotionWidget extends BaseWidget {
  constructor(canvas) {
    super(canvas);

    // Interpolierte Werte (für smooth animation)
    this._displayed = {};
    for (const e of EMOTION_LAYOUT) this._displayed[e.key] = 0;
    this._displayedMood = 0;
    this._displayedDominant = "calm";

    // Data vom EmotionEngine
    this._snapshot = null;
    this._tick = 0;
  }

  /**
   * Wird von HudPanel mit EmotionEngine-Daten aufgerufen.
   * @param {Object} emotionSnapshot — EmotionEngine.getSnapshot()
   */
  update(emotionSnapshot) {
    if (!emotionSnapshot) return;
    this._snapshot = emotionSnapshot;
  }

  draw(now) {
    if (!this.ctx || this.isPaused) return;
    if (this._checkPendingResize()) return;
    const ctx = this.ctx;
    const w = this._W, h = this._H;
    if (w === 0 || h === 0) return;

    this._tick += 0.016;

    // Interpolation vorzeichnen
    this._interpolate();

    const cx = w / 2;
    const cy = h / 2;
    const maxR = Math.min(w, h) * 0.42;
    const minR = maxR * 0.15; // Innerer Ring (Mood-Bereich)

    // ─── Background ──────────────────────────────────────────
    ctx.clearRect(0, 0, w, h);

    // ─── Concentric guide rings ──────────────────────────────
    ctx.strokeStyle = "rgba(255,255,255,0.06)";
    ctx.lineWidth = 1;
    for (let i = 1; i <= 3; i++) {
      const r = minR + (maxR - minR) * (i / 3);
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    // ─── Divider line (positive/negative) ────────────────────
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.beginPath();
    ctx.moveTo(cx - maxR - 8, cy);
    ctx.lineTo(cx + maxR + 8, cy);
    ctx.stroke();

    // ─── Emotion bars ────────────────────────────────────────
    const n = EMOTION_LAYOUT.length;
    const positiveCount = 8;
    const negativeCount = 6;

    for (let i = 0; i < n; i++) {
      const e = EMOTION_LAYOUT[i];
      let angle;

      if (i < positiveCount) {
        // Positive: 180° → 360° (obere Hälfte), gleichmäßig verteilt
        const t = i / (positiveCount - 1); // 0 → 1
        angle = Math.PI + t * Math.PI; // 180° → 360°
      } else {
        // Negative: 0° → 180° (untere Hälfte)
        const ni = i - positiveCount;
        const t = (ni + 0.5) / negativeCount; // verteilt, mit offset
        angle = t * Math.PI; // 0° → 180°
      }

      const intensity = this._displayed[e.key] || 0;
      const barLen = minR + (maxR - minR) * Math.max(MIN_BAR_LENGTH, intensity);

      const x1 = cx + Math.cos(angle) * minR;
      const y1 = cy + Math.sin(angle) * minR;
      const x2 = cx + Math.cos(angle) * barLen;
      const y2 = cy + Math.sin(angle) * barLen;

      // Bar
      const isDominant = e.key === this._displayedDominant;
      ctx.strokeStyle = e.color;
      ctx.lineWidth = isDominant ? 3.5 : 2.0;
      ctx.globalAlpha = isDominant ? 0.95 : 0.35 + intensity * 0.4;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();

      // Glow für dominante Emotion
      if (isDominant && intensity > 0.1) {
        ctx.shadowColor = e.color;
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      // Endpunkt (leuchtender Punkt)
      if (intensity > 0.05) {
        ctx.fillStyle = e.color;
        ctx.globalAlpha = 0.7 + intensity * 0.3;
        ctx.beginPath();
        ctx.arc(x2, y2, isDominant ? 3.5 : 2.0, 0, Math.PI * 2);
        ctx.fill();
      }

      // Label (nur für dominante oder intensity > 0.3)
      if (isDominant || intensity > 0.3) {
        ctx.globalAlpha = isDominant ? 1.0 : 0.5;
        ctx.fillStyle = e.color;
        ctx.font = `${isDominant ? "bold " : ""}${isDominant ? 10 : 8}px sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const labelR = barLen + 14;
        const lx = cx + Math.cos(angle) * labelR;
        const ly = cy + Math.sin(angle) * labelR;
        ctx.fillText(e.label, lx, ly);
      }

      ctx.globalAlpha = 1.0;
    }

    // ─── Mood center indicator ───────────────────────────────
    const mood = this._displayedMood; // -1 to +1
    const moodColor = mood >= 0
      ? `rgba(72, 255, 163, ${0.3 + mood * 0.4})`
      : `rgba(255, 120, 120, ${0.3 + (-mood) * 0.4})`;

    // Inner circle
    ctx.fillStyle = "rgba(10, 12, 20, 0.6)";
    ctx.beginPath();
    ctx.arc(cx, cy, minR - 2, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = moodColor;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cy, minR - 2, 0, Math.PI * 2);
    ctx.stroke();

    // Mood arc (füllt den inneren Ring entsprechend)
    const moodAbs = Math.abs(mood);
    if (moodAbs > 0.02) {
      ctx.strokeStyle = moodColor;
      ctx.lineWidth = 3;
      ctx.beginPath();
      const startA = mood >= 0 ? -Math.PI / 2 : Math.PI / 2;
      const endA = startA + moodAbs * Math.PI;
      ctx.arc(cx, cy, minR - 4, startA, endA);
      ctx.stroke();
    }

    // Mood text
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.font = "8px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("MOOD", cx, cy - 6);

    ctx.fillStyle = moodColor;
    ctx.font = "bold 11px sans-serif";
    const moodLabel = mood > 0.3 ? "+" : mood < -0.3 ? "−" : "○";
    ctx.fillText(moodLabel, cx, cy + 6);

    // ─── Dominant emotion label (unten) ──────────────────────
    const dominantInfo = EMOTION_LAYOUT.find(e => e.key === this._displayedDominant);
    if (dominantInfo) {
      ctx.fillStyle = dominantInfo.color;
      ctx.font = "bold 10px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "bottom";
      ctx.globalAlpha = 0.8;
      ctx.fillText(dominantInfo.label.toUpperCase(), cx, h - 2);
      ctx.globalAlpha = 1.0;
    }
  }

  // ─── Smooth interpolation ──────────────────────────────────────────

  _interpolate() {
    if (!this._snapshot) return;

    const emotions = this._snapshot.emotions || {};
    for (const e of EMOTION_LAYOUT) {
      const target = emotions[e.key] || 0;
      this._displayed[e.key] += (target - this._displayed[e.key]) * LERP_RATE;
    }

    const targetMood = this._snapshot.mood || 0;
    this._displayedMood += (targetMood - this._displayedMood) * LERP_RATE;

    const targetDominant = this._snapshot.dominant?.emotion || "calm";
    this._displayedDominant = targetDominant;
  }
}
