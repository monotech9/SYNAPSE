/**
 * MemoryRingsWidget — Dendritische Speicher-Ringe (SVG)
 * Jeder Cluster = ein Ring. Wachstum im Uhrzeigersinn (strokeDasharray).
 * Dendriten-Verzweigungen nach aussen zeigen Vernetzung.
 *
 * Performance: SVG-Struktur wird beim ersten Render aufgebaut und danach
 * nur noch per Attribut-Update verändert (kein innerHTML-Rebuild).
 * Zusätzlich CSS-transform für GPU-beschleunigte Rotation.
 */
export class MemoryRingsWidget {
  constructor(svgEl) {
    this.svg = svgEl;
    this.isPaused = false;
    this._built = false;
    this._rings = [];      // [{circle, dendrites: []}]
    this._lastClusterCount = 0;
  }

  update(clusters) {
    if (!this.svg || this.isPaused) return;
    const W = 240, H = 136, cx = W / 2, cy = H / 2;

    const n = Math.min(clusters.length, 5);
    const sorted = [...clusters].sort((a, b) => a.id - b.id);

    // Struktur nur neu aufbauen wenn Cluster-Anzahl sich ändert
    if (this._lastClusterCount !== n) {
      this._lastClusterCount = n;
      this._buildStructure(n, W, H, cx, cy, sorted);
    }

    // Attribute updaten (kein innerHTML-Rebuild)
    this.svg.setAttribute("viewBox", `0 0 ${W} ${H}`);

    for (let i = 0; i < n; i++) {
      const cl = sorted[i];
      const mem = Math.min(0.99, cl.memoryStrength);
      const ringR = 14 + i * 12;
      const circ = 2 * Math.PI * ringR;
      const fill = mem * circ;
      const alpha = (0.20 + mem * 0.60).toFixed(2);
      const ring = this._rings[i];
      if (!ring) continue;

      // Fill-Ring aktualisieren
      if (ring.fillCircle && fill > 0.5) {
        ring.fillCircle.setAttribute("stroke-dasharray", `${fill.toFixed(1)} ${circ.toFixed(1)}`);
        ring.fillCircle.setAttribute("stroke-dashoffset", (circ / 4).toFixed(1));
        ring.fillCircle.setAttribute("stroke", `rgba(42,184,255,${alpha})`);
        ring.fillCircle.style.filter = `drop-shadow(0 0 ${(3+mem*4).toFixed(1)}px rgba(42,184,255,${(0.22+mem*0.30).toFixed(2)}))`;
        ring.fillCircle.style.opacity = "1";
      } else if (ring.fillCircle) {
        ring.fillCircle.style.opacity = "0";
      }

      // Dendriten aktualisieren
      const numD = Math.floor(mem * 8) + 2;
      for (let d = 0; d < ring.dendrites.length; d++) {
        const dend = ring.dendrites[d];
        if (d < numD) {
          const angle = (d / numD) * Math.PI * 2 + (cl.id * 0.31);
          const dLen = 4 + mem * 6 + Math.sin(d * 2.7) * 1.5;
          const x1 = cx + Math.cos(angle) * ringR, y1 = cy + Math.sin(angle) * ringR;
          const x2 = cx + Math.cos(angle) * (ringR + dLen), y2 = cy + Math.sin(angle) * (ringR + dLen);
          const da = (0.15 + mem * 0.38).toFixed(2);
          dend.line.setAttribute("x1", x1.toFixed(1));
          dend.line.setAttribute("y1", y1.toFixed(1));
          dend.line.setAttribute("x2", x2.toFixed(1));
          dend.line.setAttribute("y2", y2.toFixed(1));
          dend.line.setAttribute("stroke", `rgba(42,184,255,${da})`);
          dend.line.style.opacity = "1";
          if (dend.dot) {
            dend.dot.setAttribute("cx", x2.toFixed(1));
            dend.dot.setAttribute("cy", y2.toFixed(1));
            dend.dot.setAttribute("fill", `rgba(42,184,255,${(parseFloat(da)*1.3).toFixed(2)})`);
            dend.dot.style.opacity = mem > 0.2 ? "1" : "0";
          }
        } else {
          dend.line.style.opacity = "0";
          if (dend.dot) dend.dot.style.opacity = "0";
        }
      }
    }

    // Core-Punkte: rotieren + Intensität basierend auf memoryStrength
    for (let i = 0; i < n; i++) {
      const cl = sorted[i];
      const mem = Math.min(0.99, cl.memoryStrength);
      const ring = this._rings[i];
      if (!ring?.coreEl) continue;
      // Angle: rotiert langsam basierend auf Cluster-ID + Zeit
      const t = (Date.now() / 1000);
      const angle = (cl.id * 1.27 + t * (0.3 + mem * 0.5)) % (Math.PI * 2);
      // Konsolidierung: starke Cluster → kleinerer Ring (weiter innen)
      const baseR = 14 + i * 12;
      const effectiveR = baseR * (1 - mem * 0.18); // max 18% nach innen
      const px = (cx + Math.cos(angle) * effectiveR).toFixed(2);
      const py = (cy + Math.sin(angle) * effectiveR).toFixed(2);
      ring.coreEl.setAttribute("cx", px);
      ring.coreEl.setAttribute("cy", py);
      ring.coreEl.setAttribute("r", (1.5 + mem * 1.2).toFixed(1));
      ring.coreEl.setAttribute("fill", `rgba(42,184,255,${(0.5 + mem * 0.45).toFixed(2)})`);
      ring.coreEl.style.filter = `drop-shadow(0 0 ${(2 + mem * 6).toFixed(1)}px rgba(42,184,255,${(0.5 + mem * 0.4).toFixed(2)}))`;
      ring.coreEl.style.opacity = "1";
    }

    // Text-Label aktualisieren
    if (this._textEl) {
      this._textEl.textContent = n > 0 ? `${n} CLUSTER` : "";
    }
  }

  _buildStructure(n, W, H, cx, cy, sorted) {
    this._rings = [];
    let svgContent = `<circle cx="${cx}" cy="${cy}" r="2.5" fill="rgba(42,184,255,0.45)" />`;

    for (let i = 0; i < n; i++) {
      const ringR = 14 + i * 12;
      const circ = 2 * Math.PI * ringR;

      // Base ring (statisch)
      svgContent += `<circle cx="${cx}" cy="${cy}" r="${ringR}" fill="none" stroke="rgba(42,184,255,0.07)" stroke-width="1.6"/>`;

      // Fill ring (dynamisch — wird per Attribut aktualisiert)
      svgContent += `<circle class="ring-fill" data-idx="${i}" cx="${cx}" cy="${cy}" r="${ringR}" fill="none" stroke="rgba(42,184,255,0)" stroke-width="2.2" transform="rotate(-90 ${cx} ${cy})" style="opacity:0; transition: opacity 0.3s ease;"/>`;

      // Dendriten (10 max — werden ein-/ausgeblendet)
      for (let d = 0; d < 10; d++) {
        svgContent += `<line class="dendrite" data-ring="${i}" data-d="${d}" x1="0" y1="0" x2="0" y2="0" stroke="rgba(42,184,255,0)" stroke-width="0.7" stroke-linecap="round" style="opacity:0; transition: opacity 0.2s ease;"/>`;
        svgContent += `<circle class="dendrite-dot" data-ring="${i}" data-d="${d}" cx="0" cy="0" r="0.9" fill="rgba(42,184,255,0)" style="opacity:0;"/>`;
      }
      // Cluster-Core-Punkt: glühender Knoten auf dem Ring
      svgContent += `<circle class="cluster-core" data-ring="${i}" cx="${cx}" cy="${cy - ringR}" r="2.2" fill="rgba(42,184,255,0.7)" style="opacity:0; filter:drop-shadow(0 0 3px rgba(42,184,255,0.8)); transition:opacity 0.4s ease;"/>`;
    }

    svgContent += `<text class="rings-label" x="${cx}" y="${H-3}" text-anchor="middle" font-family="ui-monospace" font-size="7" fill="rgba(110,155,205,0.45)" letter-spacing="0.1em"></text>`;

    this.svg.innerHTML = svgContent;

    // Referenzen cachen
    this._textEl = this.svg.querySelector(".rings-label");
    for (let i = 0; i < n; i++) {
      const fillCircle = this.svg.querySelector(`.ring-fill[data-idx="${i}"]`);
      const dendrites = [];
      for (let d = 0; d < 10; d++) {
        const line = this.svg.querySelector(`.dendrite[data-ring="${i}"][data-d="${d}"]`);
        const dot = this.svg.querySelector(`.dendrite-dot[data-ring="${i}"][data-d="${d}"]`);
        if (line) dendrites.push({ line, dot });
      }
      const coreEl = this.svg.querySelector(`.cluster-core[data-ring="${i}"]`);
      this._rings.push({ fillCircle, dendrites, coreEl });
    }
  }

  pause() {
    this.isPaused = true;
  }

  resume() {
    this.isPaused = false;
  }

  destroy() {
    if (this.svg) this.svg.innerHTML = "";
    this._rings = [];
    this._built = false;
    this.isPaused = false;
  }
}