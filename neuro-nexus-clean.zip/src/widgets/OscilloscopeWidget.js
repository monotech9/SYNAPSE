/**
 * OscilloscopeWidget — Frequenz-Oszillograph (3-Kanal: Gamma/Beta/Alpha)
 *
 * Erbt von BaseWidget für einheitliches Lifecycle-Management.
 * DPR-Scaling und ResizeObserver werden von BaseWidget übernommen.
 */
import { BaseWidget } from "./BaseWidget.js";

export class OscilloscopeWidget extends BaseWidget {
  constructor(canvas) {
    super(canvas);
    if (!this.ctx) return;

    this._offset     = 0;
    this._gammaSpike = 0;
    this._betaLevel  = 0;
    this._alphaLevel = 1;
    this._impulse    = 0;
  }

  update(pulseRatio, now) {
    this._betaLevel  += (pulseRatio - this._betaLevel) * 0.07;
    this._alphaLevel += ((1 - pulseRatio) - this._alphaLevel) * 0.04;
    if (pulseRatio > 0.4 && Math.random() < pulseRatio * 0.07) {
      this._gammaSpike = Math.min(1, this._gammaSpike + 0.25 + Math.random() * 0.3);
    }
    this._gammaSpike = Math.max(0, this._gammaSpike - 0.022);
    if (this._impulse > 0) {
      this._gammaSpike = Math.min(1, this._gammaSpike + this._impulse * 0.4);
      this._impulse    = Math.max(0, this._impulse - 0.05);
    }
  }

  triggerImpulse() { this._impulse = 1.0; }
  spikeGamma(amount = 0.18) { this._gammaSpike = Math.min(1, this._gammaSpike + amount); }

  draw(now) {
    if (!this.ctx || this._W === 0 || this._H === 0 || this.isPaused) return;
    if (this._checkPendingResize()) return;
    const el = this.canvas;
    if (el.clientWidth === 0 || el.clientHeight === 0) { this.resize(); return; }
    const ctx = this.ctx, W = this._W, H = this._H, cy = H * 0.5;
    ctx.clearRect(0, 0, W, H);

    ctx.strokeStyle = "rgba(60,140,230,0.06)"; ctx.lineWidth = 0.5;
    for (let x = 0; x <= W; x += 20) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
    for (let y = 0; y <= H; y += 12) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }

    const off = this._offset;
    const aAmp = this._alphaLevel * 7 + 2;
    ctx.save(); ctx.globalCompositeOperation = "lighter";
    const aGrad = ctx.createLinearGradient(0, cy - aAmp, 0, cy + aAmp + 4);
    aGrad.addColorStop(0, "rgba(140,100,220,0.07)");
    aGrad.addColorStop(1, "rgba(140,100,220,0)");
    ctx.beginPath();
    this._drawSine(ctx, W, cy, aAmp, 0.020, off);
    ctx.lineTo(W, cy); ctx.lineTo(0, cy); ctx.closePath();
    ctx.fillStyle = aGrad; ctx.fill();
    ctx.beginPath(); ctx.lineWidth = 2.5; ctx.strokeStyle = "rgba(140,100,220,0.11)";
    ctx.shadowColor = "#8c64dc"; ctx.shadowBlur = 7;
    this._drawSine(ctx, W, cy, aAmp, 0.020, off); ctx.stroke();
    ctx.beginPath(); ctx.lineWidth = 1.2; ctx.strokeStyle = "#8c64dc"; ctx.shadowBlur = 0;
    this._drawSine(ctx, W, cy, aAmp, 0.020, off); ctx.stroke();
    ctx.restore();

    const bAmp = this._betaLevel * 12 + 2;
    ctx.save(); ctx.globalCompositeOperation = "lighter";
    const bGrad = ctx.createLinearGradient(0, cy - bAmp, 0, cy + bAmp + 4);
    bGrad.addColorStop(0, "rgba(42,184,255,0.06)");
    bGrad.addColorStop(1, "rgba(42,184,255,0)");
    ctx.beginPath();
    this._drawBeta(ctx, W, cy, bAmp, 0.027, off);
    ctx.lineTo(W, cy); ctx.lineTo(0, cy); ctx.closePath();
    ctx.fillStyle = bGrad; ctx.fill();
    ctx.beginPath(); ctx.lineWidth = 2.5; ctx.strokeStyle = "rgba(60,140,230,0.11)";
    ctx.shadowColor = "#3c8ce6"; ctx.shadowBlur = 7;
    this._drawBeta(ctx, W, cy, bAmp, 0.027, off); ctx.stroke();
    ctx.beginPath(); ctx.lineWidth = 1.2; ctx.strokeStyle = "#3c8ce6"; ctx.shadowBlur = 0;
    this._drawBeta(ctx, W, cy, bAmp, 0.027, off); ctx.stroke();
    ctx.restore();

    const gAmp = this._gammaSpike * 15;
    if (gAmp > 0.4) {
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      const gGrad = ctx.createLinearGradient(0, cy - gAmp, 0, cy + gAmp + 4);
      gGrad.addColorStop(0, `rgba(80,220,255,${(gAmp * 0.004).toFixed(3)})`);
      gGrad.addColorStop(1, "rgba(80,220,255,0)");
      ctx.beginPath();
      this._drawGamma(ctx, W, cy, gAmp, off * 2.4);
      ctx.lineTo(W, cy); ctx.lineTo(0, cy); ctx.closePath();
      ctx.fillStyle = gGrad; ctx.fill();
      ctx.beginPath(); ctx.lineWidth = 2.2; ctx.strokeStyle = "rgba(80,220,255,0.16)";
      ctx.shadowColor = "#50dcff"; ctx.shadowBlur = 10;
      this._drawGamma(ctx, W, cy, gAmp, off * 2.4); ctx.stroke();
      ctx.beginPath(); ctx.lineWidth = 1.2; ctx.strokeStyle = "#50dcff"; ctx.shadowBlur = 0;
      this._drawGamma(ctx, W, cy, gAmp, off * 2.4); ctx.stroke();
      ctx.restore();
    }

    ctx.font = '600 7px "SF Mono",ui-monospace,monospace'; ctx.textAlign = "left";
    ctx.fillStyle = "rgba(140,100,220,0.55)"; ctx.fillText("\u03b1 ALPHA", 5, 10);
    ctx.fillStyle = "rgba(60,140,230,0.55)";  ctx.fillText("\u03b2 BETA", 5, 20);
    if (gAmp > 0.5) { ctx.fillStyle = "#50dcff"; ctx.fillText("\u03b3 GAMMA", 5, 30); }

    this._offset += 0.030 + this._betaLevel * 0.028 + this._gammaSpike * 0.045;
  }

  _drawSine(ctx, W, cy, amp, freq, off) {
    for (let x = 0; x < W; x++) { const y = cy + Math.sin(x*freq+off)*amp; x===0?ctx.moveTo(x,y):ctx.lineTo(x,y); }
  }
  _drawBeta(ctx, W, cy, amp, freq, off) {
    for (let x = 0; x < W; x++) {
      const y = cy + Math.sin(x*freq+off)*amp + Math.sin(x*freq*2.4-off*1.3)*(amp*0.3);
      x===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
    }
  }
  _drawGamma(ctx, W, cy, amp, off) {
    for (let x = 0; x < W; x++) {
      let y = cy + Math.sin(x*0.09+off)*amp*0.55 + Math.sin(x*0.22+off*1.4)*amp*0.38 + Math.sin(x*0.45-off*2.0)*amp*0.28;
      y += (Math.sin(x*0.31+off*3) > 0.92 ? amp*0.45 : 0);
      x===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
    }
  }
}
