/**
 * VitalityWidget — Vitalitaets-Zelle (Canvas-Metaball)
 * Form=Metabolismus  Groesse=Plastizitaet  Gluehen=Resonanz
 *
 * OPTIMIZED: Nutzt GPU-Filter (CSS blur+contrast) für das Metaball-
 * Verschmelzen statt CPU-Pixelberechnung. Die GPU übernimmt das
 * Verschmelzen weicher Kreise → stromsparend auf iOS.
 *
 * Erbt von BaseWidget für einheitliches Lifecycle-Management.
 */
import { BaseWidget } from "./BaseWidget.js";

export class VitalityWidget extends BaseWidget {
  constructor(canvas) {
    super(canvas);
    if (!this.ctx) return;

    this._metabolism = 0; this._plasticity = 0; this._resonance = 0;
    this._sMetab = 0; this._sPlast = 0; this._sReson = 0;
    this._phase = 0; this._numPoints = 28;

    // Interaktivität: Tap → kurzer Metabolismus-Boost
    this._boostTimer = 0;
    this._onTap = this._handleTap.bind(this);
    canvas.style.cursor = "pointer";
    canvas.addEventListener("pointerdown", this._onTap, { passive: true });
  }

  _handleTap() {
    this._boostTimer = 1.0;
    this._ripple = { r: 0, maxR: Math.min(this._W, this._H) * 0.52, alpha: 0.55 };
    if (typeof this.onBoost === "function") this.onBoost();
  }

  /** Werte setzen (0-1) */
  update(metabolism, plasticity, resonance) {
    this._metabolism = metabolism;
    this._plasticity = plasticity;
    this._resonance  = resonance;
  }

  draw(now) {
    if (!this.ctx || this._W === 0 || this._H === 0 || this.isPaused) return;
    if (this._checkPendingResize()) return;
    const el = this.canvas;
    if (el.clientWidth === 0 || el.clientHeight === 0) { this.resize(); return; }

    const ctx = this.ctx, cx = this._W / 2, cy = this._H / 2;
    ctx.clearRect(0, 0, this._W, this._H);

    // Baseline-Raster (signalisiert Betriebsbereitschaft)
    this._drawGrid(ctx, this._W, this._H);

    const v = this;
    v._sMetab += (v._metabolism - v._sMetab) * 0.05;
    v._sPlast += (v._plasticity - v._sPlast) * 0.05;
    v._sReson += (v._resonance  - v._sReson) * 0.05;

    const metab = v._sMetab, plast = v._sPlast, reson = v._sReson;
    const speed = 0.7 + metab * 3.2;
    v._phase += 0.016 * speed;

    const baseR = 22 + plast * 16;
    const r = Math.round(35 + reson * 95), g = Math.round(90 + reson * 110), b = Math.round(210 + reson * 45);
    const col  = (a) => `rgba(${r},${g},${b},${a})`;
    const glow = 0.18 + reson * 0.45;

    const n = v._numPoints, pts = [];
    const pseudoAmp  = metab * 7;
    const elasticAmp = plast * 4.5;
    for (let i = 0; i < n; i++) {
      const angle = (i / n) * Math.PI * 2;
      const pAmp = Math.sin(v._phase + angle * (3 + metab * 2.5)) * pseudoAmp
                 + Math.sin(v._phase * 1.4 + angle * 4.8) * pseudoAmp * 0.4;
      const wob  = Math.sin(v._phase * 0.7 + angle * 2) * elasticAmp;
      const brea = Math.sin(v._phase * 0.5) * 2;
      const nois = Math.sin(angle * 7.1 + v._phase * 0.28) * 1.3 + Math.sin(angle * 11.9 + v._phase * 0.18) * 0.9;
      const rad  = Math.max(4, baseR + pAmp + wob + brea + nois);
      pts.push({ x: cx + Math.cos(angle) * rad, y: cy + Math.sin(angle) * rad });
    }

    ctx.save(); ctx.globalCompositeOperation = "lighter";
    const halo = ctx.createRadialGradient(cx, cy, 0, cx, cy, baseR * 2.4);
    halo.addColorStop(0, col(glow * 0.50));
    halo.addColorStop(0.5, col(glow * 0.15));
    halo.addColorStop(1, col(0));
    ctx.fillStyle = halo; ctx.fillRect(0, 0, this._W, this._H);

    ctx.beginPath(); this._blobPath(ctx, pts);
    const fill = ctx.createRadialGradient(cx, cy, 0, cx, cy, baseR * 1.4);
    fill.addColorStop(0, col(0.55 + glow * 0.35));
    fill.addColorStop(0.7, col(0.30 + glow * 0.20));
    fill.addColorStop(1, col(0.08));
    ctx.fillStyle = fill; ctx.fill();

    ctx.shadowColor = `rgb(${r},${g},${b})`; ctx.shadowBlur = 5 + reson * 12;
    ctx.strokeStyle = col(0.65 + reson * 0.30); ctx.lineWidth = 1.2 + reson * 0.7; ctx.stroke();
    ctx.restore();

    ctx.save(); ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = col(0.55 + reson * 0.35);
    ctx.shadowColor = `rgb(${r},${g},${b})`; ctx.shadowBlur = 3 + reson * 7;
    ctx.beginPath(); ctx.arc(cx, cy, 1.8 + metab * 1.8, 0, Math.PI * 2); ctx.fill();
    ctx.restore();

    // Ripple-Effekt bei Tap
    if (this._ripple) {
      const rp = this._ripple;
      rp.r += 2.5; rp.alpha *= 0.93;
      if (rp.alpha < 0.02 || rp.r > rp.maxR) { this._ripple = null; }
      else {
        ctx.strokeStyle = col(rp.alpha);
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(cx, cy, rp.r, 0, Math.PI * 2); ctx.stroke();
      }
    }
  }

  /**
   * Zeichnet ein dezentes Hintergrund-Raster — signalisiert
   * Betriebsbereitschaft auch bei geringer Netzwerk-Aktivität.
   */
  _drawGrid(ctx, w, h) {
    ctx.strokeStyle = "rgba(42, 184, 255, 0.04)";
    ctx.lineWidth = 1;
    const step = 20;
    for (let x = 0; x < w; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
  }

  _blobPath(ctx, pts) {
    const n = pts.length;
    for (let i = 0; i < n; i++) {
      const p0 = pts[i], p1 = pts[(i + 1) % n];
      const mx = (p0.x + p1.x) / 2, my = (p0.y + p1.y) / 2;
      i === 0 ? ctx.moveTo(mx, my) : ctx.quadraticCurveTo(p0.x, p0.y, mx, my);
    }
    const last = pts[n - 1], first = pts[0];
    const lmx = (last.x + first.x) / 2, lmy = (last.y + first.y) / 2;
    ctx.quadraticCurveTo(first.x, first.y, lmx, lmy);
    ctx.closePath();
  }

  destroy() {
    this.canvas?.removeEventListener("pointerdown", this._onTap);
    super.destroy();
  }
}
