/**
 * ConnectionWidget — Verbindungsstärke-Anzeige
 *
 * Zeigt 4 Verbindungen mit animierten Füllbars und %-Werten.
 * Werte können via update(connections) mit echten Sim-Daten
 * gespeist werden; ohne externe Daten animiert sich alles selbst.
 */

import { BaseWidget } from "./BaseWidget.js";

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp  = (a, b, t) => a + (b - a) * t;

const DEFAULTS = [
  { l: "Synapse #A→B",    v: 92, c: "#34d399" },
  { l: "Cluster #00→#01", v: 67, c: "#60a5fa" },
  { l: "Bridge-Link",     v: 45, c: "#f59e0b" },
  { l: "FMRI-Feed",       v: 88, c: "#a78bfa" },
];

export class ConnectionWidget extends BaseWidget {
  /**
   * @param {HTMLElement} bodyEl — Container-Div
   */
  constructor(bodyEl) {
    super(null);
    this._body = bodyEl;
    this._conns = DEFAULTS.map(d => ({ ...d, t: d.v }));
    this._timer = null;

    this._render();
    this._timer = setInterval(() => this._tick(), 1200);
  }

  _render() {
    if (!this._body) return;
    this._body.innerHTML = this._conns
      .map(({ l, v, c }, i) => `
        <div style="display:flex;flex-direction:column;gap:2px">
          <div style="display:flex;justify-content:space-between">
            <span style="font-size:7.5px;color:var(--hud-muted,#94a3b8)">${l}</span>
            <span id="nn-cv${i}" style="font-size:7.5px;font-weight:700;color:${c}">${v}%</span>
          </div>
          <div style="height:3px;border-radius:2px;background:rgba(30,58,95,.45);overflow:hidden">
            <div id="nn-cf${i}" style="height:100%;width:${v}%;border-radius:2px;background:${c};box-shadow:0 0 5px ${c}50;transition:width .9s"></div>
          </div>
        </div>`
      ).join("");
  }

  /** Erlaubt externe Daten: array von { label, value (0–100), color } */
  update(connections) {
    if (!Array.isArray(connections)) return;
    connections.slice(0, this._conns.length).forEach((conn, i) => {
      if (conn.value !== undefined) this._conns[i].t = clamp(conn.value, 0, 100);
    });
  }

  _tick() {
    if (this._isDestroyed || this.isPaused) return;
    this._conns.forEach((cn, i) => {
      cn.t = clamp(cn.t + (Math.random() - 0.5) * 10, 15, 98);
      cn.v = lerp(cn.v, cn.t, 0.1);
      const vEl = document.getElementById(`nn-cv${i}`);
      const fEl = document.getElementById(`nn-cf${i}`);
      if (vEl) vEl.textContent = Math.round(cn.v) + "%";
      if (fEl) fEl.style.width = Math.round(cn.v) + "%";
    });
  }

  pause()  { this.isPaused = true;  }
  resume() { this.isPaused = false; }

  destroy() {
    this._isDestroyed = true;
    if (this._timer) clearInterval(this._timer);
  }
}
