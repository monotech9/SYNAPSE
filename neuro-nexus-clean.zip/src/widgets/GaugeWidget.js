/**
 * GaugeWidget — Arc-Gauge-Visualisierung (CPU / MEM / NET)
 *
 * Eigenständiges Widget mit drei kreisförmigen Gauges.
 * Daten werden über update(cpu, mem, net) als 0–1-Werte gesetzt.
 */

import { BaseWidget } from "./BaseWidget.js";

const PI = Math.PI;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp  = (a, b, t) => a + (b - a) * t;

export class GaugeWidget extends BaseWidget {
  /**
   * @param {Object} canvases — { cpu: HTMLCanvasElement, mem: HTMLCanvasElement, net: HTMLCanvasElement }
   * @param {Object} labels   — { cpu: HTMLElement, mem: HTMLElement, net: HTMLElement }
   */
  constructor(canvases, labels) {
    super(canvases.cpu); // BaseWidget uses a primary canvas for ResizeObserver
    this._canvases = canvases;
    this._labels   = labels;

    // Current (lerped) and target values
    this._cur = { cpu: 0.12, mem: 0.64, net: 0.38 };
    this._tgt = { cpu: 0.12, mem: 0.64, net: 0.38 };

    this._cols = { cpu: "#38bdf8", mem: "#60a5fa", net: "#a78bfa" };
    this._raf  = null;
    this._tick = this._tick.bind(this);
    this._raf  = requestAnimationFrame(this._tick);
  }

  /** Update target values (0–1). */
  update(cpu, mem, net) {
    this._tgt.cpu = clamp(cpu, 0, 1);
    this._tgt.mem = clamp(mem, 0, 1);
    this._tgt.net = clamp(net, 0, 1);
  }

  _tick() {
    if (this._isDestroyed || this.isPaused) {
      this._raf = requestAnimationFrame(this._tick);
      return;
    }
    const keys = ["cpu", "mem", "net"];
    keys.forEach(k => {
      this._cur[k] = lerp(this._cur[k], this._tgt[k], 0.05);
      this._drawGauge(k);
    });
    this._raf = requestAnimationFrame(this._tick);
  }

  _drawGauge(key) {
    const c = this._canvases[key];
    if (!c) return;
    const ctx = c.getContext("2d");
    const W = c.width, H = c.height;
    const cx = W / 2, cy = H / 2;
    const r = Math.min(W, H) * 0.34;
    const pct = this._cur[key];
    const col = this._cols[key];
    const startAngle = PI * 0.75;
    const endAngle   = PI * 2.25;
    const arcEnd     = startAngle + (endAngle - startAngle) * pct;

    ctx.clearRect(0, 0, W, H);

    // Track
    ctx.beginPath();
    ctx.arc(cx, cy, r, startAngle, endAngle);
    ctx.strokeStyle = "rgba(30,58,95,0.5)";
    ctx.lineWidth   = 5;
    ctx.lineCap     = "round";
    ctx.stroke();

    // Fill
    if (pct > 0) {
      ctx.beginPath();
      ctx.arc(cx, cy, r, startAngle, arcEnd);
      ctx.strokeStyle = col;
      ctx.lineWidth   = 5;
      ctx.lineCap     = "round";
      ctx.shadowBlur  = 9;
      ctx.shadowColor = col;
      ctx.stroke();
      ctx.shadowBlur  = 0;
    }

    // Inner fill
    ctx.beginPath();
    ctx.arc(cx, cy, r - 7, 0, PI * 2);
    ctx.fillStyle = "rgba(5,10,24,0.85)";
    ctx.fill();

    // Value text
    ctx.fillStyle    = "#fff";
    ctx.font         = `bold ${Math.max(7, Math.round(W * 0.115))}px monospace`;
    ctx.textAlign    = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(Math.round(pct * 100) + "%", cx, cy);

    // Update label element
    const lbl = this._labels?.[key];
    if (lbl) lbl.textContent = Math.round(pct * 100) + "%";
  }

  pause()   { this.isPaused = true;  }
  resume()  { this.isPaused = false; }

  destroy() {
    this._isDestroyed = true;
    if (this._raf) cancelAnimationFrame(this._raf);
    super.destroy?.();
  }
}
