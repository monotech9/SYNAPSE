/**
 * FmriWidget — 8×8 fMRI-Aktivitätsmatrix
 *
 * OPTIMIZED: Rendert auf einem winzigen Canvas (8×8 Pixel) via
 * ImageData. CSS streckt mit image-rendering: pixelated.
 * Verbraucht praktisch 0% CPU — ein putImageData pro Frame.
 *
 * Erbt von BaseWidget für Lifecycle-Management.
 */
import { BaseWidget } from "./BaseWidget.js";

const GRID = 8;
const CELLS = GRID * GRID;

// HUD-Akzentfarbe Cyan (RGBA: 42, 184, 255)
const BASE_R = 42;
const BASE_G = 184;
const BASE_B = 255;

export class FmriWidget extends BaseWidget {
  constructor(canvas) {
    super(canvas);
    this.cells = new Float32Array(CELLS);
    this._pendingFires = [];
    this._imgData = null;

    if (canvas) {
      canvas.width = GRID;
      canvas.height = GRID;
      // ImageData Puffer vorablegen — wird jedes Frame wiederverwendet
      if (this.ctx) {
        this._imgData = this.ctx.createImageData(GRID, GRID);
      }
    }
  }

  /** Override resize: fMRI braucht kein DPR-Scaling, nur 8×8 Pixel */
  resize() {
    // Canvas-Puffer bleibt 8×8. CSS handles the stretching.
  }

  /**
   * Welt-Dimensionen und Cluster werden von HudPanel übergeben.
   */
  update(world) {
    if (!this.ctx || this.isPaused) return;
    const cells = this.cells;

    // Langsamer Decay
    for (let i = 0; i < CELLS; i++) cells[i] *= 0.88;

    // Grundrauschen: schwache baseline Aktivität damit das Widget nie leer ist
    // Sanfte Noise-Welle über alle 64 Zellen — nicht zufällig sondern deterministisch
    const t = (this._tick || 0) * 0.02;
    this._tick = (this._tick || 0) + 1;
    for (let i = 0; i < CELLS; i++) {
      const gx = i % GRID, gy = Math.floor(i / GRID);
      // Sehr schwache Welle: 0.015–0.04 — gerade genug um Pixel sichtbar zu machen
      const noise = 0.015 + 0.025 * (0.5 + 0.5 * Math.sin(t + gx * 0.5 + gy * 0.7));
      if (cells[i] < noise) cells[i] = noise;
    }

    // Cluster-basiertes Spatial Mapping
    const clusters = world.clusters;
    if (!clusters) return;
    for (let ci = 0; ci < clusters.length; ci++) {
      const cl = clusters[ci];
      if (cl.state === "dormant") continue;
      const ctr = cl.center(world.currentTime);
      const gx = Math.floor(((ctr.x / world.width) + 0.5) * GRID);
      const gy = Math.floor(((ctr.y / world.height) + 0.5) * GRID);
      if (gx >= 0 && gx < GRID && gy >= 0 && gy < GRID) {
        const idx = gy * GRID + gx;
        cells[idx] = Math.min(1, cells[idx] + cl.activityMemory * 0.32);
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const nx = gx + dx, ny = gy + dy;
          if (nx >= 0 && nx < GRID && ny >= 0 && ny < GRID) {
            cells[ny * GRID + nx] = Math.min(1, cells[ny * GRID + nx] + cl.activityMemory * 0.08);
          }
        }
      }
    }

    // Node-Level Pulse-Mapping
    const pf = this._pendingFires;
    if (pf.length) {
      for (let pi = 0; pi < pf.length; pi++) {
        const { nx, ny } = pf[pi];
        const idx = ny * GRID + nx;
        if (idx >= 0 && idx < CELLS) {
          cells[idx] = Math.min(1, cells[idx] + 0.55);
        }
      }
      this._pendingFires.length = 0;
    }

    // Render: direktes Schreiben in ImageData — ein putImageData pro Frame
    if (!this._imgData) {
      this._imgData = this.ctx.createImageData(GRID, GRID);
    }
    const data = this._imgData.data;
    for (let i = 0; i < CELLS; i++) {
      const vv = cells[i];
      const pi = i * 4;
      if (vv < 0.005) {
        // Dunkle Zellen: transparent
        data[pi] = BASE_R;
        data[pi + 1] = BASE_G;
        data[pi + 2] = BASE_B;
        data[pi + 3] = Math.floor(vv * 400);
        continue;
      }
      // Farbverlauf: cyan (ruhig) → weiß (peak)
      const rr = Math.round(BASE_R + vv * (255 - BASE_R));
      const gg = Math.round(BASE_G + vv * (255 - BASE_G));
      const bb = Math.round(BASE_B + vv * (255 - BASE_B));
      data[pi] = rr;
      data[pi + 1] = gg;
      data[pi + 2] = bb;
      data[pi + 3] = Math.floor((0.45 + vv * 0.55) * 255);
    }
    this.ctx.putImageData(this._imgData, 0, 0);
  }

  /**
   * Wird von PulseEngine / HudPanel aufgerufen wenn ein Node feuert.
   * x, y: normalisierte Weltkoordinaten (–0.5…+0.5)
   */
  notifyFire(x, y) {
    const gx = Math.min(GRID - 1, Math.max(0, Math.floor((x + 0.5) * GRID)));
    const gy = Math.min(GRID - 1, Math.max(0, Math.floor((y + 0.5) * GRID)));
    this._pendingFires.push({ nx: gx, ny: gy });
  }
}
