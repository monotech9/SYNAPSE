/**
 * AlertWidget — System-Alarme Feed
 *
 * Zeigt eine Liste aktiver System-Alarme.
 * Alarme werden via addAlert() hinzugefügt oder intern aus
 * Simulations-Events generiert.
 */

import { BaseWidget } from "./BaseWidget.js";

const DEFAULTS = [
  { col: "#f59e0b", title: "⚠ Theta-Drift erkannt",    sub: "Abweichung +2.1 Hz seit 03:55" },
  { col: "#ef4444", title: "✕ Hohe Synaptische Last",   sub: "Netz-Auslastung > 90%" },
];

export class AlertWidget extends BaseWidget {
  /**
   * @param {HTMLElement} feedEl    — Container-Div für Alarm-Einträge
   * @param {HTMLElement} badgeEl   — Span für Alarm-Count (optional)
   */
  constructor(feedEl, badgeEl) {
    super(null);
    this._feed  = feedEl;
    this._badge = badgeEl;
    this._alerts = [...DEFAULTS];

    this._render();
  }

  _render() {
    if (!this._feed) return;
    this._feed.innerHTML = this._alerts
      .map(({ col, title, sub }) => `
        <div style="display:flex;gap:7px;align-items:flex-start;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.04)">
          <div style="width:6px;height:6px;border-radius:50%;flex-shrink:0;margin-top:3px;background:${col};box-shadow:0 0 5px ${col}80"></div>
          <div>
            <div style="font-size:8.5px;font-weight:700;color:${col};margin-bottom:1px">${title}</div>
            <div style="font-size:7.5px;color:var(--hud-muted,#475569)">${sub}</div>
          </div>
        </div>`
      ).join("");

    if (this._badge) this._badge.textContent = this._alerts.length + " AKTIV";
  }

  /** Fügt einen neuen Alarm hinzu (ältester wird nach max 5 entfernt). */
  addAlert(col, title, sub) {
    this._alerts.push({ col, title, sub });
    if (this._alerts.length > 5) this._alerts.shift();
    this._render();
  }

  /** Entfernt alle Alarme einer bestimmten Farbe/Kategorie. */
  clearAlerts() {
    this._alerts = [];
    this._render();
  }

  pause()  { /* no animation */ }
  resume() { /* no animation */ }
  destroy() { this._isDestroyed = true; }
}
