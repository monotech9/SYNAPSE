/**
 * RadarWidget — Konnektivitäts-Radar (Cluster-Topologie)
 *
 * Rundes Radar-Widget mit rotierendem Scan-Strahl.
 * Cluster feuern als leuchtende Punkte im jeweiligen Kreissektor,
 * verblasen langsam. Gibt dem Nutzer das Gefühl, die "Geografie"
 * des künstlichen Gehirns zu überwachen.
 *
 * Erbt von BaseWidget für Lifecycle-Management.
 */
import { BaseWidget } from "./BaseWidget.js";

export class RadarWidget extends BaseWidget {
  constructor(canvas) {
    super(canvas);
    this._blips = [];      // { angle, radius, intensity, decay }
    this._scanAngle = 0;   // Rotierender Scan-Strahl
    this._tick = 0;
  }

  /** Override resize: Radar braucht quadratischen Canvas mit DPR */
  resize() {
    const el = this.canvas;
    if (!el) return;
    const dpr = window.devicePixelRatio || 1;
    const w = el.clientWidth, h = el.clientHeight;
    if (w === 0 || h === 0) return;
    const pw = Math.round(w * dpr), ph = Math.round(h * dpr);
    if (el.width !== pw || el.height !== ph) {
      el.width = pw; el.height = ph;
      this.ctx?.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    this._W = w; this._H = h; this._dpr = dpr;
  }

  /**
   * Wird von HudPanel mit world-Daten aufgerufen.
   * Mappt Cluster-Positionen auf Radar-Blips.
   */
  update(world) {
    if (!this.ctx || this.isPaused) return;
    const clusters = world.clusters;
    if (!clusters) return;

    const scale = world.minSide > 1 ? world.minSide * (world.layoutScale || 0.5) : 300;

    for (const cl of clusters) {
      if (cl.state === "dormant") continue;
      let ctr;
      try { ctr = cl.center(world.currentTime || 0); } catch(e) { continue; }
      if (!ctr || typeof ctr.x !== "number") continue;
      // Normalisiere auf [-1, 1] relativ zur Layout-Skala
      const nx = scale > 0 ? ctr.x / scale : 0;
      const ny = scale > 0 ? ctr.y / scale : 0;
      const angle = Math.atan2(ny, nx);
      const dist = Math.min(0.48, Math.sqrt(nx * nx + ny * ny));
      const intensity = cl.activityMemory || 0;

      // Auch schwache Blips zeigen (Grundaktivität)
      if (intensity > 0.03) {
        this._blips.push({
          angle, dist: dist || 0.1 + Math.random() * 0.35, intensity, decay: 0.985
        });
      }
    }

    // Blips limitieren (Performance)
    if (this._blips.length > 60) {
      this._blips.splice(0, this._blips.length - 60);
    }
  }

  draw(now) {
    if (!this.ctx || this.isPaused) return;
    if (this._checkPendingResize()) return;
    const ctx = this.ctx;
    const w = this._W, h = this._H;
    if (w === 0) return;

    const cx = w / 2, cy = h / 2;
    const maxR = Math.min(w, h) * 0.46;

    // Hintergrund löschen mit leichtem Trail-Effekt
    ctx.fillStyle = "rgba(2, 8, 22, 0.18)";
    ctx.fillRect(0, 0, w, h);

    // Baseline-Raster (signalisiert Betriebsbereitschaft)
    this._drawGrid(ctx, w, h);

    // Konzentrische Grid-Kreise
    ctx.strokeStyle = "rgba(60, 140, 230, 0.12)";
    ctx.lineWidth = 0.5;
    for (let r = 0.25; r <= 1.0; r += 0.25) {
      ctx.beginPath();
      ctx.arc(cx, cy, maxR * r, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Kreuz-Linien
    ctx.beginPath();
    ctx.moveTo(cx - maxR, cy); ctx.lineTo(cx + maxR, cy);
    ctx.moveTo(cx, cy - maxR); ctx.lineTo(cx, cy + maxR);
    ctx.stroke();

    // Diagonal-Linien (schwach)
    ctx.strokeStyle = "rgba(60, 140, 230, 0.06)";
    const d = maxR * 0.707;
    ctx.beginPath();
    ctx.moveTo(cx - d, cy - d); ctx.lineTo(cx + d, cy + d);
    ctx.moveTo(cx - d, cy + d); ctx.lineTo(cx + d, cy - d);
    ctx.stroke();

    // Scan-Strahl (rotierend)
    this._scanAngle += 0.015;
    if (this._scanAngle > Math.PI * 2) this._scanAngle -= Math.PI * 2;
    const scanGrad = ctx.createLinearGradient(
      cx, cy,
      cx + Math.cos(this._scanAngle) * maxR,
      cy + Math.sin(this._scanAngle) * maxR
    );
    scanGrad.addColorStop(0, "rgba(42, 184, 255, 0.0)");
    scanGrad.addColorStop(0.7, "rgba(42, 184, 255, 0.05)");
    scanGrad.addColorStop(1, "rgba(42, 184, 255, 0.25)");

    ctx.fillStyle = scanGrad;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, maxR, this._scanAngle - 0.35, this._scanAngle);
    ctx.closePath();
    ctx.fill();

    // Scan-Linie selbst
    ctx.strokeStyle = "rgba(42, 184, 255, 0.35)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(this._scanAngle) * maxR, cy + Math.sin(this._scanAngle) * maxR);
    ctx.stroke();

    // Blips zeichnen + decay
    const surviving = [];
    for (const blip of this._blips) {
      const px = cx + Math.cos(blip.angle) * maxR * blip.dist * 2;
      const py = cy + Math.sin(blip.angle) * maxR * blip.dist * 2;
      const alpha = blip.intensity * blip.decay;

      if (alpha < 0.02) continue;

      // Glow
      const glowR = 3 + blip.intensity * 5;
      const glow = ctx.createRadialGradient(px, py, 0, px, py, glowR * 2);
      glow.addColorStop(0, `rgba(42, 184, 255, ${alpha * 0.8})`);
      glow.addColorStop(0.5, `rgba(42, 184, 255, ${alpha * 0.2})`);
      glow.addColorStop(1, "rgba(42, 184, 255, 0)");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(px, py, glowR * 2, 0, Math.PI * 2);
      ctx.fill();

      // Core dot
      ctx.fillStyle = `rgba(120, 220, 255, ${Math.min(1, alpha * 1.5)})`;
      ctx.beginPath();
      ctx.arc(px, py, 1.2 + blip.intensity * 1.5, 0, Math.PI * 2);
      ctx.fill();

      blip.decay *= 0.992;
      surviving.push(blip);
    }
    this._blips = surviving;

    // äußerer Ring
    ctx.strokeStyle = "rgba(60, 140, 230, 0.25)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, maxR, 0, Math.PI * 2);
    ctx.stroke();
  }


  /**
   * Zeichnet ein dezentes Hintergrund-Raster — signalisiert
   * Betriebsbereitschaft auch bei geringer Netzwerk-Aktivität.
   */
  _drawGrid(ctx, w, h) {
    ctx.strokeStyle = "rgba(42, 184, 255, 0.04)";
    ctx.lineWidth = 1;
    const step = 20;
    for (let x = 0; x < w; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
  }
}