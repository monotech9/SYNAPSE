/**
 * HeatmapWidget — Aktivitäts-Heatmap
 *
 * Zeigt ein 7×5-Raster mit amber-farbenen Zellen,
 * die Netzwerkaktivität der letzten Zeitintervalle darstellen.
 * Werte werden intern animiert und via pushActivity() aktualisiert.
 */

import { BaseWidget } from "./BaseWidget.js";

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export class HeatmapWidget extends BaseWidget {
  /**
   * @param {HTMLElement} gridEl — Container-Grid-Div
   */
  constructor(gridEl) {
    super(null);
    this._grid  = gridEl;
    this._cells = [];
    this._vals  = Array.from({ length: 35 }, () => Math.random() * 0.5);
    this._timer = null;

    this._init();
    this._timer = setInterval(() => this._update(), 900);
  }

  _init() {
    if (!this._grid) return;
    this._grid.innerHTML = this._vals
      .map(v =>
        `<div style="height:11px;border-radius:2px;background:rgba(245,158,11,${v.toFixed(2)});transition:background .7s"></div>`
      ).join("");
    this._cells = Array.from(this._grid.querySelectorAll("div"));
  }

  /** Schiebt einen neuen Aktivitätswert (0–1) ins Raster (ältester fällt raus). */
  pushActivity(value) {
    this._vals.shift();
    this._vals.push(clamp(value, 0, 1));
    this._applyVals();
  }

  _update() {
    if (this._isDestroyed || this.isPaused) return;
    this._vals = this._vals.map(v => clamp(v + (Math.random() - 0.5) * 0.14, 0, 1));
    this._applyVals();
  }

  _applyVals() {
    this._cells.forEach((c, i) => {
      if (c) c.style.background = `rgba(245,158,11,${this._vals[i].toFixed(2)})`;
    });
  }

  pause()  { this.isPaused = true;  }
  resume() { this.isPaused = false; }

  destroy() {
    this._isDestroyed = true;
    if (this._timer) clearInterval(this._timer);
  }
}
