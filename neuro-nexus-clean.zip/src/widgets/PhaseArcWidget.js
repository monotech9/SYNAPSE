/**
 * PhaseArcWidget — Phasen-Transitions-Arc
 *
 * Zeigt die 5 Entwicklungs-Phasen (GENESIS → KONVERGENZ)
 * als farbige Arc-Segmente. Der Fortschritt (0–1) wird
 * via setProgress() von der Simulation gesetzt.
 */

import { BaseWidget } from "./BaseWidget.js";

const PI = Math.PI;
const lerp = (a, b, t) => a + (b - a) * t;

const PHASES = ["GENESIS", "KNOSP.", "AKTIV.", "REIFUNG", "KONVERG."];
const COLS   = ["#475569", "#34d399", "#60a5fa", "#a78bfa", "#f59e0b"];

export class PhaseArcWidget extends BaseWidget {
  /**
   * @param {HTMLCanvasElement} canvas
   * @param {HTMLElement}       pctLabel — Span für %-Anzeige (optional)
   */
  constructor(canvas, pctLabel) {
    super(canvas);
    this._pctLabel = pctLabel;
    this._prog     = 0;
    this._target   = 0.65;
    this._raf      = null;
    this._tick     = this._tick.bind(this);
    this._raf      = requestAnimationFrame(this._tick);
  }

  /** Setzt den Ziel-Fortschritt (0–1). */
  setProgress(value) {
    this._target = Math.max(0, Math.min(1, value));
  }

  _tick() {
    if (this._isDestroyed || this.isPaused) {
      this._raf = requestAnimationFrame(this._tick);
      return;
    }
    this._prog = lerp(this._prog, this._target, 0.02);
    this._draw();
    this._raf = requestAnimationFrame(this._tick);
  }

  _draw() {
    const c = this.canvas;
    if (!c) return;
    const ctx = c.getContext("2d");
    const W = c.width, H = c.height;
    const cx = W / 2, cy = H / 2;
    const r  = Math.min(W, H) * 0.42;
    const prog = this._prog;

    ctx.clearRect(0, 0, W, H);

    PHASES.forEach((_, i) => {
      const sa = (i / PHASES.length) * PI * 2 - PI / 2;
      const ea = ((i + 1) / PHASES.length) * PI * 2 - PI / 2;
      const done   = i / PHASES.length < prog;
      const active = Math.floor(prog * PHASES.length) === i;

      ctx.beginPath();
      ctx.arc(cx, cy, r, sa + 0.08, ea - 0.08);
      ctx.strokeStyle = done ? COLS[i] : COLS[i] + "28";
      ctx.lineWidth   = active ? 7 : 4.5;
      ctx.lineCap     = "round";
      if (active) { ctx.shadowBlur = 12; ctx.shadowColor = COLS[i]; }
      ctx.stroke();
      ctx.shadowBlur = 0;
    });

    // Centre dot
    ctx.beginPath();
    ctx.arc(cx, cy, 10, 0, PI * 2);
    ctx.fillStyle   = "#050c1e";
    ctx.fill();
    ctx.strokeStyle = "#a78bfa";
    ctx.lineWidth   = 1.5;
    ctx.stroke();

    ctx.fillStyle    = "#a78bfa";
    ctx.font         = `bold ${Math.max(6, Math.round(W * 0.06))}px monospace`;
    ctx.textAlign    = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(Math.round(prog * 100) + "%", cx, cy);

    if (this._pctLabel) this._pctLabel.textContent = Math.round(prog * 100) + "%";
  }

  resize() { /* canvas is fixed-size */ }

  pause()  { this.isPaused = true;  }
  resume() { this.isPaused = false; }

  destroy() {
    this._isDestroyed = true;
    if (this._raf) cancelAnimationFrame(this._raf);
    super.destroy?.();
  }
}
