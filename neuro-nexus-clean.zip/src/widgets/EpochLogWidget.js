/**
 * EpochLogWidget — Evolutionäres Epochen-Log + Text-Feed
 *
 * Verwaltet zwei Bereiche:
 *  - Text-Feed (Echtzeit-Ereignisse) — neueste oben, CSS-Fade-Effekt
 *  - Epochen-Achse (Meilensteine + Events als vertikale Verzweigung)
 *
 * Zwei Integrations-Wege:
 *  1. Direkt: addLog(html, simAge) / addEpoch(label, detail, type, simAge)
 *     — genutzt von HudPanel für Simulations-Events (HTML, Sim-Zeit)
 *  2. EventBus: mount(eventBus) — lauscht auf story:event + story:milestone
 *     — genutzt für StoryMappingEngine Lebensereignisse (Plain-Text, auto-highlight)
 *
 * Die Methode erkennt automatisch ob der Text bereits HTML enthält (von HudPanel)
 * oder Plain-Text ist (von Story-Events) und wendet Keyword-Highlighting nur
 * bei Plain-Text an.
 */

// Funktion zum Aktualisieren des Tickers
function updateLiveTicker(messageText) {
  const tickerMsg = document.getElementById('tickerMsg');
  const tickerTag = document.getElementById('tickerTag');
  if (!tickerMsg || !tickerTag) return;

  // Nachricht bereinigen (falls HTML-Tags wie <span class="..."> enthalten sind)
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = messageText;
  const cleanText = tempDiv.textContent || tempDiv.innerText || "";

  // Prüfen, ob es sich um einen NOVA-Gedanken handelt
  const isNova = messageText.includes('log-hl-ai') || messageText.includes('NOVA');

  tickerMsg.textContent = cleanText;

  if (isNova) {
    tickerTag.textContent = "NOVA";
    tickerTag.style.color = "#c478ff";
    tickerTag.style.background = "rgba(196,120,255,0.12)";
    tickerMsg.classList.add('is-nova');
  } else {
    tickerTag.textContent = "SYS";
    tickerTag.style.color = "var(--hud-accent)";
    tickerTag.style.background = "var(--hud-accent-dim)";
    tickerMsg.classList.remove('is-nova');
  }
}

export class EpochLogWidget {
  /**
   * @param {string|HTMLElement} feedRef — DOM ID oder Element für den Text-Feed
   * @param {string|HTMLElement} epochRef — DOM ID oder Element für die Timeline
   * @param {string|HTMLElement} [badgeRef] — DOM ID oder Element für den Badge-Zähler
   */
  constructor(feedRef = 'logFeed', epochRef = 'epochLog', badgeRef = 'logCountBadge') {
    this.feedContainer  = typeof feedRef === 'string' ? document.getElementById(feedRef) : feedRef;
    this.epochContainer = typeof epochRef === 'string' ? document.getElementById(epochRef) : epochRef;
    this.badge          = typeof badgeRef === 'string' ? document.getElementById(badgeRef) : badgeRef;

    this.maxLogs    = 50;
    this.maxEpochs  = 18;
    this.totalEvents = 0;
    this.isPaused    = false;

    // Für Sim-Zeit-Formatierung (wird von HudPanel via addLog/addEpoch gesetzt)
    this._simAge = 0;

    // EventBus-Listener (für destroy)
    this._offStoryEvent = null;
    this._offStoryMilestone = null;
  }

  get total() { return this.totalEvents; }

  // ─── EventBus Integration ───────────────────────────────────────────

  /**
   * Verbindet das Widget mit dem Event-Bus der Simulation.
   * Subscribed auf story:event (Feed) und story:milestone (Timeline).
   */
  mount(eventBus) {
    if (!eventBus) return;

    // Story-Events → Text-Feed (mit Keyword-Highlighting)
    this._offStoryEvent = eventBus.on('story:event', (data) => {
      if (this.isPaused) return;
      const text = typeof data === 'string' ? data : (data.text || data.message || '');
      const age = (typeof data === 'object' && data.timestamp) ? data.timestamp : this._simAge;

      // Story-Events bekommen einen emotionalen Präfix
      const emotion = data?.emotion;
      const prefix = emotion ? `<span class="log-hl-story log-hl-story--${emotion}">${this._emotionLabel(emotion)}</span> ` : '';

      this.addLog(prefix + this.highlightKeywords(text), age);
    });

    // Milestones → Epochen-Timeline
    this._offStoryMilestone = eventBus.on('story:milestone', (data) => {
      if (this.isPaused) return;
      const label = data?.label || data?.emotion || 'Meilenstein';
      const detail = data?.text || '';
      const age = data?.timestamp || this._simAge;
      this.addEpoch(label, detail, 'milestone', age);
    });
  }

  // ─── Text-Feed ──────────────────────────────────────────────────────

  /**
   * Fügt eine neue Nachricht zum Live-Feed hinzu.
   * @param {string} htmlOrText — HTML (von HudPanel) oder Plain-Text (von Story-Events)
   * @param {number} [simAge] — Simulationsalter in Sekunden (für Zeitstempel)
   */
  addLog(htmlOrText, simAge) {
    if (!this.feedContainer || this.isPaused) return;

    const time = this._formatTime(simAge);
    const item = document.createElement('div');
    item.className = 'log-item newest';

    // Altes .newest entfernen, damit CSS Opacity-Fade (.newest + .log-item) greift
    this.feedContainer.querySelectorAll('.newest').forEach(el => el.classList.remove('newest'));

    // Wenn Text bereits HTML-Tags enthält → nicht doppelt highlighten
    const isHtml = /<[a-z][\s\S]*>/i.test(htmlOrText);
    const content = isHtml ? htmlOrText : this.highlightKeywords(htmlOrText);

    item.innerHTML = `
      <span class="log-time">[${time}]</span>
      <span class="log-text">${content}</span>
    `;

    // Feed: neueste oben (prepend für CSS-Fade-Effekt)
    this.feedContainer.prepend(item);

    // Limitieren
    while (this.feedContainer.children.length > this.maxLogs) {
      this.feedContainer.removeChild(this.feedContainer.lastChild);
    }

    this._incrementBadge();
    updateLiveTicker(htmlOrText);
  }

  // ─── Epochen-Timeline ───────────────────────────────────────────────

  /**
   * Fügt einen Meilenstein/Event zur Epochen-Timeline hinzu.
   * @param {string} label — Kurzer Titel
   * @param {string} [detail] — Beschreibung
   * @param {string|boolean} [type='event'] — 'milestone' oder 'event' (oder true/false für backward compat)
   * @param {number} [simAge] — Simulationsalter
   */
  addEpoch(label, detail = '', type = 'event', simAge) {
    if (!this.epochContainer || this.isPaused) return;

    // Backward compat: type kann boolean sein (isMilestone)
    const isMilestone = type === true || type === 'milestone';

    const time = this._formatTime(simAge);

    // Vorheriges Latest-Highlight entfernen
    this.epochContainer.querySelector('.epoch-entry--latest')?.classList.remove('epoch-entry--latest');

    const entry = document.createElement('div');
    entry.className = 'epoch-entry epoch-entry--latest';

    const nodeClass  = isMilestone ? 'epoch-node--milestone' : 'epoch-node--event';
    const labelClass = isMilestone ? 'epoch-label epoch-label--milestone' : 'epoch-label';

    entry.innerHTML = `
      <div class="epoch-axis"><div class="epoch-node ${nodeClass}"></div></div>
      <div class="epoch-content">
        <span class="epoch-time">[${time}]</span>
        <span class="${labelClass}">${label}</span>
        ${detail ? `<div class="epoch-detail">${this.highlightKeywords(detail)}</div>` : ''}
      </div>
    `;

    // Timeline wächst nach unten
    this.epochContainer.appendChild(entry);
    this.epochContainer.scrollTop = this.epochContainer.scrollHeight;

    // Limitieren
    while (this.epochContainer.children.length > this.maxEpochs) {
      this.epochContainer.removeChild(this.epochContainer.firstChild);
    }

    this._incrementBadge();
  }

  // ─── Keyword-Highlighting ───────────────────────────────────────────

  /**
   * Automatische CSS-Hervorhebung für Schlüsselwörter im Plain-Text.
   * Überspringt Text der bereits in HTML-Tags steht.
   */
  highlightKeywords(text) {
    if (!text) return '';
    let html = text;

    const highlights = {
      'log-hl-neuron':   /\b(Neuron|Neuronen|Zelle|Knoten)\b/gi,
      'log-hl-synapse':  /\b(Synapse|Synapsen|Verbindung|Pfad|Pfade)\b/gi,
      'log-hl-bridge':   /\b(Brücke|Brücken|Bridge)\b/gi,
      'log-hl-stage':    /\b(Epoche|Genesis|Aktivierung|Wachstum|Knospung|Netzwerk|Konstellation|Stadium)\b/gi,
      'log-hl-pulse':    /\b(Impuls|Signal|Signale|Welle|Kaskade|Puls)\b/gi,
      'log-hl-memory':   /\b(Speicher|Erinnerung|Erinnerungen|Gedächtnis|Spur|Spuren)\b/gi,
      'log-hl-warn':     /\b(Warnung|Kritisch|Fehler|Kollaps|Verlust)\b/gi,
      'log-hl-story':    /\b(AURORA|LYRA|NOVA|ELARA|VEGA|SOLEN|MIRA|ORION|NYX|LUMEN|AION|SOMA|IRIS|ECHO|NOEMA|VANTA)\b/gi,
    };

    for (const [cssClass, regex] of Object.entries(highlights)) {
      html = html.replace(regex, `<span class="${cssClass}">$&</span>`);
    }
    return html;
  }

  // ─── Hilfsfunktionen ────────────────────────────────────────────────

  _formatTime(simAge) {
    // Sim-Zeit (MM:SS) wenn verfügbar, sonst Real-Zeit
    if (typeof simAge === 'number' && isFinite(simAge) && simAge >= 0) {
      this._simAge = simAge;
      const m = Math.floor(simAge / 60).toString().padStart(2, '0');
      const s = Math.floor(simAge % 60).toString().padStart(2, '0');
      return `${m}:${s}`;
    }
    const now = new Date();
    const h = String(now.getHours()).padStart(2, '0');
    const m = String(now.getMinutes()).padStart(2, '0');
    const s = String(now.getSeconds()).padStart(2, '0');
    return `${h}:${m}:${s}`;
  }

  _emotionLabel(emotion) {
    const labels = {
      awakening:     'ERWACHEN',
      wonder:        'WUNDER',
      loss:          'VERLUST',
      tension:       'SPANNUNG',
      calm:          'RUHE',
      transformation: 'WANDEL',
      connection:    'VERBINDUNG',
      exploration:   'EXPLORATION',
      clarity:       'KLARHEIT',
      rest:          'RUHE',
      growth:        'WACHSTUM'
    };
    return labels[emotion] || 'EREIGNIS';
  }

  _incrementBadge() {
    this.totalEvents++;
    if (this.badge) {
      this.badge.textContent = this.totalEvents.toString();
    }
  }

  // ─── Lifecycle ──────────────────────────────────────────────────────

  pause()  { this.isPaused = true; }
  resume() { this.isPaused = false; }

  reset() {
    this.totalEvents = 0;
    if (this.feedContainer) this.feedContainer.innerHTML = '';
    if (this.epochContainer) this.epochContainer.innerHTML = '';
    if (this.badge) this.badge.textContent = '0';
  }

  destroy() {
    if (this._offStoryEvent) this._offStoryEvent();
    if (this._offStoryMilestone) this._offStoryMilestone();
    this.reset();
    this.isPaused = false;
  }
}
