import { clamp } from "../utils/math.js";
import { MEMORY_EVENT_LABELS } from "../content/narrative.js";

const MAX_EVENTS = 14;
const MAX_CLUSTER_PAIRS = 24;

export function createMemoryState(source = {}) {
  return {
    events: Array.isArray(source.events) ? source.events.slice(-MAX_EVENTS) : [],
    strongestTrace: Number(source.strongestTrace || 0),
    autonomousMoments: Number(source.autonomousMoments || 0),
    scarCount: Number(source.scarCount || 0),
    lastEventLabel: typeof source.lastEventLabel === "string" ? source.lastEventLabel : "",
    // Inter-Cluster-Kommunikationsgeschichte:
    // Schlüssel: "clusterA|clusterB" (sortiert), Wert: { count, lastAt, strength }
    clusterPairActivity: typeof source.clusterPairActivity === "object" && source.clusterPairActivity !== null
      ? source.clusterPairActivity
      : {}
  };
}

export function serializeMemoryState(memory) {
  return {
    events: memory.events.slice(-MAX_EVENTS),
    strongestTrace: Number(memory.strongestTrace || 0),
    autonomousMoments: Number(memory.autonomousMoments || 0),
    scarCount: Number(memory.scarCount || 0),
    lastEventLabel: memory.lastEventLabel || "",
    clusterPairActivity: memory.clusterPairActivity || {}
  };
}

export function recordMemoryEvent(memory, type, age) {
  const label = MEMORY_EVENT_LABELS[type] || type;
  const last = memory.events[memory.events.length - 1];

  if (last && last.type === type && Math.abs(last.age - age) < 8) {
    return;
  }

  memory.events.push({ type, label, age: Math.round(age * 10) / 10 });
  memory.events = memory.events.slice(-MAX_EVENTS);
  memory.lastEventLabel = label;

  if (type === "autonomousPulse") {
    memory.autonomousMoments += 1;
  }

  if (type === "scar") {
    memory.scarCount += 1;
  }
}

export function reinforceEdgeMemory(edge, amount) {
  edge.identityTrace = clamp((edge.identityTrace || 0) + amount, 0, 1);
  edge.traceAge = 0;
}

export function updateEdgeMemory(edge, dt, personality, clusterA = null, clusterB = null) {
  const retentionBias = clusterA && clusterB
    ? (clusterA.retentionBias + clusterB.retentionBias) * 0.5
    : 1;
  const retention = 0.0048 * (1.18 - personality.attachment * 0.45) / Math.max(0.72, retentionBias);

  edge.identityTrace = clamp((edge.identityTrace || 0) - dt * retention, 0, 1);
  edge.traceAge = (edge.traceAge || 0) + dt;
}

// === Inter-Cluster-Kommunikationsgeschichte ===

/**
 * Erzeugt einen sortierten Schlüssel für ein Cluster-Paar.
 */
function clusterPairKey(clusterA, clusterB) {
  const aId = clusterA.id || clusterA;
  const bId = clusterB.id || clusterB;
  return aId < bId ? `${aId}|${bId}` : `${bId}|${aId}`;
}

/**
 * Registriert eine synchronisierte Aktivierung zwischen zwei Clustern.
 * Wird aufgerufen, wenn ein Pulse eine Bridge passiert oder beide Cluster
 * gleichzeitig aktiv sind.
 *
 * @param {object} memory - Der Memory-State
 * @param {object} clusterA - Cluster-Objekt oder ID
 * @param {object} clusterB - Cluster-Objekt oder ID
 * @param {number} age - Aktuelles Simulationsalter in Sekunden
 * @param {number} strength - Stärke der Aktivierung (0..1)
 */
export function recordClusterPairActivity(memory, clusterA, clusterB, age, strength = 0.3) {
  if (!clusterA || !clusterB || clusterA === clusterB) return;

  const key = clusterPairKey(clusterA, clusterB);
  const existing = memory.clusterPairActivity[key];

  if (existing) {
    existing.count += 1;
    existing.lastAt = age;
    // Stärke als exponentiell gewichteter Durchschnitt
    existing.strength = clamp(existing.strength * 0.85 + strength * 0.15, 0, 1);
  } else {
    // Begrenze die Anzahl der gespeicherten Paare
    const keys = Object.keys(memory.clusterPairActivity);
    if (keys.length >= MAX_CLUSTER_PAIRS) {
      // Älteste Paare entfernen
      keys.sort((a, b) => memory.clusterPairActivity[a].lastAt - memory.clusterPairActivity[b].lastAt);
      delete memory.clusterPairActivity[keys[0]];
    }
    memory.clusterPairActivity[key] = { count: 1, lastAt: age, strength: clamp(strength, 0, 1) };
  }
}

/**
 * Gibt die historische Resonanz-Stärke zwischen zwei Clustern zurück (0..1).
 * Höhere Werte bedeuten: diese Cluster-Paare haben historisch oft
 * synchron kommuniziert — gute Kandidaten für bevorzugte Bridge-Bildung.
 */
export function getClusterPairResonance(memory, clusterA, clusterB) {
  if (!clusterA || !clusterB || clusterA === clusterB) return 0;
  const key = clusterPairKey(clusterA, clusterB);
  const entry = memory.clusterPairActivity[key];
  if (!entry) return 0;
  // Resonanz = Kombination aus Häufigkeit und Stärke, mit zeitlichem Decay
  const frequencyScore = clamp(entry.count / 20, 0, 1);
  return clamp(frequencyScore * 0.5 + entry.strength * 0.5, 0, 1);
}
