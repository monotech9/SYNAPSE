
import { clamp, hashString, lerp } from "../utils/math.js";
import { analyzeDna } from "./dnaArchetypes.js";
function valueFromSeed(seed, key) {
  return hashString(`${seed}:${key}`) / 4294967295;
}

function shaped(seed, key, min = 0.12, max = 0.88) {
  return min + (max - min) * valueFromSeed(seed, key);
}

export function createPersonality(seed) {
  const profilePool = ["seeker", "guardian", "spark", "rooted", "balanced"];
  const profile = profilePool[hashString(`${seed}:profile`) % profilePool.length];

  const base = {
    curiosity: shaped(seed, "curiosity", 0.04, 0.96),
    caution: shaped(seed, "caution", 0.04, 0.96),
    resilience: shaped(seed, "resilience", 0.04, 0.96),
    rhythm: shaped(seed, "rhythm", 0.04, 0.96),
    sensitivity: shaped(seed, "sensitivity", 0.04, 0.96),
    plasticity: shaped(seed, "plasticity", 0.04, 0.96),
    attachment: shaped(seed, "attachment", 0.04, 0.96),
    volatility: shaped(seed, "volatility", 0.04, 0.96)
  };

  const profileBias = {
    seeker: { curiosity: 0.24, plasticity: 0.16, caution: -0.12, attachment: -0.04 },
    guardian: { caution: 0.26, attachment: 0.16, resilience: 0.1, volatility: -0.12 },
    spark: { volatility: 0.28, sensitivity: 0.16, rhythm: 0.08, caution: -0.14 },
    rooted: { resilience: 0.26, attachment: 0.12, rhythm: 0.08, plasticity: -0.1 },
    balanced: { curiosity: 0.08, caution: 0.08, resilience: 0.08, rhythm: 0.08 }
  }[profile];

  const raw = Object.fromEntries(
    Object.entries(base).map(([key, value]) => [key, clamp(value + (profileBias[key] || 0), 0.03, 0.97)])
  );

  const curiosity = clamp(raw.curiosity * 0.76 + raw.plasticity * 0.24, 0, 1);
  const caution = clamp(raw.caution * 0.76 + raw.attachment * 0.24, 0, 1);
  const volatility = clamp(raw.volatility * 0.72 + raw.sensitivity * 0.28, 0, 1);

  return Object.freeze({
    ...raw,
    curiosity,
    caution,
    volatility,
    profile,

    // ─── DNA-Achsen + Archetyp (GDD §3-4) ────────────────────────
    dna: analyzeDna({
      ...raw, curiosity, caution, volatility
    }),

    growthIntervalMultiplier: clamp(lerp(1.68, 0.54, curiosity) * lerp(0.9, 1.42, caution), 0.48, 1.92),
    connectionIntervalMultiplier: clamp(lerp(1.62, 0.5, raw.plasticity) * lerp(0.84, 1.38, caution), 0.44, 1.86),
    bridgeBias: clamp(0.16 + curiosity * 0.38 + raw.plasticity * 0.22 - caution * 0.2, 0.06, 0.84),
    spontaneousIntervalMultiplier: clamp(lerp(1.82, 0.42, volatility) * lerp(1.12, 0.82, curiosity), 0.36, 2.05),
    spontaneousEnergyMultiplier: clamp(0.76 + volatility * 0.58 + raw.sensitivity * 0.24, 0.66, 1.58),
    signalRadiusMultiplier: clamp(0.82 + raw.sensitivity * 0.42 - caution * 0.16, 0.68, 1.38),
    signalEnergyMultiplier: clamp(0.78 + raw.sensitivity * 0.42 + raw.attachment * 0.12, 0.72, 1.44),
    memoryLearningMultiplier: clamp(0.7 + raw.attachment * 0.48 + raw.resilience * 0.28, 0.64, 1.52),
    decayMultiplier: clamp(1.2 - raw.resilience * 0.34 + volatility * 0.2, 0.7, 1.36),
    driftMultiplier: clamp(0.62 + volatility * 0.58 + curiosity * 0.22, 0.56, 1.58),
    pulseSpeedMultiplier: clamp(0.72 + raw.rhythm * 0.44 + volatility * 0.22, 0.66, 1.52),
    learningRateMultiplier: clamp(0.76 + raw.plasticity * 0.46 + raw.attachment * 0.2, 0.68, 1.56),
    pruningRateMultiplier: clamp(0.72 + caution * 0.28 + volatility * 0.2 - raw.attachment * 0.16, 0.54, 1.36)
  });
}

export function dominantBehaviorLabel(personality, world, memory) {
  const resonance = world.clusters.reduce((sum, cluster) => sum + cluster.activityMemory, 0) / Math.max(1, world.clusters.length);
  const strongestTrace = memory?.strongestTrace || 0;

  if ((memory?.autonomousMoments || 0) > 0 && world.pointerEnergy < 0.2) return "Eigenimpuls";
  if (world.clusters.some((cluster) => cluster.state === "seedling" || cluster.state === "forming")) return "erste Knospe";
  if (world.clusters.length >= 2 && resonance > 0.28) return "neue Region";
  if (strongestTrace > 0.72) return "erste Erinnerung";
  if (resonance > 0.42 || world.pointerEnergy > 0.25) return "wache Antwort";
  if (personality.volatility > 0.66) return "unruhige Muster";
  if (personality.curiosity > 0.63) return "suchende Fäden";
  if (personality.caution > 0.63) return "ruhige Resonanz";
  return "erstes Leuchten";
}
