/**
 * WorkerManager — verwaltet den optionalen Web Worker für die Simulation.
 *
 * Wenn aktiviert (?worker=1), läuft NeuroSimulation.update() in einem
 * separaten Thread. Der Main Thread empfängt Render-Snapshots und
 * leitet Pointer-Events an den Worker weiter.
 *
 * Falls der Worker nicht erstellt werden kann, fällt das System
 * transparent auf Main-Thread-Ausführung zurück.
 */

export class WorkerManager {
  constructor() {
    this.worker = null;
    this.enabled = false;
    this.ready = false;
    this.pendingFrame = null;
    this.frameCallbacks = [];
    this.latestSnapshot = null;

    // Event-Listener für Stage-Changes
    this.stageChangeListeners = [];
  }

  /**
   * Versucht, den Worker zu aktivieren.
   * @returns {Promise<boolean>} true wenn erfolgreich
   */
  async init(workerUrl) {
    try {
      this.worker = new Worker(workerUrl, { type: "module" });

      this.worker.onmessage = (e) => {
        const msg = e.data;
        switch (msg.type) {
          case "ready":
            this.ready = true;
            break;
          case "frame":
            this.latestSnapshot = msg.snapshot;
            // Frame-Callbacks aufrufen
            for (const cb of this.frameCallbacks) {
              try { cb(msg.snapshot); } catch {}
            }
            this.frameCallbacks = [];
            break;
          case "stageChange":
            for (const listener of this.stageChangeListeners) {
              try { listener({ old: msg.old, new: msg.new }); } catch {}
            }
            break;
          case "saved":
            if (this._saveResolve) {
              this._saveResolve(msg.state);
              this._saveResolve = null;
            }
            break;
          case "error":
            console.error("[Worker] Simulation error:", msg.message, msg.stack);
            break;
        }
      };

      this.worker.onerror = (err) => {
        console.error("[Worker] Fatal error:", err);
        this.enabled = false;
        this.ready = false;
      };

      this.enabled = true;
      return true;
    } catch (e) {
      console.warn("[Worker] Konnte Worker nicht starten, falle zurück auf Main-Thread:", e);
      this.enabled = false;
      return false;
    }
  }

  /**
   * Sendet Initialisierungsdaten an den Worker.
   */
  sendInit(data) {
    if (!this.worker) return;
    this.worker.postMessage({ type: "init", ...data });
  }

  /**
   * Sendet ein Update-Frame an den Worker.
   * @returns {Promise<snapshot>} oder null wenn Worker nicht bereit
   */
  update(dt, timeSeconds) {
    if (!this.worker || !this.ready) return Promise.resolve(null);

    return new Promise((resolve) => {
      this.frameCallbacks.push(resolve);
      this.worker.postMessage({ type: "update", dt, timeSeconds });
    });
  }

  /**
   * Sendet einen Pointer-Event an den Worker.
   */
  sendPointer(kind, x, y) {
    if (!this.worker || !this.ready) return;
    this.worker.postMessage({ type: "pointer", kind, x, y });
  }

  /**
   * Sendet ein Resize-Event an den Worker.
   */
  sendResize(width, height, dpr) {
    if (!this.worker || !this.ready) return;
    this.worker.postMessage({ type: "resize", width, height, dpr });
  }

  /**
   * Fordert einen Save-State vom Worker an.
   */
  save() {
    if (!this.worker || !this.ready) return Promise.resolve(null);
    return new Promise((resolve) => {
      this._saveResolve = resolve;
      this.worker.postMessage({ type: "save" });
    });
  }

  /**
   * Registriert einen Stage-Change-Listener.
   */
  onStageChange(listener) {
    this.stageChangeListeners.push(listener);
  }

  /**
   * Beendet den Worker.
   */
  terminate() {
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
    this.enabled = false;
    this.ready = false;
  }
}
