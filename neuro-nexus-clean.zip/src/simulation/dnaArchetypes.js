/**
 * dnaArchetypes.js — Die 3 DNA-Achsen + 12 Archetypen (GDD §3-4)
 *
 * Die Achsen werden NICHT als Zahlen gespeichert, sondern als
 * Interpretations-Raster für Verhalten. Jede Aktion des Netzwerks
 * wird durch dieses Raster gefiltert.
 *
 * Die 3 DNA-Achsen (abgeleitet aus den 8 Basis-Traits):
 *
 *  1. Erkundung (Exploration) — offen/verspielend ↔ vorsichtig/sicher
 *     curiosity + plasticity  ↔  caution
 *
 *  2. Resonanz (Resonance) — emotional durchlässig ↔ abgekapselt
 *     sensitivity + attachment  ↔  (low = stoic)
 *
 *  3. Dynamik (Dynamism) — explosiv/unberechenbar ↔ stabil/gleichmäßig
 *     volatility + (1-rhythm)  ↔  resilience + rhythm
 *
 * Aus den 3 Achsen ergeben sich 12 stabile Archetypen:
 *  - 8 Eck-Archetypen (alle Achsen am Extrem)
 *  - 4 Kanten-Archetypen (eine Achse neutral, zwei am Extrem)
 */

// ─── Achsen-Definitionen ─────────────────────────────────────────────

export const DNA_AXES = Object.freeze({
  EXPLORATION: "exploration",
  RESONANCE:   "resonance",
  DYNAMISM:    "dynamism"
});

export const AXIS_LABELS = Object.freeze({
  exploration: { high: "offen", low: "vorsichtig", mid: "neutral" },
  resonance:   { high: "durchlässig", low: "abgekapselt", mid: "neutral" },
  dynamism:    { high: "explosiv", low: "stabil", mid: "neutral" }
});

// ─── 12 Archetypen ───────────────────────────────────────────────────

export const ARCHETYPES = Object.freeze({
  // ── 8 Eck-Archetypen (high/low × 3 Achsen) ───────────────────────
  PIONEER: {
    id: "pioneer",
    name: "Pionier",
    axes: { exploration: "high", resonance: "high", dynamism: "high" },
    description: "Verspielt, emotional offen, unberechenbar. Stürmt in jede Richtung.",
    behavior: "schnelle Ausbreitung, häufige Impulse, große Signalreichweite",
    visualSignature: "heiße Farben, schnelle Pulse, weite Verzweigungen"
  },
  BRIDGE: {
    id: "bridge",
    name: "Brücke",
    axes: { exploration: "high", resonance: "high", dynamism: "low" },
    description: "Offen und verbunden, aber beständig. Baut stabile Beziehungen auf.",
    behavior: "geordnetes Wachstum, starke Brücken, tiefe Erinnerungen",
    visualSignature: "warme, stetige Glow, dichte Cluster-Verbindungen"
  },
  WIND: {
    id: "wind",
    name: "Wind",
    axes: { exploration: "high", resonance: "low", dynamism: "high" },
    description: "Neugierig und schnell, aber kühl. Erkundet ohne Bindung.",
    behavior: "schnelle expansive Muster, schwache Persistenz, flüchtige Spuren",
    visualSignature: "kühle, schnelle Pulse, lange dünne Fäden"
  },
  LIGHTHOUSE: {
    id: "lighthouse",
    name: "Leuchtturm",
    axes: { exploration: "high", resonance: "low", dynamism: "low" },
    description: "Ruhig und klar. Erkundet systematisch ohne emotionale Verwicklung.",
    behavior: "geplante Ausbreitung, geringe emotionale Modulation, klares Wachstum",
    visualSignature: "klares, ruhiges Licht, symmetrische Muster"
  },
  FLAME: {
    id: "flame",
    name: "Flamme",
    axes: { exploration: "low", resonance: "high", dynamism: "high" },
    description: "Vorsichtig aber intensiv. Reagiert stark, hält aber nicht lange.",
    behavior: "starke emotionale Reaktionen, kurze Impulse, schnelle Erschöpfung",
    visualSignature: "heiße, flackernde Pulse, dichte kurze Verbindungen"
  },
  HEART: {
    id: "heart",
    name: "Herz",
    axes: { exploration: "low", resonance: "high", dynamism: "low" },
    description: "Vorsichtig, tief verbunden, beständig. Hält was es liebt.",
    behavior: "langsame tiefe Bindung, starke Konsolidierung, wenig Expansion",
    visualSignature: "tiefe warme Glow, kompakte dichte Cluster"
  },
  LIGHTNING: {
    id: "lightning",
    name: "Blitz",
    axes: { exploration: "low", resonance: "low", dynamism: "high" },
    description: "Abrupt, kühl, volatil. Reagiert schnell ohne Tiefe.",
    behavior: "spontane explosive Muster, keine Persistenz, hohe Pruning-Rate",
    visualSignature: "helle, blitzartige Pulse, instabile Struktur"
  },
  STONE: {
    id: "stone",
    name: "Fels",
    axes: { exploration: "low", resonance: "low", dynamism: "low" },
    description: "Stabil, abgekapselt, unverrückbar. Kaum Veränderung.",
    behavior: "minimales Wachstum, extrem stabil, kaum emotionale Antwort",
    visualSignature: "gedämpft, massiv, kaum Bewegung"
  },

  // ── 4 Kanten-Archetypen (eine Achse neutral) ─────────────────────
  NOMAD: {
    id: "nomad",
    name: "Nomade",
    axes: { exploration: "high", resonance: "mid", dynamism: "high" },
    description: "Rastlos und offen. Wandert ohne tiefe Bindung.",
    behavior: "kontinuierliche Expansion, moderate Bindung, hohe Mobilität",
    visualSignature: "fließende Muster, weite Verzweigungen, mittlere Glow"
  },
  SAGE: {
    id: "sage",
    name: "Sage",
    axes: { exploration: "mid", resonance: "low", dynamism: "low" },
    description: "Beobachtend, ruhig, distanziert. Versteht ohne zu fühlen.",
    behavior: "langsame geordnete Muster, geringe emotionale Antwort, stabile Struktur",
    visualSignature: "klares, ruhiges Muster, symmetrische Anordnung"
  },
  GUARDIAN: {
    id: "guardian",
    name: "Hüter",
    axes: { exploration: "mid", resonance: "high", dynamism: "low" },
    description: "Beschützend, verbunden, beständig. Bewahrt was wichtig ist.",
    behavior: "starke Konsolidierung, moderate Expansion, tiefe Bindung",
    visualSignature: "warme, stetige Glow, kompakte Verteidigungsmuster"
  },
  SEEKER: {
    id: "seeker",
    name: "Sucher",
    axes: { exploration: "high", resonance: "low", dynamism: "mid" },
    description: "Getrieben von Neugier. Erkundet ohne sich zu binden.",
    behavior: "kontinuierliche Ausbreitung, schwache emotionale Bindung, moderate Geschwindigkeit",
    visualSignature: "kühle, gerichtete Pulse, lange探索-Pfade"
  }
});

// ─── Achsen-Berechnung aus Traits ────────────────────────────────────

/**
 * Berechnet die 3 DNA-Achsen aus den 8 Basis-Traits.
 * @param {Object} traits — personality trait object
 * @returns {{ exploration: number, resonance: number, dynamism: number }}
 *         Jede Achse ist 0–1 (0 = niedrig, 1 = hoch)
 */
export function computeDnaAxes(traits) {
  const exploration = clamp01(
    (traits.curiosity * 0.4 + traits.plasticity * 0.3 + (1 - traits.caution) * 0.3)
  );
  const resonance = clamp01(
    (traits.sensitivity * 0.5 + traits.attachment * 0.5)
  );
  const dynamism = clamp01(
    (traits.volatility * 0.5 + (1 - traits.rhythm) * 0.25 + (1 - traits.resilience) * 0.25)
  );
  return { exploration, resonance, dynamism };
}

/**
 * Klassifiziert einen Achsenwert als high/mid/low.
 * @param {number} value — 0–1
 * @returns {"high"|"mid"|"low"}
 */
export function classifyAxis(value) {
  if (value >= 0.62) return "high";
  if (value <= 0.38) return "low";
  return "mid";
}

/**
 * Bestimmt den Archetyp aus den 3 DNA-Achsen.
 * Sucht den besten Match unter den 12 Archetypen.
 *
 * @param {{ exploration: number, resonance: number, dynamism: number }} axes
 * @returns {{ id, name, description, behavior, visualSignature, axes }}
 */
export function resolveArchetype(axes) {
  const classified = {
    exploration: classifyAxis(axes.exploration),
    resonance: classifyAxis(axes.resonance),
    dynamism: classifyAxis(axes.dynamism)
  };

  // Exakten Match suchen
  let bestMatch = null;
  let bestScore = -1;

  for (const arch of Object.values(ARCHETYPES)) {
    let score = 0;
    for (const axis of ["exploration", "resonance", "dynamism"]) {
      if (arch.axes[axis] === classified[axis]) {
        score += 2;  // exact match
      } else if (arch.axes[axis] === "mid" || classified[axis] === "mid") {
        score += 1;  // mid is flexible
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = arch;
    }
  }

  return { ...bestMatch, resolvedAxes: classified };
}

/**
 * Vollständige DNA-Analyse: Achsen + Archetyp aus Personality.
 * @param {Object} personality — createPersonality() result
 * @returns {{ axes, archetype, classified }}
 */
export function analyzeDna(personality) {
  const axes = computeDnaAxes(personality);
  const archetype = resolveArchetype(axes);
  return {
    axes,
    archetype,
    classified: {
      exploration: classifyAxis(axes.exploration),
      resonance: classifyAxis(axes.resonance),
      dynamism: classifyAxis(axes.dynamism)
    }
  };
}

function clamp01(v) { return Math.max(0, Math.min(1, v)); }
