/**
 * MoodStateMachine — 8 Stimmungen mit Hysterese (GDD §5)
 *
 * Neben den statischen Archetypen gibt es eine dynamische Stimmung,
 * die sich sekündlich ändert. Dies ist die Quelle von "Es wirkt heute anders."
 *
 * Die 8 Stimmungen:
 *  1. RUHIG     — baseline, niedrige Aktivität
 *  2. AUFGEREGT — hohe Signal-Aktivität, viele Pulse
 *  3. ANGESPANNT — Stress, viele Verbindungen unter Druck
 *  4. TRAURIG   — Verlust, Verbindungsabbruch
 *  5. ABWESEND  — langanhaltende Traurigkeit, Rückzug
 *  6. FOKUSSIERT — tiefe Verarbeitung, hohe Kohärenz
 *  7. VERWIRRT  — hohe Prediction-Error, Desorientierung
 *  8. HARMONISCH — ausgewogen, stabil, kohärent
 *
 * Stimmungs-Übergänge folgen einer State-Machine mit Hysterese:
 *  - Mindestens 10-30s Haltedauer bevor Wechsel erlaubt
 *  - Ruhig → Aufgeregt: Signal-Threshold überschritten
 *  - Angespannt → Traurig: Verbindung bricht
 *  - Traurig → Abwesend: langanhaltende Traurigkeit
 *  - Harmonisch → Ruhig: Aktivität sinkt
 *  - Verwirrt → Fokussiert: Prediction Error sinkt
 *
 * Events (out):
 *  - "mood:change" — { from, to, holdTime, trigger }
 *
 * Events (in):
 *  - "signal:injected"     — externe Signale
 *  - "network:nodePruned"  — Verbindungsabbruch
 *  - "prediction:surprise" — hohe Prediction-Error
 *  - "consciousness:ignition" — bewusste Verarbeitung
 */

// ─── Mood States ─────────────────────────────────────────────────────

export const MoodState = Object.freeze({
  CALM:       "ruhig",
  EXCITED:    "aufgeregt",
  TENSE:      "angespannt",
  SAD:        "traurig",
  ABSENT:     "abwesend",
  FOCUSED:    "fokussiert",
  CONFUSED:   "verwirrt",
  HARMONIOUS: "harmonisch"
});

export const MOOD_LABELS = Object.freeze({
  [MoodState.CALM]:       "Ruhig",
  [MoodState.EXCITED]:    "Aufgeregt",
  [MoodState.TENSE]:      "Angespannt",
  [MoodState.SAD]:        "Traurig",
  [MoodState.ABSENT]:     "Abwesend",
  [MoodState.FOCUSED]:    "Fokussiert",
  [MoodState.CONFUSED]:   "Verwirrt",
  [MoodState.HARMONIOUS]: "Harmonisch"
});

// ─── Hysterese-Parameter ─────────────────────────────────────────────

const MIN_HOLD_TIME = 10.0;   // Mindest-Haltedauer (Sekunden)
const MAX_HOLD_TIME = 30.0;   // Maximale Haltedauer bevor erzwungener Check
const SAD_TO_ABSENT_TIME = 25.0; // Langanhaltende Traurigkeit → Abwesend

// Trigger-Schwellen
const SIGNAL_THRESHOLD = 0.45;    // Signal-Aktivität für Aufgeregt
const PRUNE_TRIGGER = 1;          // Node-Pruning für Traurig
const PREDICTION_ERROR_THRESHOLD = 0.5; // Prediction Error für Verwirrt
const COHERENCE_THRESHOLD = 0.6;  // Kohärenz für Fokussiert/Harmonisch
const ACTIVITY_LOW = 0.15;        // Niedrige Aktivität für Ruhig

// ─── MoodStateMachine Klasse ─────────────────────────────────────────

export class MoodStateMachine {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    this.currentMood = MoodState.CALM;
    this._previousMood = MoodState.CALM;
    this._holdTime = 0;
    this._moodHistory = [];
    this._maxHistory = 20;

    // Trigger-Zähler (für Übergangslogik)
    this._pruneCount = 0;
    this._pruneTimer = 0;
    this._sadTimer = 0;   // Wie lange schon Traurig
    this._signalActivity = 0;
    this._predictionError = 0;
    this._coherence = 0;
    this._activity = 0;

    // EventBus subscriptions
    this._off1 = this.events.on("signal:injected", () => {
      this._signalActivity = Math.min(1, this._signalActivity + 0.2);
    });
    this._off2 = this.events.on("network:nodePruned", () => {
      this._pruneCount++;
      this._pruneTimer = 0;
    });
    this._off3 = this.events.on("prediction:surprise", (d) => {
      this._predictionError = Math.min(1, d.error || 0);
    });
    this._off4 = this.events.on("consciousness:ignition", (d) => {
      this._signalActivity = Math.min(1, this._signalActivity + 0.1);
    });
  }

  // ─── Update ────────────────────────────────────────────────────

  update(dt) {
    this._holdTime += dt;
    this._pruneTimer += dt;
    this._signalActivity *= 0.96;  // decay
    this._predictionError *= 0.98; // decay

    // System-Zustand erfassen
    this._updateSystemState();

    // Sad-Timer aktualisieren
    if (this.currentMood === MoodState.SAD) {
      this._sadTimer += dt;
    } else {
      this._sadTimer = 0;
    }

    // Hysterese: Mindestens MIN_HOLD_TIME halten
    if (this._holdTime < MIN_HOLD_TIME) return;

    // Übergang prüfen
    const newMood = this._evaluateTransitions();
    if (newMood && newMood !== this.currentMood) {
      this._transitionTo(newMood);
    }
  }

  _updateSystemState() {
    const w = this.sim.world;
    const selfModel = this.sim.consciousness?.selfModel;

    // Durchschnittliche Cluster-Aktivität
    const activeClusters = w.clusters.filter(c => c.state !== "dormant");
    this._activity = activeClusters.length > 0
      ? activeClusters.reduce((s, c) => s + (c.activityMemory || 0), 0) / activeClusters.length
      : 0;

    // Kohärenz aus SelfModel
    this._coherence = selfModel?.selfModel?.coherence || 0;
  }

  /**
   * Evaluiert Stimmungs-Übergänge basierend auf aktuellem Zustand.
   * Gibt die neue Stimmung zurück, oder null wenn kein Wechsel nötig.
   */
  _evaluateTransitions() {
    const mood = this.currentMood;

    // ── Übergänge von RUHIG ──────────────────────────────────────
    if (mood === MoodState.CALM) {
      if (this._signalActivity > SIGNAL_THRESHOLD) return MoodState.EXCITED;
      if (this._pruneCount >= PRUNE_TRIGGER && this._pruneTimer < 3) return MoodState.TENSE;
      if (this._coherence > COHERENCE_THRESHOLD && this._activity > 0.3) return MoodState.HARMONIOUS;
      if (this._predictionError > PREDICTION_ERROR_THRESHOLD) return MoodState.CONFUSED;
    }

    // ── Übergänge von AUFGEREGT ──────────────────────────────────
    if (mood === MoodState.EXCITED) {
      if (this._signalActivity < ACTIVITY_LOW) return MoodState.CALM;
      if (this._pruneCount >= PRUNE_TRIGGER && this._pruneTimer < 3) return MoodState.TENSE;
      if (this._coherence > COHERENCE_THRESHOLD) return MoodState.FOCUSED;
    }

    // ── Übergänge von ANGESPANNT ─────────────────────────────────
    if (mood === MoodState.TENSE) {
      // GDD: "Angespannt wird zu Traurig wenn eine Verbindung bricht"
      if (this._pruneCount >= PRUNE_TRIGGER && this._pruneTimer < 3) return MoodState.SAD;
      if (this._signalActivity < ACTIVITY_LOW && this._pruneTimer > 5) return MoodState.CALM;
    }

    // ── Übergänge von TRAURIG ────────────────────────────────────
    if (mood === MoodState.SAD) {
      // GDD: "Traurig wird zu Abwesend bei langanhaltender Traurigkeit"
      if (this._sadTimer > SAD_TO_ABSENT_TIME) return MoodState.ABSENT;
      if (this._signalActivity > SIGNAL_THRESHOLD) return MoodState.EXCITED;
      if (this._coherence > COHERENCE_THRESHOLD) return MoodState.CALM;
    }

    // ── Übergänge von ABWESEND ───────────────────────────────────
    if (mood === MoodState.ABSENT) {
      if (this._signalActivity > SIGNAL_THRESHOLD * 1.5) return MoodState.EXCITED;
      if (this._holdTime > MAX_HOLD_TIME) return MoodState.CALM;
    }

    // ── Übergänge von FOKUSSIERT ─────────────────────────────────
    if (mood === MoodState.FOCUSED) {
      if (this._coherence < 0.3) return MoodState.CALM;
      if (this._predictionError > PREDICTION_ERROR_THRESHOLD) return MoodState.CONFUSED;
      if (this._signalActivity > SIGNAL_THRESHOLD) return MoodState.HARMONIOUS;
    }

    // ── Übergänge von VERWIRRT ───────────────────────────────────
    if (mood === MoodState.CONFUSED) {
      // GDD: "Verwirrt → Fokussiert wenn Prediction Error sinkt"
      if (this._predictionError < 0.2) return MoodState.FOCUSED;
      if (this._holdTime > MAX_HOLD_TIME) return MoodState.CALM;
    }

    // ── Übergänge von HARMONISCH ─────────────────────────────────
    if (mood === MoodState.HARMONIOUS) {
      if (this._activity < ACTIVITY_LOW) return MoodState.CALM;
      if (this._pruneCount >= PRUNE_TRIGGER && this._pruneTimer < 3) return MoodState.TENSE;
      if (this._predictionError > PREDICTION_ERROR_THRESHOLD) return MoodState.CONFUSED;
    }

    return null;
  }

  /**
   * Führt einen Stimmungswechsel durch.
   */
  _transitionTo(newMood) {
    this._moodHistory.push({
      from: this.currentMood,
      to: newMood,
      holdTime: this._holdTime,
      age: this.sim.world.age
    });
    if (this._moodHistory.length > this._maxHistory) this._moodHistory.shift();

    this._previousMood = this.currentMood;
    this.currentMood = newMood;
    this._holdTime = 0;
    this._sadTimer = 0;

    this.events.emit("mood:change", {
      from: this._previousMood,
      to: newMood,
      holdTime: this._moodHistory[this._moodHistory.length - 1].holdTime,
      age: this.sim.world.age
    });
  }

  // ─── API ───────────────────────────────────────────────────────

  getMood() { return this.currentMood; }

  getMoodLabel() { return MOOD_LABELS[this.currentMood]; }

  getHistory() { return [...this._moodHistory]; }

  getSnapshot() {
    return {
      current: this.currentMood,
      label: MOOD_LABELS[this.currentMood],
      holdTime: this._holdTime,
      signalActivity: this._signalActivity,
      predictionError: this._predictionError,
      coherence: this._coherence,
      activity: this._activity,
      transitions: this._moodHistory.length
    };
  }

  serialize() {
    return {
      current: this.currentMood,
      history: this._moodHistory.slice(-5)
    };
  }

  reset() {
    this.currentMood = MoodState.CALM;
    this._holdTime = 0;
    this._sadTimer = 0;
    this._pruneCount = 0;
    this._signalActivity = 0;
    this._predictionError = 0;
    this._moodHistory = [];
  }

  destroy() {
    this._off1?.();
    this._off2?.();
    this._off3?.();
    this._off4?.();
  }
}
