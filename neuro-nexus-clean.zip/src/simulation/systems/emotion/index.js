/**
 * emotion/index.js — Barrel-Export für das emotion-Modul
 */

export * from './EmotionEngine.js';
export * from './EmotionAppraiser.js';
export * from './EmotionModulation.js';
export * from './MoodStateMachine.js';
export * from './emotionConstants.js';
