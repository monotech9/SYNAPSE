/**
 * EmotionEngine — OCC-basiertes Appraisal-Emotionssystem
 *
 * Implementiert das OCC-Modell (Ortony, Clore, Collins 1988) mit
 * appraised emotions, chain-of-emotion (Croissant et al. 2023) und
 * dopaminergem Reward-Prediction-Error (Schultz 2024).
 *
 * Architektur:
 *
 *   Simulation Events → EmotionAppraiser → Emotion Intensities (0–1)
 *                                          ↓
 *                           ┌──────────────┼──────────────┐
 *                           ↓              ↓              ↓
 *                    EmotionModulation  Chain-of-Emotion  EventBus
 *                    (thresholds,       (history)        (emotion:change)
 *                     learning rates,
 *                     growth bias)
 *
 * Module:
 *  - emotionConstants.js  — EmotionType, EMOTION_DEFS, Modulation-Defaults
 *  - EmotionAppraiser.js  — EventBus-Subscriptions & periodische Appraisal
 *  - EmotionModulation.js — System-Modulation, Mood, Decay
 *
 * Events auf EventBus:
 *  - "emotion:change"   — emotion state updated (dominant emotion changed or significant shift)
 *  - "emotion:spike"    — single emotion crossed high threshold (0.7+)
 *  - "emotion:state"    — periodic state snapshot (for HUD, SelfModel, StoryEngine)
 */

import { clamp } from "../../../utils/math.js";
import { EmotionType, EMOTION_DEFS, DEFAULT_MODULATION } from "./emotionConstants.js";
import { subscribeEventBus, periodicAppraisal } from "./EmotionAppraiser.js";
import { computeModulation, computeMood, applyDecay } from "./EmotionModulation.js";

// Re-export für Abwärtskompatibilität (Tests, andere Module)
export { EmotionType };

// ─── EmotionEngine Klasse ────────────────────────────────────────────

export class EmotionEngine {
  /**
   * @param {NeuroSimulation} simulation
   */
  constructor(simulation) {
    this.simulation = simulation;
    this.events = simulation.events;

    // Emotion intensities (0–1)
    this.emotions = {};
    for (const key of Object.keys(EMOTION_DEFS)) {
      this.emotions[key] = 0;
    }

    // Chain-of-Emotion: Verlauf der dominanten Emotion
    this.emotionHistory = [];
    this.maxHistory = 100;

    // Mood: langsame Hintergrund-Valenz (-1 bis +1)
    this.mood = 0;
    this._moodTimer = 0;

    // Dominante Emotion
    this.dominantEmotion = EmotionType.CALM;
    this._prevDominant = EmotionType.CALM;

    // Systemmodulation (aktuelle Werte)
    this.modulation = { ...DEFAULT_MODULATION };

    // Reward-Prediction-Error State
    this._expectedReward = 0.5;
    this._lastRewardDelta = 0;

    // Update-Timer (Appraisal läuft mit 5Hz, Decay mit jedem update)
    this._appraisalTimer = 0;
    this._appraisalInterval = 0.2; // 5Hz

    // Personality Cache
    this._personality = simulation.personality;

    // EventBus subscribieren
    this._unsubscribe = [];
    this._subscribe();
  }

  get world() { return this.simulation.world; }

  // ─── EventBus Subscriptions ────────────────────────────────────────

  _subscribe() {
    this._unsubscribe = subscribeEventBus(this.events, this._appraise.bind(this));
  }

  // ─── Appraisal: Emotion-Impuls hinzufügen ──────────────────────────

  /**
   * Fügt einer Emotion einen Impuls hinzu, moduliert durch Personality.
   * @param {string} emotion — EmotionType key
   * @param {number} impulse — Rohe Impuls-Stärke (0–1)
   * @param {string} [source] — Quelle des Appraisals (für Debug)
   */
  _appraise(emotion, impulse, source) {
    if (!EMOTION_DEFS[emotion]) return;

    // Personality moduliert die Sensitivität
    const sensitivity = this._personality.sensitivity || 0.5;

    // Hohe Sensitivität → stärkere Impulse
    const modulatedImpulse = impulse * (0.5 + sensitivity * 0.8);

    this.emotions[emotion] = clamp(this.emotions[emotion] + modulatedImpulse, 0, 1);

    // Spike-Event wenn Schwelle überschritten
    if (this.emotions[emotion] >= 0.7 && this.emotions[emotion] - modulatedImpulse < 0.7) {
      this.events.emit("emotion:spike", {
        emotion,
        intensity: this.emotions[emotion],
        source,
        timestamp: this.world.age
      });
    }
  }

  // ─── Hauptupdate ───────────────────────────────────────────────────

  update(dt) {
    // 1. Decay aller Emotionen (mit Personality-Modulation)
    const resilience = this._personality.resilience || 0.5;
    applyDecay(this.emotions, resilience, dt);

    // 2. Periodische Appraisal (5Hz)
    this._appraisalTimer += dt;
    if (this._appraisalTimer >= this._appraisalInterval) {
      this._appraisalTimer = 0;
      periodicAppraisal({
        world: this.world,
        simulation: this.simulation,
        emotions: this.emotions,
        appraise: this._appraise.bind(this),
        state: this // _expectedReward, _lastRewardDelta live on this
      });
    }

    // 3. Dominante Emotion bestimmen
    this._updateDominant();

    // 4. Systemmodulation updaten
    this.modulation = computeModulation(this.emotions);

    // 5. Mood updaten (langsam)
    this.mood = computeMood(this.emotions, this.mood);
  }

  // ─── Dominante Emotion ─────────────────────────────────────────────

  _updateDominant() {
    let maxIntensity = 0;
    let dominant = EmotionType.CALM;

    for (const [emotion, intensity] of Object.entries(this.emotions)) {
      if (intensity > maxIntensity) {
        maxIntensity = intensity;
        dominant = emotion;
      }
    }

    // If everything is near zero, default to calm
    if (maxIntensity < 0.05) {
      dominant = EmotionType.CALM;
      this.emotions[EmotionType.CALM] = Math.max(this.emotions[EmotionType.CALM], 0.05);
    }

    const changed = dominant !== this._prevDominant;
    this.dominantEmotion = dominant;

    if (changed) {
      this.emotionHistory.push({
        emotion: dominant,
        timestamp: this.world.age,
        intensity: maxIntensity
      });
      if (this.emotionHistory.length > this.maxHistory) this.emotionHistory.shift();

      this.events.emit("emotion:change", {
        from: this._prevDominant,
        to: dominant,
        intensity: maxIntensity,
        timestamp: this.world.age,
        emotions: { ...this.emotions }
      });

      this._prevDominant = dominant;
    }
  }

  // ─── API ───────────────────────────────────────────────────────────

  /**
   * Gibt den aktuellen Emotions-Zustand als Object zurück.
   * @returns {Object} { joy: 0.3, fear: 0.1, ... }
   */
  getState() {
    return { ...this.emotions };
  }

  /**
   * Gibt die dominante Emotion + Intensität zurück.
   * @returns {{ emotion: string, intensity: number, label: string }}
   */
  getDominant() {
    return {
      emotion: this.dominantEmotion,
      intensity: this.emotions[this.dominantEmotion] || 0,
      label: EMOTION_DEFS[this.dominantEmotion]?.label || this.dominantEmotion
    };
  }

  /**
   * Gibt die aktuellen Systemmodulations-Werte zurück.
   * @returns {Object}
   */
  getModulation() {
    return { ...this.modulation };
  }

  /**
   * Gibt die Mood-Valenz zurück (-1 bis +1).
   */
  getMood() {
    return this.mood;
  }

  /**
   * Gibt die Emotions-Historie (chain-of-emotion) zurück.
   * @param {number} [limit=20] — Letzte N Einträge
   * @returns {Array}
   */
  getHistory(limit = 20) {
    return this.emotionHistory.slice(-limit);
  }

  /**
   * Gibt den Reward-Prediction-Error zurück.
   * @returns {{ expected: number, delta: number }}
   */
  getRewardState() {
    return {
      expected: this._expectedReward,
      delta: this._lastRewardDelta
    };
  }

  /**
   * Vollständiger Snapshot für HUD/SelfModel/Story.
   */
  getSnapshot() {
    return {
      emotions: this.getState(),
      dominant: this.getDominant(),
      mood: this.mood,
      modulation: this.getModulation(),
      reward: this.getRewardState(),
      history: this.getHistory(10)
    };
  }

  // ─── Reset / Destroy ───────────────────────────────────────────────

  reset() {
    for (const key of Object.keys(EMOTION_DEFS)) {
      this.emotions[key] = 0;
    }
    this.emotionHistory = [];
    this.mood = 0;
    this.dominantEmotion = EmotionType.CALM;
    this._prevDominant = EmotionType.CALM;
    this.modulation = { ...DEFAULT_MODULATION };
    this._expectedReward = 0.5;
    this._lastRewardDelta = 0;
  }

  destroy() {
    for (const off of this._unsubscribe) if (off) off();
    this._unsubscribe = [];
  }
}
