/**
 * EmotionModulation — System-Modulation und Mood-Berechnung
 *
 * Wandelt Emotion-Intensitäten in System-Modulationswerte um
 * (firing thresholds, growth rates, exploration noise, etc.)
 * und berechnet die langsame Mood-Valenz.
 *
 * Wird von EmotionEngine verwendet; nicht direkt instanziiert.
 */

import { EmotionType, EMOTION_DEFS, DEFAULT_MODULATION, MOOD_BLEND_RATE } from "./emotionConstants.js";

/**
 * Berechnet Systemmodulations-Werte aus aktuellen Emotion-Intensitäten.
 * @param {Object} emotions — { joy: 0.3, fear: 0.1, ... }
 * @param {Object} [base] — Basis-Modulation (Default-Werte)
 * @returns {Object} — Modulations-Werte
 */
export function computeModulation(emotions, base = DEFAULT_MODULATION) {
  const mod = { ...base };
  const e = emotions;

  // Fear → cautious: higher thresholds, more pruning
  const fearEffect = e[EmotionType.FEAR] || 0;
  mod.firingThresholdMultiplier = 1.0 + fearEffect * 0.4;

  // Distress → slower growth, more decay
  const distressEffect = e[EmotionType.DISTRESS] || 0;
  mod.growthRateMultiplier = 1.0 - distressEffect * 0.3;
  mod.decayRateMultiplier = 1.0 + distressEffect * 0.2;

  // Joy → faster growth, less decay
  const joyEffect = e[EmotionType.JOY] || 0;
  mod.growthRateMultiplier *= 1.0 + joyEffect * 0.2;
  mod.decayRateMultiplier *= 1.0 - joyEffect * 0.1;

  // Curiosity → more exploration noise
  const curiosityEffect = e[EmotionType.CURIOSITY] || 0;
  mod.explorationNoiseMultiplier = 1.0 + curiosityEffect * 0.5;

  // Tension → higher signal energy
  const tensionEffect = e[EmotionType.TENSION] || 0;
  mod.signalEnergyMultiplier = 1.0 + tensionEffect * 0.3;

  // Calm → more stability, less noise
  const calmEffect = e[EmotionType.CALM] || 0;
  mod.explorationNoiseMultiplier *= 1.0 - calmEffect * 0.2;
  mod.pruningRateMultiplier = 1.0 + fearEffect * 0.3 - calmEffect * 0.1;

  // Pride → autonomy boost (self-directed growth)
  const prideEffect = e[EmotionType.PRIDE] || 0;
  mod.growthRateMultiplier *= 1.0 + prideEffect * 0.1;

  // Wonder → wider attention, larger signal radius
  const wonderEffect = e[EmotionType.WONDER] || 0;
  mod.signalRadiusMultiplier = 1.0 + wonderEffect * 0.3;
  mod.attentionSpanMultiplier = 1.0 + wonderEffect * 0.2;

  // Love → stronger memory consolidation
  const loveEffect = e[EmotionType.LOVE] || 0;
  mod.memoryConsolidationMultiplier = 1.0 + loveEffect * 0.3;

  // Anger/Tension → stronger signals
  mod.signalEnergyMultiplier *= 1.0 + tensionEffect * 0.15;

  return mod;
}

/**
 * Berechnet die Mood-Valenz aus Emotion-Intensitäten.
 * Mood ist ein langsamer gewichteter Durchschnitt der Valenzen.
 *
 * @param {Object} emotions — { joy: 0.3, fear: 0.1, ... }
 * @param {number} currentMood — Aktuelle Mood-Valenz (-1 bis +1)
 * @returns {number} — Neue Mood-Valenz (-1 bis +1)
 */
export function computeMood(emotions, currentMood) {
  let weightedSum = 0;
  let totalWeight = 0;

  for (const [emotion, intensity] of Object.entries(emotions)) {
    const valence = EMOTION_DEFS[emotion]?.valence || 0;
    weightedSum += valence * intensity;
    totalWeight += intensity;
  }

  const targetMood = totalWeight > 0.01 ? weightedSum / totalWeight : 0;
  return currentMood * (1 - MOOD_BLEND_RATE) + targetMood * MOOD_BLEND_RATE;
}

/**
 * Berechnet Decay für alle Emotionen basierend auf Resilienz.
 * @param {Object} emotions — Mutable emotion-Intensitäten
 * @param {number} resilience — Personality-Resilienz (0–1)
 * @param {number} dt — Delta time
 * @returns {Object} — Mutierte emotions-Objekt
 */
export function applyDecay(emotions, resilience, dt) {
  const resilienceFactor = 0.6 + resilience * 0.8; // 0.6–1.4

  for (const [emotion, def] of Object.entries(EMOTION_DEFS)) {
    const decayRate = def.decay * resilienceFactor * dt;
    emotions[emotion] = Math.max(0, emotions[emotion] - decayRate);
  }

  return emotions;
}
