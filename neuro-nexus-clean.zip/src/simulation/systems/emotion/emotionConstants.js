/**
 * emotionConstants.js — Konstanten für EmotionEngine
 *
 * Enthält EmotionType-Enum, Emotion-Definitionen (Decay, Valence, Labels)
 * und Default-Systemmodulations-Parameter.
 * Ausgelagert aus EmotionEngine.js zur Reduzierung des Monolithen.
 */

export const EmotionType = Object.freeze({
  // Well-being (event consequences)
  JOY:            "joy",
  DISTRESS:       "distress",
  HOPE:           "hope",
  FEAR:           "fear",
  SATISFACTION:   "satisfaction",
  DISAPPOINTMENT: "disappointment",
  // Attribution (agent actions)
  PRIDE:          "pride",
  SHAME:          "shame",
  // Attraction
  LOVE:           "love",
  DISLIKE:        "dislike",
  // Neuro-Nexus extensions
  WONDER:         "wonder",
  CALM:           "calm",
  TENSION:        "tension",
  CURIOSITY:      "curiosity",
});

// Alle Emotionen mit Default-Decay-Rate (pro Sekunde) + Valence + Label
export const EMOTION_DEFS = Object.freeze({
  [EmotionType.JOY]:            { decay: 0.08, valence: +1, label: "Freude" },
  [EmotionType.DISTRESS]:       { decay: 0.06, valence: -1, label: "Kummer" },
  [EmotionType.HOPE]:           { decay: 0.05, valence: +1, label: "Hoffnung" },
  [EmotionType.FEAR]:           { decay: 0.10, valence: -1, label: "Angst" },
  [EmotionType.SATISFACTION]:   { decay: 0.07, valence: +1, label: "Befriedigung" },
  [EmotionType.DISAPPOINTMENT]: { decay: 0.06, valence: -1, label: "Enttäuschung" },
  [EmotionType.PRIDE]:          { decay: 0.06, valence: +1, label: "Stolz" },
  [EmotionType.SHAME]:          { decay: 0.05, valence: -1, label: "Scham" },
  [EmotionType.LOVE]:           { decay: 0.02, valence: +1, label: "Zuneigung" },
  [EmotionType.DISLIKE]:        { decay: 0.03, valence: -1, label: "Abneigung" },
  [EmotionType.WONDER]:         { decay: 0.09, valence: +1, label: "Staunen" },
  [EmotionType.CALM]:           { decay: 0.03, valence: +1, label: "Ruhe" },
  [EmotionType.TENSION]:        { decay: 0.12, valence: -1, label: "Spannung" },
  [EmotionType.CURIOSITY]:      { decay: 0.07, valence: +1, label: "Neugier" },
});

// Mood: langsame Hintergrund-Emotion
export const MOOD_UPDATE_INTERVAL = 5.0;   // seconds
export const MOOD_BLEND_RATE = 0.05;       // how fast mood tracks emotion average

// Default Systemmodulation
export const DEFAULT_MODULATION = Object.freeze({
  firingThresholdMultiplier:     1.0,
  pruningRateMultiplier:         1.0,
  growthRateMultiplier:          1.0,
  signalEnergyMultiplier:        1.0,
  signalRadiusMultiplier:        1.0,
  explorationNoiseMultiplier:    1.0,
  decayRateMultiplier:           1.0,
  attentionSpanMultiplier:       1.0,
  memoryConsolidationMultiplier: 1.0,
});
