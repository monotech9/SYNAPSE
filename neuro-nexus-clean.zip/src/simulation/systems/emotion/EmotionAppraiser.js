/**
 * EmotionAppraiser — EventBus-Subscriptions und Appraisal-Logik
 *
 * Wandelt Simulations-Events in Emotion-Impulse um und führt die
 * periodische Appraisal aus (aktivitätsbasiert, strukturell, RPE).
 *
 * Wird von EmotionEngine verwendet; nicht direkt instanziiert.
 */

import { clamp } from "../../../utils/math.js";
import { EmotionType, EMOTION_DEFS } from "./emotionConstants.js";

/**
 * Abonniert alle EventBus-Events und leitet sie als Appraisals weiter.
 * @param {EventBus} events
 * @param {function} appraise — this._appraise.bind(engine)
 * @returns {function[]} — Array von unsubscribe-Funktionen
 */
export function subscribeEventBus(events, appraise) {
  const offs = [];

  // Growth events → joy, pride
  offs.push(events.on("growth:nodeAdded", () => {
    appraise(EmotionType.JOY, 0.08, "node_added");
    appraise(EmotionType.PRIDE, 0.04, "node_added");
  }));

  offs.push(events.on("growth:edgeAdded", () => {
    appraise(EmotionType.JOY, 0.03, "edge_added");
  }));

  // Bridge → joy, love (connection)
  offs.push(events.on("network:bridgeCreated", () => {
    appraise(EmotionType.JOY, 0.12, "bridge");
    appraise(EmotionType.LOVE, 0.08, "bridge");
    appraise(EmotionType.SATISFACTION, 0.06, "bridge");
  }));

  // Pruning → distress, sadness
  offs.push(events.on("network:nodePruned", (d) => {
    const intensity = d?.significant ? 0.15 : 0.06;
    appraise(EmotionType.DISTRESS, intensity, "pruned");
    appraise(EmotionType.DISAPPOINTMENT, intensity * 0.7, "pruned");
  }));

  // Scar → fear, distress (significant negative event)
  offs.push(events.on("scar:created", () => {
    appraise(EmotionType.FEAR, 0.2, "scar");
    appraise(EmotionType.DISTRESS, 0.15, "scar");
  }));

  // Signal injected (user interaction) → curiosity + surprise
  offs.push(events.on("signal:injected", () => {
    appraise(EmotionType.CURIOSITY, 0.1, "signal");
    appraise(EmotionType.HOPE, 0.05, "signal");
  }));

  // Pulse spike → tension (high activity)
  offs.push(events.on("pulse:spike", (d) => {
    const intensity = clamp((d?.count || 0) / 200, 0, 0.2);
    appraise(EmotionType.TENSION, intensity, "pulse_spike");
  }));

  // Memory flash → satisfaction (learning success)
  offs.push(events.on("memory:flash", () => {
    appraise(EmotionType.SATISFACTION, 0.05, "memory_flash");
  }));

  // Emergence → wonder (key driver for "life events")
  offs.push(events.on("emergence:detected", (d) => {
    const intensity = clamp(d?.score || 0.3, 0, 0.5);
    appraise(EmotionType.WONDER, intensity, "emergence");

    // CRITICAL_SPIKE → awe, hope
    if (d?.level === "CRITICAL_SPIKE") {
      appraise(EmotionType.HOPE, 0.2, "critical_spike");
      appraise(EmotionType.PRIDE, 0.15, "critical_spike");
    }

    // PHASE_SHIFT with structure drift → distress + transformation
    if (d?.level === "PHASE_SHIFT" && d?.signals?.structureDrift > 0.4) {
      appraise(EmotionType.DISTRESS, 0.1, "restructure");
    }
  }));

  // Prediction surprise → curiosity (moderate) or fear (extreme)
  offs.push(events.on("prediction:surprise", (d) => {
    const error = d?.error || 0;
    if (error > 0.3) {
      appraise(EmotionType.FEAR, error * 0.2, "prediction_extreme");
    } else {
      appraise(EmotionType.CURIOSITY, error * 0.3, "prediction_surprise");
    }
  }));

  // Consciousness ignition → pride, joy
  offs.push(events.on("consciousness:ignition", (d) => {
    const intensity = clamp(d?.salience || 0.3, 0, 0.2);
    appraise(EmotionType.PRIDE, intensity, "ignition");
    appraise(EmotionType.JOY, intensity * 0.7, "ignition");
  }));

  // Growth stage transition → transformation emotions
  offs.push(events.on("growth:stageChange", (d) => {
    appraise(EmotionType.PRIDE, 0.15, "stage_up");
    appraise(EmotionType.HOPE, 0.1, "stage_up");
    appraise(EmotionType.WONDER, 0.08, "stage_up");
  }));

  // Story events can feed back (emotional resonance from own narrative)
  offs.push(events.on("story:event", (d) => {
    // Story events create mild emotional echoes — the system "feels" its own story
    const echoIntensity = clamp((d?.edScore || 0.3) * 0.1, 0, 0.1);
    if (d?.emotion === "loss") appraise(EmotionType.DISTRESS, echoIntensity, "story_echo");
    if (d?.emotion === "awakening") appraise(EmotionType.WONDER, echoIntensity, "story_echo");
    if (d?.emotion === "tension") appraise(EmotionType.TENSION, echoIntensity, "story_echo");
    if (d?.emotion === "calm") appraise(EmotionType.CALM, echoIntensity, "story_echo");
    if (d?.emotion === "transformation") appraise(EmotionType.HOPE, echoIntensity, "story_echo");
  }));

  return offs;
}

/**
 * Führt die periodische Appraisal basierend auf Simulationszustand aus.
 * Aktivitätsbasiert, strukturell, Wachstum, dopaminerger RPE.
 *
 * @param {Object} ctx — { world, simulation, emotions, appraise, state }
 *   - world: simulation.world
 *   - simulation: NeuroSimulation
 *   - emotions: this.emotions (mutable)
 *   - appraise: this._appraise.bind(engine)
 *   - state: { _expectedReward, _lastRewardDelta } (mutable properties on ctx.state)
 */
export function periodicAppraisal(ctx) {
  const { world: w, simulation, appraise, state } = ctx;
  const clusters = w.clusters || [];
  const activeClusters = clusters.filter(c => c.state !== "dormant");
  const totalNodes = simulation.totalNodeCount();
  const totalEdges = w.edges.length;
  const bridgeCount = w.bridgeEdges.length;
  const scarCount = (w.scars || []).length;
  const pulseCount = w.pulses.length;
  const pointerEnergy = w.pointerEnergy || 0;

  // --- Activity-based appraisal ---

  // Low activity → calm
  if (pulseCount < 10 && totalNodes > 5) {
    appraise(EmotionType.CALM, 0.03, "low_activity");
  }

  // High activity → tension
  if (pulseCount > 150) {
    appraise(EmotionType.TENSION, clamp((pulseCount - 150) / 200, 0, 0.08), "high_activity");
  }

  // User interaction → curiosity
  if (pointerEnergy > 0.2) {
    appraise(EmotionType.CURIOSITY, pointerEnergy * 0.05, "user_present");
  }

  // --- Structural appraisal ---

  // Many bridges → love (connection satisfaction)
  if (bridgeCount >= 2 && activeClusters.length >= 2) {
    appraise(EmotionType.LOVE, 0.02, "well_connected");
  }

  // Scars accumulate → chronic distress
  if (scarCount > 2) {
    appraise(EmotionType.DISTRESS, clamp(scarCount * 0.01, 0, 0.04), "scar_burden");
  }

  // --- Growth-based appraisal ---

  // System growing → hope
  if (w.growthStage !== "genesis" && totalNodes > 10) {
    appraise(EmotionType.HOPE, 0.01, "growing");
  }

  // System mature → satisfaction
  if (w.maturity > 0.7) {
    appraise(EmotionType.SATISFACTION, 0.02, "mature");
  }

  // --- Dopaminergic Reward-Prediction-Error ---

  // "Reward" = composite of growth + connection + coherence
  const currentReward = clamp(
    (totalNodes / 100) * 0.3 +
    (totalEdges / 200) * 0.2 +
    (bridgeCount / 5) * 0.2 +
    (1 - scarCount * 0.1) * 0.3,
    0, 1
  );

  const rewardDelta = currentReward - state._expectedReward;
  state._lastRewardDelta = rewardDelta;

  // Positive RPE → joy (dopamine burst)
  if (rewardDelta > 0.02) {
    appraise(EmotionType.JOY, clamp(rewardDelta * 0.3, 0, 0.1), "rpe_positive");
  }

  // Negative RPE → disappointment (dopamine dip)
  if (rewardDelta < -0.02) {
    appraise(EmotionType.DISAPPOINTMENT, clamp(-rewardDelta * 0.2, 0, 0.08), "rpe_negative");
  }

  // Update expectation (slowly tracking actual reward)
  state._expectedReward = state._expectedReward * 0.95 + currentReward * 0.05;
}
