/**
 * sleepConstants.js — Konstanten für SleepCycle
 *
 * Enthält SleepState-Enum und Default-Konfiguration.
 * Ausgelagert aus SleepCycle.js zur Reduzierung des Monolithen.
 */

export const SleepState = Object.freeze({
  WAKE:      "WAKE",
  NREM:      "NREM",
  REM:       "REM",
  WAKING_UP: "WAKING_UP",
});

export const SLEEP_DEFAULTS = Object.freeze({
  // Wake → Sleep Trigger
  energyThreshold: 0.15,       // Bei welcher Energie (%) der Schlaf triggert
  cycleInterval: 120,          // Sekunden Wachphase bevor Schlaf möglich
  minWakeTime: 60,             // Mindestens 60s Wach bevor Schlaf möglich

  // NREM (Deep Sleep / Slow-Wave)
  nremDuration: 8,             // Sekunden NREM-Phase
  nremReplayCount: 12,         // Anzahl Episoden die replayed werden
  nremReinforceAmount: 0.06,   // Wie viel identityTrace pro Replay zunimmt
  nremDownscaleFactor: 0.92,   // Globale Gewichts-Reduktion (synaptische Homöostase)
  nremFatigueRestore: 0.85,    // Wie viel Fatigue abgebaut wird

  // REM (Dream Sleep)
  remDuration: 6,              // Sekunden REM-Phase
  remWalkSteps: 8,             // Anzahl Schritte im Memory-Graph
  remNewLinkProb: 0.35,        // Wahrscheinlichkeit für neue Traum-Verbindungen
  remNewLinkWeight: 0.15,      // Startgewicht für Traum-Verbindungen
  remCreativeThreshold: 0.6,   // Ab wann eine Traum-Sequenz als "kreativ" gilt

  // Wake-Up
  wakeUpDuration: 3,           // Sekunden Übergang zurück zum Wachzustand
  driftCorrectionRate: 0.7,    // Wie stark Drift korrigiert wird (0=none, 1=full reset)
  identityCheckThreshold: 0.3, // Ab wann Identitäts-Drift korrigiert wird

  // Emotionaler Einfluss
  moodSleepBias: 0.3,          // Wie stark negativer Mood Schlaf beschleunigt
  positiveDreamBias: 0.4,      // Wie stark positiver Mood REM-Kreativität beeinflusst
});
