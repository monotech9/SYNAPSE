/**
 * SleepDreamEngine — NREM Replay & REM Traum-Logik
 *
 * Wissenschaftliche Basis:
 *  - Xie et al. 2023: Replay im Schlaf verbessert Robustheit
 *  - Barry & Love 2021: Generatives Replay erzeugt neue Prototypen (REM)
 *  - Fachechi et al. 2018: Sleep-Unlearning entfernt spuriöse Muster
 *
 * Ausgelagert aus SleepCycle.js zur Reduzierung des Monolithen.
 */

import { clamp } from "../../../utils/math.js";

export class SleepDreamEngine {
  constructor(simulation, config, events) {
    this.sim = simulation;
    this.config = config;
    this.events = events;

    // NREM Tracking
    this.nremReplayed = 0;
    this.nremReinforced = 0;
    this.nremDownscaled = 0;

    // REM Tracking
    this.remDreams = [];
    this.remNewConnections = 0;
    this.remCreativeCount = 0;
  }

  // ─── NREM: Hebbian Replay + Synaptisches Downscaling ─────────────

  /**
   * Führt ein einzelnes NREM-Replay durch.
   * Wählt Kanten mit hoher identityTrace (gewichtet) und verstärkt diese
   * plus Nachbarkanten (Assoziation).
   */
  doNremReplay() {
    const edges = this.sim.world.edges;
    if (!edges || edges.length === 0) return;

    const candidates = edges.filter(e => !e.bridge && e.identityTrace > 0.02);
    if (candidates.length === 0) return;

    // Weighted random: höherer identityTrace = höhere Wahrscheinlichkeit
    const totalWeight = candidates.reduce((s, e) => s + (e.identityTrace || 0.01), 0);
    let r = Math.random() * totalWeight;
    let chosen = candidates[0];
    for (const e of candidates) {
      r -= (e.identityTrace || 0.01);
      if (r <= 0) { chosen = e; break; }
    }

    // Hebbian Reinforcement
    const reinforceAmount = this.config.nremReinforceAmount;
    chosen.identityTrace = clamp((chosen.identityTrace || 0) + reinforceAmount, 0, 1);
    chosen.weight = clamp((chosen.weight || 0.3) + reinforceAmount * 0.3, 0, 1);
    chosen.traceAge = 0;
    this.nremReinforced++;

    // Nachbarkanten leicht verstärken (Assoziation)
    const neighborsA = edges.filter(e => e !== chosen && !e.bridge && (e.a === chosen.a || e.b === chosen.a));
    const neighborsB = edges.filter(e => e !== chosen && !e.bridge && (e.a === chosen.b || e.b === chosen.b));
    for (const n of [...neighborsA, ...neighborsB].slice(0, 3)) {
      n.identityTrace = clamp((n.identityTrace || 0) + reinforceAmount * 0.3, 0, 1);
      this.nremReinforced++;
    }

    // Nodes leicht reaktivieren (Replay-Pattern)
    chosen.a.activation = Math.max(chosen.a.activation, 0.15);
    chosen.b.activation = Math.max(chosen.b.activation, 0.15);
  }

  /**
   * Synaptisches Downscaling — globale Gewichts-Reduktion
   * (synaptische Homöostase nach Tononi & Cirelli).
   * Nur Nicht-Bridge-Kanten — Bridges sind strukturell wichtig.
   */
  doSynapticDownscaling(epoch) {
    const edges = this.sim.world.edges;
    if (!edges) return;

    const factor = this.config.nremDownscaleFactor;
    for (const edge of edges) {
      if (!edge.bridge) {
        edge.weight = clamp((edge.weight || 0.3) * factor, 0.05, 1);
        edge.identityTrace = clamp((edge.identityTrace || 0) * (factor + 0.04), 0.005, 1);
        this.nremDownscaled++;
      }
    }

    this.events.emit("sleep:nremReplay", {
      replayedEdges: this.nremReplayed,
      reinforcedEdges: this.nremReinforced,
      downscaledEdges: this.nremDownscaled,
      epoch,
    });
  }

  /**
   * Fatigue-Reduktion während NREM.
   */
  restoreFatigue(dt) {
    const edges = this.sim.world.edges;
    if (!edges) return;
    const restoreRate = this.config.nremFatigueRestore * dt / this.config.nremDuration;
    for (const edge of edges) {
      if (edge.fatigue) {
        edge.fatigue = clamp(edge.fatigue - restoreRate, 0, 1);
        edge.fatigueGlow = clamp(edge.fatigueGlow - restoreRate, 0, 1);
      }
    }
  }

  // ─── REM: Generatives Replay / Träume ─────────────────────────────

  /**
   * Führt einen REM-Traum-Walk durch: stochastische Traversierung
   * des Memory-Graph über verbundene Cluster.
   */
  doRemWalk(epoch) {
    const edges = this.sim.world.edges;
    const clusters = this.sim.world.clusters;
    if (!edges || edges.length < 2 || !clusters || clusters.length < 2) return;

    const activeClusters = clusters.filter(c => c.state !== "dormant");
    if (activeClusters.length < 2) return;

    let currentCluster = activeClusters[Math.floor(Math.random() * activeClusters.length)];
    const sequence = [currentCluster];
    const visitedClusters = new Set([currentCluster]);

    // Random Walk über verbundene Cluster (3-6 Schritte)
    const steps = 3 + Math.floor(Math.random() * 4);
    for (let s = 0; s < steps; s++) {
      const connectedEdges = edges.filter(e => {
        const ca = e.a?.cluster, cb = e.b?.cluster;
        return ca === currentCluster || cb === currentCluster;
      });
      if (connectedEdges.length === 0) break;

      // Bevorzugt schwache/unbekannte Kanten für Kreativität
      const sortedByNovelty = connectedEdges.sort((a, b) =>
        (a.identityTrace || 0) - (b.identityTrace || 0)
      );
      const chosen = sortedByNovelty[Math.floor(Math.random() * Math.min(3, sortedByNovelty.length))];

      const nextCluster = chosen.a?.cluster === currentCluster ? chosen.b?.cluster : chosen.a?.cluster;
      if (!nextCluster || visitedClusters.has(nextCluster)) break;

      sequence.push(nextCluster);
      visitedClusters.add(nextCluster);
      currentCluster = nextCluster;
    }

    // Traum bewerten
    const isCreative = sequence.length >= 4 && Math.random() < this.config.remNewLinkProb;
    const mood = this.sim.emotionEngine?.mood || 0;
    const creativityBoost = mood > 0 ? mood * this.config.positiveDreamBias : 0;
    const creativeScore = sequence.length / 6 + creativityBoost;

    const dream = {
      sequence: sequence.map(c => c.id || "unknown"),
      length: sequence.length,
      creativeScore,
      isCreative: creativeScore > this.config.remCreativeThreshold,
      epoch,
    };

    this.remDreams.push(dream);

    // Kreativer Traum → neue schwache Verbindung
    if (dream.isCreative && sequence.length >= 3) {
      this._createDreamLink(sequence[0], sequence[sequence.length - 1]);
      this.remCreativeCount++;
    }

    this.events.emit("sleep:remDream", {
      dreamSequence: dream.sequence,
      length: dream.length,
      isCreative: dream.isCreative,
      creativeScore: dream.creativeScore,
      newConnections: this.remNewConnections,
      epoch: dream.epoch,
    });
  }

  /**
   * Erstellt eine schwache Traum-Verbindung zwischen zwei Clustern.
   * Erzeugt keine echte Edge (würde Wachstumssystem verwirren),
   * sondern verstärkt den clusterPairActivity-Eintrag im Memory.
   */
  _createDreamLink(clusterA, clusterB) {
    if (!clusterA || !clusterB || clusterA === clusterB) return;

    // Bestehende Bridge verstärken
    const existing = this.sim.world.edges.find(e =>
      e.bridge && ((e.a?.cluster === clusterA && e.b?.cluster === clusterB) ||
                    (e.a?.cluster === clusterB && e.b?.cluster === clusterA))
    );
    if (existing) {
      existing.identityTrace = clamp((existing.identityTrace || 0) + 0.03, 0, 1);
      return;
    }

    // Bestehende direkte Kante verstärken
    const nodeA = clusterA.nodes?.[0];
    const nodeB = clusterB.nodes?.[0];
    if (!nodeA || !nodeB) return;

    const directEdge = this.sim.world.edges.find(e =>
      (e.a === nodeA && e.b === nodeB) || (e.a === nodeB && e.b === nodeA)
    );
    if (directEdge) {
      directEdge.identityTrace = clamp((directEdge.identityTrace || 0) + 0.05, 0, 1);
      return;
    }

    // Neue Traum-Verbindung im Memory-Graph
    const memory = this.sim.world.memory;
    if (memory && memory.clusterPairActivity) {
      const key = [clusterA.id, clusterB.id].sort().join("|");
      const entry = memory.clusterPairActivity[key] || { count: 0, lastAt: 0, strength: 0 };
      entry.count += 1;
      entry.lastAt = this.sim.world.age;
      entry.strength = clamp(entry.strength + this.config.remNewLinkWeight, 0, 1);
      memory.clusterPairActivity[key] = entry;
    }

    this.remNewConnections++;
  }

  // ─── Reset ────────────────────────────────────────────────────────

  reset() {
    this.nremReplayed = 0;
    this.nremReinforced = 0;
    this.nremDownscaled = 0;
    this.remDreams = [];
    this.remNewConnections = 0;
    this.remCreativeCount = 0;
  }
}
