/**
 * sleepSnapshot — Snapshot-Kapture, Drift-Berechnung & Korrektur
 *
 * Reine Funktionen für SleepCycle's Identitäts-Drift-Mechanismus.
 * Während des Schlafs wird ein Snapshot des Netzwerk-Zustands erfasst,
 * nach dem Aufwachen wird die Drift gemessen und ggf. korrigiert.
 */

import { clamp, lerp } from "../../../utils/math.js";

/**
 * Erfasst einen Snapshot des aktuellen Netzwerk-Zustands.
 * @param {Object} sim — NeuroSimulation
 * @returns {Object} — Snapshot-Objekt
 */
export function captureSnapshot(sim) {
  const clusters = sim.world.clusters || [];
  const edges = sim.world.edges || [];

  return {
    clusterCount: clusters.filter(c => c.state !== "dormant").length,
    totalNodes: sim.totalNodeCount(),
    edgeCount: edges.length,
    bridgeCount: edges.filter(e => e.bridge).length,
    avgIdentityTrace: edges.length > 0
      ? edges.reduce((s, e) => s + (e.identityTrace || 0), 0) / edges.length : 0,
    avgWeight: edges.length > 0
      ? edges.reduce((s, e) => s + (e.weight || 0), 0) / edges.length : 0,
    scars: sim.world.scars?.length || 0,
    personalityVector: getPersonalityVector(sim),
    emotionSnapshot: sim.emotionEngine?.getSnapshot() || null,
  };
}

/**
 * Berechnet die Drift zwischen zwei Snapshots.
 * @param {Object} pre — Snapshot vor dem Schlaf
 * @param {Object} post — Snapshot nach dem Schlaf
 * @returns {number} — Drift-Wert [0, 1]
 */
export function calculateDrift(pre, post) {
  if (!pre || !post) return 0;

  const clusterDelta = Math.abs(post.clusterCount - pre.clusterCount) / Math.max(1, pre.clusterCount);
  const edgeDelta = Math.abs(post.edgeCount - pre.edgeCount) / Math.max(1, pre.edgeCount);
  const traceDelta = Math.abs(post.avgIdentityTrace - pre.avgIdentityTrace);
  const weightDelta = Math.abs(post.avgWeight - pre.avgWeight);

  let personalityDelta = 0;
  if (pre.personalityVector && post.personalityVector) {
    for (const key of Object.keys(pre.personalityVector)) {
      personalityDelta += Math.abs(
        (post.personalityVector[key] || 0) - (pre.personalityVector[key] || 0)
      );
    }
    personalityDelta /= Object.keys(pre.personalityVector).length || 1;
  }

  return clamp(
    clusterDelta * 0.3 + edgeDelta * 0.2 + traceDelta * 0.2 +
    weightDelta * 0.15 + personalityDelta * 0.15, 0, 1
  );
}

/**
 * Korrigiert Drift im Personality-Vektor (lerp zurück zum Pre-Sleep-Wert).
 * @param {Object} sim — NeuroSimulation
 * @param {Object} pre — Pre-Sleep Snapshot
 * @param {number} rate — Korrektur-Rate (0–1)
 */
export function correctDrift(sim, pre, rate) {
  const personality = sim.personality;
  if (!personality || !pre.personalityVector) return;

  for (const key of Object.keys(pre.personalityVector)) {
    const current = personality[key] || 0;
    const target = pre.personalityVector[key];
    personality[key] = lerp(current, target, rate);
  }
}

/**
 * Extrahiert den Personality-Vektor als flaches Objekt.
 */
export function getPersonalityVector(sim) {
  const p = sim.personality;
  if (!p) return null;
  return {
    curiosity: p.curiosity || 0, caution: p.caution || 0,
    resilience: p.resilience || 0, rhythm: p.rhythm || 0,
    sensitivity: p.sensitivity || 0, plasticity: p.plasticity || 0,
    attachment: p.attachment || 0, volatility: p.volatility || 0,
  };
}
