/**
 * SleepCycle — Schlaf- & Traumzyklus State Machine (Orchestrator)
 *
 * Wissenschaftliche Basis:
 *  - Brodt et al. 2023: Schlaf dient der Systemgedächtnis-Konsolidierung
 *  - Singh et al. 2022: NREM/REM-Wechsel balanciert Integration & Homöostase
 *
 * Architektur:
 *
 *  WAKE ──────► NREM_PHASE (Replay + Downscaling) → SleepDreamEngine
 *                   │
 *                   ▼
 *              REM_PHASE (Generatives Replay / Träume) → SleepDreamEngine
 *                   │
 *                   ▼
 *              WAKE_UP (Drift-Korrektur + Identity-Check)
 *                   │
 *                   ▼
 *              WAKE (Reset Fatigue, Update Mood)
 *
 * Module:
 *   - sleepConstants.js  — SleepState, SLEEP_DEFAULTS
 *   - SleepDreamEngine.js — NREM/REM Logik
 *   - sleepSnapshot.js   — Snapshot, Drift-Berechnung, Korrektur
 *
 * Events:
 *  - "sleep:stateChange" — { from, to, epoch }
 *  - "sleep:nremReplay"  — { replayedEdges, reinforcedEdges, downscaledEdges }
 *  - "sleep:remDream"    — { dreamSequence, newConnections, isCreative }
 *  - "sleep:wakeUp"      — { duration, consolidated, drift, identityStable }
 *  - "sleep:tick"        — { phase, progress, remaining }
 */

import { SleepState, SLEEP_DEFAULTS } from "./sleepConstants.js";
import { SleepDreamEngine } from "./SleepDreamEngine.js";
import { captureSnapshot, calculateDrift, correctDrift } from "./sleepSnapshot.js";

export { SleepState };

export class SleepCycle {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    this.config = { ...SLEEP_DEFAULTS };
    this._dream = new SleepDreamEngine(simulation, this.config, this.events);

    // State Machine
    this.state = SleepState.WAKE;
    this._prevState = SleepState.WAKE;
    this._stateTimer = 0;
    this._wakeTimer = 0;
    this._sleepCount = 0;
    this._totalSleepTime = 0;

    // Wake-Up Tracking
    this._lastConsolidated = 0;
    this._lastDrift = 0;
    this._identityStable = true;
    this._preSleepSnapshot = null;

    this._off1 = null;
    this._setupListeners();
  }

  _setupListeners() {
    this._off1 = this.events.on("personality:drift", (data) => {
      this._applyPersonalityModulation(data);
    });
  }

  _applyPersonalityModulation(personality) {
    if (!personality) return;
    this.config.nremReinforceAmount = 0.04 + personality.resilience * 0.06;
    this.config.remNewLinkProb = 0.2 + personality.volatility * 0.3;
    this.config.energyThreshold = 0.25 - personality.sensitivity * 0.15;
  }

  // ─── Main Update (State Machine) ───────────────────────────────────

  update(dt) {
    this._stateTimer += dt;
    switch (this.state) {
      case SleepState.WAKE:      this._updateWake(dt); break;
      case SleepState.NREM:      this._updateNREM(dt); break;
      case SleepState.REM:       this._updateREM(dt); break;
      case SleepState.WAKING_UP: this._updateWakingUp(dt); break;
    }
  }

  // ─── WAKE ──────────────────────────────────────────────────────────

  _updateWake(dt) {
    this._wakeTimer += dt;

    const energy = this._getSystemEnergy();
    const cycleReady = this._wakeTimer >= this.config.cycleInterval;
    const energyLow = energy < this.config.energyThreshold;
    const minWakePassed = this._wakeTimer >= this.config.minWakeTime;

    const mood = this.sim.emotionEngine?.mood || 0;
    const moodBoost = mood < 0 ? -mood * this.config.moodSleepBias : 0;
    const effectiveThreshold = this.config.energyThreshold + moodBoost;

    if (minWakePassed && (energy < effectiveThreshold || cycleReady)) {
      this._enterSleep();
    }

    this.events.emit("sleep:tick", {
      phase: SleepState.WAKE,
      progress: this._wakeTimer / this.config.cycleInterval,
      remaining: Math.max(0, this.config.cycleInterval - this._wakeTimer),
      energy,
    });
  }

  _enterSleep() {
    this._prevState = this.state;
    this.state = SleepState.NREM;
    this._stateTimer = 0;
    this._sleepCount++;
    this._preSleepSnapshot = captureSnapshot(this.sim);
    this._dream.reset();

    this.events.emit("sleep:stateChange", {
      from: SleepState.WAKE, to: SleepState.NREM,
      epoch: this._getEpoch(), sleepCount: this._sleepCount,
    });
  }

  // ─── NREM ──────────────────────────────────────────────────────────

  _updateNREM(dt) {
    const progress = this._stateTimer / this.config.nremDuration;

    const replayPerSecond = this.config.nremReplayCount / this.config.nremDuration;
    const expectedReplays = Math.floor(this._stateTimer * replayPerSecond);

    while (this._dream.nremReplayed < expectedReplays) {
      this._dream.doNremReplay();
      this._dream.nremReplayed++;
    }

    if (this._stateTimer >= this.config.nremDuration * 0.5 && this._dream.nremDownscaled === 0) {
      this._dream.doSynapticDownscaling(this._getEpoch());
    }

    this._dream.restoreFatigue(dt);

    this.events.emit("sleep:tick", {
      phase: SleepState.NREM, progress,
      remaining: Math.max(0, this.config.nremDuration - this._stateTimer),
    });

    if (this._stateTimer >= this.config.nremDuration) this._enterREM();
  }

  // ─── REM ───────────────────────────────────────────────────────────

  _enterREM() {
    this._prevState = this.state;
    this.state = SleepState.REM;
    this._stateTimer = 0;

    this.events.emit("sleep:stateChange", {
      from: SleepState.NREM, to: SleepState.REM, epoch: this._getEpoch(),
    });
  }

  _updateREM(dt) {
    const progress = this._stateTimer / this.config.remDuration;

    const walksPerSecond = this.config.remWalkSteps / this.config.remDuration;
    const expectedWalks = Math.floor(this._stateTimer * walksPerSecond);

    while (this._dream.remDreams.length < expectedWalks) {
      this._dream.doRemWalk(this._getEpoch());
    }

    this.events.emit("sleep:tick", {
      phase: SleepState.REM, progress,
      remaining: Math.max(0, this.config.remDuration - this._stateTimer),
    });

    if (this._stateTimer >= this.config.remDuration) this._enterWakingUp();
  }

  // ─── WAKING_UP ─────────────────────────────────────────────────────

  _enterWakingUp() {
    this._prevState = this.state;
    this.state = SleepState.WAKING_UP;
    this._stateTimer = 0;

    this.events.emit("sleep:stateChange", {
      from: SleepState.REM, to: SleepState.WAKING_UP, epoch: this._getEpoch(),
    });

    // Drift berechnen + korrigieren
    const postSnapshot = captureSnapshot(this.sim);
    const drift = calculateDrift(this._preSleepSnapshot, postSnapshot);
    this._lastDrift = drift;

    if (drift > this.config.identityCheckThreshold) {
      correctDrift(this.sim, this._preSleepSnapshot, this.config.driftCorrectionRate);
      this._identityStable = false;
    } else {
      this._identityStable = true;
    }

    this._lastConsolidated = this._dream.nremReinforced + this._dream.remNewConnections;

    this.events.emit("sleep:wakeUp", {
      duration: this.config.nremDuration + this.config.remDuration,
      consolidated: this._lastConsolidated,
      drift, identityStable: this._identityStable,
      dreams: this._dream.remDreams.length,
      creativeDreams: this._dream.remCreativeCount,
      epoch: this._getEpoch(),
    });
  }

  _updateWakingUp(dt) {
    const progress = this._stateTimer / this.config.wakeUpDuration;

    if (this._stateTimer >= this.config.wakeUpDuration) this._enterWake();

    this.events.emit("sleep:tick", {
      phase: SleepState.WAKING_UP, progress,
      remaining: Math.max(0, this.config.wakeUpDuration - this._stateTimer),
    });
  }

  _enterWake() {
    this._prevState = this.state;
    this.state = SleepState.WAKE;
    this._stateTimer = 0;
    this._wakeTimer = 0;
    this._totalSleepTime += this.config.nremDuration + this.config.remDuration + this.config.wakeUpDuration;

    this._dream.remDreams = [];

    this.events.emit("sleep:stateChange", {
      from: SleepState.WAKING_UP, to: SleepState.WAKE,
      epoch: this._getEpoch(), sleepCount: this._sleepCount,
    });
  }

  // ─── Helpers ───────────────────────────────────────────────────────

  _getSystemEnergy() {
    const clusters = this.sim.world.clusters;
    if (!clusters?.length) return 0;
    const active = clusters.filter(c => c.state !== "dormant");
    if (!active.length) return 0;
    return active.reduce((s, c) => s + (c.activityMemory || 0), 0) / active.length;
  }

  _getEpoch() { return Math.floor(this.sim.world.age || 0); }

  // ─── Public API ────────────────────────────────────────────────────

  getState() { return this.state; }
  isSleeping() { return this.state !== SleepState.WAKE; }
  isInREM() { return this.state === SleepState.REM; }

  getSnapshot() {
    return {
      state: this.state, prevState: this._prevState,
      stateTimer: this._stateTimer, wakeTimer: this._wakeTimer,
      sleepCount: this._sleepCount, totalSleepTime: this._totalSleepTime,
      energy: this._getSystemEnergy(),
      nremReplayed: this._dream.nremReplayed,
      nremReinforced: this._dream.nremReinforced,
      nremDownscaled: this._dream.nremDownscaled,
      remDreams: this._dream.remDreams.length,
      remNewConnections: this._dream.remNewConnections,
      remCreativeCount: this._dream.remCreativeCount,
      lastConsolidated: this._lastConsolidated,
      lastDrift: this._lastDrift,
      identityStable: this._identityStable,
      config: { ...this.config },
    };
  }

  forceSleep() {
    if (this.state === SleepState.WAKE) { this._enterSleep(); return true; }
    return false;
  }

  forceWake() {
    if (this.state !== SleepState.WAKE) { this._enterWake(); return true; }
    return false;
  }

  reset() {
    this.state = SleepState.WAKE;
    this._prevState = SleepState.WAKE;
    this._stateTimer = 0;
    this._wakeTimer = 0;
    this._sleepCount = 0;
    this._totalSleepTime = 0;
    this._lastConsolidated = 0;
    this._lastDrift = 0;
    this._identityStable = true;
    this._preSleepSnapshot = null;
    this._dream.reset();
  }

  destroy() { this._off1?.(); }
}
