/**
 * lifecycle/index.js — Barrel-Export für das lifecycle-Modul
 */

export * from './LifecycleLoop.js';
export * from './HeartbeatSystem.js';
export * from './ActivityScheduler.js';
export * from './UpdateLoop.js';
export * from './GrowthSystem.js';
export * from './SpontaneityEngine.js';
