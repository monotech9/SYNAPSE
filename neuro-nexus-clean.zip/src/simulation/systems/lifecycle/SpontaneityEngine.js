/**
 * SpontaneityEngine — Eigeninitiative State-Machine
 *
 * Implementiert das Idle→Seeking→Acting→Returning Modell aus dem
 * Executive Summary. Das Netzwerk handelt nicht nur reaktiv — es
 * entscheidet von sich aus, etwas zu tun, wenn der Spieler fehlt.
 *
 * ─── State-Machine ───────────────────────────────────────────────
 *
 *   IDLE ──(idleTimeout)──► SEEKING ──(targetFound)──► ACTING
 *     ▲                        │ (noTarget)               │
 *     │                        ▼                          │
 *     └──────────────── RETURNING ◄──────────────────────┘
 *
 *   IDLE:      Wartet. Tritt ein nach Spieler-Interaktion oder Abschluss.
 *   SEEKING:   Netzwerk sucht aktiv ein interessantes Ziel
 *              (Knoten mit niedrigster Aktivität, isolierte Region, Brücken-
 *              kandidat). Sichtbar: langsames Pulsieren in Zielregion.
 *   ACTING:    Führt konkrete Aktion aus (Signal, Bridge-Ping, Glow-Burst).
 *              Sichtbar: klarer Impuls von der Zielregion ausgehend.
 *   RETURNING: Kurze Pause nach der Aktion. Netzwerk "atmet durch".
 *
 * ─── Timing ──────────────────────────────────────────────────────
 *
 *   Idle-Timeout:   30s Basis (nach letzter Spieler-Interaktion)
 *   Random-Kick:    5% Chance pro Sekunde (auch bei kurzem Idle)
 *   Seeking-Phase:  2–5s
 *   Acting-Phase:   1–3s
 *   Returning-Phase: 3–8s
 *
 * ─── Integration ─────────────────────────────────────────────────
 *
 *   - Liest RelationshipLayer.neglectLevel für Timeout-Skalierung
 *   - Liest IntrinsicMotivation.dominantDrive für Aktionswahl
 *   - Schreibt in world.spontaneousTimer (bestehender Mechanismus)
 *   - Emittiert eigene Events für HUD + AudioHint
 *
 * Events (out):
 *   "spontaneity:seeking"  — Netzwerk beginnt zu suchen { target, drive }
 *   "spontaneity:acting"   — Aktion wird ausgeführt { action, target, intensity }
 *   "spontaneity:idle"     — Zurück in Ruhe
 *
 * Events (in):
 *   "signal:injected"      — Spieler hat eingegriffen → reset nach IDLE
 *   "relationship:neglect" — Vernachlässigung → Timeout verkürzen
 */

import { clamp } from "../../../utils/math.js";
import { recordMemoryEvent } from "../../memory.js";
import { ClusterStates } from "../../clusterRoles.js";
import { GrowthStages } from "../../growthStages.js";

// ─── Zustände ────────────────────────────────────────────────────

export const SpontaneityState = Object.freeze({
  IDLE:      "idle",
  SEEKING:   "seeking",
  ACTING:    "acting",
  RETURNING: "returning",
});

// ─── Konfiguration ───────────────────────────────────────────────

const IDLE_TIMEOUT_BASE    = 30;   // Sekunden bis SEEKING beginnt
const RANDOM_KICK_RATE     = 0.05; // Chance pro Sekunde für spontanen Kick
const SEEKING_DURATION_MIN = 2.0;
const SEEKING_DURATION_MAX = 5.0;
const ACTING_DURATION_MIN  = 1.0;
const ACTING_DURATION_MAX  = 3.0;
const RETURNING_DURATION_MIN = 3.0;
const RETURNING_DURATION_MAX = 8.0;

// ─── SpontaneityEngine ───────────────────────────────────────────

export class SpontaneityEngine {
  /**
   * @param {NeuroSimulation} simulation
   */
  constructor(simulation) {
    this.sim    = simulation;
    this.events = simulation.events;

    this.state        = SpontaneityState.IDLE;
    this._stateTimer  = 0;
    this._idleTimer   = 0;
    this._target      = null;   // { cluster, edge, type }
    this._lastAction  = null;   // zuletzt ausgeführte Aktion
    this._actionCount = 0;      // Gesamtzahl ausgeführter Eigeninitiativ-Aktionen

    // Sichtbares Seeking-Glow auf Ziel-Cluster
    this.seekingGlow = null;    // { clusterId, intensity } oder null

    // Subscriptions
    this._unsubs = [
      this.events.on("signal:injected",      () => this._onPlayerInput()),
      this.events.on("relationship:neglect",  (d) => this._onNeglect(d)),
    ];
  }

  // ─── Update ──────────────────────────────────────────────────

  update(dt) {
    const world = this.sim.world;

    // Nicht aktiv in sehr früher Phase
    if (world.growthStage === GrowthStages.GENESIS) return;

    this._stateTimer += dt;

    switch (this.state) {
      case SpontaneityState.IDLE:
        this._updateIdle(dt);
        break;
      case SpontaneityState.SEEKING:
        this._updateSeeking(dt);
        break;
      case SpontaneityState.ACTING:
        this._updateActing(dt);
        break;
      case SpontaneityState.RETURNING:
        this._updateReturning(dt);
        break;
    }
  }

  // ─── IDLE ────────────────────────────────────────────────────

  _updateIdle(dt) {
    this._idleTimer += dt;
    this.seekingGlow = null;

    const rel = this.sim.relationshipLayer;
    const neglect = rel?.neglectLevel ?? 0;

    // Timeout verkürzt sich mit Vernachlässigung (Netzwerk wird unruhiger)
    const timeoutScale = clamp(1.0 - neglect * 0.5, 0.5, 1.0);
    const timeout = IDLE_TIMEOUT_BASE * timeoutScale;

    // Zeitbasiert: nach timeout in SEEKING
    if (this._idleTimer >= timeout) {
      this._enterSeeking("timer");
      return;
    }

    // Zufalls-Kick: 5% pro Sekunde (nach mind. 10s Idle)
    if (this._idleTimer > 10 && Math.random() < RANDOM_KICK_RATE * dt) {
      this._enterSeeking("random");
      return;
    }

    // Drive-basiert: IntrinsicMotivation schiebt an
    const motivation = this.sim.consciousness?.motivation;
    if (motivation) {
      const dominantPressure = motivation.drives[motivation.dominantDrive]?.pressure ?? 0;
      if (dominantPressure > 0.7 && this._idleTimer > 8) {
        this._enterSeeking("drive_" + motivation.dominantDrive);
        return;
      }
    }
  }

  // ─── SEEKING ─────────────────────────────────────────────────

  _updateSeeking(dt) {
    const duration = this._seekingDuration ?? SEEKING_DURATION_MAX;

    // Seeking-Glow auf Ziel-Cluster pulsieren lassen
    if (this._target?.cluster) {
      const pulse = (Math.sin(this._stateTimer * 4) * 0.5 + 0.5) * 0.6;
      this.seekingGlow = {
        clusterId: this._target.cluster.id,
        intensity: pulse,
        type: this._target.type,
      };
    }

    if (this._stateTimer >= duration) {
      if (this._target) {
        this._enterActing();
      } else {
        // Kein Ziel gefunden → zurück nach IDLE
        this._enterIdle();
      }
    }
  }

  // ─── ACTING ──────────────────────────────────────────────────

  _updateActing(dt) {
    const duration = this._actingDuration ?? ACTING_DURATION_MAX;

    // Aktion nur einmal am Anfang ausführen
    if (this._stateTimer < dt * 2 && !this._actionFired) {
      this._fireAction();
      this._actionFired = true;
    }

    if (this._stateTimer >= duration) {
      this._enterReturning();
    }
  }

  // ─── RETURNING ───────────────────────────────────────────────

  _updateReturning(dt) {
    const duration = this._returningDuration ?? RETURNING_DURATION_MAX;

    // Glow langsam ausblenden
    if (this.seekingGlow) {
      this.seekingGlow.intensity *= 0.95;
      if (this.seekingGlow.intensity < 0.01) this.seekingGlow = null;
    }

    if (this._stateTimer >= duration) {
      this._enterIdle();
    }
  }

  // ─── Übergänge ───────────────────────────────────────────────

  _enterSeeking(trigger) {
    this.state        = SpontaneityState.SEEKING;
    this._stateTimer  = 0;
    this._actionFired = false;
    this._target      = this._findTarget();
    this._seekingDuration = this._rngRange(SEEKING_DURATION_MIN, SEEKING_DURATION_MAX);

    this.events.emit("spontaneity:seeking", {
      trigger,
      target: this._target ? { type: this._target.type, clusterId: this._target.cluster?.id } : null,
      drive:  this.sim.consciousness?.motivation?.dominantDrive ?? "curiosity",
    });
  }

  _enterActing() {
    this.state       = SpontaneityState.ACTING;
    this._stateTimer = 0;
    this._actingDuration = this._rngRange(ACTING_DURATION_MIN, ACTING_DURATION_MAX);
  }

  _enterReturning() {
    this.state       = SpontaneityState.RETURNING;
    this._stateTimer = 0;
    this._returningDuration = this._rngRange(RETURNING_DURATION_MIN, RETURNING_DURATION_MAX);
  }

  _enterIdle() {
    this.state       = SpontaneityState.IDLE;
    this._stateTimer = 0;
    this._idleTimer  = 0;
    this._target     = null;
    this._actionFired= false;

    this.events.emit("spontaneity:idle", { lastAction: this._lastAction });
  }

  // ─── Zielsuche ───────────────────────────────────────────────

  /**
   * Findet das interessanteste Ziel basierend auf dominant Drive.
   * Gibt { cluster, edge?, type } zurück oder null.
   */
  _findTarget() {
    const world  = this.sim.world;
    const motivation = this.sim.consciousness?.motivation;
    const drive  = motivation?.dominantDrive ?? "curiosity";
    const rng    = this.sim.rng;

    const activeClusters = world.clusters.filter(
      c => c.birthProgress > 0.3 && c.state !== ClusterStates.DORMANT
    );
    if (!activeClusters.length) return null;

    switch (drive) {
      case "curiosity": {
        // Suche den ruhigsten Cluster (am meisten vernachlässigt)
        const target = activeClusters
          .map(c => ({ cluster: c, score: 1 - (c.activityMemory || 0) + Math.random() * 0.2 }))
          .sort((a, b) => b.score - a.score)[0]?.cluster;
        return target ? { cluster: target, type: "explore" } : null;
      }
      case "coherence": {
        // Suche isolierten Cluster (wenige Bridge-Edges)
        const bridgeCounts = new Map();
        for (const edge of world.bridgeEdges) {
          bridgeCounts.set(edge.a.cluster, (bridgeCounts.get(edge.a.cluster) || 0) + 1);
          bridgeCounts.set(edge.b.cluster, (bridgeCounts.get(edge.b.cluster) || 0) + 1);
        }
        const isolated = activeClusters
          .map(c => ({ cluster: c, bridges: bridgeCounts.get(c) || 0 }))
          .sort((a, b) => a.bridges - b.bridges)[0]?.cluster;
        return isolated ? { cluster: isolated, type: "bridge_ping" } : null;
      }
      case "homeostasis": {
        // Suche aktivsten (stressigsten) Cluster
        const stressed = activeClusters
          .map(c => ({ cluster: c, score: (c.stress || 0) + (c.activityMemory || 0) + Math.random() * 0.1 }))
          .sort((a, b) => b.score - a.score)[0]?.cluster;
        return stressed ? { cluster: stressed, type: "stabilize" } : null;
      }
      case "autonomy":
      case "competence":
      default: {
        // Zufällig einen aktiven Cluster wählen
        const idx = Math.floor(Math.random() * activeClusters.length);
        return { cluster: activeClusters[idx], type: "signal_burst" };
      }
    }
  }

  // ─── Aktion ausführen ────────────────────────────────────────

  _fireAction() {
    const { cluster, type } = this._target;
    const world   = this.sim.world;
    const pulse   = this.sim.pulseEngine;
    const rng     = this.sim.rng;

    // Edges dieses Clusters
    const clusterEdges = world.edges.filter(e =>
      e.birthProgress > 0.3 &&
      (e.a.cluster === cluster || e.b.cluster === cluster)
    );
    if (!clusterEdges.length) { this._enterReturning(); return; }

    let intensity = 0;

    switch (type) {
      case "explore": {
        // Mehrere sanfte Pulse durch den ruhigen Cluster
        const count = 2 + Math.floor(Math.random() * 3);
        const candidates = [...clusterEdges].sort(() => Math.random() - 0.5).slice(0, count);
        for (const edge of candidates) {
          const fwd = Math.random() < 0.5;
          pulse.spawnPulse(edge, fwd, 0.25 + Math.random() * 0.2, {
            visualOnly: true,
            support: true,
            speedMultiplier: rng.range(0.7, 1.1)
          });
        }
        intensity = 0.4;
        recordMemoryEvent(this.sim.memory, "autonomousPulse", world.age);
        this.sim.memory.autonomousMoments = (this.sim.memory.autonomousMoments || 0) + 1;
        break;
      }
      case "bridge_ping": {
        // Bridge-Pulse wenn möglich, sonst interner Burst
        const bridgeEdges = clusterEdges.filter(e => e.bridge);
        const targets = bridgeEdges.length ? bridgeEdges : clusterEdges;
        const edge = targets[Math.floor(Math.random() * Math.min(3, targets.length))];
        pulse.spawnPulse(edge, Math.random() < 0.5, 0.35, {
          visualOnly: true,
          bridge: edge.bridge,
          speedMultiplier: 0.7
        });
        intensity = 0.5;
        break;
      }
      case "stabilize": {
        // Sanfter Pulse auf aktivem Cluster zur Beruhigung
        const edge = clusterEdges[Math.floor(Math.random() * Math.min(2, clusterEdges.length))];
        pulse.spawnPulse(edge, Math.random() < 0.5, 0.15, {
          visualOnly: true,
          support: true,
          speedMultiplier: 0.5
        });
        intensity = 0.2;
        break;
      }
      case "signal_burst":
      default: {
        // Energetischer Burst-Puls
        const edge = clusterEdges[Math.floor(Math.random() * Math.min(4, clusterEdges.length))];
        pulse.spawnPulse(edge, Math.random() < 0.5, 0.4 + Math.random() * 0.2, {
          visualOnly: false,
          speedMultiplier: rng.range(0.9, 1.3)
        });
        intensity = 0.6;
        recordMemoryEvent(this.sim.memory, "autonomousPulse", world.age);
        this.sim.memory.autonomousMoments = (this.sim.memory.autonomousMoments || 0) + 1;
        break;
      }
    }

    this._actionCount++;
    this._lastAction = { type, clusterId: cluster.id, age: world.age, intensity };

    this.events.emit("spontaneity:acting", {
      action:    type,
      clusterId: cluster.id,
      intensity,
      actionCount: this._actionCount,
    });
  }

  // ─── Event-Handler ───────────────────────────────────────────

  _onPlayerInput() {
    // Spieler greift ein → Netzwerk "bemerkt" es, geht zurück in IDLE
    if (this.state !== SpontaneityState.IDLE) {
      this._enterIdle();
    }
    this._idleTimer = 0; // Timer neu starten nach Spieler-Input
  }

  _onNeglect(d) {
    // Bei Vernachlässigung: idleTimer beschleunigen
    if (this.state === SpontaneityState.IDLE) {
      const boost = (d.level || 0.6) * 15;
      this._idleTimer = Math.min(this._idleTimer + boost, IDLE_TIMEOUT_BASE * 0.9);
    }
  }

  // ─── Hilfsmethoden ───────────────────────────────────────────

  _rngRange(min, max) {
    return min + Math.random() * (max - min);
  }

  // ─── Snapshot ────────────────────────────────────────────────

  getSnapshot() {
    return {
      state:        this.state,
      idleTimer:    Math.round(this._idleTimer * 10) / 10,
      stateTimer:   Math.round(this._stateTimer * 10) / 10,
      targetType:   this._target?.type ?? null,
      targetCluster:this._target?.cluster?.id ?? null,
      seekingGlow:  this.seekingGlow,
      actionCount:  this._actionCount,
      lastAction:   this._lastAction,
    };
  }

  destroy() {
    this._unsubs.forEach(fn => fn?.());
    this._unsubs = [];
  }
}

