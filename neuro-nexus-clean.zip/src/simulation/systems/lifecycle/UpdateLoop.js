import { CONFIG } from "../../../config.js";
import { resolveGrowthStage } from "../../growthStages.js";
import { updateClusterMetrics } from "../../clusterMetrics.js";
import { clamp, lerp } from "../../../utils/math.js";
import { ActivityScheduler } from "./ActivityScheduler.js";
import { LifecycleLoop } from "./LifecycleLoop.js";

/**
 * UpdateLoop — zentrale update()-Orchestrierung.
 *
 * Delegiert an zwei spezialisierte Sub-Module:
 *  - ActivityScheduler: ambient activity, preferred-path activity, spontaneous signals
 *  - LifecycleLoop: adaptive growth, bridge ping, memory flash, relay lifecycle
 *
 * UpdateLoop selbst behält: update(), updateInjectedWaves, updatePersistence.
 * Pulse-Lifecycle wird an PulseEngine.updatePulses() delegiert.
 */
export class UpdateLoop {
  constructor(simulation) {
    this.simulation = simulation;
    this.activity = new ActivityScheduler(simulation);
    this.lifecycle = new LifecycleLoop(simulation);
  }

  get world() { return this.simulation.world; }
  get pulseEngine() { return this.simulation.pulseEngine; }
  get networkPruning() { return this.simulation.networkPruning; }
  get growthSystem() { return this.simulation.growthSystem; }

  // ─── Main update orchestration ───────────────────────────────────

  update(dt, timeSeconds) {
    const w = this.world;

    w.currentTime = timeSeconds;
    w.age = clamp(w.age + dt, 0, CONFIG.maturitySeconds);
    w.maturity = clamp(w.age / CONFIG.maturitySeconds, 0, 1);

    this.simulation.ensureClusters();

    // Camera smoothing
    const cam = this.simulation.camera;
    cam.scale = lerp(cam.scale, cam.targetScale, CONFIG.zoomSmoothing);
    cam.offsetX = lerp(cam.offsetX, cam.targetOffsetX, CONFIG.panSmoothing);
    cam.offsetY = lerp(cam.offsetY, cam.targetOffsetY, CONFIG.panSmoothing);

    w.pointerEnergy = Math.max(0, w.pointerEnergy - dt * 1.5);

    // Entity updates
    for (const cluster of w.clusters) cluster.update(dt, timeSeconds);
    for (const edge of w.edges) edge.update(dt);

    // Metrics + Pruning
    updateClusterMetrics(this.simulation, dt);
    this.networkPruning.update(dt);

    // Growth stage resolution
    w.previousGrowthStage = w.growthStage;
    w.growthStage = resolveGrowthStage(this.simulation);
    if (w.growthStage !== w.previousGrowthStage) {
      this.growthSystem.handleGrowthStageTransition(w.previousGrowthStage, w.growthStage);
    }

    for (const cluster of w.clusters) cluster.updateRadius();

    // Pulse lifecycle (delegated to PulseEngine)
    this.pulseEngine.updatePulses(dt);
    this.updateInjectedWaves(dt);

    // Sub-system orchestration
    this.activity.updateAmbientActivity(dt);
    this.activity.updatePreferredPathActivity(dt);
    this.activity.updateSpontaneousSignals(dt);
    this.lifecycle.updateAdaptiveGrowth(dt);
    this.lifecycle.updateBridgePing(dt);
    this.lifecycle.updateMemoryFlash(dt);
    this.lifecycle.updateRelayLifecycle(dt);

    // Advanced systems (optional chaining for safety)
    this.simulation.heartbeatSystem?.update(dt);
    this.simulation.scarSystem?.update(dt);
    this.simulation.emergenceSystem?.update(dt);
    this.simulation.emergenceDetector?.update(dt);
    this.simulation.emotionEngine?.update(dt);
    this.simulation.sleepCycle?.update(dt);
    this.simulation.episodicMemory?.update(dt);
    this.simulation.autobiographicalMemory?.update(dt);

    // Reward System — Dopamine RPE (läuft mit 30Hz, intern gedämpft)
    this.simulation.rewardSystem?.update(dt);
    // Mood State Machine — 8 Stimmungen mit Hysterese (GDD §5)
    this.simulation.moodStateMachine?.update(dt);
    // Echo Memory — wiederkehrende Muster (GDD §6 M3)
    this.simulation.echoMemory?.update(dt);
    // Environment Layer (GDD §9)
    this.simulation.externalStimuli?.update(dt);
    this.simulation.energyModel?.update(dt);
    this.simulation.multiAgentHub?.update(dt);
    this.simulation.spontaneityEngine?.update(dt);
    this.simulation.relationshipLayer?.update(dt);
    this.simulation.networkMoodBridge?.update(dt);

    // Conscious Core — Meta-Layer (läuft intern mit 10Hz)
    this.simulation.consciousness?.update(dt);

    this.updatePersistence(dt);
  }

  // ─── Injected waves ───────────────────────────────────────────────

  updateInjectedWaves(dt) {
    for (let i = this.world.injectedWaves.length - 1; i >= 0; i -= 1) {
      const wave = this.world.injectedWaves[i];
      wave.age += dt;
      if (wave.age > wave.life) this.world.injectedWaves.splice(i, 1);
    }
  }

  // ─── Persistence ──────────────────────────────────────────────────

  updatePersistence(dt) {
    this.world.saveTimer += dt;
    if (this.world.saveTimer < CONFIG.saveIntervalSeconds) return;
    this.world.saveTimer = 0;
    if (!this.world.dirty) return;
    this.simulation.save();
  }
}
