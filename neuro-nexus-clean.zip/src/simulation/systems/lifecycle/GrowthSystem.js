import { CONFIG, GENESIS_BLUEPRINT } from "../../../config.js";
import { ClusterRoles, ClusterStates, clusterTypeForRole } from "../../clusterRoles.js";
import {GrowthIntent} from "../../growthScheduler.js";
import { GrowthStages } from "../../growthStages.js";
import { recordMemoryEvent } from "../../memory.js";
import { clamp } from "../../../utils/math.js";

/**
 * GrowthSystem — Wachstumsstadien, Growth-Intent-Ausführung,
 * Cluster-Initialisierung und -Wiederherstellung.
 *
 * Verwaltet den Lebenszyklus von Clustern: Genesis-Boot, Restore
 * aus persistentem State, Stage-Transition-Handling und die
 * Delegation von Growth-Intents an den NetworkBuilder.
 */
export class GrowthSystem {
  constructor(simulation) {
    this.simulation = simulation;
    this.stageChangeListeners = [];
  }

  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }
  get networkBuilder() { return this.simulation.networkBuilder; }
  get signalSystem() { return this.simulation.signalSystem; }

  // ─── Growth intent execution ──────────────────────────────────────

  executeGrowthIntent(intent) {
    const type = intent?.type || GrowthIntent.PAUSE;
    this.diagnosticCounters.lastGrowthIntent = type;
    this.diagnosticCounters.growthIntents[type] = (this.diagnosticCounters.growthIntents[type] || 0) + 1;

    let changed = false;

    switch (type) {
      case GrowthIntent.ADD_NODE:
        changed = this.networkBuilder.addNodeToCluster(intent.cluster);
        if (changed) this.simulation.events.emit("growth:nodeAdded", { cluster: intent.cluster });
        break;
      case GrowthIntent.ADD_INTERNAL_EDGE:
        changed = this.networkBuilder.addInternalEdge(intent.cluster);
        break;
      case GrowthIntent.STRENGTHEN_MEMORY_PATH:
        changed = this.networkBuilder.strengthenMemoryPath(intent.cluster);
        break;
      case GrowthIntent.CREATE_BUD:
        changed = this.networkBuilder.createBud(intent.cluster);
        break;
      case GrowthIntent.CREATE_BRIDGE:
        changed = this.networkBuilder.createBridgeConnection();
        break;
      case GrowthIntent.PAUSE:
      default:
        if (this.rng.chance(0.08) && this.world.growthStage !== GrowthStages.GENESIS) {
          recordMemoryEvent(this.memory, "growthPause", this.world.age);
        }
        changed = false;
        break;
    }

    this.diagnosticCounters.lastGrowthChanged = Boolean(changed);
    if (changed) {
      this.diagnosticCounters.growthActions[type] = (this.diagnosticCounters.growthActions[type] || 0) + 1;
    }

    return changed;
  }

  // ─── Stage transitions ────────────────────────────────────────────

  handleGrowthStageTransition(previousStage, nextStage) {
    const activeCluster = this.world.clusters[this.world.clusters.length - 1] || this.world.clusters[0];
    if (!activeCluster) return;

    const center = activeCluster.center(this.world.currentTime || performance.now() / 1000);
    const stageStrength = nextStage === GrowthStages.BUDDING || nextStage === GrowthStages.NETWORK ? 0.74 : 0.48;
    this.diagnosticCounters.visibleStageEvents += 1;
    this.signalSystem.createInjectedWave(center.x, center.y, Math.max(74, activeCluster.pixelRadius * 1.45), {
      strength: stageStrength,
      life: 1.8
    });

    for (const node of activeCluster.nodes) {
      node.visualImpact = Math.max(node.visualImpact || 0, nextStage === GrowthStages.NETWORK ? 0.96 : 0.68);
      node.setActivation(Math.max(node.activation, nextStage === GrowthStages.NETWORK ? 0.32 : 0.24));
    }

    // Event-Hooks für externe Listener
    for (const listener of this.stageChangeListeners) {
      try { listener({ old: previousStage, new: nextStage }); } catch { /* Listener-Fehler ignorieren */ }
    }
  }

  /**
   * Registriert einen Listener für Wachstumsstadien-Übergänge.
   * Der Listener erhält { old, new } mit den vorherigen/neuen Stadien.
   * @returns {Function} unsubscribe-Funktion
   */
  onGrowthStageChange(listener) {
    this.stageChangeListeners.push(listener);
    return () => {
      const idx = this.stageChangeListeners.indexOf(listener);
      if (idx >= 0) this.stageChangeListeners.splice(idx, 1);
    };
  }

  /**
   * Entfernt einen Stage-Change-Listener direkt (Alternative zur unsubscribe-Funktion).
   */
  removeStageChangeListener(listener) {
    const idx = this.stageChangeListeners.indexOf(listener);
    if (idx >= 0) this.stageChangeListeners.splice(idx, 1);
  }

  // ─── Cluster initialization & restoration ────────────────────────

  ensureClusters() {
    if (this.world.clusters.length > 0) return;

    const freshBoot = globalThis.NEURO_NEXUS_DEBUG_FRESH_BOOT || globalThis.NEURO_NEXUS_FORCE_FRESH_START;
    const storedClusters = !freshBoot && Array.isArray(this.simulation.persistentState.growth?.clusters)
      ? this.simulation.persistentState.growth.clusters
      : [];

    if (storedClusters.length > 0) {
      this.restoreClusterSkeletons(storedClusters);
      return;
    }

    this.networkBuilder.addCluster(GENESIS_BLUEPRINT, { instant: this.world.age > 3 });
  }

  restoreClusterSkeletons(storedClusters) {
    const limited = storedClusters.slice(0, CONFIG.maxClusters);

    for (const [index, storedCluster] of limited.entries()) {
      const role = storedCluster.role || storedCluster.type || (index === 0 ? ClusterRoles.GENESIS : ClusterRoles.EXPLORATION);
      const blueprint = {
        ...storedCluster,
        id: storedCluster.id || `${role}-${index}`,
        type: clusterTypeForRole(role),
        role,
        state: storedCluster.state || (index === 0 ? ClusterStates.ACTIVE : ClusterStates.FORMING),
        angle: Number.isFinite(storedCluster.angle) ? storedCluster.angle : index * 1.8,
        distance: Number.isFinite(storedCluster.distance) ? storedCluster.distance : index === 0 ? 0 : 0.32 + index * 0.08,
        initialNodes: Math.max(2, Math.min(10, Math.round((storedCluster.nodeCount || 8) * 0.45))),
        createdAtAge: Number(storedCluster.createdAtAge || 0)
      };

      this.networkBuilder.addCluster(blueprint, { instant: this.world.age > 3, wake: index === 0 });
    }

    this.connectRestoredClusters();
  }

  connectRestoredClusters() {
    const core = this.world.clusters.find((cluster) => cluster.role === ClusterRoles.GENESIS) || this.world.clusters[0];
    if (!core) return;

    for (const cluster of this.world.clusters) {
      if (cluster === core) continue;
      this.networkBuilder.createBridgeBetweenClusters(core, cluster, { gentle: true });
    }
  }

  wakeCluster(cluster, energy) {
    for (const node of cluster.nodes) {
      const local = node.localPosition();
      const distance = Math.hypot(local.x, local.y);
      const influence = clamp(1 - distance * 0.8, 0.05, 1);

      node.setActivation(Math.max(node.activation, energy * influence * this.rng.range(0.48, 0.84) * this.personality.signalEnergyMultiplier));
      node.charge = Math.max(node.charge, energy * influence);
    }
  }

  // ─── Serialization ────────────────────────────────────────────────

  serializeGrowthState() {
    return {
      stage: this.world.growthStage,
      clusters: this.world.clusters.map((cluster) => ({
        id: cluster.id,
        role: cluster.role,
        type: cluster.type,
        state: cluster.state,
        parentId: cluster.parentId,
        angle: cluster.angle,
        distance: cluster.distance,
        createdAtAge: cluster.createdAtAge,
        nodeCount: cluster.nodes.length,
        maturity: cluster.maturity,
        density: cluster.density,
        stability: cluster.stability,
        stress: cluster.stress,
        saturation: cluster.saturation,
        memoryStrength: cluster.memoryStrength,
        expansionPressure: cluster.expansionPressure,
        localActivity: cluster.localActivity,
        bridgeStrength: cluster.bridgeStrength,
        softNodeLimit: cluster.softNodeLimit,
        hardNodeLimit: cluster.hardNodeLimit,
        growthBias: cluster.growthBias,
        bridgeBias: cluster.bridgeBias,
        retentionBias: cluster.retentionBias,
        plasticityBias: cluster.plasticityBias,
        budCooldown: cluster.budCooldown,
        dormantTimer: cluster.dormantTimer
      }))
    };
  }
}
