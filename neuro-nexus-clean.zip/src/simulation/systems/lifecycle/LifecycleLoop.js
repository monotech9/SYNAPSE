import { CONFIG, CLUSTER_TYPES } from "../../../config.js";
import { GrowthStages } from "../../growthStages.js";
import {ClusterRoles, ClusterStates} from "../../clusterRoles.js";
import {chooseGrowthIntent} from "../../growthScheduler.js";
import {recordClusterPairActivity} from "../../memory.js";
import { clamp, lerp } from "../../../utils/math.js";

/**
 * LifecycleLoop — periodische Lebenszyklus-Subsysteme:
 * adaptive growth, bridge ping, memory flash, relay lifecycle.
 *
 * Folgt demselben Pattern wie PulseEngine / NetworkBuilder / etc.:
 * erhält die Simulation im Konstruktor und greift über Getter auf
 * world, rng, personality, memory, … zu.
 */
export class LifecycleLoop {
  constructor(simulation) {
    this.simulation = simulation;
  }

  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }
  get pulseEngine() { return this.simulation.pulseEngine; }
  get networkBuilder() { return this.simulation.networkBuilder; }
  get signalSystem() { return this.simulation.signalSystem; }
  get growthSystem() { return this.simulation.growthSystem; }

  // ─── Adaptive growth ──────────────────────────────────────────────

  updateAdaptiveGrowth(dt) {
    this.world.growthTimer -= dt;
    this.world.connectionGrowthTimer -= dt;

    if (this.world.growthTimer <= 0) {
      const intent = chooseGrowthIntent(this.simulation);
      const changed = this.growthSystem.executeGrowthIntent(intent);
      const densityFactor = clamp(this.simulation.totalNodeCount() / CONFIG.maxTotalNodes, 0, 1);
      const stagePause = changed ? 1 : 1.28;
      this.world.growthTimer = this.rng.range(CONFIG.growthIntervalMin, CONFIG.growthIntervalMax) * lerp(1, 2.25, densityFactor) * this.personality.growthIntervalMultiplier * stagePause;
    }

    if (this.world.connectionGrowthTimer <= 0) {
      if (this.world.age >= 180 && (this.world.growthStage === GrowthStages.NETWORK || this.world.growthStage === GrowthStages.CONSTELLATION)) {
        this.networkBuilder.createBridgeConnection();
      } else {
        const core = this.world.clusters.find((cluster) => cluster.role === ClusterRoles.GENESIS) || this.world.clusters[0];
        if (core && core.density < 0.66) this.networkBuilder.addInternalEdge(core);
      }

      this.world.connectionGrowthTimer = this.rng.range(CONFIG.connectionIntervalMin, CONFIG.connectionIntervalMax) * this.personality.connectionIntervalMultiplier;
    }
  }

  // ─── Bridge ping ──────────────────────────────────────────────────

  // Bridge ping: every 8–14 s after age 60, fire a deliberate preferred-path
  // pulse across a bridge edge so the viewer can see inter-cluster conversation.
  updateBridgePing(dt) {
    if (this.world.age < 60) return;

    this.world.bridgePingTimer -= dt;
    if (this.world.bridgePingTimer > 0) return;

    // Nutze bridgeEdges-Array statt edges.filter
    const eligibleBridges = this.world.bridgeEdges.filter((e) => e.birthProgress > 0.55);
    if (eligibleBridges.length > 0) {
      const edge = eligibleBridges[this.rng.int(0, eligibleBridges.length - 1)];
      const forward = this.rng.chance(0.5);
      const strength = this.rng.range(0.24, 0.42);
      this.pulseEngine.spawnPulse(edge, forward, strength, {
        visualOnly: true,
        preferredPath: true,
        bridge: true,
        speedMultiplier: this.rng.range(0.55, 0.78)
      });
      // Also light up the two endpoint nodes so the communication is readable.
      edge.a.visualImpact = Math.max(edge.a.visualImpact || 0, 0.38 + strength * 0.22);
      edge.b.incomingPulseEnergy = Math.max(edge.b.incomingPulseEnergy || 0, 0.34 + strength * 0.28);
      edge.b.incomingPulseTimer = Math.max(edge.b.incomingPulseTimer || 0, 0.18);

      // Inter-Cluster-Kommunikation protokollieren
      recordClusterPairActivity(this.memory, edge.a.cluster, edge.b.cluster, this.world.age, strength);
    }

    this.world.bridgePingTimer = this.rng.range(8, 14);
  }

  // ─── Memory flash ─────────────────────────────────────────────────

  // Memory Flash: after age 90, occasionally light up an old, strong path
  // autonomously, simulating a surfacing memory or deep thought.
  updateMemoryFlash(dt) {
    if (this.world.age < 90) return;

    this.world.memoryFlashTimer -= dt;
    if (this.world.memoryFlashTimer > 0) return;

    const strongEdges = this.world.edges.filter((e) => (e.identityTrace || 0) > 0.65 && e.birthProgress > 0.8 && e.activityGlow < 0.2);
    if (strongEdges.length > 0) {
      const edge = strongEdges[this.rng.int(0, strongEdges.length - 1)];
      const forward = this.rng.chance(0.5);

      // Fast, bright pulse
      this.pulseEngine.spawnPulse(edge, forward, 0.58, {
        visualOnly: true,
        preferredPath: true,
        speedMultiplier: this.rng.range(1.6, 2.2)
      });
      edge.a.visualImpact = Math.max(edge.a.visualImpact || 0, 0.48);
      edge.b.incomingPulseEnergy = Math.max(edge.b.incomingPulseEnergy || 0, 0.45);
      edge.b.incomingPulseTimer = Math.max(edge.b.incomingPulseTimer || 0, 0.08);

      this.memory.autonomousMoments = (this.memory.autonomousMoments || 0) + 1;
    }

    this.world.memoryFlashTimer = this.rng.range(15, 25);
  }

  // ─── Relay lifecycle ──────────────────────────────────────────────

  /**
   * Relay-Cluster-Lebenszyklus:
   * - Spawnt nach CONSTELLATION-Stadium temporäre Relay-Cluster zwischen
   *   weit entfernten Cluster-Paaren.
   * - Relay-Cluster haben keine eigenen Nodes, nur Bridge-Kanten.
   * - Nach Ablauf der Lebensdauer (CONFIG.relayLifespan) werden sie sanft
   *   entfernt.
   */
  updateRelayLifecycle(dt) {
    // 1. Abgelaufene Relay-Cluster entfernen
    for (let i = this.world.clusters.length - 1; i >= 0; i -= 1) {
      const cluster = this.world.clusters[i];
      if (cluster.isExpired()) {
        this.removeRelayCluster(cluster);
      }
    }

    // 2. Relay-Spawn prüfen
    if (this.world.age < CONFIG.relaySpawnMinAge) return;
    if (this.world.growthStage !== GrowthStages.CONSTELLATION) return;

    if (!this.world.relaySpawnTimer) this.world.relaySpawnTimer = this.rng.range(...CONFIG.relaySpawnInterval);
    this.world.relaySpawnTimer -= dt;

    if (this.world.relaySpawnTimer > 0) return;

    // Reset timer
    this.world.relaySpawnTimer = this.rng.range(...CONFIG.relaySpawnInterval);

    // Bereits aktive Relays zählen
    const activeRelays = this.world.clusters.filter(c => c.isRelay).length;
    if (activeRelays >= CONFIG.relayMaxActive) return;

    // Mindestens 3 Cluster für Relay sinnvoll
    if (this.world.clusters.filter(c => !c.isRelay && c.state !== ClusterStates.DORMANT).length < 3) return;

    // Finde zwei weit entfernte Cluster basierend auf clusterPairActivity
    this.spawnRelayCluster();
  }

  /**
   * Spawnt einen Relay-Cluster zwischen zwei weit entfernten, historisch
   * resonanten Clustern.
   */
  spawnRelayCluster() {
    const candidates = this.world.clusters.filter(c => !c.isRelay && c.state !== ClusterStates.DORMANT);
    if (candidates.length < 2) return;

    // Finde das Paar mit der größten Distanz und (falls verfügbar) höchster
    // historischer Aktivität
    let bestPair = null;
    let bestScore = -1;

    for (let i = 0; i < candidates.length; i++) {
      for (let j = i + 1; j < candidates.length; j++) {
        const a = candidates[i];
        const b = candidates[j];
        const centerA = a.center(this.world.currentTime || 0);
        const centerB = b.center(this.world.currentTime || 0);
        const dist = Math.hypot(centerA.x - centerB.x, centerA.y - centerB.y);

        // Historische Aktivität als Bonus
        const pairKey = `${a.id}-${b.id}`;
        const pairActivity = (this.memory.clusterPairActivity && this.memory.clusterPairActivity[pairKey]) || null;
        const activityBonus = pairActivity ? pairActivity.count * 0.05 : 0;

        const score = dist + activityBonus * 100;
        if (score > bestScore) {
          bestScore = score;
          bestPair = [a, b];
        }
      }
    }

    if (!bestPair) return;
    const [a, b] = bestPair;

    // Relay-Position: Mittelpunkt zwischen den beiden Clustern
    const centerA = a.center(this.world.currentTime || 0);
    const centerB = b.center(this.world.currentTime || 0);
    const midX = (centerA.x + centerB.x) / 2;
    const midY = (centerA.y + centerB.y) / 2;

    // Konvertiere zurück in angle/distance Layout-Koordinaten
    const dx = midX - this.world.centerX;
    const dy = (midY - this.world.centerY) / 0.78;
    const angle = Math.atan2(dy, dx);
    const distance = Math.hypot(dx, dy) / (this.world.minSide * this.world.layoutScale);

    const relayId = `relay-${Math.round(this.world.age)}-${this.world.clusters.length}`;

    // maxClusters für Relay überschreiben (Relay ist temporär)
    const wasMaxClusters = CONFIG.maxClusters;
    if (this.world.clusters.length >= CONFIG.maxClusters) {
      // Nur Relay darf über maxClusters gehen
      this.world._relayOverrideMaxClusters = true;
    }

    const cluster = this.networkBuilder.addCluster({
      id: relayId,
      type: "relay",
      role: "relay",
      state: ClusterStates.ACTIVE,
      angle,
      distance: clamp(distance, 0.15, 0.7),
      initialNodes: 0,
      birthDuration: 8,
      createdAtAge: this.world.age,
      lifespan: CONFIG.relayLifespan
    }, { instant: false, wake: false });

    if (!cluster) return;

    cluster.relayConnectedClusters = [a, b];

    // Bridge-Kanten vom Relay zu beiden Clustern erstellen
    // Finde die am nächsten gelegenen Nodes in den Zielclustern
    const relayCenter = cluster.center(this.world.currentTime || 0);

    for (const targetCluster of [a, b]) {
      let nearestNode = null;
      let nearestDist = Infinity;
      for (const node of targetCluster.nodes) {
        const nodePos = node.position(this.world.currentTime || 0);
        const d = Math.hypot(nodePos.x - relayCenter.x, nodePos.y - relayCenter.y);
        if (d < nearestDist) {
          nearestDist = d;
          nearestNode = node;
        }
      }
      // Relay hat keine eigenen Nodes — wir brauchen einen virtuellen Ankerpunkt.
      // Wir verbinden direkt die zwei nächsten Nodes der beiden Cluster über eine
      // Bridge-Kante, die durch den Relay-Punkt verläuft.
    }

    // Da Relay keine Nodes hat: erstelle eine direkte Bridge zwischen den
    // nächsten Nodes der beiden Cluster, mit erhöhtem Gewicht und markiert
    // als relay-bridged
    let nearestA = null, nearestB = null;
    let minDistA = Infinity, minDistB = Infinity;
    for (const node of a.nodes) {
      const pos = node.position(this.world.currentTime || 0);
      const d = Math.hypot(pos.x - relayCenter.x, pos.y - relayCenter.y);
      if (d < minDistA) { minDistA = d; nearestA = node; }
    }
    for (const node of b.nodes) {
      const pos = node.position(this.world.currentTime || 0);
      const d = Math.hypot(pos.x - relayCenter.x, pos.y - relayCenter.y);
      if (d < minDistB) { minDistB = d; nearestB = node; }
    }

    if (nearestA && nearestB) {
      const relayEdge = this.simulation.addEdge(nearestA, nearestB, {
        bridge: true,
        weight: CLUSTER_TYPES.relay.baseWeight * this.rng.range(0.78, 0.96),
        birthDuration: 6,
        instant: false
      });
      if (relayEdge) {
        relayEdge.isRelayBridge = true;
        relayEdge.relayCluster = cluster;
      }
    }

    // Visueller Effekt beim Spawn
    this.signalSystem.createInjectedWave(relayCenter.x, relayCenter.y, 60, {
      strength: 0.5,
      life: 1.2,
      rgb: CLUSTER_TYPES.relay.rgb
    });

    // Audio-Feedback
    if (this.simulation.audio && this.simulation.audio.enabled) {
      this.simulation.audio.playStageTransition({ type: "relaySpawn" });
    }
  }

  /**
   * Entfernt einen abgelaufenen Relay-Cluster und seine Bridge-Kanten.
   */
  removeRelayCluster(cluster) {
    // Entferne alle Bridge-Kanten, die zu diesem Relay gehören
    const toRemove = this.world.edges.filter(e => e.isRelayBridge && e.relayCluster === cluster);
    for (const edge of toRemove) {
      this.simulation.removeEdge(edge);
    }

    // Cluster aus der Welt entfernen
    const idx = this.world.clusters.indexOf(cluster);
    if (idx >= 0) {
      this.world.clusters.splice(idx, 1);
      this.world.dirty = true;
    }
  }
}
