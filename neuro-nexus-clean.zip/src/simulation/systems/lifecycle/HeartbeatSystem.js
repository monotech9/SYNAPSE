/**
 * HeartbeatSystem — Der Netzwerk-Herzschlag.
 *
 * Nicht regelmäßig. Sondern abhängig vom Zustand.
 *
 * Zustandserkennung:
 *  - CALM:     niedrige Aktivität, reife Netzwerk, wenige Pulse
 *  - STRESS:   hohe Aktivität, viele Brücken, hohe Fatigue
 *  - LEARNING: moderate Aktivität, starkes identityTrace-Wachstum
 *  - UNCERTAIN: fluktuierende Aktivität, viele dorman/forming Cluster
 *
 * Auswirkung auf Rhythmus:
 *  - CALM:     langsame, regelmäßige Pulse (~0.15 Hz), sanft
 *  - STRESS:   schnelle, intensive Pulse (~0.8 Hz), stark
 *  - LEARNING: rhythmische Wellen (~0.4 Hz), kaskadierend
 *  - UNCERTAIN: unregelmäßig, unvorhersehbar
 *
 * Der Herzschlag treibt:
 *  1. Koordinierte Pulse-Wellen vom aktivsten Cluster ausgehend
 *  2. Einen subtilen Hintergrund-Puls (visuelles Atmen des Netzwerks)
 *  3. Modulation der ambient activity timing
 */
import { clamp, lerp } from "../../../utils/math.js";
import { ClusterStates } from "../../clusterRoles.js";

export const HeartbeatState = Object.freeze({
  CALM: "calm",
  STRESS: "stress",
  LEARNING: "learning",
  UNCERTAIN: "uncertain"
});

export class HeartbeatSystem {
  constructor(simulation) {
    this.simulation = simulation;

    // Zustandserkennung — rollierende Durchschnitte
    this._activityHistory = [];
    this._historyMax = 60; // ~60 Sekunden History
    this._lastSampleTime = 0;

    // Aktueller Zustand
    this.state = HeartbeatState.CALM;
    this.stateConfidence = 0; // 0..1, wie sicher wir uns sind
    this._stateTimer = 0;     // Wie lange wir im aktuellen Zustand sind

    // Herzschlag-Timing
    this._beatTimer = 0;
    this._nextBeatInterval = 5.0; // wird basierend auf Zustand gesetzt
    this._beatStrength = 0.3;
    this._irregularNextBeat = 0;  // Für UNCERTAIN: nächste Beat-Zeit kann unregelmäßig sein

    // Visual: Hintergrund-Puls
    this.backgroundPulse = 0; // 0..1, klingt nach jedem Beat ab
    this._bgPulseDecay = 0.4;

    // Telemetrie
    this.beatCount = 0;
    this.lastBeatAge = 0;
  }

  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get pulseEngine() { return this.simulation.pulseEngine; }

  /**
   * Wird jeden Sim-Tick aufgerufen.
   */
  update(dt) {
    // ─── Zustandserkennung ──────────────────────────────────────────
    this._sampleNetworkState(dt);
    this._detectState(dt);

    // ─── Herzschlag ─────────────────────────────────────────────────
    this._beatTimer += dt;
    if (this._beatTimer >= this._nextBeatInterval) {
      this._fireBeat();
      this._beatTimer = 0;
      this._scheduleNextBeat();
    }

    // ─── Hintergrund-Puls Decay ─────────────────────────────────────
    this.backgroundPulse = Math.max(0, this.backgroundPulse - dt * this._bgPulseDecay);
  }

  // ─── Zustandserkennung ─────────────────────────────────────────────

  _sampleNetworkState(dt) {
    this._lastSampleTime += dt;
    if (this._lastSampleTime < 1.0) return; // Sample jede Sekunde
    this._lastSampleTime = 0;

    const world = this.world;
    const clusters = world.clusters;
    if (clusters.length === 0) return;

    // Durchschnittliche Aktivität
    const avgActivity = clusters.reduce((s, c) => s + c.activityMemory, 0) / clusters.length;

    // Volatilität: Varianz der Aktivität über die History
    this._activityHistory.push(avgActivity);
    if (this._activityHistory.length > this._historyMax) this._activityHistory.shift();

    // Fatigue-Durchschnitt
    const avgFatigue = world.edges.length > 0
      ? world.edges.reduce((s, e) => s + (e.fatigueGlow || 0), 0) / world.edges.length
      : 0;

    // Dorman/Forming-Anteil
    const dormantCount = clusters.filter(c => c.state === ClusterStates.DORMANT || c.state === ClusterStates.SEEDLING).length;
    const dormantRatio = dormantCount / clusters.length;

    // Bridge-Aktivität
    const bridgeCount = world.bridgeEdges.length;
    const recentBridges = bridgeCount; // vereinfacht

    // Identity-Trace-Wachstum (indirekt über strongestTrace)
    const traceGrowth = (this.memory?.strongestTrace || 0);

    this._lastSample = {
      avgActivity,
      avgFatigue,
      dormantRatio,
      bridgeCount: recentBridges,
      traceGrowth,
      volatility: this._computeVolatility(),
      age: world.age,
      pulseCount: world.pulses.length
    };
  }

  _computeVolatility() {
    if (this._activityHistory.length < 5) return 0;
    const vals = this._activityHistory;
    const mean = vals.reduce((s, v) => s + v, 0) / vals.length;
    const variance = vals.reduce((s, v) => s + (v - mean) ** 2, 0) / vals.length;
    return clamp(Math.sqrt(variance) * 3, 0, 1);
  }

  _detectState(dt) {
    this._stateTimer += dt;
    if (!this._lastSample) return;

    // Mindestens 5s im aktuellen Zustand bleiben, bevor wir wechseln
    if (this._stateTimer < 5.0) return;

    const s = this._lastSample;
    const scores = {
      [HeartbeatState.CALM]: this._scoreCalm(s),
      [HeartbeatState.STRESS]: this._scoreStress(s),
      [HeartbeatState.LEARNING]: this._scoreLearning(s),
      [HeartbeatState.UNCERTAIN]: this._scoreUncertain(s)
    };

    // Besten Zustand finden
    let bestState = HeartbeatState.CALM;
    let bestScore = scores[HeartbeatState.CALM];
    for (const [state, score] of Object.entries(scores)) {
      if (score > bestScore) {
        bestScore = score;
        bestState = state;
      }
    }

    // Zustand nur wechseln wenn der neue deutlich besser ist (Hysterese)
    if (bestState !== this.state && bestScore > scores[this.state] + 0.15) {
      this.state = bestState;
      this.stateConfidence = bestScore;
      this._stateTimer = 0;
    } else {
      this.stateConfidence = lerp(this.stateConfidence, bestScore, dt * 0.2);
    }
  }

  _scoreCalm(s) {
    let score = 0.5;
    if (s.avgActivity < 0.2) score += 0.3;
    if (s.volatility < 0.15) score += 0.2;
    if (s.age > 120) score += 0.15;
    if (s.pulseCount < 5) score += 0.1;
    if (s.avgFatigue < 0.1) score += 0.1;
    return clamp(score, 0, 1);
  }

  _scoreStress(s) {
    let score = 0.2;
    if (s.avgActivity > 0.45) score += 0.35;
    if (s.avgFatigue > 0.3) score += 0.25;
    if (s.bridgeCount > 0) score += 0.1;
    if (s.pulseCount > 15) score += 0.15;
    if (s.volatility > 0.3) score += 0.1;
    return clamp(score, 0, 1);
  }

  _scoreLearning(s) {
    let score = 0.3;
    if (s.avgActivity > 0.2 && s.avgActivity < 0.5) score += 0.25;
    if (s.traceGrowth > 0.3) score += 0.25;
    if (s.avgFatigue > 0.05 && s.avgFatigue < 0.25) score += 0.15;
    if (s.volatility < 0.25) score += 0.1;
    return clamp(score, 0, 1);
  }

  _scoreUncertain(s) {
    let score = 0.2;
    if (s.dormantRatio > 0.3) score += 0.3;
    if (s.volatility > 0.35) score += 0.25;
    if (s.avgActivity > 0.1 && s.avgActivity < 0.3) score += 0.15;
    if (s.age < 60) score += 0.15;
    return clamp(score, 0, 1);
  }

  // ─── Herzschlag ────────────────────────────────────────────────────

  _scheduleNextBeat() {
    const p = this.personality;
    const baseRhythm = p.rhythm;

    switch (this.state) {
      case HeartbeatState.CALM:
        // Langsam, regelmäßig: 4-7 Sekunden zwischen Beats
        this._nextBeatInterval = lerp(7.0, 4.0, baseRhythm) * (0.9 + this.rng.range(0, 0.2));
        this._beatStrength = 0.25 + baseRhythm * 0.1;
        break;

      case HeartbeatState.STRESS:
        // Schnell, intensiv: 1-2 Sekunden zwischen Beats
        this._nextBeatInterval = lerp(2.0, 1.0, baseRhythm) * (0.85 + this.rng.range(0, 0.3));
        this._beatStrength = 0.5 + p.volatility * 0.2;
        break;

      case HeartbeatState.LEARNING:
        // Rhythmische Wellen: 2-3.5 Sekunden
        this._nextBeatInterval = lerp(3.5, 2.0, baseRhythm) * (0.9 + this.rng.range(0, 0.15));
        this._beatStrength = 0.35 + p.curiosity * 0.15;
        break;

      case HeartbeatState.UNCERTAIN:
        // Unregelmäßig: 1-8 Sekunden, unvorhersehbar
        this._nextBeatInterval = this.rng.range(1.0, 8.0);
        this._beatStrength = 0.2 + this.rng.range(0, 0.3);
        break;
    }
  }

  _fireBeat() {
    this.beatCount++;
    this.lastBeatAge = this.world.age;

    // Hintergrund-Puls auslösen
    this.backgroundPulse = this._beatStrength;

    // Den aktivsten Cluster finden als Beat-Ursprung
    const clusters = this.world.clusters.filter(c => c.state !== ClusterStates.DORMANT && c.birthProgress > 0.5);
    if (clusters.length === 0) return;

    clusters.sort((a, b) => b.activityMemory - a.activityMemory);
    const origin = clusters[0];

    // Beat-Pulse vom Ursprung ausgehend
    const originEdges = this.world.edges.filter(e =>
      e.birthProgress > 0.4 &&
      (e.a.cluster === origin || e.b.cluster === origin) &&
      e.a.cluster.state !== ClusterStates.DORMANT &&
      e.b.cluster.state !== ClusterStates.DORMANT
    );

    if (originEdges.length === 0) return;

    // Je nach Zustand unterschiedliche Pulse-Muster
    const beatPattern = this._getBeatPattern();

    for (const { edge, delay, strength } of beatPattern) {
      // Verzögerte Pulse durch einen Timer simulieren
      // (wir nutzen die Pulse-Geschwindigkeit als Verzögerung)
      const forward = edge.a.cluster === origin;
      this.pulseEngine.spawnPulse(edge, forward, strength, {
        visualOnly: true,
        speedMultiplier: 0.6 + delay * 0.1, // schnellere Pulse für geringere Verzögerung
        preferredPath: true
      });
    }

    // Audio-Feedback für den Herzschlag
    if (this.simulation.audio && this.simulation.audio.enabled) {
      this.simulation.audio.playHeartbeat?.(this._beatStrength, this.state);
    }
  }

  _getBeatPattern() {
    const clusters = this.world.clusters.filter(c => c.state !== ClusterStates.DORMANT && c.birthProgress > 0.5);
    if (clusters.length === 0) return [];

    const origin = clusters.sort((a, b) => b.activityMemory - a.activityMemory)[0];
    const originEdges = this.world.edges.filter(e =>
      e.birthProgress > 0.4 &&
      (e.a.cluster === origin || e.b.cluster === origin)
    ).sort((a, b) => (b.identityTrace || 0) - (a.identityTrace || 0));

    const pattern = [];
    const maxEdges = Math.min(originEdges.length, this.state === HeartbeatState.STRESS ? 5 : 3);

    for (let i = 0; i < maxEdges; i++) {
      const edge = originEdges[i];
      if (!edge) continue;

      switch (this.state) {
        case HeartbeatState.CALM:
          // Ein sanfter Pulse, leicht verzögert
          pattern.push({ edge, delay: i * 0.5, strength: this._beatStrength * 0.8 });
          break;

        case HeartbeatState.STRESS:
          // Mehrere schnelle, starke Pulse
          pattern.push({ edge, delay: i * 0.1, strength: this._beatStrength * (1 - i * 0.1) });
          break;

        case HeartbeatState.LEARNING:
          // Kaskadierende Wave: jeder Edge etwas schwächer und später
          pattern.push({ edge, delay: i * 0.3, strength: this._beatStrength * (1 - i * 0.15) });
          break;

        case HeartbeatState.UNCERTAIN:
          // Unregelmäßig: manche Edges, manche nicht, zufällige Stärke
          if (this.rng.chance(0.6)) {
            pattern.push({ edge, delay: this.rng.range(0, 1), strength: this._beatStrength * this.rng.range(0.5, 1.2) });
          }
          break;
      }
    }

    return pattern;
  }

  /**
   * Gibt einen lesbaren Zustands-Label zurück.
   */
  get stateLabel() {
    const labels = {
      [HeartbeatState.CALM]: "ruhig",
      [HeartbeatState.STRESS]: "erregt",
      [HeartbeatState.LEARNING]: "lernend",
      [HeartbeatState.UNCERTAIN]: "unsicher"
    };
    return labels[this.state] || "ruhig";
  }

  /**
   * Gibt die effektive Herzschlag-Frequenz in BPM zurück.
   */
  get effectiveBPM() {
    if (this._nextBeatInterval <= 0) return 0;
    return Math.round(60 / this._nextBeatInterval);
  }
}
