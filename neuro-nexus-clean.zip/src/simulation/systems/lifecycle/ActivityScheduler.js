import {CONFIG} from "../../../config.js";
import { GrowthStages } from "../../growthStages.js";
import { ClusterRoles, ClusterStates } from "../../clusterRoles.js";
import { recordMemoryEvent } from "../../memory.js";
import { clamp, lerp } from "../../../utils/math.js";

/**
 * ActivityScheduler — periodische Aktivitäts-Subsysteme:
 * ambient activity, preferred-path activity, spontaneous signals.
 *
 * Folgt demselben Pattern wie PulseEngine / NetworkBuilder / etc.:
 * erhält die Simulation im Konstruktor und greift über Getter auf
 * world, rng, personality, memory, … zu.
 */
export class ActivityScheduler {
  constructor(simulation) {
    this.simulation = simulation;
  }

  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }
  get pulseEngine() { return this.simulation.pulseEngine; }
  get signalSystem() { return this.simulation.signalSystem; }

  // ─── Ambient activity ─────────────────────────────────────────────

  updateAmbientActivity(dt) {
    this.world.ambientActivityTimer -= dt;

    if (this.world.ambientActivityTimer > 0) return;

    this.triggerAmbientActivity();

    // After age 60, trigger an extra ambient cycle aimed at a non-genesis cluster
    // to keep secondary clusters visibly active in the second half.
    if (this.world.age > 60 && this.world.clusters.length > 1) {
      const nonGenesis = this.world.clusters.filter((c) => c.role !== "genesis" && c.state !== "dormant" && c.birthProgress > 0.5);
      if (nonGenesis.length > 0) {
        const target = nonGenesis[this.rng.int(0, nonGenesis.length - 1)];
        const targetEdges = this.world.edges.filter((e) => e.birthProgress > 0.34 && (e.a.cluster === target || e.b.cluster === target));
        if (targetEdges.length > 0) {
          const edge = targetEdges[this.rng.int(0, Math.min(3, targetEdges.length - 1))];
          const forward = this.rng.chance(0.5);
          this.pulseEngine.spawnPulse(edge, forward, this.rng.range(0.14, 0.28), { visualOnly: true, support: true });
        }
      }
    }

    const clusterFactor = clamp(this.world.clusters.length / 3, 0, 1);
    const stageFactor = this.world.growthStage === GrowthStages.GENESIS
      ? 1.06
      : this.world.growthStage === GrowthStages.ACTIVATION
        ? 0.92
        : this.world.growthStage === GrowthStages.GROWTH
          ? 0.78
          : this.world.growthStage === GrowthStages.BUDDING
            ? 0.68
            : 0.74;
    this.world.ambientActivityTimer = this.rng.range(CONFIG.ambientSignalMin, CONFIG.ambientSignalMax) * stageFactor * lerp(1.04, 0.78, clusterFactor);
  }

  triggerAmbientActivity() {
    const eligibleEdges = this.world.edges.filter((edge) => {
      if (edge.birthProgress < 0.34) return false;
      if (edge.a.cluster.state === ClusterStates.DORMANT || edge.b.cluster.state === ClusterStates.DORMANT) return false;
      return !edge.bridge || this.world.growthStage === GrowthStages.BUDDING || this.world.growthStage === GrowthStages.NETWORK || this.world.growthStage === GrowthStages.CONSTELLATION;
    });

    if (!eligibleEdges.length) return;

    const stageBurst = this.world.growthStage === GrowthStages.GENESIS
      ? 1
      : this.world.growthStage === GrowthStages.ACTIVATION
        ? 1
        : this.world.growthStage === GrowthStages.GROWTH
          ? this.rng.int(1, 2)
          : 2;
    const densityBurst = this.simulation.totalNodeCount() >= 18 && this.rng.chance(0.35) ? 1 : 0;
    const activeEdges = eligibleEdges.filter((edge) => (edge.activityGlow || edge.visualActivity || 0) > 0.16).length;
    const supportBurst = activeEdges < Math.min(6, Math.max(3, Math.round(eligibleEdges.length * 0.16))) && this.rng.chance(0.42) ? 1 : 0;
    const pulseCount = Math.min(2, stageBurst + densityBurst + supportBurst);

    const candidates = eligibleEdges
      .map((edge) => ({
        edge,
        score: edge.weight * 0.5 + (edge.identityTrace || 0) * 0.9 + edge.a.cluster.activityMemory * 0.25 + (edge.activityGlow || 0) * 0.12 + this.rng.range(0, 0.08)
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, Math.max(4, pulseCount * 3));

    for (let i = 0; i < pulseCount && candidates.length > 0; i += 1) {
      const [candidate] = candidates.splice(0, 1);
      const edge = candidate.edge;
      const forward = this.rng.chance(0.5) ? edge.a.activation >= edge.b.activation : edge.b.activation > edge.a.activation;
      const strength = this.rng.range(0.14, 0.32) + clamp(edge.identityTrace || 0, 0, 1) * 0.1;

      this.pulseEngine.spawnPulse(edge, forward, strength, {
        visualOnly: true,
        support: (edge.identityTrace || 0) < 0.55,
        bridge: edge.bridge,
        speedMultiplier: this.rng.range(0.72, 1.02)
      });
    }
  }

  // ─── Preferred path activity ──────────────────────────────────────

  updatePreferredPathActivity(dt) {
    this.world.pathSignalTimer -= dt;

    if (this.world.pathSignalTimer > 0) return;

    const profile = this.preferredPathActivityProfile();
    this.triggerPreferredPathActivity(profile);

    this.world.pathSignalTimer = this.rng.range(CONFIG.pathSignalMin, CONFIG.pathSignalMax) * profile.intervalMultiplier;
  }

  preferredPathActivityProfile() {
    // Age-aware burst boost: more path signals in the mature phase
    // so activity doesn't visibly quiet after the second cluster forms.
    const ageBurstBoost = this.world.age > 75 ? 1 : 0;

    switch (this.world.growthStage) {
      case GrowthStages.GENESIS:
        return { burst: 1, intervalMultiplier: 1.08, bridgeBurst: 0 };
      case GrowthStages.ACTIVATION:
        return { burst: 2 + ageBurstBoost, intervalMultiplier: 0.94, bridgeBurst: 0 };
      case GrowthStages.GROWTH:
        return { burst: 2 + ageBurstBoost, intervalMultiplier: 0.78, bridgeBurst: 0 };
      case GrowthStages.BUDDING:
        return { burst: 3 + ageBurstBoost, intervalMultiplier: 0.68, bridgeBurst: 1 };
      case GrowthStages.NETWORK:
      case GrowthStages.CONSTELLATION:
        return { burst: 3 + ageBurstBoost, intervalMultiplier: 0.74, bridgeBurst: 1 };
      default:
        return { burst: 2 + ageBurstBoost, intervalMultiplier: 0.9, bridgeBurst: 0 };
    }
  }

  triggerPreferredPathActivity(profile) {
    const candidates = this.world.edges
      .filter((edge) => edge.birthProgress > 0.58 && !edge.bridge && edge.a.cluster.state !== ClusterStates.DORMANT && edge.b.cluster.state !== ClusterStates.DORMANT)
      .map((edge) => ({
        edge,
        score: (edge.identityTrace || 0) * 1.35 + edge.weight * 0.32 + edge.memory * 0.24 + (edge.visualActivity || 0) * 0.08 + this.rng.range(0, 0.045)
      }))
      .sort((a, b) => b.score - a.score);

    if (!candidates.length) return;

    const leading = candidates.slice(0, Math.min(4, candidates.length));
    for (let i = 0; i < profile.burst && i < leading.length; i += 1) {
      const edge = leading[i].edge;
      const forward = i % 2 === 0 ? edge.a.activation >= edge.b.activation : edge.b.activation > edge.a.activation;
      const trace = clamp(edge.identityTrace || 0, 0, 1);
      const strength = 0.22 + trace * 0.18 + this.rng.range(0.02, 0.08);

      this.pulseEngine.spawnPulse(edge, forward, strength, {
        visualOnly: true,
        preferredPath: true,
        speedMultiplier: this.rng.range(0.72, 1.02)
      });
    }

    this.triggerEmergentClusterActivity(profile);
  }

  triggerEmergentClusterActivity(profile) {
    if (!profile.bridgeBurst || this.world.clusters.length < 2) return;

    // After age 60, give all non-genesis clusters their own activity moment,
    // not just the newest one — so the whole network feels busy.
    const sourceClusters = this.world.age > 60
      ? this.world.clusters.filter((c) => c.birthProgress > 0.5 && c.state !== "dormant")
      : [this.world.clusters[this.world.clusters.length - 1]];

    // Extra bridgeBurst after age 60 for more inter-cluster communication.
    const effectiveBridgeBurst = this.world.age > 60 ? profile.bridgeBurst + 1 : profile.bridgeBurst;

    for (const newestCluster of sourceClusters) {
      const clusterEdges = this.world.edges
        .filter((edge) => edge.birthProgress > 0.42 && (edge.a.cluster === newestCluster || edge.b.cluster === newestCluster))
        .map((edge) => ({
          edge,
          score: (edge.bridge ? 0.72 : 0.38) + (edge.identityTrace || 0) * 0.62 + edge.weight * 0.34 + this.rng.range(0, 0.12)
        }))
        .sort((a, b) => b.score - a.score);

      for (let i = 0; i < Math.min(effectiveBridgeBurst + 1, clusterEdges.length); i += 1) {
        const edge = clusterEdges[i].edge;
        const forward = edge.a.cluster === newestCluster ? this.rng.chance(0.62) : !this.rng.chance(0.62);
        this.pulseEngine.spawnPulse(edge, forward, this.rng.range(0.2, 0.38), {
          visualOnly: true,
          support: true,
          bridge: edge.bridge,
          speedMultiplier: edge.bridge ? this.rng.range(0.62, 0.92) : this.rng.range(0.85, 1.18)
        });
      }
    }
  }

  // ─── Spontaneous signals ──────────────────────────────────────────

  updateSpontaneousSignals(dt) {
    this.world.spontaneousTimer -= dt;

    if (this.world.spontaneousTimer > 0) return;

    this.triggerSpontaneousSignal();
    this.world.spontaneousTimer = this.rng.range(CONFIG.spontaneousSignalMin, CONFIG.spontaneousSignalMax) * this.personality.spontaneousIntervalMultiplier;
  }

  triggerSpontaneousSignal() {
    if (this.world.clusters.length === 0) return;

    const activeClusters = this.world.clusters.filter((cluster) => cluster.birthProgress > 0.45 && cluster.state !== ClusterStates.DORMANT);
    if (activeClusters.length === 0) return;

    activeClusters.sort((a, b) => {
      const aScore = a.localActivity * 0.35 + a.bridgeBias * 0.22 + this.rng.range(0, 0.3);
      const bScore = b.localActivity * 0.35 + b.bridgeBias * 0.22 + this.rng.range(0, 0.3);
      return bScore - aScore;
    });

    const cluster = activeClusters[0];
    const matureNodes = cluster.nodes.filter((node) => node.birthProgress > 0.45);
    if (matureNodes.length === 0) return;

    const node = matureNodes[this.rng.int(0, matureNodes.length - 1)];
    const energy = this.rng.range(0.26, 0.56) * this.personality.spontaneousEnergyMultiplier * (cluster.role === ClusterRoles.EXPLORATION ? 1.12 : 1);
    this.diagnosticCounters.spontaneousSignals += 1;

    node.setActivation(Math.max(node.activation, energy));
    node.charge = Math.max(node.charge, energy);
    node.refractory = 0.05;
    node.visualImpact = Math.max(node.visualImpact || 0, 0.72 + energy * 0.5);
    this.signalSystem.reinforceNodeEdges(node, 0.034 + this.personality.volatility * 0.026);
    this.pulseEngine.emitNodePulses(node, 0.18 + energy * 0.22, cluster.role === ClusterRoles.EXPLORATION ? 2 : 1);
    this.pulseEngine.emitNodePulses(node, 0.16 + energy * 0.18, cluster.role === ClusterRoles.EXPLORATION ? 3 : 2, {
      visualOnly: true,
      speedMultiplier: 1.12
    });

    const position = node.position(this.world.currentTime || performance.now() / 1000);

    if (this.world.age > 12 && this.memory.autonomousMoments === 0) {
      recordMemoryEvent(this.memory, "autonomousPulse", this.world.age);
      this.signalSystem.createInjectedWave(position.x, position.y, this.world.minSide * this.rng.range(0.07, 0.105), { strength: 0.72, life: 1.65 });
      return;
    }

    this.signalSystem.createInjectedWave(position.x, position.y, this.world.minSide * this.rng.range(0.026, 0.052), {
      strength: 0.2 + energy * 0.38,
      life: 1.05
    });
  }
}
