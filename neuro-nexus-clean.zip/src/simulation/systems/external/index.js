/**
 * external/index.js — Barrel-Export für externe Systeme
 */

export * from './ExternalStimuli.js';
export * from './MultiAgentHub.js';
export * from './ScarSystem.js';
export * from './RelationshipLayer.js';
export * from './NetworkMoodBridge.js';
