/**
 * NetworkMoodBridge — Network → Spieler Feedback-Kanal
 *
 * Übersetzt die interne Netzwerk-Stimmung (EmotionEngine + RelationshipLayer)
 * in wahrnehmbare UI-Signale für den Spieler:
 *
 *   - Farbpaletten-Shift (warm/kalt je nach attitude_toward_player)
 *   - Intensitäts-Pulsieren (Aktivität → Vitalitäts-Glow)
 *   - Neglect-Warnung (rotes Flackern bei Vernachlässigung)
 *   - Bond-Feedback (visueller Höhepunkt bei Bond-Tier-Aufstieg)
 *   - Akustisches Signal-Objekt (Töne für andere Systeme abrufbar)
 *
 * Die Bridge schreibt NICHT direkt ins DOM — sie pflegt ein
 * `moodFeedback`-Objekt, das der HUD via Snapshot liest.
 *
 * Struktur des moodFeedback-Objekts:
 * {
 *   colorShift:   { r, g, b }     // Additive RGB-Tint (-1 bis +1 pro Kanal)
 *   warmth:       number          // 0 (kalt/grau) bis 1 (warm/golden)
 *   pulseIntensity: number        // 0–1 — Glow-Stärke
 *   neglectFlicker: number        // 0–1 — rotes Flackern
 *   bondGlow:     number          // 0–1 — spezieller Glow bei Bond-Event (faded aus)
 *   audioHint:    string|null     // "hum_happy"|"hum_sad"|"hum_neutral"|"bond_chime"|null
 *   attitude:     number          // -1 bis +1 (Rohwert für CSS-Variablen)
 * }
 *
 * Events (in):
 *   "relationship:change"   — Haltung ändert sich → colorShift update
 *   "relationship:neglect"  — Vernachlässigung → neglectFlicker aktivieren
 *   "relationship:bond"     — Bond-Aufstieg → bondGlow aktivieren
 *   "emotion:state"         — Periodischer Zustand → pulseIntensity
 *   "scar:created"          — Narbe → kurzes rotes Flackern
 *
 * Events (out):
 *   "mood:feedback"         — moodFeedback-Objekt aktualisiert (für HUD)
 */

import { clamp, lerp } from "../../../utils/math.js";

const BOND_GLOW_DURATION    = 8.0;   // Sekunden
const NEGLECT_FLICKER_DECAY = 0.5;   // pro Sekunde
const SCAR_FLICKER_DURATION = 3.0;   // Sekunden

export class NetworkMoodBridge {
  /**
   * @param {NeuroSimulation} simulation
   */
  constructor(simulation) {
    this.sim    = simulation;
    this.events = simulation.events;

    this.moodFeedback = {
      colorShift:     { r: 0, g: 0, b: 0 },
      warmth:         0.5,
      pulseIntensity: 0.3,
      neglectFlicker: 0,
      bondGlow:       0,
      seekingGlow:    null,   // { clusterId, intensity, type } wenn Eigeninitiative aktiv
      spontaneityState: "idle",
      audioHint:      null,
      attitude:       0,
    };

    // Interne Timer
    this._bondGlowTimer    = 0;
    this._scarFlickerTimer = 0;
    this._prevAttitude     = 0;
    this._prevAudioHint    = null;

    // EventBus subscriptions
    this._unsubs = [
      this.events.on("relationship:change",  (d) => this._onRelationshipChange(d)),
      this.events.on("relationship:neglect",  (d) => this._onNeglect(d)),
      this.events.on("relationship:bond",     (d) => this._onBond(d)),
      this.events.on("emotion:state",         (d) => this._onEmotionState(d)),
      this.events.on("scar:created",          ()  => this._onScar()),
    ];
  }

  // ─── Update ─────────────────────────────────────────────────────

  update(dt) {
    // Bond-Glow ausfaden
    if (this._bondGlowTimer > 0) {
      this._bondGlowTimer = Math.max(0, this._bondGlowTimer - dt);
      this.moodFeedback.bondGlow = this._bondGlowTimer / BOND_GLOW_DURATION;
    }

    // Scar-Flicker ausfaden
    if (this._scarFlickerTimer > 0) {
      this._scarFlickerTimer = Math.max(0, this._scarFlickerTimer - dt);
      const flickerPulse = Math.sin(this._scarFlickerTimer * 8) * 0.5 + 0.5;
      this.moodFeedback.neglectFlicker = Math.max(
        this.moodFeedback.neglectFlicker,
        (this._scarFlickerTimer / SCAR_FLICKER_DURATION) * flickerPulse
      );
    }

    // Neglect-Flicker langsam ausblenden wenn kein aktives neglect
    if (this._scarFlickerTimer <= 0) {
      this.moodFeedback.neglectFlicker = Math.max(
        0,
        this.moodFeedback.neglectFlicker - NEGLECT_FLICKER_DECAY * dt
      );
    }

    // audioHint nach einem Tick zurücksetzen (einmalige Signale)
    if (this.moodFeedback.audioHint && this.moodFeedback.audioHint !== this._prevAudioHint) {
      this._prevAudioHint = this.moodFeedback.audioHint;
    } else if (this.moodFeedback.audioHint === this._prevAudioHint) {
      this.moodFeedback.audioHint = null;
    }

    // SpontaneityEngine-Status übernehmen
    const sp = this.sim.spontaneityEngine;
    if (sp) {
      this.moodFeedback.seekingGlow    = sp.seekingGlow;
      this.moodFeedback.spontaneityState = sp.state;

      // Seeking → leichte Farbverschiebung (blau-cyan: Neugier)
      if (sp.state === "seeking" || sp.state === "acting") {
        this.moodFeedback.colorShift.b += 0.03;
        if (sp.state === "acting") this.moodFeedback.pulseIntensity = Math.min(0.9, this.moodFeedback.pulseIntensity + 0.2);
      }
    }

    // Periodisch feedback emittieren (alle 0.5s genug)
    this.events.emit("mood:feedback", { ...this.moodFeedback });
  }

  // ─── Event-Handler ───────────────────────────────────────────────

  _onRelationshipChange(d) {
    const attitude = d.attitude_toward_player ?? 0;
    this.moodFeedback.attitude = attitude;

    // Warmth: 0 (kalt, attitude=-1) bis 1 (warm, attitude=+1)
    this.moodFeedback.warmth = clamp((attitude + 1) / 2, 0, 1);

    // ColorShift:
    //   Positiv (warm) → leicht golden (+r, +g)
    //   Negativ (scheu/fremdelt) → leicht grau/kalt (-r, -g, leicht +b)
    //   Neutral → kein Shift
    if (attitude >= 0) {
      this.moodFeedback.colorShift = {
        r:  attitude * 0.08,
        g:  attitude * 0.04,
        b: -attitude * 0.02,
      };
    } else {
      const abs = Math.abs(attitude);
      this.moodFeedback.colorShift = {
        r: -abs * 0.06,
        g: -abs * 0.06,
        b:  abs * 0.04,
      };
    }

    // Audio-Hint bei signifikanter Haltungsänderung
    const delta = Math.abs(attitude - this._prevAttitude);
    if (delta > 0.15) {
      if (attitude > 0.4)       this.moodFeedback.audioHint = "hum_happy";
      else if (attitude < -0.3) this.moodFeedback.audioHint = "hum_sad";
      else                      this.moodFeedback.audioHint = "hum_neutral";
      this._prevAttitude = attitude;
    }
  }

  _onNeglect(d) {
    // Vernachlässigung → roter Flicker proportional zum Level
    this.moodFeedback.neglectFlicker = Math.max(
      this.moodFeedback.neglectFlicker,
      d.level || 0.6
    );
    this.moodFeedback.audioHint = "hum_sad";
  }

  _onBond(d) {
    // Bond-Aufstieg → goldener Glow
    this._bondGlowTimer = BOND_GLOW_DURATION;
    this.moodFeedback.bondGlow = 1.0;
    this.moodFeedback.audioHint = "bond_chime";
  }

  _onEmotionState(d) {
    // Pulse-Intensität aus dominanter Emotion ableiten
    const arousal = d?.arousal ?? 0.3;
    const valence = d?.valence ?? 0;

    // Hohe Erregung → stärkeres Pulsieren
    this.moodFeedback.pulseIntensity = clamp(0.2 + arousal * 0.6, 0.1, 0.9);

    // Sehr negativer Zustand → colorShift leicht röter
    if (valence < -0.5) {
      this.moodFeedback.colorShift.r += 0.04;
    }
  }

  _onScar() {
    // Scar → kurzes rotes Flackern
    this._scarFlickerTimer = SCAR_FLICKER_DURATION;
    this.moodFeedback.audioHint = "hum_sad";
  }

  // ─── Snapshot ───────────────────────────────────────────────────

  getSnapshot() {
    return { ...this.moodFeedback };
  }

  destroy() {
    this._unsubs.forEach(fn => fn?.());
    this._unsubs = [];
  }
}
