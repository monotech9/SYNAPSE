/**
 * ExternalStimuli — Environment Layer: Externe Reize (GDD §9)
 *
 * Generiert Umwelt-Signale die auf das Netzwerk einwirken.
 * Quellen:
 *  - Ambient noise (zufällige schwache Signale)
 *  - Periodic pulses (rhythmische Reize)
 *  - Burst events (plötzliche starke Reize)
 *  - Silence phases (Ruhe, keine Reize)
 *
 * Die Reize werden über den EventBus als "environment:stimulus"
 * events emitiert und vom SignalSystem/GlobalWorkspace konsumiert.
 *
 * Events (out):
 *  - "environment:stimulus" — { type, intensity, x, y, duration }
 *  - "environment:silence"  — { duration }
 */

const AMBIENT_INTERVAL = [8, 20];    // Sekunden zwischen Ambient-Reizen
const PERIODIC_INTERVAL = [15, 35];  // Sekunden zwischen periodischen Reizen
const BURST_INTERVAL = [45, 120];    // Sekunden zwischen Burst-Events
const SILENCE_CHANCE = 0.15;         // 15% Chance auf Ruhe-Phase

export class ExternalStimuli {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;
    this.rng = simulation.rng;

    this._ambientTimer = 0;
    this._periodicTimer = 0;
    this._burstTimer = 0;
    this._nextAmbient = this.rng.range(...AMBIENT_INTERVAL);
    this._nextPeriodic = this.rng.range(...PERIODIC_INTERVAL);
    this._nextBurst = this.rng.range(...BURST_INTERVAL);

    this._stimulusCount = 0;
    this._silenceCount = 0;
  }

  update(dt) {
    if (this.sim.world.age < 10) return; // Erste 10s: keine externen Reize

    this._ambientTimer += dt;
    this._periodicTimer += dt;
    this._burstTimer += dt;

    // Ambient: schwache, zufällige Signale
    if (this._ambientTimer >= this._nextAmbient) {
      this._ambientTimer = 0;
      this._nextAmbient = this.rng.range(...AMBIENT_INTERVAL);

      if (this.rng.chance(SILENCE_CHANCE)) {
        this._silenceCount++;
        this.events.emit("environment:silence", {
          duration: this.rng.range(5, 15)
        });
      } else {
        this._emitStimulus("ambient", this.rng.range(0.1, 0.25));
      }
    }

    // Periodic: rhythmische, moderate Reize
    if (this._periodicTimer >= this._nextPeriodic) {
      this._periodicTimer = 0;
      this._nextPeriodic = this.rng.range(...PERIODIC_INTERVAL);
      this._emitStimulus("periodic", this.rng.range(0.2, 0.4));
    }

    // Burst: seltene, starke Reize
    if (this._burstTimer >= this._nextBurst) {
      this._burstTimer = 0;
      this._nextBurst = this.rng.range(...BURST_INTERVAL);
      this._emitStimulus("burst", this.rng.range(0.4, 0.7));
    }
  }

  _emitStimulus(type, intensity) {
    // Position: zufällig am Rand des Netzwerks
    const angle = this.rng.range(0, Math.PI * 2);
    const dist = this.sim.world.minSide * 0.4;
    const x = this.sim.world.centerX + Math.cos(angle) * dist;
    const y = this.sim.world.centerY + Math.sin(angle) * dist;

    this._stimulusCount++;

    this.events.emit("environment:stimulus", {
      type,
      intensity,
      x, y,
      duration: type === "burst" ? 2.0 : type === "periodic" ? 1.0 : 0.5
    });

    // Auch als Signal in das Netzwerk injizieren
    if (this.sim.signalSystem) {
      this.sim.signalSystem.injectSignal(x, y);
    }
  }

  getSnapshot() {
    return {
      stimulusCount: this._stimulusCount,
      silenceCount: this._silenceCount
    };
  }

  serialize() {
    return {
      stimulusCount: this._stimulusCount,
      silenceCount: this._silenceCount
    };
  }

  reset() {
    this._ambientTimer = 0;
    this._periodicTimer = 0;
    this._burstTimer = 0;
    this._stimulusCount = 0;
    this._silenceCount = 0;
  }

  destroy() {}
}
