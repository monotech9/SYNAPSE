/**
 * RelationshipLayer — Emotionale Bindung zwischen Spielerin und Netzwerk
 *
 * Implementiert das Relationship-Modell aus dem Executive Summary:
 *  - Mehrdimensionale Kennwerte: affinity, trust, curiosity, familiarity
 *  - Beeinflussung durch Spieler-Aktionen (update via Game-Loop)
 *  - Beeinflussung durch Netzwerk-Events (Emotion, Emergenz, Schlaf)
 *  - Zeitbasierter Decay bei Inaktivität (Vernachlässigungs-Mechanik)
 *  - Berechnet attitude_toward_player (→ Network→Player Feedback)
 *
 * Dimensionen:
 *   affinity     (0–100)  Allgemeine Bindungsstärke; wächst durch positive Interaktion
 *   trust        (0–100)  Vertrauen; wächst langsam, fällt schnell bei Schaden
 *   curiosity    (0–100)  Neugier auf den Spieler; sinkt bei Wiederholung
 *   familiarity  (0–100)  Wie vertraut das Netzwerk mit dem Spieler ist; wächst mit Zeit
 *
 * Abgeleitete Werte:
 *   attitude_toward_player  (-1 bis +1) — für UI-Feedback (Farbe, Klang)
 *   neglectLevel            (0–1)       — wie lange keine Interaktion
 *   bondStrength            (0–1)       — normalisierte Gesamtbindung
 *
 * Events (in):
 *   "signal:injected"      — Spieler hat Signal gesetzt → +affinity, +curiosity, -familiarity decay reset
 *   "scar:created"         — Verletzung → -trust, -affinity (leicht)
 *   "emotion:spike"        — Emotion-Spike → ±affinity je nach Valenz
 *   "emergence:moment"     — Emergenz-Moment → +affinity, +trust (Staunen)
 *   "sleep:wakeUp"         — Netzwerk wacht auf → familiarity nudge
 *   "reward:positive"      — Positiver Reward → +trust
 *   "reward:negative"      — Negativer Reward → -trust (leicht)
 *
 * Events (out):
 *   "relationship:change"  — Kennwerte haben sich signifikant verändert { affinity, trust, curiosity, familiarity, attitude }
 *   "relationship:neglect" — Vernachlässigung erreicht Schwellwert { level, since }
 *   "relationship:bond"    — Bond-Stärke überschreitet neues Niveau { strength, tier }
 */

import { clamp, lerp } from "../../../utils/math.js";

// ─── Konfiguration ────────────────────────────────────────────────────

const DECAY_INTERVAL      = 30;    // Sekunden Inaktivität bis Decay beginnt
const AFFINITY_DECAY_RATE = 0.004; // pro Sekunde nach Decay-Interval
const TRUST_DECAY_RATE    = 0.002; // trust fällt langsamer
const CURIOSITY_DECAY_RATE= 0.008; // curiosity fällt schneller (Gewöhnung)

const SIGNAL_AFFINITY_GAIN   = 2.5;
const SIGNAL_CURIOSITY_GAIN  = 1.8;
const SIGNAL_FAMILIARITY_GAIN= 0.6;
const SIGNAL_TRUST_GAIN      = 0.4;

const SCAR_TRUST_LOSS        = 6.0;
const SCAR_AFFINITY_LOSS     = 2.0;
const EMERGENCE_AFFINITY_GAIN= 8.0;
const EMERGENCE_TRUST_GAIN   = 4.0;
const REWARD_TRUST_GAIN      = 1.2;
const REWARD_TRUST_LOSS      = 0.8;

const NEGLECT_THRESHOLD      = 0.6;  // neglectLevel ab dem Event gefeuert wird
const BOND_TIERS             = [0.25, 0.5, 0.75, 0.9]; // bondStrength-Schwellen

// ─── RelationshipLayer ───────────────────────────────────────────────

export class RelationshipLayer {
  /**
   * @param {NeuroSimulation} simulation
   */
  constructor(simulation) {
    this.sim    = simulation;
    this.events = simulation.events;

    // ── Kern-Kennwerte (0–100) ──
    this.affinity    = 20;  // Startwert: neutral-positiv
    this.trust       = 50;  // Startwert: neutral
    this.curiosity   = 60;  // Startwert: Netzwerk ist neugierig auf alles Neue
    this.familiarity = 0;   // Startwert: unbekannt

    // ── Abgeleitete Werte ──
    this.attitude_toward_player = 0;  // -1 bis +1
    this.neglectLevel           = 0;  // 0–1
    this.bondStrength           = 0;  // 0–1
    this._bondTier              = 0;  // aktuell erreichtes Tier (0–4)

    // ── Interne Zustandsverfolgung ──
    this._lastInteractionAge = 0;
    this._prevAffinity       = 20;
    this._prevTrust          = 50;
    this._signalCount        = 0;   // Gesamtzahl Spieler-Signale (für Familiarity)

    // ── Personality-Bias ──
    // attachment → erhöht affinity-Startgeschwindigkeit
    // sensitivity → curiosity empfindlicher auf Events
    const p = simulation.personality;
    this._attachmentBias  = p ? (p.attachment  || 0.5) : 0.5;
    this._sensitivityBias = p ? (p.sensitivity || 0.5) : 0.5;

    // ── Persistierter Zustand laden (falls vorhanden) ──
    const stored = simulation.persistentState?.relationship;
    if (stored) this.deserialize(stored);

    // ── EventBus-Subscriptions ──
    this._unsubs = [
      this.events.on("signal:injected",  (d) => this._onSignal(d)),
      this.events.on("scar:created",     (d) => this._onScar(d)),
      this.events.on("emotion:spike",    (d) => this._onEmotionSpike(d)),
      this.events.on("emergence:moment", (d) => this._onEmergence(d)),
      this.events.on("sleep:wakeUp",     ()  => this._onWakeUp()),
      this.events.on("reward:positive",  (d) => this._onRewardPositive(d)),
      this.events.on("reward:negative",  (d) => this._onRewardNegative(d)),
    ];
  }

  // ─── Update (wird vom UpdateLoop mit dt aufgerufen) ──────────────

  /**
   * @param {number} dt  Delta-Zeit in Sekunden
   */
  update(dt) {
    const age = this.sim.world?.age || 0;

    // Inaktivitäts-Decay
    const idleTime = age - this._lastInteractionAge;
    if (idleTime > DECAY_INTERVAL) {
      const excess = idleTime - DECAY_INTERVAL;
      const decayFactor = Math.min(1, excess / 120); // voller Decay nach 2 Min

      this.affinity  = Math.max(5,  this.affinity  - AFFINITY_DECAY_RATE  * dt * decayFactor * 100);
      this.trust     = Math.max(10, this.trust     - TRUST_DECAY_RATE     * dt * decayFactor * 100);
      this.curiosity = Math.max(0,  this.curiosity - CURIOSITY_DECAY_RATE * dt * decayFactor * 100);
    }

    // familiarity wächst kontinuierlich mit Zeit (sehr langsam)
    this.familiarity = Math.min(100, this.familiarity + 0.01 * dt);

    // Neglect berechnen
    const prevNeglect = this.neglectLevel;
    this.neglectLevel = clamp((idleTime - DECAY_INTERVAL) / 180, 0, 1);

    if (this.neglectLevel >= NEGLECT_THRESHOLD && prevNeglect < NEGLECT_THRESHOLD) {
      this.events.emit("relationship:neglect", {
        level: this.neglectLevel,
        since: this._lastInteractionAge
      });
    }

    // Abgeleitete Werte neu berechnen
    this._recalcDerived();

    // Signifikante Änderung → Event
    const affinityDelta = Math.abs(this.affinity - this._prevAffinity);
    const trustDelta    = Math.abs(this.trust    - this._prevTrust);
    if (affinityDelta > 1.5 || trustDelta > 1.5) {
      this._emitChange();
      this._prevAffinity = this.affinity;
      this._prevTrust    = this.trust;
    }
  }

  // ─── Spieler-Aktion API ─────────────────────────────────────────

  /**
   * Wird vom Game-Loop bei jeder Spieler-Interaktion aufgerufen.
   * Kann direkt von InteractionHandler genutzt werden.
   *
   * @param {"signal"|"bridge"|"addNode"|"prune"} actionType
   * @param {object} context  Optionaler Kontext (Position, Intensität etc.)
   */
  onPlayerAction(actionType, context = {}) {
    const age = this.sim.world?.age || 0;
    this._lastInteractionAge = age;
    this.neglectLevel = 0;
    this._signalCount++;

    switch (actionType) {
      case "signal": {
        const intensity = context.intensity || 1.0;
        this.affinity    = Math.min(100, this.affinity    + SIGNAL_AFFINITY_GAIN   * intensity * (1 + this._attachmentBias * 0.5));
        this.curiosity   = Math.min(100, this.curiosity   + SIGNAL_CURIOSITY_GAIN  * intensity * (1 + this._sensitivityBias * 0.4));
        this.familiarity = Math.min(100, this.familiarity + SIGNAL_FAMILIARITY_GAIN);
        this.trust       = Math.min(100, this.trust       + SIGNAL_TRUST_GAIN * intensity);
        break;
      }
      case "bridge":
        this.affinity    = Math.min(100, this.affinity    + 3.5);
        this.trust       = Math.min(100, this.trust       + 1.8);
        this.familiarity = Math.min(100, this.familiarity + 1.0);
        break;
      case "addNode":
        this.affinity    = Math.min(100, this.affinity    + 2.0);
        this.curiosity   = Math.min(100, this.curiosity   + 3.0);
        this.familiarity = Math.min(100, this.familiarity + 0.8);
        break;
      case "prune":
        // Pruning senkt Trust leicht — Netzwerk mag Verluste nicht
        this.trust    = Math.max(0, this.trust    - 2.5);
        this.affinity = Math.max(0, this.affinity - 0.5);
        break;
    }

    this._recalcDerived();
    this._emitChange();
  }

  // ─── EventBus-Handler ───────────────────────────────────────────

  _onSignal(d) {
    // signal:injected kommt vom SignalSystem — leichtere Version
    const age = this.sim.world?.age || 0;
    this._lastInteractionAge = age;
    this.neglectLevel = 0;
    this.affinity  = Math.min(100, this.affinity  + 1.2);
    this.curiosity = Math.min(100, this.curiosity + 0.8);
    this._recalcDerived();
  }

  _onScar(_d) {
    this.trust    = Math.max(0, this.trust    - SCAR_TRUST_LOSS);
    this.affinity = Math.max(0, this.affinity - SCAR_AFFINITY_LOSS);
    this._recalcDerived();
    this._emitChange();
  }

  _onEmotionSpike(d) {
    // Positive Emotionen (joy, curiosity, awe) → +affinity
    // Negative (fear, sadness, anger) → -affinity, -trust
    const valence = d?.valence ?? 0;
    const intensity = d?.intensity ?? 0.5;
    const gain = valence * intensity * 3.0 * (1 + this._sensitivityBias * 0.4);
    this.affinity = clamp(this.affinity + gain, 0, 100);
    if (valence < -0.3) {
      this.trust = Math.max(0, this.trust - Math.abs(gain) * 0.5);
    }
    this._recalcDerived();
  }

  _onEmergence(_d) {
    // Emergenz-Momente sind beeindruckend → starker affinity + trust Boost
    this.affinity = Math.min(100, this.affinity + EMERGENCE_AFFINITY_GAIN);
    this.trust    = Math.min(100, this.trust    + EMERGENCE_TRUST_GAIN);
    this._recalcDerived();
    this._emitChange();
  }

  _onWakeUp() {
    // Nach Schlaf ist das Netzwerk frischer → curiosity erholt sich leicht
    this.curiosity = Math.min(100, this.curiosity + 5.0);
    this._recalcDerived();
  }

  _onRewardPositive(d) {
    const delta = Math.min(1, d?.delta || 0.3);
    this.trust = Math.min(100, this.trust + REWARD_TRUST_GAIN * delta * 10);
    this._recalcDerived();
  }

  _onRewardNegative(d) {
    const delta = Math.abs(Math.max(-1, d?.delta || -0.2));
    this.trust = Math.max(0, this.trust - REWARD_TRUST_LOSS * delta * 10);
    this._recalcDerived();
  }

  // ─── Berechnungen ───────────────────────────────────────────────

  /**
   * Berechnet attitude_toward_player und bondStrength neu.
   * attitude_toward_player: -1 (feindlich/scheu) bis +1 (warm/offen)
   */
  _recalcDerived() {
    // Gewichtete Kombination:
    //   trust ist am wichtigsten für Haltung
    //   affinity gibt die emotionale Wärme
    //   familiarity dämpft Extrema
    const tNorm  = this.trust      / 100;
    const aNorm  = this.affinity   / 100;
    const fNorm  = this.familiarity / 100;
    const cNorm  = this.curiosity  / 100;

    this.attitude_toward_player = clamp(
      (tNorm * 0.45 + aNorm * 0.35 + cNorm * 0.10 + fNorm * 0.10) * 2 - 1,
      -1, 1
    );

    this.bondStrength = clamp(
      (aNorm * 0.4 + tNorm * 0.35 + fNorm * 0.15 + cNorm * 0.10),
      0, 1
    );

    // Bond-Tier prüfen
    for (let i = BOND_TIERS.length - 1; i >= 0; i--) {
      if (this.bondStrength >= BOND_TIERS[i] && this._bondTier <= i) {
        this._bondTier = i + 1;
        this.events.emit("relationship:bond", {
          strength: this.bondStrength,
          tier: this._bondTier
        });
        break;
      }
    }
  }

  _emitChange() {
    this.events.emit("relationship:change", {
      affinity:               Math.round(this.affinity),
      trust:                  Math.round(this.trust),
      curiosity:              Math.round(this.curiosity),
      familiarity:            Math.round(this.familiarity),
      attitude_toward_player: Math.round(this.attitude_toward_player * 100) / 100,
      bondStrength:           Math.round(this.bondStrength * 100) / 100,
      neglectLevel:           Math.round(this.neglectLevel * 100) / 100,
    });
  }

  // ─── Serialisierung ─────────────────────────────────────────────

  getSnapshot() {
    return {
      affinity:               this.affinity,
      trust:                  this.trust,
      curiosity:              this.curiosity,
      familiarity:            this.familiarity,
      attitude_toward_player: this.attitude_toward_player,
      neglectLevel:           this.neglectLevel,
      bondStrength:           this.bondStrength,
      bondTier:               this._bondTier,
      signalCount:            this._signalCount,
    };
  }

  serialize() {
    return {
      affinity:             this.affinity,
      trust:                this.trust,
      curiosity:            this.curiosity,
      familiarity:          this.familiarity,
      lastInteractionAge:   this._lastInteractionAge,
      bondTier:             this._bondTier,
      signalCount:          this._signalCount,
    };
  }

  deserialize(data) {
    if (!data) return;
    this.affinity             = data.affinity            ?? 20;
    this.trust                = data.trust               ?? 50;
    this.curiosity            = data.curiosity           ?? 60;
    this.familiarity          = data.familiarity         ?? 0;
    this._lastInteractionAge  = data.lastInteractionAge  ?? 0;
    this._bondTier            = data.bondTier            ?? 0;
    this._signalCount         = data.signalCount         ?? 0;
    this._recalcDerived();
  }

  destroy() {
    this._unsubs.forEach(fn => fn?.());
    this._unsubs = [];
  }
}
