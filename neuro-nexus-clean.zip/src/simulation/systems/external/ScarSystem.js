/**
 * ScarSystem — Sichtbare Erinnerungen des Netzwerks.
 *
 * Wenn eine Kante entfernt wird, hinterlässt sie eine Narbe.
 * Narben sind extrem schwache Schatten ehemaliger Verbindungen.
 * Wie Fossilien oder Narben auf der Haut.
 *
 * Eigenschaften:
 *  - Sehr schwach sichtbar (alpha ~0.02-0.05)
 *  - Verblasen sehr langsam (über 20+ Minuten)
 *  - Gelegentlich "echot" eine Narbe — ein kurzer, geisterhafter Pulse
 *    auf dem alten Pfad, als würde sich das Netzwerk an etwas erinnern
 *  - Narben speichern: Position, ehemalige Stärke, Cluster-Typ, Alter
 *
 * Das macht die Simulation emotionaler:
 *  "Hier war früher einmal viel Aktivität."
 */
import { recordMemoryEvent } from "../../memory.js";

const MAX_SCARS = 60;

export class ScarSystem {
  constructor(simulation) {
    this.simulation = simulation;
    this.scars = [];
    this._echoTimer = 0;
    this._nextEchoInterval = 30; // alle 30-60s ein Echo
  }

  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get memory() { return this.simulation.memory; }

  /**
   * Wird aufgerufen, wenn eine Kante entfernt wird.
   * Erstellt eine Narbe an der Position der ehemaligen Verbindung.
   */
  recordScar(edge) {
    if (this.scars.length >= MAX_SCARS) {
      // Älteste Narbe entfernen
      this.scars.shift();
    }

    const time = this.world.currentTime || 0;
    const aPos = edge.a.position(time);
    const bPos = edge.b.position(time);

    // Die Narbe speichert die Position relativ zum Welt-Zentrum,
    // da Nodes sich bewegen und nicht mehr existieren müssen.
    const clusterA = edge.a.cluster;
    const clusterB = edge.b.cluster;

    this.scars.push({
      id: `scar-${this.scars.length}-${Math.round(this.world.age)}`,
      // Absolute Position zum Zeitpunkt der Narbenbildung
      ax: aPos.x, ay: aPos.y,
      bx: bPos.x, by: bPos.y,
      // Ehemalige Stärke
      formerWeight: edge.peakWeight || edge.weight,
      formerTrace: edge.peakTrace || edge.identityTrace || 0,
      formerMemory: edge.peakMemory || edge.memory,
      // Cluster-Info für Farbe
      typeA: clusterA?.type || "exploration",
      typeB: clusterB?.type || "exploration",
      // Timing
      bornAtAge: this.world.age,
      // Verblaschen
      opacity: 1.0,
      // Echo
      echoGlow: 0
    });

    recordMemoryEvent(this.memory, "scar", this.world.age);
    this.simulation.events.emit("scar:created", { x: this.world.centerX, y: this.world.centerY });
  }

  /**
   * Wird jeden Sim-Tick aufgerufen.
   */
  update(dt) {
    // Narben verblaschen lassen — sehr langsam
    const fadeRate = 0.0008; // ~20 Minuten bis vollständig verschwunden
    for (let i = this.scars.length - 1; i >= 0; i--) {
      const scar = this.scars[i];
      scar.opacity = Math.max(0, scar.opacity - dt * fadeRate);

      // Echo-Glow abklingen lassen
      scar.echoGlow = Math.max(0, scar.echoGlow - dt * 0.5);

      // Vollständig verschwundene Narben entfernen
      if (scar.opacity <= 0.001 && scar.echoGlow <= 0.001) {
        this.scars.splice(i, 1);
      }
    }

    // Echo: gelegentlich eine Narbe aufleuchten lassen
    this._echoTimer += dt;
    if (this._echoTimer >= this._nextEchoInterval) {
      this._triggerEcho();
      this._echoTimer = 0;
      this._nextEchoInterval = this.rng.range(30, 60);
    }
  }

  /**
   * Lässt eine zufällige Narbe kurz aufleuchten — ein geisterhafter Pulse.
   * Wahrscheinlichkeit ist höher für Narben mit hoher ehemaliger Stärke
   * und solchen, die schon lange schlafen.
   */
  _triggerEcho() {
    if (this.scars.length === 0) return;
    if (this.world.age < 60) return; // Erst nach 60s

    // Gewichtete Auswahl: starke alte Narben bevorzugen
    const candidates = this.scars
      .filter(s => s.opacity > 0.1)
      .map(s => ({
        scar: s,
        weight: s.formerTrace * 0.5 + s.formerWeight * 0.3 + (this.world.age - s.bornAtAge) * 0.001
      }))
      .sort((a, b) => b.weight - a.weight);

    if (candidates.length === 0) return;

    // Aus den Top 30% eine zufällige wählen
    const topCount = Math.max(1, Math.floor(candidates.length * 0.3));
    const chosen = candidates[this.rng.int(0, topCount - 1)].scar;

    chosen.echoGlow = 0.6 + chosen.formerTrace * 0.3;

    // Audio: sehr leises Echo
    if (this.simulation.audio && this.simulation.audio.enabled) {
      this.simulation.audio.playScarEcho?.(chosen);
    }
  }

  /**
   * Gibt die Anzahl aktiver Narben zurück.
   */
  get count() {
    return this.scars.length;
  }

  /**
   * Serialisiert die Narben für den Save-State.
   */
  serialize() {
    return this.scars.map(s => ({
      id: s.id,
      ax: s.ax, ay: s.ay, bx: s.bx, by: s.by,
      fw: s.formerWeight, ft: s.formerTrace, fm: s.formerMemory,
      tA: s.typeA, tB: s.typeB,
      ba: s.bornAtAge,
      o: s.opacity
    }));
  }

  /**
   * Deserialisiert Narben aus einem Save-State.
   */
  deserialize(data) {
    if (!Array.isArray(data)) return;
    this.scars = data.map(s => ({
      id: s.id || `scar-restored`,
      ax: s.ax, ay: s.ay, bx: s.bx, by: s.by,
      formerWeight: s.fw || 0.3,
      formerTrace: s.ft || 0,
      formerMemory: s.fm || 0,
      typeA: s.tA || "exploration",
      typeB: s.tB || "exploration",
      bornAtAge: s.ba || 0,
      opacity: s.o || 0.5,
      echoGlow: 0
    })).slice(0, MAX_SCARS);
  }
}
