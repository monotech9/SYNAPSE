/**
 * MultiAgentHub — Environment Layer: Multi-Agent Interface (GDD §9)
 *
 * Stub für zukünftige Multi-Agent-Interaktion.
 * In der aktuellen Single-Agent-Simulation ist dies ein Platzhalter,
 * der die Architektur für künftige Erweiterung vorbereitet.
 *
 * Geplante Funktion (zukünftig):
 *  - Andere digitale Entitäten senden Signale ins Netzwerk
 *  - "Fremde" Narben oder Muster können auftauchen
 *  - Netzwerk kann auf externe Agent-Antworten reagieren
 *
 * Aktuelle Funktion:
 *  - Definiert die Interface-Struktur
 *  - Emitiert gelegentliche "foreign:signal" Platzhalter-Events
 *    (sehr selten, sehr schwach — wie ein Radio-Rauschen aus anderem Netzwerk)
 *
 * Events (out):
 *  - "foreign:signal" — Fremdes Signal detected { strength, origin }
 */

const FOREIGN_SIGNAL_INTERVAL = [60, 180]; // Sehr selten
const FOREIGN_SIGNAL_STRENGTH = [0.05, 0.15]; // Sehr schwach

export class MultiAgentHub {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;
    this.rng = simulation.rng;

    this._timer = 0;
    this._nextSignal = this.rng.range(...FOREIGN_SIGNAL_INTERVAL);
    this._foreignSignalCount = 0;
    this._connectedAgents = []; // Zukünftig: Liste verbundener Agenten
  }

  update(dt) {
    if (this.sim.world.age < 30) return; // Erste 30s: keine fremden Signale

    this._timer += dt;
    if (this._timer < this._nextSignal) return;
    this._timer = 0;
    this._nextSignal = this.rng.range(...FOREIGN_SIGNAL_INTERVAL);

    // Sehr schwaches "fremdes" Signal — wie kosmisches Hintergrundrauschen
    const strength = this.rng.range(...FOREIGN_SIGNAL_STRENGTH);
    this._foreignSignalCount++;

    this.events.emit("foreign:signal", {
      strength,
      origin: "unknown",
      timestamp: this.sim.world.age
    });

    // Auch als sehr schwaches Signal ins Netzwerk
    if (this.sim.signalSystem) {
      const angle = this.rng.range(0, Math.PI * 2);
      const dist = this.sim.world.minSide * 0.5;
      const x = this.sim.world.centerX + Math.cos(angle) * dist;
      const y = this.sim.world.centerY + Math.sin(angle) * dist;
      this.sim.signalSystem.inject(x, y, strength);
    }
  }

  /**
   * Zukünftig: Agent registrieren.
   * Aktuell: No-op, aber definiert das Interface.
   */
  registerAgent(agentInfo) {
    this._connectedAgents.push({
      id: agentInfo.id,
      name: agentInfo.name,
      connectedAt: this.sim.world.age
    });
  }

  /**
   * Zukünftig: Agent abmelden.
   */
  unregisterAgent(agentId) {
    this._connectedAgents = this._connectedAgents.filter(a => a.id !== agentId);
  }

  getConnectedAgents() { return [...this._connectedAgents]; }

  getSnapshot() {
    return {
      foreignSignalCount: this._foreignSignalCount,
      connectedAgents: this._connectedAgents.length
    };
  }

  serialize() {
    return {
      foreignSignalCount: this._foreignSignalCount,
      connectedAgents: this._connectedAgents.map(a => a.id)
    };
  }

  reset() {
    this._timer = 0;
    this._foreignSignalCount = 0;
    this._connectedAgents = [];
  }

  destroy() {}
}
