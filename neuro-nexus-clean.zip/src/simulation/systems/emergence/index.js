/**
 * emergence/index.js — Barrel-Export für das emergence-Modul
 */

export * from './EmergenceSystem.js';
export * from './EmergenceDetector.js';
export * from './emergenceConstants.js';
export * from './emergenceMetrics.js';
