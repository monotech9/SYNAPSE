/**
 * emergenceMetrics — Mathematische Hilfsfunktionen für EmergenceDetector
 *
 *  - shannonEntropy:   Shannon-Entropie einer Wahrscheinlichkeitsverteilung
 *  - mutualInformation: MI zwischen zwei Variablen via Binning
 *  - jaccardDistance:  Jaccard-Distanz zwischen zwei Sets
 *  - edgeSignature:    Stabile Signatur für eine Kante
 */

import { clamp } from "../../../utils/math.js";

/**
 * Shannon-Entropie einer Wahrscheinlichkeitsverteilung.
 * @param {number[]} probs — Wahrscheinlichkeiten (sum = 1)
 * @returns {number} H in bits
 */
export function shannonEntropy(probs) {
  let h = 0;
  for (const p of probs) {
    if (p > 0) h -= p * Math.log2(p);
  }
  return h;
}

/**
 * Mutual Information zwischen zwei Variablen via Binning.
 * X und Y sind Arrays gleicher Länge; Werte werden in numBins Bins quantisiert.
 *
 * @param {number[]} x — Werte zum Zeitpunkt t
 * @param {number[]} y — Werte zum Zeitpunkt t-1
 * @param {number} [numBins=6] — Anzahl der Bins
 * @returns {number} MI in bits
 */
export function mutualInformation(x, y, numBins = 6) {
  if (!x.length || x.length !== y.length) return 0;

  // Gemeinsamer Wertebereich für konsistente Bins
  let lo = Infinity, hi = -Infinity;
  for (const v of [...x, ...y]) {
    if (v < lo) lo = v;
    if (v > hi) hi = v;
  }
  const range = hi - lo;
  if (range < 1e-10) return 0; // Alle Werte identisch → MI undefiniert

  const binWidth = range / numBins;
  const toBin = (v) => clamp(Math.floor((v - lo) / binWidth), 0, numBins - 1);

  const n = x.length;
  const joint = new Map();       // "bx,by" → count
  const px = new Array(numBins).fill(0);
  const py = new Array(numBins).fill(0);

  for (let i = 0; i < n; i++) {
    const bx = toBin(x[i]);
    const by = toBin(y[i]);
    const key = `${bx},${by}`;
    joint.set(key, (joint.get(key) || 0) + 1);
    px[bx]++;
    py[by]++;
  }

  let mi = 0;
  for (const [key, count] of joint) {
    const [bx, by] = key.split(',').map(Number);
    const pxy = count / n;
    const pxi = px[bx] / n;
    const pyi = py[by] / n;
    if (pxi > 0 && pyi > 0) {
      mi += pxy * Math.log2(pxy / (pxi * pyi));
    }
  }

  return Math.max(0, mi); // MI ≥ 0 per Definition
}

/**
 * Jaccard-Distanz zwischen zwei Sets von Edge-Signaturen.
 * 0 = identisch, 1 = komplett verschieden.
 *
 * @param {Set} setA
 * @param {Set} setB
 * @returns {number}
 */
export function jaccardDistance(setA, setB) {
  if (setA.size === 0 && setB.size === 0) return 0;
  let intersection = 0;
  for (const elem of setA) {
    if (setB.has(elem)) intersection++;
  }
  const union = setA.size + setB.size - intersection;
  return union === 0 ? 0 : 1 - intersection / union;
}

/**
 * Erzeugt eine stabile Signatur für eine Kante aus Node-Indizes.
 * Sortiert, damit (a,b) und (b,a) dieselbe Signatur ergeben.
 *
 * @param {Edge} edge
 * @returns {string}
 */
export function edgeSignature(edge) {
  const ia = edge.a.index ?? 0;
  const ib = edge.b.index ?? 0;
  return ia < ib ? `${ia}-${ib}` : `${ib}-${ia}`;
}
