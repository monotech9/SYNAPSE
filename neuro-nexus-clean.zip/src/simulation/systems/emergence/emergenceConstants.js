/**
 * emergenceConstants — Konstanten für EmergenceDetector
 *
 *  - EmergenceLevel: Klassifikation der Emergenz-Stufen
 *  - DEFAULT_WEIGHTS: Metrik-Gewichte für ED-Score
 *  - DEFAULT_THRESHOLDS: Klassifizierungs-Schwellen
 */

export const EmergenceLevel = Object.freeze({
  STABLE:         "STABLE",
  TRANSITION:     "TRANSITION",
  PHASE_SHIFT:    "PHASE_SHIFT",
  CRITICAL_SPIKE: "CRITICAL_SPIKE"
});

export const DEFAULT_WEIGHTS = Object.freeze({
  avalanche:       0.20,
  synchronization: 0.20,
  structureDrift:  0.25,
  entropy:         0.15,
  branching:       0.20
});

export const DEFAULT_THRESHOLDS = Object.freeze({
  stable:         0.30,
  transition:     0.60,
  criticalSync:   0.70,   // Sync-Schwellwert für CRITICAL_SPIKE
  criticalBranch: 0.98    // σ ≈ 1 Toleranz
});
