/**
 * EmergenceSystem — Unerwartete, emergente Momente.
 *
 * Ab und zu passiert etwas, das niemand erwartet.
 * Nicht zufällig. Sondern emergent — bedingt durch die Geschichte des Netzwerks.
 *
 * Events:
 *  1. REAWAKENING: Ein alter, fast vergessener Cluster leuchtet wieder auf
 *  2. SELF_CONNECTION: Zwei getrennte Regionen verbinden sich selbstständig
 *  3. NEW_MAIN_PATH: Das Netz entwickelt einen völlig neuen Hauptpfad
 *  4. MEMORY_CASCADE: Eine Erinnerung löst eine Kaskade weiterer Pulse aus
 *
 * Jedes Event ist selten (alle paar Minuten), fühlt sich organisch an
 * und ist durch Bedingungen im Netzwerkzustand begründet.
 */
import { clamp } from "../../../utils/math.js";
import { ClusterStates } from "../../clusterRoles.js";
import { recordMemoryEvent, getClusterPairResonance } from "../../memory.js";

export const EmergenceEventType = Object.freeze({
  REAWAKENING: "reawakening",
  SELF_CONNECTION: "selfConnection",
  NEW_MAIN_PATH: "newMainPath",
  MEMORY_CASCADE: "memoryCascade"
});

export class EmergenceSystem {
  constructor(simulation) {
    this.simulation = simulation;

    // Check-Timer: prüft alle 5-10s auf emergente Events
    this._checkTimer = 0;
    this._nextCheckInterval = 5;

    // Event-History für Telemetrie
    this.eventHistory = [];
    this.lastEventType = null;
    this.lastEventAge = 0;
  }

  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get pulseEngine() { return this.simulation.pulseEngine; }
  get networkBuilder() { return this.simulation.networkBuilder; }
  get scarSystem() { return this.simulation.scarSystem; }

  update(dt) {
    this._checkTimer += dt;
    if (this._checkTimer < this._nextCheckInterval) return;

    this._checkTimer = 0;
    this._nextCheckInterval = this.rng.range(5, 12);

    // Nur nach einer gewissen Reifezeit
    if (this.world.age < 60) return;

    // Events prüfen — jedes mit eigener Wahrscheinlichkeit und Bedingung
    this._checkReawakening();
    this._checkSelfConnection();
    this._checkNewMainPath();
    this._checkMemoryCascade();
  }

  // ─── 1. Reawakening ────────────────────────────────────────────────

  /**
   * Ein alter, fast vergessener Cluster leuchtet wieder auf.
   * Bedingung: Cluster ist DORMANT, hat aber hohe memoryStrength.
   * Wahrscheinlichkeit: ~2% pro Check (alle 5-12s) → etwa alle 5-10 Minuten.
   */
  _checkReawakening() {
    const dormantClusters = this.world.clusters.filter(c =>
      c.state === ClusterStates.DORMANT &&
      c.memoryStrength > 0.3 &&
      c.nodes.length > 0
    );

    if (dormantClusters.length === 0) return;

    // Je länger der Cluster schlummert, desto höher die Wahrscheinlichkeit
    for (const cluster of dormantClusters) {
      const dormancyDuration = this.world.age - (cluster.dormantSince || cluster.createdAtAge);
      const probability = 0.005 + dormancyDuration * 0.0001; // 0.5% + steigt mit Dauer

      if (this.rng.chance(clamp(probability, 0, 0.05))) {
        this._triggerReawakening(cluster);
        return;
      }
    }
  }

  _triggerReawakening(cluster) {
    // Cluster wieder aktivieren
    cluster.state = ClusterStates.ACTIVE;
    cluster.dormantTimer = 0;
    cluster.activityMemory = 0.3;

    // Burst von Pulsen auf den Kanten dieses Clusters
    const clusterEdges = this.world.edges.filter(e =>
      (e.a.cluster === cluster || e.b.cluster === cluster) &&
      e.birthProgress > 0.5
    );

    for (const edge of clusterEdges.slice(0, 4)) {
      const forward = edge.a.cluster === cluster;
      this.pulseEngine.spawnPulse(edge, forward, 0.5, {
        visualOnly: true,
        preferredPath: true,
        speedMultiplier: this.rng.range(0.8, 1.3)
      });
    }

    // Alle Nodes des Clusters visualImpact geben
    for (const node of cluster.nodes) {
      node.visualImpact = Math.max(node.visualImpact || 0, 0.5);
      node.activation = Math.max(node.activation, 0.3);
    }

    this._recordEvent(EmergenceEventType.REAWAKENING, {
      clusterId: cluster.id,
      dormancyDuration: this.world.age - (cluster.dormantSince || cluster.createdAtAge)
    });

    recordMemoryEvent(this.memory, "autonomousPulse", this.world.age);
    this.simulation.events.emit("emergence:moment", { type: "autonomousPulse", intensity: 0.5 });
  }

  // ─── 2. Self-Connection ────────────────────────────────────────────

  /**
   * Zwei getrennte Regionen verbinden sich nach langer Zeit selbstständig.
   * Bedingung: Zwei Cluster mit hoher historischer Resonanz aber ohne direkte Bridge.
   * Wahrscheinlichkeit: ~1% pro Check → etwa alle 10-15 Minuten.
   */
  _checkSelfConnection() {
    if (this.world.bridgeEdges.length >= 2) return; // nicht zu viele Brücken
    if (this.world.age < 120) return;

    const clusters = this.world.clusters.filter(c =>
      c.state !== ClusterStates.DORMANT &&
      c.birthProgress > 0.7 &&
      !c.isRelay
    );

    if (clusters.length < 2) return;

    // Finde Cluster-Paare mit hoher Resonanz aber ohne Bridge
    for (let i = 0; i < clusters.length; i++) {
      for (let j = i + 1; j < clusters.length; j++) {
        const a = clusters[i];
        const b = clusters[j];

        // Gibt es schon eine Bridge zwischen diesen Clustern?
        const hasBridge = this.world.bridgeEdges.some(e =>
          (e.a.cluster === a && e.b.cluster === b) ||
          (e.a.cluster === b && e.b.cluster === a)
        );
        if (hasBridge) continue;

        const resonance = getClusterPairResonance(this.memory, a, b);
        if (resonance < 0.2) continue;

        // Wahrscheinlichkeit steigt mit Resonanz
        const probability = 0.005 * resonance;
        if (this.rng.chance(probability)) {
          this._triggerSelfConnection(a, b);
          return;
        }
      }
    }
  }

  _triggerSelfConnection(clusterA, clusterB) {
    // Finde die nächsten Nodes in den beiden Clustern
    const time = this.world.currentTime || 0;
    const centerA = clusterA.center(time);
    const centerB = clusterB.center(time);

    let nearestPair = null;
    let nearestDist = Infinity;

    for (const nodeA of clusterA.nodes) {
      const posA = nodeA.position(time);
      for (const nodeB of clusterB.nodes) {
        const posB = nodeB.position(time);
        const dist = Math.hypot(posA.x - posB.x, posA.y - posB.y);
        if (dist < nearestDist) {
          nearestDist = dist;
          nearestPair = { nodeA, nodeB };
        }
      }
    }

    if (!nearestPair) return;

    // Bridge erstellen
    const edge = this.simulation.addEdge(nearestPair.nodeA, nearestPair.nodeB, {
      bridge: true,
      birthDuration: 8, // langsame Geburt — fühlt sich organisch an
      weight: 0.5
    });

    if (edge) {
      // Erste Pulse über die neue Brücke
      this.pulseEngine.spawnPulse(edge, true, 0.45, {
        visualOnly: true,
        preferredPath: true,
        bridge: true,
        speedMultiplier: 0.6
      });

      this._recordEvent(EmergenceEventType.SELF_CONNECTION, {
        clusterA: clusterA.id,
        clusterB: clusterB.id
      });

      recordMemoryEvent(this.memory, "autonomousPulse", this.world.age);
    }
  }

  // ─── 3. New Main Path ──────────────────────────────────────────────

  /**
   * Das Netz entwickelt einen völlig neuen Hauptpfad.
   * Bedingung: Netz ist reif (age > 200), hat mehrere Cluster, und der
   * aktuell stärkste Pfad ist schon lange unverändert.
   * Wahrscheinlichkeit: ~0.5% pro Check → etwa alle 20-30 Minuten.
   */
  _checkNewMainPath() {
    if (this.world.age < 200) return;
    if (this.world.clusters.length < 3) return;

    // Finde Kanten mit mittlerem identityTrace, die potenziell neue Hauptpfade sein könnten
    const candidates = this.world.edges.filter(e =>
      !e.bridge &&
      (e.identityTrace || 0) > 0.2 &&
      (e.identityTrace || 0) < 0.6 &&
      e.birthProgress > 0.8 &&
      e.a.cluster.state !== ClusterStates.DORMANT &&
      e.b.cluster.state !== ClusterStates.DORMANT
    );

    if (candidates.length === 0) return;

    if (this.rng.chance(0.003)) {
      const edge = candidates[this.rng.int(0, candidates.length - 1)];

      // Den neuen Hauptpfad verstärken: identityTrace pushen und Pulse-Flut
      edge.identityTrace = Math.min(1, (edge.identityTrace || 0) + 0.3);
      edge.weight = Math.min(0.9, edge.weight + 0.15);

      // Mehrere Pulse in Folge auf diesem Pfad
      for (let i = 0; i < 3; i++) {
        this.pulseEngine.spawnPulse(edge, i % 2 === 0, 0.4 + i * 0.1, {
          visualOnly: true,
          preferredPath: true,
          speedMultiplier: this.rng.range(0.9, 1.4)
        });
      }

      this._recordEvent(EmergenceEventType.NEW_MAIN_PATH, {
        edgeWeight: edge.weight,
        edgeTrace: edge.identityTrace
      });

      recordMemoryEvent(this.memory, "autonomousPulse", this.world.age);
    }
  }

  // ─── 4. Memory Cascade ──────────────────────────────────────────────

  /**
   * Eine Erinnerung löst eine Kaskade weiterer Pulse aus.
   * Bedingung: Es gibt eine Narbe mit hohem echoGlow (recently echoed),
   * oder eine Kante mit sehr hohem identityTrace die lange inaktiv war.
   * Die Kaskade breitet sich über das Netzwerk aus.
   * Wahrscheinlichkeit: ~1% pro Check → etwa alle 10-15 Minuten.
   */
  _checkMemoryCascade() {
    if (this.world.age < 90) return;

    // Suche nach Kanten mit hohem identityTrace die gerade nicht aktiv sind
    const sleepingPaths = this.world.edges.filter(e =>
      (e.identityTrace || 0) > 0.6 &&
      (e.activityGlow || 0) < 0.1 &&
      e.birthProgress > 0.9 &&
      e.a.cluster.state !== ClusterStates.DORMANT &&
      e.b.cluster.state !== ClusterStates.DORMANT
    );

    if (sleepingPaths.length === 0) return;

    if (this.rng.chance(0.008)) {
      const trigger = sleepingPaths[this.rng.int(0, sleepingPaths.length - 1)];

      // Erst den Trigger-Pulse
      this.pulseEngine.spawnPulse(trigger, true, 0.5, {
        visualOnly: true,
        preferredPath: true,
        speedMultiplier: 1.5
      });

      // Dann Kaskade: Pulse auf benachbarten Kanten
      const triggerNode = trigger.b;
      const adjacentEdges = this.world.edges.filter(e =>
        e !== trigger &&
        (e.a === triggerNode || e.b === triggerNode) &&
        e.birthProgress > 0.5
      );

      for (const edge of adjacentEdges.slice(0, 3)) {
        const forward = edge.a === triggerNode;
        this.pulseEngine.spawnPulse(edge, forward, 0.35, {
          visualOnly: true,
          preferredPath: true,
          speedMultiplier: this.rng.range(1.0, 1.6)
        });
      }

      this._recordEvent(EmergenceEventType.MEMORY_CASCADE, {
        triggerTrace: trigger.identityTrace,
        cascadeSize: Math.min(3, adjacentEdges.length) + 1
      });

      recordMemoryEvent(this.memory, "autonomousPulse", this.world.age);
    }
  }

  // ─── Utility ────────────────────────────────────────────────────────

  _recordEvent(type, details) {
    this.lastEventType = type;
    this.lastEventAge = this.world.age;
    this.eventHistory.push({ type, age: this.world.age, details });
    if (this.eventHistory.length > 20) this.eventHistory.shift();
  }

  getEventLabel(type) {
    const labels = {
      [EmergenceEventType.REAWAKENING]: "Wiedererwachen",
      [EmergenceEventType.SELF_CONNECTION]: "Selbstverbindung",
      [EmergenceEventType.NEW_MAIN_PATH]: "Neuer Hauptpfad",
      [EmergenceEventType.MEMORY_CASCADE]: "Erinnerungskaskade"
    };
    return labels[type] || type;
  }
}
