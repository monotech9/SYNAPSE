/**
 * EmergenceDetector — Phasenwechsel-Erkennung für Neuro Nexus.
 *
 * Ansatz: Emergenz = Wechsel der Organisationsform, nicht bloße Aktivität.
 *
 * Der Detector misst sechs Metriken aus dem Netzwerkzustand:
 *   1. Avalanche Index (AI)       — Kaskadenstärke
 *   2. Synchronization (Sync)     — Ordnungsparameter (Kuramoto)
 *   3. Structure Drift (SD)       — Jaccard-Distanz auf Kantenmenge
 *   4. Entropy (H)                — Shannon-Entropie der Aktivitätsverteilung
 *   5. Branching Ratio (σ)        — Kritikalitätsmaß (aktive Nodes t+1 / t)
 *   6. Mutual Information Drift   — Bedeutungsverschiebung I(X_t ; X_{t-1})
 *
 * Module:
 *  - emergenceConstants.js — EmergenceLevel, Weights, Thresholds
 *  - emergenceMetrics.js   — shannonEntropy, mutualInformation, jaccardDistance, edgeSignature
 *
 * Events auf dem EventBus:
 *   "emergence:score"     — jeder Sample-Tick, enthält vollen Metrik-Satz
 *   "emergence:detected"  — bei Klassifizierung als TRANSITION oder höher
 *   "emergence:phaseShift"— bei PHASE_SHIFT oder CRITICAL_SPIKE
 */

import { clamp } from "../../../utils/math.js";
import {
  EmergenceLevel,
  DEFAULT_WEIGHTS,
  DEFAULT_THRESHOLDS
} from "./emergenceConstants.js";
import {
  shannonEntropy,
  mutualInformation,
  jaccardDistance,
  edgeSignature
} from "./emergenceMetrics.js";

// Re-export für Abwärtskompatibilität
export { EmergenceLevel };

export class EmergenceDetector {
  /**
   * @param {NeuroSimulation} simulation
   * @param {object} [options]
   */
  constructor(simulation, options = {}) {
    this.simulation = simulation;

    this.sampleInterval = options.sampleInterval ?? 1.5;
    this.weights = { ...DEFAULT_WEIGHTS, ...options.weights };
    this.thresholds = { ...DEFAULT_THRESHOLDS, ...options.thresholds };
    this.activationThreshold = options.activationThreshold ?? 0.15;
    this.historySize = options.historySize ?? 60;
    this.coolDown = options.coolDown ?? 4.0;

    // Sample-Timer
    this._timer = 0;

    // Vorheriger Zustand für Differenz-Metriken
    this._prevActiveCount = 0;
    this._prevEdgeSet = new Set();
    this._prevActivations = null;
    this._hasPrevState = false;

    // Historie für Trend-Analyse und MI-Drift
    this.history = [];

    // Letzter Score und Level
    this.lastScore = 0;
    this.lastLevel = EmergenceLevel.STABLE;
    this.lastEventAge = -Infinity;

    // Kumulierte Statistiken
    this.stats = {
      totalSamples: 0,
      totalDetections: 0,
      totalPhaseShifts: 0,
      totalCriticalSpikes: 0,
      maxScore: 0,
      avgScore: 0
    };
  }

  get world() { return this.simulation.world; }
  get events() { return this.simulation.events; }

  // ─── Update — wird jeden Tick von UpdateLoop aufgerufen ─────────────

  update(dt) {
    this._timer += dt;
    if (this._timer < this.sampleInterval) return;
    this._timer = 0;
    this._sample();
  }

  // ─── Kern: Sample ziehen und Metriken berechnen ─────────────────────

  _sample() {
    const world = this.world;
    const nodes = this._collectNodes();
    const edges = world.edges;
    const N = nodes.length;

    if (N < 2) {
      this._hasPrevState = false;
      return;
    }

    // ── Aktivierungs-Vektor ──
    const activations = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      activations[i] = nodes[i].activation;
    }

    // ── 1. Avalanche Index ──
    const activeCount = activations.filter(a => a > this.activationThreshold).length;
    const avalancheIndex = clamp(
      Math.log(1 + activeCount) / Math.log(1 + N),
      0, 1
    );

    // ── 2. Synchronization (Kuramoto Order Parameter) ──
    let syncReal = 0, syncImag = 0, syncWeight = 0;
    for (let i = 0; i < N; i++) {
      const w = activations[i];
      const phi = nodes[i].phase;
      syncReal += w * Math.cos(phi);
      syncImag += w * Math.sin(phi);
      syncWeight += w;
    }
    const sync = syncWeight > 1e-6
      ? clamp(Math.hypot(syncReal, syncImag) / syncWeight, 0, 1)
      : 0;

    // ── 3. Structure Drift (Jaccard-Distanz auf Kanten) ──
    const currentEdgeSet = new Set();
    for (const edge of edges) {
      if (edge.birthProgress > 0.5) {
        currentEdgeSet.add(edgeSignature(edge));
      }
    }
    const structureDrift = this._hasPrevState
      ? jaccardDistance(this._prevEdgeSet, currentEdgeSet)
      : 0;

    // ── 4. Entropy der Aktivitätsverteilung ──
    const numBins = 8;
    let maxAct = 0;
    for (let i = 0; i < N; i++) maxAct = Math.max(maxAct, activations[i]);
    if (maxAct < 1e-6) maxAct = 1;
    const binCounts = new Array(numBins).fill(0);
    for (let i = 0; i < N; i++) {
      const bin = clamp(Math.floor(activations[i] / maxAct * numBins), 0, numBins - 1);
      binCounts[bin]++;
    }
    const probs = binCounts.map(c => c / N);
    const maxEntropy = Math.log2(numBins);
    const entropy = maxEntropy > 0 ? clamp(shannonEntropy(probs) / maxEntropy, 0, 1) : 0;

    // ── 5. Branching Ratio (σ) ──
    let branchingRatio = 1;
    let branchingDeviation = 0;
    if (this._hasPrevState && this._prevActiveCount > 0) {
      branchingRatio = activeCount / this._prevActiveCount;
      branchingDeviation = clamp(Math.abs(branchingRatio - 1), 0, 1);
    }

    // ── 6. Mutual Information Drift ──
    let miDrift = 0;
    if (this._hasPrevState && this._prevActivations && this._prevActivations.length === N) {
      const mi = mutualInformation(
        Array.from(activations),
        Array.from(this._prevActivations),
        6
      );
      const maxMI = Math.log2(N);
      miDrift = maxMI > 0 ? clamp(1 - mi / maxMI, 0, 1) : 0;
    }

    // ── ED-Score berechnen (gewichtete Kombination) ──
    const w = this.weights;
    const score = clamp(
      w.avalanche       * avalancheIndex +
      w.synchronization * sync +
      w.structureDrift  * structureDrift +
      w.entropy         * entropy +
      w.branching       * branchingDeviation,
      0, 1
    );

    // MI-Drift als Bonus: steigert Score wenn Bedeutungsverschiebung bei hoher Entropy
    const miDriftContribution = miDrift * entropy * 0.15;
    const finalScore = clamp(score + miDriftContribution, 0, 1);

    // ── Klassifizierung ──
    const level = this._classify(finalScore, sync, branchingRatio);

    const result = {
      age: world.age,
      score: finalScore,
      rawScore: score,
      level,
      signals: {
        avalanche: avalancheIndex,
        sync,
        structureDrift,
        entropy,
        branching: branchingRatio,
        miDrift,
        miDriftContribution,
        activeCount,
        totalNodes: N,
        totalEdges: currentEdgeSet.size
      }
    };

    // ── Historie aktualisieren ──
    this.history.push(result);
    if (this.history.length > this.historySize) this.history.shift();

    // ── Statistiken ──
    this.stats.totalSamples++;
    this.stats.maxScore = Math.max(this.stats.maxScore, finalScore);
    this.stats.avgScore = this.stats.avgScore * 0.95 + finalScore * 0.05;

    // ── Previous State speichern ──
    this._prevActiveCount = activeCount;
    this._prevEdgeSet = currentEdgeSet;
    this._prevActivations = activations;
    this._hasPrevState = true;

    // ── EventBus Events feuern ──
    this.lastScore = finalScore;
    this.lastLevel = level;

    this.events.emit("emergence:score", result);

    if (level !== EmergenceLevel.STABLE) {
      const sinceLastEvent = world.age - this.lastEventAge;
      if (sinceLastEvent >= this.coolDown) {
        this.stats.totalDetections++;
        this.lastEventAge = world.age;

        const eventPayload = {
          ...result,
          interpretation: this._interpret(result)
        };

        this.events.emit("emergence:detected", eventPayload);

        if (level === EmergenceLevel.PHASE_SHIFT || level === EmergenceLevel.CRITICAL_SPIKE) {
          this.stats.totalPhaseShifts++;
          if (level === EmergenceLevel.CRITICAL_SPIKE) this.stats.totalCriticalSpikes++;
          this.events.emit("emergence:phaseShift", eventPayload);
        }
      }
    }
  }

  // ─── Klassifizierung ───────────────────────────────────────────────

  _classify(score, sync, branchingRatio) {
    if (
      Math.abs(branchingRatio - 1) < (1 - this.thresholds.criticalBranch) &&
      sync > this.thresholds.criticalSync
    ) {
      return EmergenceLevel.CRITICAL_SPIKE;
    }

    if (score >= this.thresholds.transition) {
      return EmergenceLevel.PHASE_SHIFT;
    }

    if (score >= this.thresholds.stable) {
      return EmergenceLevel.TRANSITION;
    }

    return EmergenceLevel.STABLE;
  }

  // ─── Interpretation (für Narrative / Story Curator) ─────────────────

  _interpret(result) {
    const s = result.signals;
    const interpretations = [];

    if (s.structureDrift > 0.3)
      interpretations.push("Network restructuring detected");
    if (s.sync > 0.7)
      interpretations.push("Global synchronization emerging");
    if (s.branching > 0.95 && s.branching < 1.05)
      interpretations.push("Critical branching regime");
    if (s.entropy > 0.75)
      interpretations.push("High exploratory diversity");
    if (s.entropy < 0.2)
      interpretations.push("Rigid focal state");
    if (s.avalanche > 0.6)
      interpretations.push("System-wide activation cascade");
    if (s.miDrift < 0.3 && s.entropy > 0.5)
      interpretations.push("Semantic reconfiguration — new organizational form");

    if (interpretations.length === 0)
      return "Nominal system behavior";
    return interpretations.join("; ");
  }

  // ─── Hilfsfunktion: alle Nodes einsammeln ───────────────────────────

  _collectNodes() {
    const nodes = [];
    for (const cluster of this.world.clusters) {
      for (const node of cluster.nodes) {
        if (node.birthProgress > 0.1) {
          nodes.push(node);
        }
      }
    }
    return nodes;
  }

  // ─── API ────────────────────────────────────────────────────────────

  getSnapshot() {
    return {
      score: this.lastScore,
      level: this.lastLevel,
      stats: { ...this.stats },
      recent: this.history.slice(-10),
      weights: { ...this.weights },
      thresholds: { ...this.thresholds }
    };
  }

  setWeights(newWeights) {
    this.weights = { ...this.weights, ...newWeights };
  }

  reset() {
    this._timer = 0;
    this._prevActiveCount = 0;
    this._prevEdgeSet = new Set();
    this._prevActivations = null;
    this._hasPrevState = false;
    this.history = [];
    this.lastScore = 0;
    this.lastLevel = EmergenceLevel.STABLE;
    this.lastEventAge = -Infinity;
    this.stats = {
      totalSamples: 0,
      totalDetections: 0,
      totalPhaseShifts: 0,
      totalCriticalSpikes: 0,
      maxScore: 0,
      avgScore: 0
    };
  }
}
