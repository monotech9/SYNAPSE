import { CONFIG, CLUSTER_TYPES } from "../../../config.js";
import { ClusterRoles, ClusterStates } from "../../clusterRoles.js";
import { clamp } from "../../../utils/math.js";
import { Node } from "../../entities/Node.js";

/**
 * NodeBuilder — Node-Erstellung, morphologische Platzierung und Parent-Wahl.
 */
export class NodeBuilder {
  constructor(builder) {
    this.builder = builder;
  }

  get simulation() { return this.builder.simulation; }
  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }

  addNodeToCluster(cluster, options = {}) {
    if (!cluster) return false;
    if (this.simulation.totalNodeCount() >= CONFIG.maxTotalNodes) return false;
    if (cluster.nodes.length >= cluster.hardNodeLimit) return false;
    if (cluster.state === ClusterStates.DORMANT || cluster.state === ClusterStates.STRESSED) return false;

    const parent = this.chooseGrowthParent(cluster);
    const parentLocal = parent ? parent.localPosition() : { x: 0, y: 0 };
    const target = options.manualTargetLocal || this.chooseMorphologicalNodeTarget(cluster, parent);

    const newNode = new Node(this.simulation, cluster, {
      index: cluster.nodes.length,
      originLocalX: parentLocal.x,
      originLocalY: parentLocal.y,
      targetLocalX: target.x,
      targetLocalY: target.y,
      mass: this.rng.range(0.48, 1.36),
      phase: this.rng.range(0, Math.PI * 2),
      birthDuration: this.rng.range(7.5, 16.5) * this.personality.growthIntervalMultiplier / Math.max(0.7, cluster.growthBias),
      visualImpact: 1.12,
      instant: options.instant || false
    });

    cluster.nodes.push(newNode);
    cluster.updateRadius();
    this.world.dirty = true;
    this.simulation.createNodeBirthWave(newNode, 0.34);
    if (this.simulation.invalidateSpatialGrid) this.simulation.invalidateSpatialGrid();

    const typeConfig = CLUSTER_TYPES[cluster.type] || CLUSTER_TYPES[cluster.role] || CLUSTER_TYPES.exploration;

    if (parent) {
      this.simulation.addEdge(parent, newNode, {
        bridge: false,
        weight: typeConfig.baseWeight * this.rng.range(0.44, 0.8) * this.personality.learningRateMultiplier,
        birthDuration: this.rng.range(4.4, 9.5) * this.personality.connectionIntervalMultiplier
      });
    }

    const nearest = this.builder.findNearestNodes(newNode, cluster.nodes, cluster.state === ClusterStates.SEEDLING ? 2 : this.rng.int(1, 3));

    for (const target of nearest) {
      if (target === parent) continue;
      if (this.rng.chance(clamp(0.24 + this.personality.curiosity * 0.12 + cluster.plasticityBias * 0.07, 0.16, 0.54))) {
        this.simulation.addEdge(target, newNode, {
          bridge: false,
          weight: typeConfig.baseWeight * this.rng.range(0.26, 0.62) * this.personality.learningRateMultiplier,
          birthDuration: this.rng.range(5.5, 12.5) * this.personality.connectionIntervalMultiplier
        });
      }
    }

    newNode.setActivation(0.26 + this.personality.curiosity * 0.12);
    if (parent) {
      parent.setActivation(Math.max(parent.activation, 0.34 + this.personality.attachment * 0.08));
      parent.visualImpact = Math.max(parent.visualImpact || 0, 0.42);
    }
    this.diagnosticCounters.nodesAdded += 1;

    // Audio-Feedback bei Node-Geburt
    if (this.simulation.audio && this.simulation.audio.enabled) {
      this.simulation.audio.playNodeBirth(cluster);
    }

    return true;
  }

  chooseMorphologicalNodeTarget(cluster, parent) {
    const index = cluster.nodes.length;
    const goldenAngle = 2.399963229728653;
    const existingLocals = cluster.nodes.map((node) => node.localPosition());
    const parentLocal = parent.localPosition();
    const parentAngle = Math.atan2(parentLocal.y, parentLocal.x);
    let best = null;
    let bestScore = -Infinity;

    for (let attempt = 0; attempt < 12; attempt += 1) {
      const indexRatio = clamp((index + attempt * 0.37) / Math.max(8, cluster.softNodeLimit), 0, 1);
      const roleRadius = cluster.role === ClusterRoles.GENESIS
        ? 0.28 + Math.sqrt(indexRatio) * 0.64
        : cluster.state === ClusterStates.SEEDLING
          ? 0.18 + Math.sqrt(indexRatio) * 0.34
          : 0.22 + Math.sqrt(indexRatio) * 0.52;
      const angle = cluster.role === ClusterRoles.GENESIS
        ? cluster.phase + index * goldenAngle + attempt * 0.37 + this.rng.range(-0.24, 0.24)
        : parentAngle + this.rng.range(-0.9, 0.9) + attempt * 0.18;
      const radius = clamp(roleRadius + this.rng.range(-0.055, 0.06), 0.16, cluster.role === ClusterRoles.GENESIS ? 0.98 : 0.7);
      const elliptic = cluster.role === ClusterRoles.GENESIS ? this.rng.range(0.94, 1.06) : this.rng.range(0.9, 1.1);
      const candidate = {
        x: Math.cos(angle) * radius * elliptic,
        y: Math.sin(angle) * radius / elliptic
      };

      const minDistance = existingLocals.reduce((min, local) => Math.min(min, Math.hypot(candidate.x - local.x, candidate.y - local.y)), Infinity);
      const radial = Math.hypot(candidate.x, candidate.y);
      const targetBand = cluster.role === ClusterRoles.GENESIS ? 0.58 : 0.42;
      const bandScore = 1 - Math.abs(radial - targetBand);
      const separationScore = clamp(minDistance / 0.32, 0, 1);
      const parentContinuity = 1 - clamp(Math.hypot(candidate.x - parentLocal.x, candidate.y - parentLocal.y) / 1.35, 0, 1);
      const score = separationScore * 0.48 + bandScore * 0.34 + parentContinuity * 0.18 + this.rng.range(0, 0.04);

      if (score > bestScore) {
        bestScore = score;
        best = candidate;
      }
    }

    return best || { x: 0.3, y: 0 };
  }

  chooseGrowthParent(cluster) {
    const matureNodes = cluster.nodes.filter((node) => node.birthProgress > 0.68);

    if (matureNodes.length === 0) return cluster.nodes[0];

    matureNodes.sort((a, b) => {
      const aLocal = a.localPosition();
      const bLocal = b.localPosition();
      const aDistance = Math.hypot(aLocal.x, aLocal.y);
      const bDistance = Math.hypot(bLocal.x, bLocal.y);
      const distanceBias = cluster.role === ClusterRoles.EXPLORATION ? 0.23 : 0.12;
      const aScore = a.activation + aDistance * distanceBias + (a.isCore ? this.personality.attachment * 0.08 : 0) + this.rng.range(0, 0.16);
      const bScore = b.activation + bDistance * distanceBias + (b.isCore ? this.personality.attachment * 0.08 : 0) + this.rng.range(0, 0.16);
      return bScore - aScore;
    });

    return matureNodes[0];
  }
}
