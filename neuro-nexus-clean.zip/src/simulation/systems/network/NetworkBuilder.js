import { ClusterBuilder } from "./ClusterBuilder.js";
import { NodeBuilder } from "./NodeBuilder.js";
import { EdgeBuilder } from "./EdgeBuilder.js";
import { BridgeBuilder } from "./BridgeBuilder.js";

/**
 * NetworkBuilder — Fassade für Netzwerk-Aufbau.
 *
 * Delegiert an vier spezialisierte Sub-Builder:
 *  - ClusterBuilder: Cluster-Erstellung + Seed-Verbindungen
 *  - NodeBuilder: Node-Erstellung + morphologische Platzierung
 *  - EdgeBuilder: interne Kanten + Memory-Pfad-Verstärkung
 *  - BridgeBuilder: Bud-Erstellung + Bridge-Kanten zwischen Clustern
 *
 * findNearestNodes() bleibt hier als Shared Utility, da es von
 * ClusterBuilder, NodeBuilder und EdgeBuilder gleichermaßen genutzt wird.
 */
export class NetworkBuilder {
  constructor(simulation) {
    this.simulation = simulation;
    this.clusterBuilder = new ClusterBuilder(this);
    this.nodeBuilder = new NodeBuilder(this);
    this.edgeBuilder = new EdgeBuilder(this);
    this.bridgeBuilder = new BridgeBuilder(this);
  }

  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }

  // ─── Shared utility ───────────────────────────────────────────────

  findNearestNodes(source, candidates, count) {
    return candidates
      .filter((candidate) => candidate !== source)
      .map((candidate) => {
        const a = source.localPosition();
        const b = candidate.localPosition();
        return { node: candidate, distance: Math.hypot(a.x - b.x, a.y - b.y) };
      })
      .sort((a, b) => a.distance - b.distance)
      .slice(0, count)
      .map((entry) => entry.node);
  }

  // ─── Delegating stubs ─────────────────────────────────────────────

  addCluster(blueprint, options = {}) {
    return this.clusterBuilder.addCluster(blueprint, options);
  }

  addNodeToCluster(cluster, options = {}) {
    return this.nodeBuilder.addNodeToCluster(cluster, options);
  }

  addInternalEdge(cluster) {
    return this.edgeBuilder.addInternalEdge(cluster);
  }

  strengthenMemoryPath(cluster) {
    return this.edgeBuilder.strengthenMemoryPath(cluster);
  }

  createBud(parent) {
    return this.bridgeBuilder.createBud(parent);
  }

  createBridgeBetweenClusters(aCluster, bCluster, options = {}) {
    const bridge = this.bridgeBuilder.createBridgeBetweenClusters(aCluster, bCluster, options);
    if (bridge) this.simulation.events.emit("network:bridgeCreated", { bridge, count: this.world.bridgeEdges.length });
    return bridge;
  }

  createBridgeConnection() {
    return this.bridgeBuilder.createBridgeConnection();
  }
}
