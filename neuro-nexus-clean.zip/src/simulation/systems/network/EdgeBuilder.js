import { CONFIG, CLUSTER_TYPES } from "../../../config.js";
import { clamp } from "../../../utils/math.js";
import { recordMemoryEvent, reinforceEdgeMemory } from "../../memory.js";

/**
 * EdgeBuilder — interne Kanten-Erstellung und Memory-Pfad-Verstärkung.
 */
export class EdgeBuilder {
  constructor(builder) {
    this.builder = builder;
  }

  get simulation() { return this.builder.simulation; }
  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }

  addInternalEdge(cluster) {
    if (!cluster || this.world.edges.length >= CONFIG.maxTotalEdges) return false;
    if (cluster.nodes.length < 4) return false;

    const matureNodes = cluster.nodes.filter((node) => node.birthProgress > 0.65);
    if (matureNodes.length < 4) return false;

    const source = matureNodes[this.rng.int(0, matureNodes.length - 1)];
    const nearby = this.builder.findNearestNodes(source, matureNodes, 8).filter((node) => !this.simulation.hasEdge(source, node));

    if (!nearby.length) return false;

    const target = nearby[this.rng.int(0, nearby.length - 1)];
    const typeConfig = CLUSTER_TYPES[cluster.type] || CLUSTER_TYPES[cluster.role] || CLUSTER_TYPES.exploration;
    const edge = this.simulation.addEdge(source, target, {
      bridge: false,
      weight: typeConfig.baseWeight * this.rng.range(0.22, 0.56) * this.personality.learningRateMultiplier,
      birthDuration: this.rng.range(5, 13) * this.personality.connectionIntervalMultiplier
    });

    if (!edge) return false;

    source.setActivation(Math.max(source.activation, 0.26));
    target.setActivation(Math.max(target.activation, 0.2));
    this.diagnosticCounters.internalEdgesAdded += 1;
    return true;
  }

  strengthenMemoryPath(cluster) {
    const candidates = this.world.edges.filter((edge) => {
      return edge.a.cluster === cluster && edge.b.cluster === cluster && edge.birthProgress > 0.55;
    });

    if (!candidates.length) return this.addInternalEdge(cluster);

    candidates.sort((a, b) => {
      const aScore = (a.identityTrace || 0) * 0.45 + a.weight * 0.35 + a.memory * 0.2 + this.rng.range(0, 0.08);
      const bScore = (b.identityTrace || 0) * 0.45 + b.weight * 0.35 + b.memory * 0.2 + this.rng.range(0, 0.08);
      return bScore - aScore;
    });

    const edge = candidates[0];
    edge.weight = clamp(edge.weight + 0.018 * cluster.retentionBias, 0.06, 0.9);
    reinforceEdgeMemory(edge, 0.075 * cluster.retentionBias * this.personality.memoryLearningMultiplier);
    this.simulation.pulseEngine.spawnPulse(edge, true, 0.2 + (edge.identityTrace || 0) * 0.25);
    this.memory.strongestTrace = Math.max(this.memory.strongestTrace, edge.identityTrace || 0);

    edge.a.setActivation(Math.max(edge.a.activation, 0.24));
    edge.b.setActivation(Math.max(edge.b.activation, 0.22));

    if ((edge.identityTrace || 0) > 0.36 && this.memory.events.length === 0) {
      recordMemoryEvent(this.memory, "firstTrace", this.world.age);
    }

    return true;
  }
}
