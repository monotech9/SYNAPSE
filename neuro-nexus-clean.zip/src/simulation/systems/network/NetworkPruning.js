import { ClusterStates } from "../../clusterRoles.js";
import { recordMemoryEvent } from "../../memory.js";

export class NetworkPruning {
  constructor(simulation) {
    this.simulation = simulation;
  }

  get world() {
    return this.simulation.world;
  }

  get personality() {
    return this.simulation.personality;
  }

  get memory() {
    return this.simulation.memory;
  }

  update(dt) {
    // PHASE 5: Φ/Coherence moduliert Pruning-Aggressivität.
    // Hohes Φ = System ist integriert → konservativer prunen (Strukturerhalt).
    // Niedriges Φ = System ist fragmentiert → aggressiver prunen (Exploration).
    const con = this.simulation.consciousness;
    const phi = con?.selfModel?.selfModel.phi || 0;
    const coherence = con?.selfModel?.selfModel.coherence || 0;
    // phiMod: 0.6 (hohes Φ → weniger pruning) bis 1.4 (niedriges Φ → mehr pruning)
    const phiMod = 1.4 - (phi * 0.5 + coherence * 0.3);

    // 1. Remove dead edges.
    const pruningRate = this.personality.pruningRateMultiplier * phiMod;
    // trafficThreshold: niedriger bei hohem phiMod (aggressiver) — Kanten schneller bereit zum Pruning
    const trafficThreshold = 180 / pruningRate;  // ~3 Minuten ohne Traffic → pruning-bereit

    const beforeEdges = this.world.edges.length;
    const toRemove = [];
    for (const edge of this.world.edges) {
      const noTrace = (edge.identityTrace || 0) < 0.05;
      const noMemory = edge.memory < 0.05;
      const mature = edge.birthProgress > 0.9;

      // Bei hohem Φ: Schwellwert erhöhen (Struktur schwerer zu prunen)
      const weightThreshold = 0.05 * (1 - phi * 0.3);
      const weightDead = edge.weight < weightThreshold;
      const trafficDead = noTrace && noMemory && mature
        && edge.weight < 0.14
        && (edge.traceAge || 0) > trafficThreshold;

      const isDead = (weightDead || trafficDead) && noTrace && noMemory && mature;

      if (isDead) {
        toRemove.push(edge);
      }
    }
    // Narbe aufzeichnen bevor die Kante entfernt wird
    // Wir verwenden peakTrace/peakMemory — eine Kante die einmal wichtig war,
    // hinterlässt eine Narbe auch wenn sie zum Zeitpunkt des Prunings schwach ist.
    for (const edge of toRemove) {
      const wasSignificant = (edge.peakTrace || 0) > 0.15 || (edge.peakMemory || 0) > 0.15;
      if (wasSignificant) {
        this.simulation.scarSystem.recordScar(edge);
      }
      this.simulation.removeEdge(edge);
      if (this.simulation.invalidateSpatialGrid) this.simulation.invalidateSpatialGrid();
    }

    if (this.world.edges.length < beforeEdges) {
      this.simulation.world.dirty = true;
      if (this.world.age > 45 && this.rng?.chance(0.02)) {
        recordMemoryEvent(this.memory, "firstPruning", this.world.age);
      }
    }

    // 2. Remove dead nodes
    for (let i = this.world.clusters.length - 1; i >= 0; i -= 1) {
      const cluster = this.world.clusters[i];
      if (cluster.state === ClusterStates.DORMANT) continue;

      const beforeNodes = cluster.nodes.length;
      // Nutze Per-Cluster Edge-Index statt Full-Scan für Connectivity-Check
      const internalEdges = this.simulation.getInternalEdges(cluster);
      const bridgeEdges = this.simulation.getClusterBridgeEdges(cluster);
      cluster.nodes = cluster.nodes.filter((node) => {
        if (node.isCore || node.birthProgress < 1) return true;
        // Prüfe nur die Kanten dieses Clusters (intern + bridge) statt aller Kanten
        const hasConnections = internalEdges.some((edge) => edge.a === node || edge.b === node)
          || bridgeEdges.some((edge) => edge.a === node || edge.b === node);
        const isActive = node.activation > 0.04 || node.charge > 0.04;
        return hasConnections || isActive || node.birthAge < 25;
      });

      if (cluster.nodes.length !== beforeNodes) {
        cluster.updateRadius();
      }
    }
  }

  get rng() {
    return this.simulation.rng;
  }
}
