import { CONFIG } from "../../../config.js";
import { ClusterRoles, ClusterStates, chooseBudRole, clusterTypeForRole } from "../../clusterRoles.js";
import { clamp, lerp } from "../../../utils/math.js";
import { recordMemoryEvent, reinforceEdgeMemory, recordClusterPairActivity, getClusterPairResonance } from "../../memory.js";

/**
 * BridgeBuilder — Bud-Erstellung, Bridge-Kanten zwischen Clustern und
 * Bridge-Connection-Logik (späte Netzwerk-Phase).
 */
export class BridgeBuilder {
  constructor(builder) {
    this.builder = builder;
  }

  get simulation() { return this.builder.simulation; }
  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }

  // ─── Bud creation ─────────────────────────────────────────────────

  createBud(parent) {
    if (!parent || this.world.clusters.length >= CONFIG.maxClusters) return false;
    if (parent.budCooldown > 0) return false;

    const role = chooseBudRole(parent, this.personality, this.world.clusters.length);
    const type = clusterTypeForRole(role);
    const angle = this.findBudAngle(parent);
    const distance = clamp(Math.max(parent.distance + this.rng.range(0.17, 0.25), 0.2 + this.world.clusters.length * 0.025), 0.2, 0.42);
    const id = `${role}-${Math.round(this.world.age)}-${this.world.clusters.length}`;
    const initialNodes = role === ClusterRoles.MEMORY ? 1 : this.rng.int(1, 2);

    const cluster = this.builder.addCluster({
      id,
      type,
      role,
      state: ClusterStates.SEEDLING,
      parentId: parent.id,
      threshold: 0,
      angle,
      distance,
      initialNodes,
      birthDuration: this.rng.range(18, 28),
      createdAtAge: this.world.age
    }, { instant: false, wake: true });

    if (!cluster) return false;

    cluster.nodes.forEach((node) => {
      node.visualImpact = Math.max(node.visualImpact || 0, 1.35);
      node.setActivation(Math.max(node.activation, 0.3));
    });
    this.simulation.createClusterBirthWave(cluster, 0.48);

    const bridge = this.createBridgeBetweenClusters(parent, cluster, { gentle: false });
    if (bridge) {
      reinforceEdgeMemory(bridge, 0.08);
    }

    parent.budCooldown = this.rng.range(90, 150) * lerp(1.25, 0.75, this.personality.curiosity) * lerp(0.85, 1.25, this.personality.caution);
    parent.setActivation?.(0);
    recordMemoryEvent(this.memory, "firstBud", this.world.age);
    this.diagnosticCounters.budsCreated += 1;

    return true;
  }

  findBudAngle(parent) {
    if (this.world.focusPoint) {
      const now = performance.now() / 1000;
      const parentPos = parent.center(now);
      const targetAngle = Math.atan2(this.world.focusPoint.y - parentPos.y, this.world.focusPoint.x - parentPos.x);

      const dist = Math.hypot(this.world.focusPoint.x - parentPos.x, this.world.focusPoint.y - parentPos.y);
      if (dist < 100 / this.simulation.camera.scale) {
        this.world.focusPoint = null;
      }
      return targetAngle + this.rng.range(-0.1, 0.1);
    }

    const peripheral = parent.nodes
      .filter((node) => node.birthProgress > 0.75)
      .map((node) => {
        const local = node.localPosition();
        return {
          angle: Math.atan2(local.y, local.x),
          radius: Math.hypot(local.x, local.y),
          score: Math.hypot(local.x, local.y) * 0.58 + node.activation * 0.28 + (node.visualImpact || 0) * 0.14 + this.rng.range(0, 0.08)
        };
      })
      .sort((a, b) => b.score - a.score);

    const baseAngle = peripheral[0]?.angle ?? this.rng.range(-Math.PI, Math.PI);
    let bestAngle = parent.angle + baseAngle + this.rng.range(-0.42, 0.42);
    let bestScore = -Infinity;

    for (let attempt = 0; attempt < 12; attempt += 1) {
      const angle = parent.angle + baseAngle + this.rng.range(-0.72, 0.72);
      const score = this.world.clusters.reduce((sum, cluster) => {
        if (cluster === parent) return sum + 0.5;
        const delta = Math.abs(Math.atan2(Math.sin(angle - cluster.angle), Math.cos(angle - cluster.angle)));
        return sum + clamp(delta / 1.2, 0, 1);
      }, 0) - Math.abs(Math.sin(angle)) * 0.08;

      if (score > bestScore) {
        bestScore = score;
        bestAngle = angle;
      }
    }

    return bestAngle;
  }

  // ─── Bridge edges ─────────────────────────────────────────────────

  createBridgeBetweenClusters(aCluster, bCluster, options = {}) {
    if (!aCluster || !bCluster || aCluster === bCluster) return null;

    const a = this.chooseBridgeNode(aCluster);
    const b = this.chooseBridgeNode(bCluster);
    if (!a || !b) return null;

    const edge = this.simulation.addEdge(a, b, {
      bridge: true,
      weight: this.rng.range(options.gentle ? 0.08 : 0.1, options.gentle ? 0.15 : 0.2) * (0.86 + this.personality.curiosity * 0.16),
      birthDuration: this.rng.range(12, 24) * this.personality.connectionIntervalMultiplier,
      identityTrace: options.gentle ? 0.055 : 0.095
    });

    if (!edge) return null;

    a.setActivation(Math.max(a.activation, 0.28));
    b.setActivation(Math.max(b.activation, 0.26));
    a.visualImpact = Math.max(a.visualImpact || 0, 0.48);
    b.visualImpact = Math.max(b.visualImpact || 0, 0.62);
    this.diagnosticCounters.bridgesCreated += 1;

    // Inter-Cluster-Kommunikationsgeschichte protokollieren
    recordClusterPairActivity(this.memory, aCluster, bCluster, this.world.age, 0.4);

    return edge;
  }

  chooseBridgeNode(cluster) {
    const matureNodes = cluster.nodes.filter((node) => node.birthProgress > 0.55);
    const nodes = matureNodes.length ? matureNodes : cluster.nodes;

    nodes.sort((a, b) => {
      const aLocal = a.localPosition();
      const bLocal = b.localPosition();
      const aScore = Math.hypot(aLocal.x, aLocal.y) + a.activation * 0.22 + this.rng.range(0, 0.1);
      const bScore = Math.hypot(bLocal.x, bLocal.y) + b.activation * 0.22 + this.rng.range(0, 0.1);
      return bScore - aScore;
    });

    return nodes[0];
  }

  createBridgeConnection() {
    if (this.world.age < 180) return false;

    const clusters = this.world.clusters.filter((cluster) => {
      return cluster.birthProgress > 0.55 && cluster.state !== ClusterStates.DORMANT;
    });

    if (clusters.length < 2) return false;

    clusters.sort((a, b) => (b.bridgeBias + b.expansionPressure) - (a.bridgeBias + a.expansionPressure));
    const aCluster = clusters[0];
    const otherClusters = clusters.slice(1).filter((cluster) => {
      // Nutze bridgeEdges statt edges.filter für O(1)-Look-up
      return !this.world.bridgeEdges.some((edge) => {
        return (
          (edge.a.cluster === aCluster && edge.b.cluster === cluster) ||
          (edge.a.cluster === cluster && edge.b.cluster === aCluster)
        );
      });
    });

    // Bevorzuge historisch resonante Cluster-Paare für Bridge-Bildung
    otherClusters.sort((a, b) => {
      const aResonance = getClusterPairResonance(this.memory, aCluster, a);
      const bResonance = getClusterPairResonance(this.memory, aCluster, b);
      return bResonance - aResonance;
    });

    const bCluster = otherClusters[0] || clusters[1];
    const edge = this.createBridgeBetweenClusters(aCluster, bCluster, { gentle: true });

    if (!edge) return false;

    recordMemoryEvent(this.memory, "denseBridge", this.world.age);
    return true;
  }
}
