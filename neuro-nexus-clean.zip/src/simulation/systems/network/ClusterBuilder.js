import { CONFIG, CLUSTER_TYPES } from "../../../config.js";
import { ClusterRoles, ClusterStates } from "../../clusterRoles.js";
import { clamp } from "../../../utils/math.js";
import { Cluster } from "../../entities/Cluster.js";

/**
 * ClusterBuilder — Cluster-Erstellung und Seed-Verbindungen.
 *
 * Folgt demselben Pattern wie die anderen System-Module:
 * erhält den NetworkBuilder (builder) im Konstruktor und greift
 * über builder.simulation auf die Simulation zu.
 */
export class ClusterBuilder {
  constructor(builder) {
    this.builder = builder;
  }

  get simulation() { return this.builder.simulation; }
  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }

  addCluster(blueprint, options = {}) {
    // Relay-Cluster dürfen maxClusters überschreiten (temporär)
    const isRelay = blueprint.type === "relay" || blueprint.role === "relay";
    if (!isRelay && this.world.clusters.length >= CONFIG.maxClusters) return null;
    if (isRelay && this.world.clusters.length >= CONFIG.maxClusters + CONFIG.relayMaxActive) return null;

    const instant = options.instant ?? (blueprint.role === ClusterRoles.GENESIS && this.world.age > 3);
    const cluster = new Cluster(this.simulation, blueprint, this.world.clusters.length, instant);

    cluster.updateRadius();
    this.world.clusters.push(cluster);
    this.world.dirty = true;

    this.createSeedConnections(cluster, instant);

    if (options.wake !== false) {
      this.simulation.wakeCluster(cluster, instant ? 0.18 : 0.26);
    }

    return cluster;
  }

  createSeedConnections(cluster, instant) {
    // Relay-Cluster haben keine Nodes — keine Seed-Verbindungen nötig
    if (cluster.isRelay || cluster.nodes.length === 0) return;

    const typeConfig = CLUSTER_TYPES[cluster.type] || CLUSTER_TYPES[cluster.role] || CLUSTER_TYPES.exploration;
    const nodes = cluster.nodes;
    const core = nodes[0];
    const coreConnectChance = cluster.state === ClusterStates.SEEDLING ? 0.46 : 0.68;

    for (let i = 1; i < nodes.length; i += 1) {
      if (this.rng.chance(clamp(coreConnectChance + this.personality.attachment * 0.12 - this.personality.volatility * 0.05, 0.42, 0.94))) {
        this.simulation.addEdge(core, nodes[i], {
          instant,
          bridge: false,
          weight: typeConfig.baseWeight * this.rng.range(0.58, 0.92) * this.personality.learningRateMultiplier,
          birthDuration: this.rng.range(3.6, 8.8) * this.personality.connectionIntervalMultiplier
        });
      }
    }

    for (let i = 1; i < nodes.length; i += 1) {
      const nearest = this.builder.findNearestNodes(nodes[i], nodes, cluster.state === ClusterStates.SEEDLING ? 1 : 2);

      for (const target of nearest) {
        if (this.rng.chance(clamp(0.18 + this.personality.curiosity * 0.12 + cluster.plasticityBias * 0.06 - this.personality.caution * 0.08, 0.10, 0.48))) {
          this.simulation.addEdge(nodes[i], target, {
            instant,
            bridge: false,
            weight: typeConfig.baseWeight * this.rng.range(0.36, 0.78) * this.personality.learningRateMultiplier,
            birthDuration: this.rng.range(4.2, 10.5) * this.personality.connectionIntervalMultiplier
          });
        }
      }
    }
  }
}
