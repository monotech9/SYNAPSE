/**
 * RewardSystem — Dopamin-basiertes Belohnungssystem (RPE)
 *
 * GDD §12: Reward wird nicht als Zähler modelliert. Dopaminerge Signale
 * kodieren Reward-Prediction-Errors (RPE):
 *   delta = actualOutcome - expectedOutcome
 *
 *   delta > 0: positiver Dopamin-Impuls → stärkt aktive Hebb-Verbindungen
 *   delta < 0: negativer Signal → beschleunigt Pruning inaktiver Pfade
 *
 * Das System koppelt an:
 *  - PredictionEngine: liefert expectedOutcome (Vorhersage)
 *  - EmotionEngine: liefert actualOutcome (emotionale Bewertung)
 *  - Edge-Objekte: Hebbian-Verstärkung / Pruning-Beschleunigung
 *
 * Events (out):
 *  - "reward:rpe"        — Reward-Prediction-Error { delta, dopamine, action }
 *  - "reward:positive"   — Positiver Dopamin-Impuls { delta, reinforcedEdges }
 *  - "reward:negative"   — Negativer Dopamin-Impuls { delta, prunedEdges }
 *
 * Events (in):
 *  - "prediction:surprise"  — Prediction Error vom PredictionEngine
 *  - "consciousness:ignition" — Bewusste Bewertung eines Events
 *  - "sleep:wakeUp"          — Reset nach Schlaf
 */

const RPE_SMOOTHING = 0.3;        // EWMA smoothing factor
const HEBB_REINFORCE_AMOUNT = 0.03;  // Wie viel eine positive RPE die edge verstärkt
const PRUNE_ACCELERATION = 1.4;   // Wie viel eine negative RPE das Pruning beschleunigt
const DOPAMINE_DECAY = 0.92;      // pro Tick (10Hz)
const MAX_DOPAMINE = 1.0;

export class RewardSystem {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Dopamin-Level (0–1)
    this.dopamine = 0.5;        // baseline
    this._dopamineBaseline = 0.5;

    // RPE-Historie (für Metriken)
    this._rpeHistory = [];
    this._totalPositive = 0;
    this._totalNegative = 0;
    this._reinforcedEdges = 0;
    this._prunedEdges = 0;

    // Letzter RPE
    this._lastRPE = { delta: 0, timestamp: 0 };

    // EventBus subscriptions
    this._off1 = this.events.on("prediction:surprise", (d) => {
      this._processRPE(d.error || 0, d);
    });
    this._off2 = this.events.on("sleep:wakeUp", () => {
      this.dopamine = this._dopamineBaseline;
      this._rpeHistory = [];
    });
  }

  /**
   * Verarbeitet einen Reward-Prediction-Error.
   * delta = actualOutcome - expectedOutcome
   *
   * Im Kontext von Neuro Nexus:
   *  - actualOutcome = wie gut das System auf ein Ereignis reagiert hat
   *    (abgeleitet aus Emotion-Valence + Kohärenz)
   *  - expectedOutcome = was der PredictionEngine vorhergesagt hat
   *    (inverse des Prediction Errors: hohes surprise = niedrige Erwartung)
   *
   * Eine hohe Überraschung (surprise) mit positiver emotionaler Valence
   * = positiver RPE (unerwartet gute Erfahrung).
   * Eine hohe Überraschung mit negativer Valence
   * = negativer RPE (unerwartet schlechte Erfahrung).
   */
  _processRPE(predictionError, data = {}) {
    const emotionEngine = this.sim.emotionEngine;
    if (!emotionEngine) return;

    // Actual outcome: emotionale Valence (-1 to +1 → 0 to 1)
    const snapshot = emotionEngine.getSnapshot();
    const emotionalValence = (snapshot.dominant?.intensity || 0.5) *
      (snapshot.dominant?.valence || 0);  // -1 to +1

    // Expected outcome: inverse of prediction error (high surprise = low expectation)
    const expected = 1.0 - Math.min(1, predictionError);

    // Actual: map emotional valence to 0–1
    const actual = 0.5 + emotionalValence * 0.5;

    // RPE: delta = actual - expected
    const delta = actual - expected;

    // Smooth RPE (EWMA)
    const smoothedDelta = this._lastRPE.delta * (1 - RPE_SMOOTHING) + delta * RPE_SMOOTHING;

    this._lastRPE = { delta: smoothedDelta, timestamp: this.sim.world.age };
    this._rpeHistory.push(smoothedDelta);
    if (this._rpeHistory.length > 50) this._rpeHistory.shift();

    // Dopamin-Level updaten
    this.dopamine = Math.max(0, Math.min(MAX_DOPAMINE,
      this.dopamine * DOPAMINE_DECAY + Math.max(0, smoothedDelta) * 0.3
    ));

    this.events.emit("reward:rpe", {
      delta: smoothedDelta,
      dopamine: this.dopamine,
      predictionError,
      emotionalValence,
      action: data.action || null
    });

    // Koppelung an Hebbian Learning / Pruning
    if (smoothedDelta > 0.05) {
      this._reinforceHebbian(smoothedDelta);
    } else if (smoothedDelta < -0.05) {
      this._acceleratePruning(smoothedDelta);
    }
  }

  /**
   * Positiver Dopamin-Impuls: stärkt aktive Hebb-Verbindungen.
   * Findet die aktivsten Edges und verstärkt deren identityTrace.
   */
  _reinforceHebbian(delta) {
    const w = this.sim.world;
    const amount = HEBB_REINFORCE_AMOUNT * delta;

    // Aktivste Edges finden (die mit hoher Aktivität)
    let reinforced = 0;
    for (const edge of w.edges) {
      // Nur aktive Edges verstärken (Hebb: "neurons that fire together wire together")
      if (edge.activityGlow > 0.15 || edge.pulseEnergy > 0.1) {
        edge.identityTrace = Math.min(1, (edge.identityTrace || 0) + amount);
        edge.weight = Math.min(1, (edge.weight || 0.5) + amount * 0.5);
        reinforced++;
      }
    }

    this._totalPositive++;
    this._reinforcedEdges += reinforced;

    if (reinforced > 0) {
      this.events.emit("reward:positive", {
        delta,
        reinforcedEdges: reinforced,
        amount
      });
    }
  }

  /**
   * Negativer Dopamin-Impuls: beschleunigt Pruning inaktiver Pfade.
   */
  _acceleratePruning(delta) {
    const w = this.sim.world;
    const factor = PRUNE_ACCELERATION * Math.abs(delta);

    // Inaktive Edges abschwächen (Pruning-Kandidaten)
    let pruned = 0;
    for (const edge of w.edges) {
      if (edge.activityGlow < 0.05 && (edge.identityTrace || 0) < 0.2) {
        edge.weight = Math.max(0.01, (edge.weight || 0.5) * (1 - factor * 0.1));
        edge.identityTrace = Math.max(0, (edge.identityTrace || 0) - factor * 0.02);
        pruned++;
      }
    }

    this._totalNegative++;
    this._prunedEdges += pruned;

    if (pruned > 0) {
      this.events.emit("reward:negative", {
        delta,
        prunedEdges: pruned,
        factor
      });
    }
  }

  /**
   * Per-Tick Update: Dopamin-Decay (Rückkehr zur Baseline).
   */
  update(dt) {
    // Langsamer Rückkehr zur Baseline
    this.dopamine = this.dopamine * 0.99 + this._dopamineBaseline * 0.01;
  }

  // ─── API ───────────────────────────────────────────────────────

  getDopamine() { return this.dopamine; }

  getLastRPE() { return this._lastRPE; }

  getSnapshot() {
    const recent = this._rpeHistory.slice(-10);
    const avgRPE = recent.length > 0
      ? recent.reduce((s, d) => s + d, 0) / recent.length
      : 0;
    return {
      dopamine: this.dopamine,
      lastRPE: this._lastRPE.delta,
      avgRPE,
      totalPositive: this._totalPositive,
      totalNegative: this._totalNegative,
      reinforcedEdges: this._reinforcedEdges,
      prunedEdges: this._prunedEdges
    };
  }

  serialize() {
    return {
      dopamine: this.dopamine,
      totalPositive: this._totalPositive,
      totalNegative: this._totalNegative,
      reinforcedEdges: this._reinforcedEdges,
      prunedEdges: this._prunedEdges
    };
  }

  destroy() {
    this._off1?.();
    this._off2?.();
    this._rpeHistory = [];
  }
}
