import { CONFIG } from "../../../config.js";
import { ClusterRoles } from "../../clusterRoles.js";
import { reinforceEdgeMemory, recordMemoryEvent } from "../../memory.js";
import { Edge } from "../../entities/Edge.js";

/**
 * SignalSystem — Signal-Injektion, Wave-Erzeugung und Edge-Verstärkung.
 *
 * Alle Methoden, die Signale in das Netzwerk einspeisen oder visuelle
 * Wellen (injected waves, birth waves) erzeugen, sowie die Kanten-
 * Verstärkung bei Knoten-Aktivierung.
 */
export class SignalSystem {
  constructor(simulation) {
    this.simulation = simulation;
  }

  get world() { return this.simulation.world; }
  get rng() { return this.simulation.rng; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }
  get pulseEngine() { return this.simulation.pulseEngine; }

  // ─── Signal injection ─────────────────────────────────────────────

  injectSignal(screenX, screenY) {
    this.simulation.persistentState.interactionCount += 1;
    this.diagnosticCounters.signalsInjected += 1;
    this.world.pointerEnergy = 1;

    const nearestResult = this.simulation.findNearestNode(screenX, screenY);
    if (!nearestResult) return;
    const nearest = nearestResult.node;
    const now = this.world.currentTime || performance.now() / 1000;

    const origin = nearest.position(now);
    const radius = Math.max(88, this.world.minSide * 0.105) * this.personality.signalRadiusMultiplier / this.simulation.camera.scale;

    for (const cluster of this.world.clusters) {
      const roleSensitivity = cluster.role === ClusterRoles.EXPLORATION ? 1.18 : cluster.role === ClusterRoles.STABLE ? 0.88 : 1;

      for (const node of cluster.nodes) {
        const position = node.position(now);
        const distance = Math.hypot(position.x - origin.x, position.y - origin.y);
        if (distance > radius) continue;

        const falloff = 1 - distance / radius;
        const activation = (0.14 + falloff * 0.42) * this.personality.signalEnergyMultiplier * roleSensitivity;

        node.setActivation(Math.max(node.activation, activation));
        node.charge = Math.max(node.charge, activation);
        node.refractory = Math.max(node.refractory, 0.05);
        this.reinforceNodeEdges(node, 0.012 + falloff * 0.03);
      }
    }

    this.pulseEngine.emitNodePulses(nearest, 0.28, 4, {
      visualOnly: true,
      speedMultiplier: 1.18
    });

    this.createInjectedWave(origin.x, origin.y, radius, { strength: 0.62, life: 1.45 });

    if (this.personality.sensitivity > 0.62 || this.personality.attachment > 0.68) {
      this.world.spontaneousTimer = Math.min(this.world.spontaneousTimer, this.rng.range(0.2, 0.5));
    }
  }

  forceBridge(nodeA, nodeB) {
    if (!nodeA || !nodeB || nodeA === nodeB) return;
    
    // Check if edge already exists
    let existing = this.world.edges.find((e) => (e.a === nodeA && e.b === nodeB) || (e.a === nodeB && e.b === nodeA));

    if (existing) {
      existing.weight = Math.min(0.9, existing.weight + 0.4);
      existing.identityTrace = Math.min(1.0, (existing.identityTrace || 0) + 0.6);
      existing.pathPulseGlow = 1.0;
    } else {
      const edge = new Edge(this.simulation, nodeA, nodeB, {
        bridge: nodeA.cluster !== nodeB.cluster,
        weight: 0.6,
        identityTrace: 0.8,
        pathPulseGlow: 1.0,
        birthDuration: 1.5 // fast birth
      });
      this.world.edges.push(edge);
      this.world.edgeSet.add(this.simulation._edgeKey(nodeA, nodeB));
      if (edge.bridge) this.world.bridgeEdges.push(edge);
      this.world.dirty = true;
      this.diagnosticCounters.bridgesCreated += edge.bridge ? 1 : 0;
      existing = edge;
    }
    
    // Huge pulse to solidify it
    this.pulseEngine.spawnPulse(existing, true, 1.0, { visualOnly: true, speedMultiplier: 1.5 });
    nodeA.visualImpact = 1.0;
    nodeB.visualImpact = 1.0;
    nodeA.thermalLoad = 1.0;
    nodeB.thermalLoad = 1.0;
    
    const now = this.world.currentTime || performance.now() / 1000;
    const origin = nodeA.position(now);
    this.createInjectedWave(origin.x, origin.y, 40 / this.simulation.camera.scale, { strength: 0.8, life: 1.0, rgb: [255, 230, 150] });
  }

  // ─── Edge reinforcement ───────────────────────────────────────────

  reinforceNodeEdges(node, amount) {
    for (const edge of this.world.edges) {
      if (edge.a !== node && edge.b !== node) continue;

      reinforceEdgeMemory(edge, amount * this.personality.memoryLearningMultiplier * node.cluster.retentionBias);
      this.memory.strongestTrace = Math.max(this.memory.strongestTrace, edge.identityTrace || 0);
    }

    if (this.memory.strongestTrace > 0.34 && this.memory.events.length === 0) {
      recordMemoryEvent(this.memory, "firstTrace", this.world.age);
    }
  }

  // ─── Injected waves ───────────────────────────────────────────────

  createInjectedWave(x, y, radius, options = {}) {
    if (this.world.injectedWaves.length > CONFIG.maxInjectedWaves) {
      this.world.injectedWaves.shift();
    }

    this.diagnosticCounters.visibleWaveEvents += 1;
    this.world.injectedWaves.push({
      x,
      y,
      radius,
      age: 0,
      life: options.life ?? 1.25,
      strength: (options.strength ?? 0.5) * this.personality.signalEnergyMultiplier,
      rgb: options.rgb || null
    });
  }

  createNodeBirthWave(node, strength = 0.32) {
    if (!node) return;
    const position = node.position(this.world.currentTime || performance.now() / 1000);
    this.diagnosticCounters.visibleBirthEvents += 1;
    this.createInjectedWave(position.x, position.y, Math.max(34, node.cluster.pixelRadius * 0.42), {
      strength,
      life: 1.45
    });
  }

  createClusterBirthWave(cluster, strength = 0.58) {
    if (!cluster) return;
    const center = cluster.center(this.world.currentTime || performance.now() / 1000);
    this.diagnosticCounters.visibleBirthEvents += 1;
    this.createInjectedWave(center.x, center.y, Math.max(64, cluster.pixelRadius * 1.2), {
      strength,
      life: 1.9
    });
  }
}
