import { clamp } from "../../../utils/math.js";
import { CONFIG } from "../../../config.js";
import { reinforceEdgeMemory, recordMemoryEvent } from "../../memory.js";

export class PulseEngine {
  constructor(simulation) {
    this.simulation = simulation;
    // Object Pool für Pulse-Objekte — vermeidet GC-Pressure bei hoher Aktivität
    this._pool = [];
    this._poolMax = 64;
  }

  get world()             { return this.simulation.world; }
  get rng()               { return this.simulation.rng; }
  get personality()       { return this.simulation.personality; }
  get memory()            { return this.simulation.memory; }
  get diagnosticCounters(){ return this.simulation.diagnosticCounters; }

  // ─── Object Pool ─────────────────────────────────────────────────

  _acquirePulse() {
    return this._pool.length > 0
      ? this._pool.pop()
      : { edge: null, from: null, to: null, t: 0, speed: 1, strength: 0.1, visualOnly: false };
  }

  _releasePulse(pulse) {
    if (this._pool.length >= this._poolMax) return;
    // Referenzen nullen um Memory-Leaks zu vermeiden
    pulse.edge = null;
    pulse.from = null;
    pulse.to   = null;
    pulse.t    = 0;
    pulse.speed = 1;
    pulse.strength = 0.1;
    pulse.visualOnly = false;
    this._pool.push(pulse);
  }

  // ─── Pulse Spawning ───────────────────────────────────────────────

  spawnPulse(edge, forward, strength, options = {}) {
    if (!edge) return;

    // Refraktärzeit: Kanten mit zu vielen kürzlichen Pulsen werden gedrosselt.
    // visualOnly-Pulse werden großzügiger behandelt (doppeltes Fenster).
    const visualOnly = Boolean(options.visualOnly);
    const refractory = CONFIG.edgeRefractoryWindow * (visualOnly ? 2.0 : 1.0);
    if ((edge.recentPulseCount || 0) >= CONFIG.edgeRefractoryMaxPulses && refractory > 0) {
      return;
    }
    edge.recentPulseCount = (edge.recentPulseCount || 0) + 1;

    // Consciousness: broadcast pulse spike to workspace
    if (this.world.pulses.length > 50 && Math.random() < 0.08) {
      this.simulation.events.emit("pulse:spike", { count: this.world.pulses.length });
    }
    if (this.world.pulses.length > CONFIG.maxPulses) {
      const oldest = this.world.pulses.shift();
      this._releasePulse(oldest);
    }

    const clampedStrength = clamp(strength, 0.08, visualOnly ? 0.48 : 0.72);

    this.diagnosticCounters.pulsesSpawned += 1;
    if (visualOnly) {
      this.diagnosticCounters.ambientPulseEvents += 1;
      if (options.preferredPath) this.diagnosticCounters.preferredPathPulseEvents += 1;
      if (options.support) this.diagnosticCounters.supportPulseEvents += 1;
      if (edge.bridge || options.bridge) this.diagnosticCounters.bridgePulseEvents += 1;
    }

    if (options.preferredPath) {
      edge.pathPulseGlow = Math.max(edge.pathPulseGlow || 0, 0.42 + clampedStrength * 0.38);
    }

    edge.visualActivity = Math.max(edge.visualActivity || 0, (visualOnly ? 0.25 : 0.28) + clampedStrength * (visualOnly ? 0.46 : 0.68));
    edge.a.visualImpact = Math.max(edge.a.visualImpact || 0, visualOnly ? 0.16 + clampedStrength * 0.32 : 0.36);
    edge.b.visualImpact = Math.max(edge.b.visualImpact || 0, visualOnly ? 0.14 + clampedStrength * 0.28 : 0.3);

    // Synaptische Ermüdung
    edge.applyFatigue(visualOnly ? 0.03 : 0.08);

    // Nachglühen
    edge.afterglow = Math.min(1, (edge.afterglow || 0) + (visualOnly ? 0.25 : 0.45));

    const pulse = this._acquirePulse();
    pulse.edge     = edge;
    pulse.from     = forward ? edge.a : edge.b;
    pulse.to       = forward ? edge.b : edge.a;
    pulse.t        = 0;
    pulse.speed    = this.rng.range(0.48, 0.9)
                     * (edge.bridge ? 0.68 : 1)
                     * this.personality.pulseSpeedMultiplier
                     * (options.speedMultiplier || 1);
    pulse.strength  = clampedStrength;
    pulse.visualOnly = visualOnly;
    this.world.pulses.push(pulse);
  }

  emitNodePulses(node, strength = 0.22, limit = 2, options = {}) {
    const edges = this.world.edges
      .filter(e => e.birthProgress > 0.32 && (e.a === node || e.b === node))
      .sort((a, b) => ((b.identityTrace || 0) + b.weight) - ((a.identityTrace || 0) + a.weight));

    let emitted = 0;
    for (const edge of edges) {
      if (emitted >= limit) break;
      const forward = edge.a === node;
      this.spawnPulse(edge, forward, strength + (edge.identityTrace || 0) * 0.18, options);
      if (!options.visualOnly) {
        edge.cooldown = Math.max(edge.cooldown, 0.42);
      }
      emitted += 1;
    }
  }

  /**
   * Pulse-Lifecycle-Update — verarbeitet Pulse-Ankunft mit:
   *  - Causal Delay (visuelle Puls-Verzögerung)
   *  - Aktivierungs-Propagation für nicht-visuelle Pulse
   *  - Edge-Glow / VisualActivity
   *  - Memory-Verstärkung (reinforceEdgeMemory)
   *  - Event-Recording (firstTrace, strongTrace)
   *  - Audio-Feedback
   *  - Refraktär-Decay
   */
  updatePulses(dt) {
    // Refraktär-Decay
    const decayRate = dt / Math.max(0.001, CONFIG.edgeRefractoryWindow);
    for (const edge of this.world.edges) {
      if (edge.recentPulseCount > 0) {
        edge.recentPulseCount = Math.max(0, edge.recentPulseCount - decayRate * CONFIG.edgeRefractoryMaxPulses);
      }
    }

    for (let i = this.world.pulses.length - 1; i >= 0; i -= 1) {
      const pulse = this.world.pulses[i];
      pulse.t += dt * pulse.speed;

      if (pulse.t < 1) continue;

      // ── Pulse-Ankunft: Wirkung auf Ziel-Node und Edge ──

      if (pulse.visualOnly) {
        // Causal delay: Energie wird auf dem Ziel-Node gestaffelt, nicht sofort appliziert.
        // Die update() des Nodes feuert die Antwort ~0.12s später — lesbare Sequenz:
        // Quelle feuert → Pulse reist → Ziel antwortet.
        pulse.to.incomingPulseEnergy = Math.max(pulse.to.incomingPulseEnergy || 0, 0.18 + pulse.strength * 0.34);
        pulse.to.incomingPulseTimer = Math.max(pulse.to.incomingPulseTimer || 0, 0.12);
        // Post-arrival Edge-Glow: Edge leuchtet kurz nach Ankunft weiter.
        pulse.edge.visualActivity = Math.max(pulse.edge.visualActivity || 0, 0.28 + pulse.strength * 0.46);
      } else {
        // Vollständige Aktivierungs-Propagation
        pulse.to.setActivation(Math.max(
          pulse.to.activation,
          pulse.from.activation * 0.48 + pulse.strength * 0.18
        ));
        pulse.to.charge = Math.max(pulse.to.charge, pulse.strength);
        pulse.to.refractory = 0.08;
        // Auch nicht-visuelle Pulse bekommen Causal Delay auf visualImpact.
        pulse.to.incomingPulseEnergy = Math.max(pulse.to.incomingPulseEnergy || 0, 0.4 + pulse.strength * 0.42);
        pulse.to.incomingPulseTimer = Math.max(pulse.to.incomingPulseTimer || 0, 0.12);
        pulse.edge.visualActivity = Math.max(pulse.edge.visualActivity || 0, 0.38 + pulse.strength * 0.66);

        // Memory-Verstärkung
        reinforceEdgeMemory(pulse.edge, 0.032 + pulse.strength * 0.06 * this.personality.memoryLearningMultiplier);
        this.memory.strongestTrace = Math.max(this.memory.strongestTrace, pulse.edge.identityTrace || 0);

        // Memory-Events
        if ((pulse.edge.identityTrace || 0) > 0.42 && this.memory.events.length === 0) {
          recordMemoryEvent(this.memory, "firstTrace", this.world.age);
        }
        if ((pulse.edge.identityTrace || 0) > 0.74) {
          recordMemoryEvent(this.memory, "strongTrace", this.world.age);
        }
      }

      // Audio-Feedback bei Pulse-Abschluss
      if (this.simulation.audio?.enabled) {
        this.simulation.audio.playPulse(pulse.edge, pulse.strength);
      }

      this.world.pulses.splice(i, 1);
      this._releasePulse(pulse);
    }
  }
}
