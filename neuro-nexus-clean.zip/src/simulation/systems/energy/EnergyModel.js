/**
 * EnergyModel — Environment Layer: Energie-Haushalt (GDD §9)
 *
 * Das Netzwerk hat einen begrenzten Energie-Budget. Wachstum,
 * Signale und Bewusstseins-Aktivität verbrauchen Energie.
 * Ruhe und Schlaf regenerieren Energie.
 *
 * Energie beeinflusst:
 *  - Wachstumsrate (niedrige Energie → weniger Wachstum)
 *  - Signal-Stärke (niedrige Energie → schwächere Signale)
 *  - Bewusstseins-Klarheit (niedrige Energie → weniger kohärent)
 *  - Schlaf-Auslösung (sehr niedrige Energie → Müdigkeit → Schlaf)
 *
 * Events (out):
 *  - "energy:low"      — Energie unter 30% { level }
 *  - "energy:critical" — Energie unter 10% { level }
 *  - "energy:recovered" — Energie über 50% nach kritischer Phase { level }
 */

const MAX_ENERGY = 1.0;
const BASE_DECAY = 0.0003;           // pro Tick (30Hz)
const GROWTH_COST = 0.002;           // pro Node-Wachstum
const SIGNAL_COST = 0.0005;          // pro Signal
const CONSCIOUSNESS_COST = 0.0008;   // pro Ignition
const SLEEP_RESTORE = 0.0008;        // pro Tick im Schlaf
const FATIGUE_THRESHOLD = 0.2;       // ab hier Müdigkeit
const CRITICAL_THRESHOLD = 0.1;      // ab hier kritisch

export class EnergyModel {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    this.energy = MAX_ENERGY;
    this._wasCritical = false;
    this._wasLow = false;

    // EventBus: Wachstum und Signale kosten Energie
    this._off1 = this.events.on("growth:nodeAdded", () => {
      this.energy = Math.max(0, this.energy - GROWTH_COST);
    });
    this._off2 = this.events.on("signal:injected", () => {
      this.energy = Math.max(0, this.energy - SIGNAL_COST);
    });
    this._off3 = this.events.on("consciousness:ignition", (d) => {
      if (d.salience > 0.5) {
        this.energy = Math.max(0, this.energy - CONSCIOUSNESS_COST);
      }
    });
    // Schlaf regeneriert Energie
    this._off4 = this.events.on("sleep:stateChange", (d) => {
      // Wird im update über sleepState gehandelt
    });
  }

  update(dt) {
    // Basis-Decay (Metabolismus)
    this.energy = Math.max(0, this.energy - BASE_DECAY * dt * 30);

    // Schlaf regeneriert
    const sleepState = this.sim.consciousness?.selfModel?.selfModel?.sleepState;
    if (sleepState && sleepState !== "WAKE") {
      this.energy = Math.min(MAX_ENERGY, this.energy + SLEEP_RESTORE * dt * 30);
    }

    // Low-Energy Events
    if (this.energy < CRITICAL_THRESHOLD && !this._wasCritical) {
      this._wasCritical = true;
      this.events.emit("energy:critical", { level: this.energy });
    } else if (this.energy < FATIGUE_THRESHOLD && !this._wasLow) {
      this._wasLow = true;
      this.events.emit("energy:low", { level: this.energy });
    } else if (this.energy > 0.5 && this._wasCritical) {
      this._wasCritical = false;
      this._wasLow = false;
      this.events.emit("energy:recovered", { level: this.energy });
    }

    // Energie-Modulation an andere Systeme
    // Niedrige Energie → reduzierte Wachstumsrate
    // (wird über modulation-Faktor von anderen Systemen gelesen)
  }

  /**
   * Energie-Multiplikator für Wachstum (0–1).
   * Bei voller Energie → 1.0, bei niedriger → reduziert.
   */
  getGrowthMultiplier() {
    return clamp01(0.3 + this.energy * 0.7);
  }

  /**
   * Energie-Multiplikator für Signal-Stärke (0–1).
   */
  getSignalMultiplier() {
    return clamp01(0.5 + this.energy * 0.5);
  }

  /**
   * Ist das System müde (Energie < FATIGUE_THRESHOLD)?
   */
  isFatigued() {
    return this.energy < FATIGUE_THRESHOLD;
  }

  getEnergy() { return this.energy; }

  getSnapshot() {
    return {
      energy: this.energy,
      fatigued: this.isFatigued(),
      wasCritical: this._wasCritical,
      wasLow: this._wasLow
    };
  }

  serialize() {
    return { energy: this.energy };
  }

  reset() {
    this.energy = MAX_ENERGY;
    this._wasCritical = false;
    this._wasLow = false;
  }

  destroy() {
    this._off1?.();
    this._off2?.();
    this._off3?.();
    this._off4?.();
  }
}

function clamp01(v) { return Math.max(0, Math.min(1, v)); }
