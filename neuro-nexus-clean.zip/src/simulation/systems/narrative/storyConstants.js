/**
 * storyConstants — Konstanten für StoryMappingEngine
 *
 *  - StoryEventType: Kategorie des Lebensereignisses
 *  - EmotionTag: Emotionale Valenz des Ereignisses
 */

export const StoryEventType = Object.freeze({
  MILESTONE: "milestone",   // CRITICAL_SPIKE — Wendepunkt, Einmaligkeit
  MAJOR:     "major",       // PHASE_SHIFT — Bedeutsame Transformation
  MINOR:     "minor"        // TRANSITION — Kleine Entwicklung
});

export const EmotionTag = Object.freeze({
  AWAKENING:      "awakening",
  WONDER:         "wonder",
  LOSS:           "loss",
  TENSION:        "tension",
  CALM:           "calm",
  TRANSFORMATION: "transformation",
  CONNECTION:     "connection",
  EXPLORATION:    "exploration",
  CLARITY:        "clarity",
  REST:           "rest",
  GROWTH:         "growth"
});
