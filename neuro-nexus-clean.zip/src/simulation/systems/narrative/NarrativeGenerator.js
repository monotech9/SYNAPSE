/**
 * NarrativeGenerator — Generierung von Kapitel-Zusammenfassungen,
 * Lebensnarrativ und Life-Themes
 *
 * Funktionen:
 *  - generateChapterSummary: Zusammenfassung eines einzelnen Kapitels
 *  - updateLifeNarrative: Komplettes Lebensnarrativ aus allen Kapiteln
 *  - generateOverallSummary: Gesamtüberblick
 *  - detectLifeThemes: Wiederkehrende Themen erkennen
 */

import {
  VALENCE_LABELS_DE,
  LIFE_NARRATIVE_INTROS,
  EMOTION_SHIFT_THRESHOLD,
  themeLabelDe,
  emotionLabelDe
} from "../memory/autobioConstants.js";

/**
 * Generiert eine Zusammenfassung für ein einzelnes Kapitel.
 * @param {Object} chapter
 * @param {EpisodicMemory} episodic
 * @returns {string}
 */
export function generateChapterSummary(chapter, episodic) {
  const episodes = episodic.getAll().filter(ep => chapter.episodeIds.includes(ep.id));
  if (episodes.length === 0) return "";

  // Dominant emotion in chapter
  const sortedEmos = [...chapter.dominantEmotions].sort((a, b) => b.count - a.count);
  const topEmo = sortedEmos[0]?.emotion || "neutral";

  // Emotional tone
  const balance = chapter.emotionalBalance;
  const total = balance.positive + balance.negative + balance.neutral;
  const posRatio = balance.positive / Math.max(1, total);
  const negRatio = balance.negative / Math.max(1, total);

  let tone;
  if (posRatio > 0.5) tone = "positive";
  else if (negRatio > 0.5) tone = "negative";
  else if (posRatio > 0.3 && negRatio > 0.3) tone = "mixed";
  else tone = "neutral";

  // Pick representative episode (strongest)
  const representative = episodes.reduce((a, b) => a.strength > b.strength ? a : b);

  const phaseLabel = chapter.phaseLabel || "Phase";
  const valenceDesc = VALENCE_LABELS_DE[tone] || "ausgewogen";

  let summary = `${chapter.title} (${phaseLabel}, ${valenceDesc}). `;
  summary += `${episodes.length} Erlebnisse. `;
  if (topEmo !== "neutral") {
    summary += `Geprägt von ${emotionLabelDe(topEmo)}. `;
  }
  summary += `Höhepunkt: "${representative.text.substring(0, 60)}". `;
  if (chapter.phiRange.max > 0) {
    summary += `Φ zwischen ${Math.round(chapter.phiRange.min * 100)} und ${Math.round(chapter.phiRange.max * 100)}.`;
  }

  return summary;
}

/**
 * Generiert das komplette Lebensnarrativ aus allen Kapiteln.
 * @param {Object[]} chapters
 * @param {EpisodicMemory} episodic
 * @returns {string}
 */
export function updateLifeNarrative(chapters, episodic) {
  if (chapters.length === 0) return "";

  const parts = [];
  const totalChapters = chapters.length;

  parts.push(generateOverallSummary(chapters, episodic));

  for (let i = 0; i < totalChapters; i++) {
    const ch = chapters[i];
    let intro;
    if (i === 0) intro = LIFE_NARRATIVE_INTROS.early;
    else if (i === totalChapters - 1 && !ch.isClosed) intro = LIFE_NARRATIVE_INTROS.recent;
    else intro = LIFE_NARRATIVE_INTROS.middle;

    const summary = ch.summary || generateChapterSummary(ch, episodic);
    if (summary) {
      parts.push(`${intro}: ${summary}`);
    }
  }

  return parts.join(" ");
}

/**
 * Generiert eine Gesamtübersicht über alle Episoden und Kapitel.
 * @param {Object[]} chapters
 * @param {EpisodicMemory} episodic
 * @returns {string}
 */
export function generateOverallSummary(chapters, episodic) {
  const total = episodic.episodes.length;
  const forgotten = episodic._forgotten.length;
  const snapshot = episodic.getSnapshot();
  const closedChapters = chapters.filter(c => c.isClosed).length;

  let s = `${LIFE_NARRATIVE_INTROS.overall}: `;
  s += `${total} Erlebnisse in ${chapters.length} Kapiteln (${closedChapters} abgeschlossen). `;
  if (forgotten > 0) {
    s += `${forgotten} Erinnerungen verblasst. `;
  }
  if (snapshot.avgStrength !== undefined) {
    s += `Durchschnittliche Erinnerungsstärke: ${Math.round(snapshot.avgStrength * 100)}%.`;
  }
  return s;
}

/**
 * Erkennt wiederkehrende Themen über alle Kapitel hinweg.
 * @param {Object[]} chapters
 * @returns {Array} — [{ emotion, count, label }]
 */
export function detectLifeThemes(chapters) {
  const emotionCounts = new Map();

  for (const ch of chapters) {
    for (const { emotion, count } of ch.dominantEmotions) {
      emotionCounts.set(emotion, (emotionCounts.get(emotion) || 0) + count);
    }
  }

  // Sort by count descending, take top 5
  const themes = [...emotionCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([emotion, count]) => ({
      emotion,
      count,
      label: themeLabelDe(emotion)
    }));

  return themes;
}
