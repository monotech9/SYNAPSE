/**
 * ChapterFactory — Erstellung und Verwaltung von Lebenskapiteln
 *
 * Funktionen:
 *  - createChapter: Neues Kapitel aus erster Episode
 *  - updateChapterData: Episode zu Kapitel hinzufügen
 *  - closeChapter: Kapitel abschließen
 *  - chapterAverageValence: Durchschnitts-Valenz eines Kapitels
 *  - chapterSummary: Reduzierter Snapshot für Events/API
 *  - mergeOldestChapters: Zwei alte Kapitel verschmelzen
 *  - derivePhaseLabel: Phasen-Label aus Kapitel-Nummer
 */

import {
  CHAPTER_TITLES,
  VALENCE_LABELS_DE,
  MIN_EPISODES_PER_CHAPTER,
  MAX_CHAPTERS,
  EMOTION_SHIFT_THRESHOLD
} from "../memory/autobioConstants.js";
import { emotionLabelDe } from "../memory/autobioConstants.js";

let chapterCounter = 0;

/**
 * Erstellt ein neues Lebenskapitel aus der ersten Episode.
 * @param {Object} firstEpisode
 * @param {string} phaseLabel
 * @returns {Object} — Neues Kapitel-Objekt
 */
export function createChapter(firstEpisode, phaseLabel) {
  const valence = firstEpisode.valence;
  const valenceKey = valence > 0 ? "positive" : valence < 0 ? "negative" : "neutral";

  const titles = CHAPTER_TITLES[valenceKey] || CHAPTER_TITLES.neutral;
  const title = titles[Math.floor(Math.random() * titles.length)];

  return {
    id: `chapter_${++chapterCounter}`,
    title,
    phaseLabel,
    valenceKey,
    startTime: firstEpisode.timestamp,
    endTime: firstEpisode.timestamp,
    episodeIds: [],
    episodeCount: 0,
    emotionalBalance: { positive: 0, negative: 0, neutral: 0 },
    summary: "",
    dominantEmotions: [],
    phiRange: { min: firstEpisode.phi, max: firstEpisode.phi },
    growthStages: new Set([firstEpisode.growthStage]),
    isClosed: false
  };
}

/**
 * Aktualisiert ein Kapitel mit Daten aus einer neuen Episode.
 * @param {Object} chapter — Mutable Kapitel-Objekt
 * @param {Object} episode
 */
export function updateChapterData(chapter, episode) {
  chapter.endTime = episode.timestamp;
  chapter.episodeIds.push(episode.id);
  chapter.episodeCount++;

  // Emotional balance
  if (episode.valence > 0) chapter.emotionalBalance.positive++;
  else if (episode.valence < 0) chapter.emotionalBalance.negative++;
  else chapter.emotionalBalance.neutral++;

  // Phi range
  chapter.phiRange.min = Math.min(chapter.phiRange.min, episode.phi);
  chapter.phiRange.max = Math.max(chapter.phiRange.max, episode.phi);

  // Growth stages
  chapter.growthStages.add(episode.growthStage);

  // Track dominant emotions
  const emo = episode.dominantEmotion;
  if (emo && emo !== "neutral") {
    const existing = chapter.dominantEmotions.find(e => e.emotion === emo);
    if (existing) existing.count++;
    else chapter.dominantEmotions.push({ emotion: emo, count: 1 });
  }
}

/**
 * Schließt ein Kapitel ab (markiert als geschlossen, generiert Zusammenfassung).
 * @param {Object} chapter
 * @param {function} generateSummary — _generateChapterSummary callback
 * @returns {Object} — chapterSummary für Event
 */
export function closeChapter(chapter, generateSummary) {
  chapter.isClosed = true;
  chapter.summary = generateSummary(chapter);
  return chapterSummary(chapter);
}

/**
 * Berechnet die durchschnittliche Valenz eines Kapitels.
 * @param {Object} chapter
 * @returns {number} — -1 bis +1
 */
export function chapterAverageValence(chapter) {
  if (chapter.episodeCount === 0) return 0;
  const total = chapter.emotionalBalance;
  const sum = total.positive - total.negative;
  return sum / chapter.episodeCount;
}

/**
 * Gibt einen reduzierten Snapshot eines Kapitels zurück (für Events/API).
 * @param {Object} chapter
 * @returns {Object}
 */
export function chapterSummary(chapter) {
  return {
    id: chapter.id,
    title: chapter.title,
    phaseLabel: chapter.phaseLabel,
    episodeCount: chapter.episodeCount,
    valenceKey: chapter.valenceKey,
    emotionalBalance: { ...chapter.emotionalBalance },
    isClosed: chapter.isClosed,
    summary: chapter.summary || ""
  };
}

/**
 * Verschmilzt die zwei ältesten Kapitel.
 * @param {Object[]} chapters — Mutable Array (wird in-place modifiziert)
 * @param {function} generateSummary — _generateChapterSummary callback
 */
export function mergeOldestChapters(chapters, generateSummary) {
  if (chapters.length < 2) return;
  const first = chapters[0];
  const second = chapters[1];

  // Merge into first
  first.episodeIds.push(...second.episodeIds);
  first.episodeCount += second.episodeCount;
  first.emotionalBalance.positive += second.emotionalBalance.positive;
  first.emotionalBalance.negative += second.emotionalBalance.negative;
  first.emotionalBalance.neutral += second.emotionalBalance.neutral;
  first.endTime = second.endTime;
  first.phiRange.min = Math.min(first.phiRange.min, second.phiRange.min);
  first.phiRange.max = Math.max(first.phiRange.max, second.phiRange.max);
  second.growthStages.forEach(s => first.growthStages.add(s));
  first.summary = generateSummary(first);
  first.isClosed = true;

  // Remove second
  chapters.splice(1, 1);
}

/**
 * Leitet ein Phasen-Label aus der Kapitel-Nummer ab.
 * @param {number} chapterCount
 * @returns {string}
 */
export function derivePhaseLabel(chapterCount) {
  if (chapterCount <= 1) return "Frühe Phase";
  if (chapterCount <= 3) return "Mittlere Phase";
  if (chapterCount <= 6) return "Späte Phase";
  return "Reife Phase";
}

// Re-export Konstanten für Abwärtskompatibilität
export { MIN_EPISODES_PER_CHAPTER, MAX_CHAPTERS, EMOTION_SHIFT_THRESHOLD };
