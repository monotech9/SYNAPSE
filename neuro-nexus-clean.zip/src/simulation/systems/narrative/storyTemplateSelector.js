/**
 * storyTemplateSelector — Wählt Narrative-Templates basierend auf ED-Signalen
 *
 * Analysiert das Signal-Pattern eines EmergenceDetector-Results
 * und wählt die passenden Templates, emotionale Valenz und
 * Lebensereignis-Kategorie.
 */

import { StoryEventType, EmotionTag } from "./storyConstants.js";
import {
  CRITICAL_SPIKE_TEMPLATES,
  PHASE_SHIFT_STRUCTURE_TEMPLATES,
  PHASE_SHIFT_NOVELTY_TEMPLATES,
  PHASE_SHIFT_AVALANCHE_TEMPLATES,
  PHASE_SHIFT_SYNC_TEMPLATES,
  TRANSITION_AVALANCHE_TEMPLATES,
  TRANSITION_STRUCTURE_TEMPLATES,
  TRANSITION_EXPLORATION_TEMPLATES,
  TRANSITION_FOCUS_TEMPLATES,
  TRANSITION_SYNC_TEMPLATES,
} from "./storyTemplates.js";

/**
 * Wählt die passenden Templates basierend auf dem Signal-Pattern.
 * @param {Object} result — ED-Result mit .level und .signals
 * @returns {{ templates: function[], emotion: string, category: string }}
 */
export function selectTemplates(result) {
  const s = result.signals;
  const level = result.level;

  // ── CRITICAL_SPIKE ────────────────────────────────────────────────
  if (level === "CRITICAL_SPIKE") {
    return {
      templates: CRITICAL_SPIKE_TEMPLATES,
      emotion: EmotionTag.AWAKENING,
      category: StoryEventType.MILESTONE
    };
  }

  // ── PHASE_SHIFT — nach dominantem Signal differenzieren ───────────
  if (level === "PHASE_SHIFT") {
    if (s.structureDrift > 0.35 && s.structureDrift >= s.avalanche) {
      return {
        templates: PHASE_SHIFT_STRUCTURE_TEMPLATES,
        emotion: EmotionTag.TRANSFORMATION,
        category: StoryEventType.MAJOR
      };
    }
    if (s.miDrift < 0.4 && s.entropy > 0.5) {
      return {
        templates: PHASE_SHIFT_NOVELTY_TEMPLATES,
        emotion: EmotionTag.WONDER,
        category: StoryEventType.MAJOR
      };
    }
    if (s.avalanche > 0.6 && s.avalanche >= s.sync) {
      return {
        templates: PHASE_SHIFT_AVALANCHE_TEMPLATES,
        emotion: EmotionTag.TENSION,
        category: StoryEventType.MAJOR
      };
    }
    if (s.sync > 0.6) {
      return {
        templates: PHASE_SHIFT_SYNC_TEMPLATES,
        emotion: EmotionTag.CONNECTION,
        category: StoryEventType.MAJOR
      };
    }
    // Fallback
    return {
      templates: PHASE_SHIFT_STRUCTURE_TEMPLATES,
      emotion: EmotionTag.TRANSFORMATION,
      category: StoryEventType.MAJOR
    };
  }

  // ── TRANSITION — feiner differenzieren ────────────────────────────
  if (s.avalanche > 0.5 && s.avalanche >= s.structureDrift) {
    return {
      templates: TRANSITION_AVALANCHE_TEMPLATES,
      emotion: EmotionTag.TENSION,
      category: StoryEventType.MINOR
    };
  }
  if (s.structureDrift > 0.3) {
    return {
      templates: TRANSITION_STRUCTURE_TEMPLATES,
      emotion: EmotionTag.GROWTH,
      category: StoryEventType.MINOR
    };
  }
  if (s.entropy > 0.65) {
    return {
      templates: TRANSITION_EXPLORATION_TEMPLATES,
      emotion: EmotionTag.EXPLORATION,
      category: StoryEventType.MINOR
    };
  }
  if (s.entropy < 0.3) {
    return {
      templates: TRANSITION_FOCUS_TEMPLATES,
      emotion: EmotionTag.CALM,
      category: StoryEventType.MINOR
    };
  }
  if (s.sync > 0.5) {
    return {
      templates: TRANSITION_SYNC_TEMPLATES,
      emotion: EmotionTag.CONNECTION,
      category: StoryEventType.MINOR
    };
  }

  // Generic fallback
  return {
    templates: TRANSITION_EXPLORATION_TEMPLATES,
    emotion: EmotionTag.EXPLORATION,
    category: StoryEventType.MINOR
  };
}
