/**
 * StoryMappingEngine — Übersetzt Emergence-Detector-Events in Lebensereignisse.
 *
 * Der ED misst: "Hier ändert sich die Organisationsform."
 * Die StoryEngine übersetzt: "Was bedeutet das für das Wesen?"
 *
 * Sie lauscht auf EventBus-Events vom EmergenceDetector:
 *   "emergence:detected"  → TRANSITION oder höher
 *   "emergence:phaseShift"→ PHASE_SHIFT oder CRITICAL_SPIKE
 *
 * Und erzeugt daraus:
 *   - Narrative Texte (Deutsch, mit Variationen gegen Wiederholung)
 *   - Emotionale Valenz (wonder, loss, tension, calm, awakening, ...)
 *   - Lebensereignis-Kategorien (milestone / major / minor)
 *   - Eine autobiografische Timeline (story log)
 *
 * Events auf dem EventBus:
 *   "story:event"     — neues Lebensereignis generiert
 *   "story:milestone" — besonders signifikantes Ereignis
 *
 * Module:
 *   - storyConstants.js        — StoryEventType, EmotionTag
 *   - storyTemplates.js        — Narrative Vorlagen
 *   - storyTemplateSelector.js — Template-Auswahl-Logik
 *
 * Integration:
 *   - HudPanel kann story:event abonnieren → EpochLogWidget.addLog/addEpoch
 *   - SelfModelEngine kann story:event für narrativeThread nutzen
 *   - Zukünftige EmotionEngine kann emotionale Valenz verarbeiten
 */

import { StoryEventType } from "./storyConstants.js";
import { selectTemplates } from "./storyTemplateSelector.js";

// Re-export für Abwärtskompatibilität
export { StoryEventType, EmotionTag } from "./storyConstants.js";

export class StoryMappingEngine {
  /**
   * @param {NeuroSimulation} simulation
   * @param {object} [options]
   * @param {number} [options.maxEvents=50] — Max Anzahl gespeicherter Lebensereignisse
   */
  constructor(simulation, options = {}) {
    this.simulation = simulation;
    this.events = simulation.events;

    this.maxEvents = options.maxEvents ?? 50;

    // Autobiografische Timeline
    this.timeline = [];

    // Letzte Emotion für Verlaufskohärenz
    this.lastEmotion = null;

    // Zähler für variation — verhindert unmittelbare Wiederholung desselben Templates
    this._lastTemplateIndex = -1;
    this._lastWasPhaseShift = false;

    // EventBus subscribieren
    this._subscribe();
  }

  // ─── Convenience ───────────────────────────────────────────────────

  get world() { return this.simulation.world; }
  get identity() { return this.simulation.identity; }
  get rng() { return this.simulation.rng; }

  // ─── EventBus Subscriptions ────────────────────────────────────────

  _subscribe() {
    this._offDetected = this.events.on("emergence:detected", (result) => {
      this._processEvent(result);
    });

    this._offPhaseShift = this.events.on("emergence:phaseShift", (_result) => {
      this._lastWasPhaseShift = true;
    });
  }

  // ─── Event verarbeiten → Lebensereignis generieren ──────────────────

  _processEvent(result) {
    const selection = selectTemplates(result);
    const templates = selection.templates;

    // Template wählen, Wiederholung vermeiden
    let templateIndex = this.rng.int(0, templates.length - 1);
    if (templates.length > 1 && templateIndex === this._lastTemplateIndex) {
      templateIndex = (templateIndex + 1) % templates.length;
    }
    this._lastTemplateIndex = templateIndex;

    // Kontext aufbauen
    const ctx = {
      name: this.identity?.name || "das Netz",
      age: this.world.age,
      epoch: result.epoch,
      signals: result.signals,
      prevEvent: this.timeline[this.timeline.length - 1] || null,
      stats: result.stats || {},
      rng: this.rng
    };

    // Text generieren
    const text = templates[templateIndex](ctx);

    // Story Event konstruieren
    const storyEvent = {
      id: `story_${this.timeline.length}`,
      timestamp: this.world.age,
      epoch: result.epoch,
      edScore: result.score,
      edLevel: result.level,
      text,
      emotion: selection.emotion,
      category: selection.category,
      signals: { ...result.signals },
      interpretation: result.interpretation || "",
      wasPhaseShift: this._lastWasPhaseShift || false
    };
    this._lastWasPhaseShift = false;

    // Timeline aktualisieren
    this.timeline.push(storyEvent);
    if (this.timeline.length > this.maxEvents) this.timeline.shift();

    // Letzte Emotion aktualisieren
    this.lastEmotion = selection.emotion;

    // EventBus Events feuern
    this.events.emit("story:event", storyEvent);

    if (selection.category === StoryEventType.MILESTONE) {
      this.events.emit("story:milestone", storyEvent);
    }
  }

  // ─── API: Timeline abfragen ────────────────────────────────────────

  getTimeline(limit = 20) {
    return this.timeline.slice(-limit);
  }

  getLastEvent() {
    return this.timeline[this.timeline.length - 1] || null;
  }

  getMilestones() {
    return this.timeline.filter(e => e.category === StoryEventType.MILESTONE);
  }

  // ─── API: Lebensphasen (Chapter) generieren ────────────────────────

  /**
   * Teilt die Timeline in "Kapitel" — Phasen mit ähnlichem emotionalem Ton.
   */
  getChapters() {
    if (this.timeline.length === 0) return [];

    const chapters = [];
    let current = {
      emotion: this.timeline[0].emotion,
      events: [this.timeline[0]],
      startAge: this.timeline[0].timestamp,
      endAge: this.timeline[0].timestamp
    };

    for (let i = 1; i < this.timeline.length; i++) {
      const event = this.timeline[i];

      if (event.emotion === current.emotion) {
        current.events.push(event);
        current.endAge = event.timestamp;
      } else {
        chapters.push(current);
        current = {
          emotion: event.emotion,
          events: [event],
          startAge: event.timestamp,
          endAge: event.timestamp
        };
      }
    }
    chapters.push(current);

    return chapters.map(ch => ({
      emotion: ch.emotion,
      eventCount: ch.events.length,
      startAge: ch.startAge,
      endAge: ch.endAge,
      duration: ch.endAge - ch.startAge,
      summary: ch.events[0].text,
      milestones: ch.events.filter(e => e.category === StoryEventType.MILESTONE).length
    }));
  }

  // ─── API: Emotionale Bilanz ────────────────────────────────────────

  getEmotionalBalance() {
    if (this.timeline.length === 0) {
      return { dominant: null, distribution: {}, total: 0 };
    }

    const counts = {};
    for (const event of this.timeline) {
      counts[event.emotion] = (counts[event.emotion] || 0) + 1;
    }

    let dominant = null;
    let maxCount = 0;
    for (const [emotion, count] of Object.entries(counts)) {
      if (count > maxCount) {
        maxCount = count;
        dominant = emotion;
      }
    }

    return {
      dominant,
      distribution: counts,
      total: this.timeline.length
    };
  }

  // ─── Reset ─────────────────────────────────────────────────────────

  reset() {
    this.timeline = [];
    this.lastEmotion = null;
    this._lastTemplateIndex = -1;
    this._lastWasPhaseShift = false;
  }

  // ─── Destroy (EventBus-Listener abmelden) ──────────────────────────

  destroy() {
    if (this._offDetected) this._offDetected();
    if (this._offPhaseShift) this._offPhaseShift();
  }
}
