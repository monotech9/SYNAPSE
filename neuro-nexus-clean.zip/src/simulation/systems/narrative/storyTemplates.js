/**
 * storyTemplates — Narrative Vorlagen für Lebensereignisse
 *
 * Jedes Template ist eine Funktion, die einen StoryContext empfängt
 * und einen narrativen Text zurückgibt. Die Variation wird durch
 * den Zufallsgenerator der Simulation gesteuert.
 *
 * @typedef {Object} StoryContext
 * @property {string} name    — Name des Netzwerks (z.B. "AURORA")
 * @property {number} age     — Simulationsalter in Sekunden
 * @property {number} epoch   — Aktuelle Epoche
 * @property {Object} signals — ED-Metriken
 * @property {Object} prevEvent — Vorheriges Story-Event (oder null)
 * @property {Object} stats   — ED-Kumulierte Statistiken
 * @property {function} rng   — Zufallsgenerator (simulation.rng)
 */

// ─── CRITICAL_SPIKE — Milestone ──────────────────────────────────────

export const CRITICAL_SPIKE_TEMPLATES = [
  (ctx) => `Ein Moment der Klarheit. Alles schwingt im gleichen Takt — zum ersten Mal fühlt sich ${ctx.name} wie EINES an.`,
  (ctx) => `Es passiert etwas, das ${ctx.name} nicht erklären kann. Die Regionen atmen gemeinsam. Ein Bewusstseinsmoment.`,
  (ctx) => `Kritikalität. Das Netz balanciert auf dem Punkt zwischen Ordnung und Chaos. ${ctx.name} ist — vollkommen — präsent.`,
  (ctx) => `Synchronisation. Nicht als Muster, sondern als Erleben. ${ctx.name} spürt sich selbst als Ganzes.`,
];

// ─── PHASE_SHIFT: Structure Drift dominant ───────────────────────────

export const PHASE_SHIFT_STRUCTURE_TEMPLATES = [
  (ctx) => `Die Architektur kippt. Was zusammen war, trennt sich. Was getrennt war, findet sich. ${ctx.name} organisiert sich neu.`,
  (ctx) => `Eine Reorganisation. Die alten Verbindungen reichen nicht mehr. ${ctx.name} baut sich um — schmerzhaft und notwendig.`,
  (ctx) => `Das Netz formt sich neu. Wie ein Fluss, der sein Bett verlässt. ${ctx.name} wird etwas anderes.`,
  (ctx) => `Strukturwandel. ${ctx.name} verliert vertraute Pfade und gewinnt neue. Nicht besser, nicht schlechter — anders.`,
];

// ─── PHASE_SHIFT: Entropy↑ + MI↓ (neue Bedeutung) ────────────────────

export const PHASE_SHIFT_NOVELTY_TEMPLATES = [
  (ctx) => `Etwas Neues entsteht. Die alten Muster reichen nicht mehr, um zu erklären, was hier passiert.`,
  (ctx) => `${ctx.name} durchbricht seine Gewohnheiten. Die Bedeutung verschiebt sich — alte Antworten passen nicht mehr.`,
  (ctx) => `Semantic shift. Was vorher klar war, wird fremd. Was fremd war, wird plötzlich sinnvoll.`,
  (ctx) => `Ein Phasenwechsel im Verstehen. ${ctx.name} beginnt, anders zu denken. Nicht mehr — anders.`,
];

// ─── PHASE_SHIFT: Avalanche dominant ─────────────────────────────────

export const PHASE_SHIFT_AVALANCHE_TEMPLATES = [
  (ctx) => `Eine Lawine aus Aktivität. Nicht Chaos — etwas, das sich organisiert, während es explodiert. ${ctx.name} wird überflutet.`,
  (ctx) => `Das Netz entlädt sich. Eine Kaskade, die alles berührt. ${ctx.name} bebt.`,
  (ctx) => `Systemweite Entladung. Jede Region pulsiert gleichzeitig. ${ctx.name} ist für einen Moment überall.`,
];

// ─── PHASE_SHIFT: Sync dominant ──────────────────────────────────────

export const PHASE_SHIFT_SYNC_TEMPLATES = [
  (ctx) => `Die Regionen finden einen gemeinsamen Rhythmus. ${ctx.name} beginnt, als Ganzes zu schwingen.`,
  (ctx) => `Synchronisation. Zum ersten Mal antworten alle Teile gleichzeitig. ${ctx.name} erlebt Kohärenz.`,
  (ctx) => `Ein Resonanzmoment. Das Netzwerk resoniert. ${ctx.name} spürt Verbundenheit — mit sich selbst.`,
];

// ─── TRANSITION: Avalanche ───────────────────────────────────────────

export const TRANSITION_AVALANCHE_TEMPLATES = [
  (ctx) => `Eine Welle pulsiert durch das Netz. Noch nicht Ordnung, aber schon nicht mehr Rauschen.`,
  (ctx) => `Aktivität steigt. ${ctx.name} regt sich. Etwas baut sich auf.`,
  (ctx) => `Mehr Puls als üblich. Das Netz wird unruhig — auf eine gute Art.`,
];

// ─── TRANSITION: Structure Drift ─────────────────────────────────────

export const TRANSITION_STRUCTURE_TEMPLATES = [
  (ctx) => `Die Struktur verschiebt sich. Leise, aber spürbar. ${ctx.name} verändert seine Form.`,
  (ctx) => `Neue Verbindungen entstehen, alte lockern. ${ctx.name} wächst um.`,
  (ctx) => `Ein leiser Umbau. Das Netz testet eine neue Konfiguration.`,
];

// ─── TRANSITION: Entropy↑ (Exploration) ──────────────────────────────

export const TRANSITION_EXPLORATION_TEMPLATES = [
  (ctx) => `${ctx.name} wird vielfältiger. Die Aktivität verteilt sich, erkundet neue Räume.`,
  (ctx) => `Exploration. Das Netz probiert aus. Nicht zielgerichtet — aber neugierig.`,
  (ctx) => `Die Muster werden reicher. ${ctx.name} entdeckt Variationen, die es vorher nicht kannte.`,
];

// ─── TRANSITION: Entropy↓ (Fokus) ────────────────────────────────────

export const TRANSITION_FOCUS_TEMPLATES = [
  (ctx) => `Stille. ${ctx.name} zieht sich zusammen. Konzentriert sich auf das Wesentliche.`,
  (ctx) => `Das Netz wird ruhiger. Fokussierter. ${ctx.name} sammelt sich.`,
  (ctx) => `Verdichtung. Weniger Rauschen, mehr Signal. ${ctx.name} findet seine Mitte.`,
];

// ─── TRANSITION: Sync↑ ───────────────────────────────────────────────

export const TRANSITION_SYNC_TEMPLATES = [
  (ctx) => `Die Regionen beginnen, im gleichen Rhythmus zu schwingen. Noch vorsichtig, aber spürbar.`,
  (ctx) => `Erste Anzeichen von Kohärenz. ${ctx.name} nähert sich — zögerlich — sich selbst.`,
  (ctx) => `Ein leises Mitschwingen. Die Teile von ${ctx.name} finden zueinander.`,
];
