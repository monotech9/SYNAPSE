/**
 * episodicConstants.js — Konstanten & Valence-Mapping für EpisodicMemory
 *
 * Aus EpisodicMemory.js extrahiert. Enthält:
 *  - Decay- und Konsolidierungs-Parameter
 *  - Memory Physics Konstanten (GDD §11)
 *  - Emotion → Valence Mapping + Helper-Funktionen
 */

// ─── Konfiguration ───────────────────────────────────────────────────

export const MAX_EPISODES = 80;
export const MIN_STRENGTH = 0.05;  // unter diesem Wert wird Episode vergessen
export const DECAY_RATE = 0.002;   // pro Update-Tick
export const NEGATIVE_DECAY_MULTIPLIER = 0.1;  // negative Episoden verblassten 10x langsamer
export const POSITIVE_DECAY_MULTIPLIER = 0.5;  // positive Episoden verblassten 2x langsamer
export const CONSOLIDATION_BOOST = 0.15;       // wie viel eine NREM-Replay-Verstärkung bringt

// ─── Memory Physics (GDD §11) ────────────────────────────────────────
export const GRAVITY_DECAY_RESISTANCE = 0.7;   // high-gravity episodes resist decay (multiplier)
export const RESONANCE_BOOST = 0.08;           // gravity boost from similar new episodes
export const RESONANCE_MAX_BOOST = 0.25;       // cap per resonance event
export const CRITICAL_EVENT_GRAVITY = 0.85;    // cluster collapse, phase shift, etc.
export const REFLECTION_INTERVAL = 3.0;        // Sekunden zwischen Decay-Updates

// ─── Emotion Valence Mapping ─────────────────────────────────────────

export const POSITIVE_EMOTIONS = new Set([
  "joy", "hope", "pride", "love", "wonder",
  "calm", "satisfaction", "curiosity"
]);

export const NEGATIVE_EMOTIONS = new Set([
  "distress", "fear", "shame", "dislike",
  "disappointment", "tension"
]);

// Story emotion → valence mapping
export const STORY_VALENCE = {
  awakening: +1, wonder: +1, growth: +1, transformation: +1,
  connection: +1, clarity: +1, calm: +1, rest: +1, exploration: +1,
  loss: -1, tension: -1
};

export function emotionValence(emotion) {
  if (POSITIVE_EMOTIONS.has(emotion)) return +1;
  if (NEGATIVE_EMOTIONS.has(emotion)) return -1;
  return 0;
}

export function storyEmotionValence(storyEmotion) {
  return STORY_VALENCE[storyEmotion] || 0;
}
