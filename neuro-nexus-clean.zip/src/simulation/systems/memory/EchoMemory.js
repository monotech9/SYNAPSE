/**
 * EchoMemory (M3) — Echo-Gedächtnis für wiederkehrende Muster (GDD §6)
 *
 * Während EpisodicMemory diskrete Episoden speichert, detectiert
 * EchoMemory Muster die WIEDERKEHREN — mit leichten Variationen.
 * Ein Echo ist kein exaktes Duplikat, sondern ein strukturelles
 * "Schatten" eines früheren Erlebnisses.
 *
 * Funktion:
 *  1. Beobachtet story:event und emotion:spike Events
 *  2. Vergleicht mit historischen Mustern (via EpisodicMemory)
 *  3. Wenn ein Muster ähnlich (aber nicht identisch) zu einem
 *     historischen Muster ist → Echo detected
 *  4. Echo-Stärke basiert auf Ähnlichkeit × Zeitabstand
 *  5. Echos koppeln zurück an SelfModel (storyEcho) und
 *     EpisodicMemory (resonance boost)
 *
 * Events (out):
 *  - "echo:detected"  — Echo erkannt { pattern, match, strength, ageGap }
 *  - "echo:fade"      — Echo verblasst { pattern }
 *
 * Events (in):
 *  - "story:event"    — Neue Story-Event für Muster-Vergleich
 *  - "emotion:spike"  — Emotion-Spike für Echo-Detection
 */

const ECHO_SIMILARITY_THRESHOLD = 0.3;
const ECHO_MAX_AGE_GAP = 120;     // Max Zeitabstand für Echo (Sekunden)
const ECHO_STRENGTH_DECAY = 0.98; // Pro Tick
const MAX_ACTIVE_ECHOS = 10;

export class EchoMemory {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Aktive Echos (Pattern die gerade "nachhallen")
    this._activeEchos = [];

    // Muster-Historie (reduzierte Story-Events für Vergleich)
    this._patternHistory = [];
    this._maxHistory = 50;

    // EventBus subscriptions
    this._off1 = this.events.on("story:event", (d) => this._checkEcho(d));
    this._off2 = this.events.on("emotion:spike", (d) => this._checkEmotionEcho(d));
  }

  /**
   * Prüft ob ein Story-Event ein Echo eines früheren Musters ist.
   */
  _checkEcho(storyEvent) {
    const now = this.sim.world.age;

    // Muster extrahieren: emotion + category + growth stage
    const pattern = {
      emotion: storyEvent.emotion || "neutral",
      category: storyEvent.category || "minor",
      text: storyEvent.text || "",
      timestamp: now
    };

    // In Historie aufnehmen
    this._patternHistory.push(pattern);
    if (this._patternHistory.length > this._maxHistory) {
      this._patternHistory.shift();
    }

    // Vergleiche mit älteren Mustern
    let bestMatch = null;
    let bestSimilarity = 0;

    for (const old of this._patternHistory) {
      if (old === pattern) continue;
      const ageGap = now - old.timestamp;
      if (ageGap < 5 || ageGap > ECHO_MAX_AGE_GAP) continue;

      const similarity = this._computeSimilarity(pattern, old);
      if (similarity > bestSimilarity) {
        bestSimilarity = similarity;
        bestMatch = old;
      }
    }

    if (bestMatch && bestSimilarity > ECHO_SIMILARITY_THRESHOLD) {
      const ageGap = now - bestMatch.timestamp;
      // Echo-Stärke: Ähnlichkeit × (1 / (1 + ageGap/60))
      const strength = bestSimilarity * (1 / (1 + ageGap / 60));

      const echo = {
        pattern,
        match: bestMatch,
        strength,
        ageGap,
        detectedAt: now
      };

      this._activeEchos.push(echo);
      if (this._activeEchos.length > MAX_ACTIVE_ECHOS) {
        this._activeEchos.shift();
      }

      this.events.emit("echo:detected", echo);

      // Resonance boost an EpisodicMemory
      const episodic = this.sim.episodicMemory;
      if (episodic && episodic.resonanceSearch) {
        const queryTags = [
          `valence:${pattern.emotion === 'loss' || pattern.emotion === 'tension' ? 'neg' : 'pos'}`,
          pattern.emotion
        ];
        episodic.resonanceSearch(queryTags, 3);
      }
    }
  }

  /**
   * Prüft Emotion-Spikes auf Echo-Muster.
   */
  _checkEmotionEcho(spike) {
    const now = this.sim.world.age;
    const pattern = {
      emotion: spike.emotion || "neutral",
      category: "emotion_spike",
      intensity: spike.intensity || 0.5,
      timestamp: now
    };

    // Ähnliche Emotion-Spikes in der Historie finden
    let bestMatch = null;
    let bestSimilarity = 0;

    for (const old of this._patternHistory) {
      if (old.category !== "emotion_spike") continue;
      const ageGap = now - old.timestamp;
      if (ageGap < 10 || ageGap > ECHO_MAX_AGE_GAP) continue;

      const similarity = (old.emotion === pattern.emotion ? 0.6 : 0) +
        (1 - Math.abs((old.intensity || 0.5) - (pattern.intensity || 0.5)) * 0.4);

      if (similarity > bestSimilarity) {
        bestSimilarity = similarity;
        bestMatch = old;
      }
    }

    if (bestMatch && bestSimilarity > ECHO_SIMILARITY_THRESHOLD) {
      this._activeEchos.push({
        pattern,
        match: bestMatch,
        strength: bestSimilarity * 0.7,
        ageGap: now - bestMatch.timestamp,
        detectedAt: now
      });
      if (this._activeEchos.length > MAX_ACTIVE_ECHOS) {
        this._activeEchos.shift();
      }
      this.events.emit("echo:detected", {
        pattern,
        match: bestMatch,
        strength: bestSimilarity * 0.7,
        ageGap: now - bestMatch.timestamp
      });
    }
  }

  /**
   * Berechnet Ähnlichkeit zwischen zwei Mustern.
   * Nicht-identisch: gleiche Emotion + ähnliche Kategorie = Echo.
   * Text-Overlap als Bonus.
   */
  _computeSimilarity(a, b) {
    let sim = 0;
    // Emotion match (wichtigster Faktor)
    if (a.emotion === b.emotion) sim += 0.5;
    // Kategorie match
    if (a.category === b.category) sim += 0.2;
    // Text-Overlap (Wort-Jaccard)
    if (a.text && b.text) {
      const wordsA = new Set(a.text.toLowerCase().split(/\s+/).filter(w => w.length > 3));
      const wordsB = new Set(b.text.toLowerCase().split(/\s+/).filter(w => w.length > 3));
      if (wordsA.size > 0 && wordsB.size > 0) {
        let intersection = 0;
        for (const w of wordsA) if (wordsB.has(w)) intersection++;
        sim += (intersection / (wordsA.size + wordsB.size - intersection)) * 0.3;
      }
    }
    return Math.min(1, sim);
  }

  // ─── Update ────────────────────────────────────────────────────

  update(dt) {
    // Aktive Echos decayen
    for (let i = this._activeEchos.length - 1; i >= 0; i--) {
      this._activeEchos[i].strength *= ECHO_STRENGTH_DECAY;
      if (this._activeEchos[i].strength < 0.02) {
        this.events.emit("echo:fade", { pattern: this._activeEchos[i].pattern });
        this._activeEchos.splice(i, 1);
      }
    }
  }

  // ─── API ───────────────────────────────────────────────────────

  getActiveEchos() { return [...this._activeEchos]; }

  getEchoCount() { return this._activeEchos.length; }

  getStrongestEcho() {
    if (this._activeEchos.length === 0) return null;
    return this._activeEchos.reduce((max, e) => e.strength > max.strength ? e : max);
  }

  getSnapshot() {
    return {
      activeCount: this._activeEchos.length,
      strongestStrength: this._activeEchos.length > 0
        ? Math.max(...this._activeEchos.map(e => e.strength))
        : 0,
      patternHistory: this._patternHistory.length,
      totalDetected: this._patternHistory.length
    };
  }

  serialize() {
    return {
      activeCount: this._activeEchos.length,
      patternHistory: this._patternHistory.length
    };
  }

  reset() {
    this._activeEchos = [];
    this._patternHistory = [];
  }

  destroy() {
    this._off1?.();
    this._off2?.();
    this._activeEchos = [];
    this._patternHistory = [];
  }
}
