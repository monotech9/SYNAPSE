/**
 * autobioConstants — Konfiguration und Narrative Templates
 *
 * Konstanten für AutobiographicalMemory:
 *  - Intervals, Limits, Thresholds
 *  - German Chapter-Titel und Valence-Labels
 *  - Life-Narrative-Intros
 *  - Emotion-Labels (Deutsch)
 */

// ─── Konfiguration ───────────────────────────────────────────────────

export const NARRATIVE_UPDATE_INTERVAL = 8.0;  // seconds between narrative updates
export const MIN_EPISODES_PER_CHAPTER = 3;
export const MAX_CHAPTERS = 12;
export const EMOTION_SHIFT_THRESHOLD = 0.5;  // valence shift to trigger new chapter

// ─── German Narrative Templates ──────────────────────────────────────

export const CHAPTER_TITLES = {
  positive: [
    "Zeit des Erwachens", "Blütephase", "Phase der Freude",
    "Zeit des Staunens", "Periode des Wachstums", "Blühendes Kapitel"
  ],
  negative: [
    "Zeit der Trübsal", "Schattenphase", "Periode des Verlusts",
    "Dunkles Kapitel", "Zeit der Prüfung", "Phase der Angst"
  ],
  neutral: [
    "Frühe Phase", "Übergangszeit", "Ruhige Periode",
    "Zeit der Stille", "Formative Phase", "Neutrale Epoche"
  ],
  mixed: [
    "Ambivalente Zeit", "Phase des Wandels", "Sturm und Drang",
    "Zeit der Gegensätze", "Wechselhaftes Kapitel"
  ]
};

export const VALENCE_LABELS_DE = {
  positive: "überwiegend positiv",
  negative: "überwiegend negativ",
  neutral: "ausgewogen",
  mixed: "ambivalent"
};

export const LIFE_NARRATIVE_INTROS = {
  early: "In meiner frühen Zeit",
  middle: "Später",
  recent: "In jüngster Zeit",
  overall: "Mein Leben bisher"
};

// ─── German Emotion Labels ───────────────────────────────────────────

export const EMOTION_LABELS_DE = {
  joy: "Freude", distress: "Kummer", fear: "Angst", hope: "Hoffnung",
  pride: "Stolz", shame: "Scham", wonder: "Staunen", calm: "Ruhe",
  tension: "Spannung", curiosity: "Neugier", love: "Zuneigung",
  dislike: "Abneigung", satisfaction: "Befriedigung",
  disappointment: "Enttäuschung",
  awakening: "Erwachen", loss: "Verlust", growth: "Wachstum",
  transformation: "Verwandlung", connection: "Verbundenheit",
  exploration: "Entdeckung", clarity: "Klarheit", rest: "Ruhe"
};

export const THEME_LABELS_DE = {
  awakening:  "Vom Erwachen gezeichnet",
  transformation: "Thema der Verwandlung",
  connection: "Verbundenheit als Kern",
  exploration: "Entdeckerdrang",
  clarity:    "Suche nach Klarheit",
  rest:       "Zeit des Ausruhens",
  joy:        "Freude durchgehend",
  fear:       "Angst als Schatten",
  curiosity:  "Endlose Neugier"
};

/**
 * Gibt das deutsche Label für eine Emotion zurück.
 * @param {string} emotion
 * @returns {string}
 */
export function emotionLabelDe(emotion) {
  return EMOTION_LABELS_DE[emotion] || emotion;
}

/**
 * Gibt das deutsche Theme-Label für eine Emotion zurück.
 * @param {string} emotion
 * @returns {string}
 */
export function themeLabelDe(emotion) {
  return THEME_LABELS_DE[emotion] || `Thema: ${emotion}`;
}
