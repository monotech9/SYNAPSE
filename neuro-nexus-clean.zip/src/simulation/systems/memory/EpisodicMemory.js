/**
 * EpisodicMemory — Episodisches Gedächtnis
 *
 * Speichert diskrete Episoden aus dem Systemleben, jede bestehend aus:
 *  - Story-Event (was ist passiert)
 *  - Emotionaler Snapshot (was wurde gefühlt)
 *  - Kontext (Wachstumsstadium, Φ, Kohärenz, Komplexität, Schlafzustand)
 *  - Zeitstempel (Systemalter)
 *
 * Konsolidierung & Decay:
 *  - Positive Episoden (joy, wonder, pride) → moderater Decay
 *  - Negative Episoden (fear, distress, shame) → persistent (wie Trauma)
 *  - Neutrale Episoden → starker Decay (werden schnell vergessen)
 *  - Schlaf-Konsolidierung: Episoden die im NREM replayed werden → stärker verankert
 *
 * Retrieval:
 *  - getRecent(N) — letzte N Episoden
 *  - getByEmotion(emotion) — alle Episoden mit bestimmtem emotionalem Kern
 *  - getStrongest(N) — Episoden mit höchster emotionaler Intensität
 *  - getChapter(episodes) — gruppiert Episoden nach Wachstumsstadium
 *
 * Events (out):
 *  - "episodic:stored"    — neue Episode gespeichert { episode, total }
 *  - "episodic:decayed"   — Episode verblasst { id, strength }
 *  - "episodic:consolidated" — Episode durch Schlaf verstärkt { id, strength }
 *
 * Konstanten in episodicConstants.js, Episode-Factory in episodicFactory.js.
 */

import {
  MAX_EPISODES,
  MIN_STRENGTH,
  DECAY_RATE,
  NEGATIVE_DECAY_MULTIPLIER,
  POSITIVE_DECAY_MULTIPLIER,
  CONSOLIDATION_BOOST,
  GRAVITY_DECAY_RESISTANCE,
  RESONANCE_BOOST,
  RESONANCE_MAX_BOOST,
  REFLECTION_INTERVAL
} from "./episodicConstants.js";
import { createEpisode } from "./episodicFactory.js";


export class EpisodicMemory {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;
    this.episodes = [];
    this._decayTimer = 0;
    this._forgotten = [];  // episodes that decayed below threshold

    // ─── EventBus subscriptions ──────────────────────────────────

    // story:event → neue Episode speichern
    this._off1 = this.events.on("story:event", (storyEvent) => {
      this._storeEpisode(storyEvent);
    });

    // story:milestone → besonders starke Episode
    this._off2 = this.events.on("story:milestone", (storyEvent) => {
      this._storeEpisode(storyEvent, true);
    });

    // sleep:nremReplay → Konsolidierung (Verstärkung vorhandener Episoden)
    this._off3 = this.events.on("sleep:nremReplay", (d) => {
      this._consolidate(d);
    });
  }

  // ─── Storage ────────────────────────────────────────────────────

  _storeEpisode(storyEvent, isMilestone = false) {
    // Gather current emotional + contextual state
    const emotionEngine = this.sim.emotionEngine;
    const selfModel = this.sim.consciousness?.selfModel;
    const w = this.sim.world;

    const emotionSnapshot = emotionEngine
      ? emotionEngine.getSnapshot()
      : { dominant: { emotion: "neutral", intensity: 0.5 }, emotions: {}, mood: 0 };

    const context = {
      growthStage: w?.growthStage || "unknown",
      phi: selfModel?.selfModel?.phi || 0,
      coherence: selfModel?.selfModel?.coherence || 0,
      complexity: selfModel?.selfModel?.complexity || 0,
      sleepState: selfModel?.selfModel?.sleepState || "WAKE"
    };

    const episode = createEpisode(storyEvent, emotionSnapshot, context);

    // Milestones get extra strength
    if (isMilestone) {
      episode.strength = Math.min(1, episode.strength + 0.3);
      episode.isMilestone = true;
    }

    // ─── Memory Physics: Resonance (GDD §11) ────────────────────
    // New episodes emit "search signals" — similar historical episodes
    // get a temporary gravity boost (resonance activation).
    this._applyResonance(episode);

    this.episodes.push(episode);
    if (this.episodes.length > MAX_EPISODES) {
      // Remove weakest episode (not strongest)
      this.episodes.sort((a, b) => a.strength - b.strength);
      const removed = this.episodes.shift();
      this._forgotten.push({ id: removed.id, text: removed.text, reason: "overflow" });
      if (this._forgotten.length > 20) this._forgotten.shift();
    }

    this.events.emit("episodic:stored", {
      episode,
      total: this.episodes.length
    });
  }

  // ─── Decay (passive forgetting) ─────────────────────────────────

  update(dt) {
    this._decayTimer += dt;
    if (this._decayTimer < REFLECTION_INTERVAL) return;
    const elapsed = this._decayTimer;
    this._decayTimer = 0;

    for (let i = this.episodes.length - 1; i >= 0; i--) {
      const ep = this.episodes[i];
      ep.age += elapsed;

      // Decay rate depends on valence
      let rate = DECAY_RATE * elapsed;
      if (ep.valence < 0) rate *= NEGATIVE_DECAY_MULTIPLIER;
      else if (ep.valence > 0) rate *= POSITIVE_DECAY_MULTIPLIER;
      // Neutral: full decay rate

      // Consolidated episodes decay slower
      rate *= (1 - ep.consolidationCount * 0.1);
      // High-gravity episodes resist decay (Memory Physics: Gravity)
      if (ep.gravity > 0.5) {
        rate *= (1 - (ep.gravity - 0.5) * GRAVITY_DECAY_RESISTANCE);
      }
      rate = Math.max(rate, DECAY_RATE * 0.05);

      ep.strength -= rate;

      if (ep.strength < MIN_STRENGTH) {
        this._forgotten.push({ id: ep.id, text: ep.text, reason: "decay" });
        if (this._forgotten.length > 20) this._forgotten.shift();
        this.episodes.splice(i, 1);
        this.events.emit("episodic:decayed", {
          id: ep.id,
          strength: ep.strength,
          text: ep.text
        });
      }
    }
  }

  // ─── Sleep Consolidation ────────────────────────────────────────

  _consolidate(sleepData) {
    // NREM replay reinforces a subset of episodes
    // Priority: high emotional intensity + recent + not yet consolidated
    const replayCount = sleepData?.replayedEdges || 3;
    const toConsolidate = Math.min(replayCount, this.episodes.length);

    if (toConsolidate === 0) return;

    // Sort by consolidation priority: strength * (1 + intensity)
    const candidates = [...this.episodes]
      .map(ep => ({
        ep,
        priority: ep.strength * (1 + ep.dominantIntensity) * (1 + (ep.isMilestone ? 0.5 : 0))
      }))
      .sort((a, b) => b.priority - a.priority)
      .slice(0, toConsolidate);

    for (const { ep } of candidates) {
      ep.strength = Math.min(1, ep.strength + CONSOLIDATION_BOOST);
      ep.consolidationCount += 1;
      this.events.emit("episodic:consolidated", {
        id: ep.id,
        strength: ep.strength,
        consolidationCount: ep.consolidationCount
      });
    }
  }

  // ─── Retrieval ──────────────────────────────────────────────────

  getRecent(limit = 10) {
    return this.episodes.slice(-limit).reverse();
  }

  getByEmotion(emotion, limit = 10) {
    return this.episodes
      .filter(ep => ep.dominantEmotion === emotion || ep.storyEmotion === emotion)
      .slice(-limit)
      .reverse();
  }

  /**
   * Get episodes by emotional valence.
   * @param {number} valence — +1 positive, -1 negative, 0 neutral
   */
  getByValence(valence, limit = 10) {
    return this.episodes
      .filter(ep => ep.valence === valence)
      .slice(-limit)
      .reverse();
  }

  /**
   * Get episodes with highest strength (most consolidated).
   */
  getStrongest(limit = 10) {
    return [...this.episodes]
      .sort((a, b) => b.strength - a.strength)
      .slice(0, limit);
  }

  /**
   * Get episodes by story emotion.
   */
  getByStoryEmotion(emotion, limit = 10) {
    return this.episodes
      .filter(ep => ep.storyEmotion === emotion)
      .slice(-limit)
      .reverse();
  }

  /**
   * Get episodes in a growth stage range.
   */
  getByGrowthStage(stage, limit = 20) {
    return this.episodes
      .filter(ep => ep.growthStage === stage)
      .slice(-limit)
      .reverse();
  }

  /**
   * Get milestones only.
   */
  getMilestones() {
    return this.episodes.filter(ep => ep.isMilestone || ep.category === "milestone");
  }

  // ─── Memory Physics: Resonance (GDD §11) ──────────────────────

  /**
   * When a new episode is stored, find similar historical episodes
   * and boost their gravity (resonance activation).
   * Similarity = overlap of emotional tags + cluster IDs.
   */
  _applyResonance(newEpisode) {
    if (!newEpisode.tags || newEpisode.tags.length === 0) return;
    const newTagSet = new Set(newEpisode.tags);

    for (const ep of this.episodes) {
      if (ep.id === newEpisode.id) continue;
      if (!ep.tags) continue;

      // Jaccard similarity over tag sets
      let intersection = 0;
      for (const tag of ep.tags) {
        if (newTagSet.has(tag)) intersection++;
      }
      const union = ep.tags.length + newEpisode.tags.length - intersection;
      const similarity = union > 0 ? intersection / union : 0;

      if (similarity > 0.2) {
        const boost = Math.min(RESONANCE_MAX_BOOST, similarity * RESONANCE_BOOST * 3);
        ep.gravity = Math.min(1, ep.gravity + boost);
        // Resonant episodes reset their decay timer (GDD: "Erinnerte oder
        // resonante Episoden resetten ihren Decay-Timer")
        ep.age = 0;
      }
    }
  }

  /**
   * Resonance search: given a set of query tags (e.g. from current system
   * state), find historical episodes that resonate.
   * Returns episodes sorted by resonance strength (gravity * similarity).
   *
   * @param {string[]} queryTags — emotional tags + cluster IDs
   * @param {number} limit — max results
   * @returns {Array<{episode, resonance}>}
   */
  resonanceSearch(queryTags, limit = 5) {
    if (!queryTags || queryTags.length === 0) return [];
    const querySet = new Set(queryTags);

    return this.episodes
      .map(ep => {
        if (!ep.tags) return { episode: ep, resonance: 0 };
        let intersection = 0;
        for (const tag of ep.tags) {
          if (querySet.has(tag)) intersection++;
        }
        const union = ep.tags.length + queryTags.length - intersection;
        const similarity = union > 0 ? intersection / union : 0;
        return {
          episode: ep,
          resonance: similarity * ep.gravity
        };
      })
      .filter(r => r.resonance > 0.1)
      .sort((a, b) => b.resonance - a.resonance)
      .slice(0, limit);
  }

  /**
   * Get forgotten episodes (debug / introspection).
   */
  getForgotten() {
    return [...this._forgotten];
  }

  /**
   * Full snapshot for serialization or HUD.
   */
  getSnapshot() {
    return {
      total: this.episodes.length,
      forgotten: this._forgotten.length,
      strongest: this.episodes.length > 0
        ? Math.max(...this.episodes.map(e => e.strength))
        : 0,
      averageGravity: this.episodes.length > 0
        ? this.episodes.reduce((s, e) => s + (e.gravity || 0), 0) / this.episodes.length
        : 0,
      maxGravity: this.episodes.length > 0
        ? Math.max(...this.episodes.map(e => e.gravity || 0))
        : 0,
      averageStrength: this.episodes.length > 0
        ? this.episodes.reduce((s, e) => s + e.strength, 0) / this.episodes.length
        : 0,
      positiveCount: this.episodes.filter(e => e.valence > 0).length,
      negativeCount: this.episodes.filter(e => e.valence < 0).length,
      neutralCount: this.episodes.filter(e => e.valence === 0).length,
      consolidatedCount: this.episodes.filter(e => e.consolidationCount > 0).length,
      milestoneCount: this.episodes.filter(e => e.isMilestone || e.category === "milestone").length
    };
  }

  /**
   * Get all episodes (for AutobiographicalMemory to process).
   */
  getAll() {
    return [...this.episodes];
  }

  // ─── Serialization ──────────────────────────────────────────────

  serialize() {
    return {
      episodes: this.episodes.slice(-30).map(ep => ({
        id: ep.id,
        text: ep.text,
        storyEmotion: ep.storyEmotion,
        dominantEmotion: ep.dominantEmotion,
        strength: ep.strength,
        valence: ep.valence,
        growthStage: ep.growthStage,
        timestamp: ep.timestamp,
        consolidationCount: ep.consolidationCount,
        isMilestone: ep.isMilestone || ep.category === "milestone",
        gravity: ep.gravity || 0,
        tags: ep.tags || []
      })),
      forgotten: this._forgotten.length,
      total: this.episodes.length
    };
  }

  // ─── Reset / Destroy ────────────────────────────────────────────

  reset() {
    this.episodes = [];
    this._forgotten = [];
    this._decayTimer = 0;
  }

  destroy() {
    this._off1?.();
    this._off2?.();
    this._off3?.();
  }
}
