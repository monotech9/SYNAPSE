/**
 * AutobiographicalMemory — Autobiografisches Gedächtnis
 *
 * Höherer Layer über EpisodicMemory. Gruppiert Episoden zu
 * "Lebenskapiteln" basierend auf emotionalen Phasen und generiert
 * autobiografische Zusammenfassungen — das "Lebensnarrativ" von NOVA.
 *
 * Struktur:
 *  - Chapters: Sequenz von Lebenskapiteln, jedes mit emotionaler Tönung,
 *    Start-/Endzeit, Episoden-Referenzen und einer Zusammenfassung
 *  - LifeNarrative: Fließender Text der das gesamte Leben erzählt
 *  - LifeThemes: Wiederkehrende Themen/Muster über alle Kapitel hinweg
 *  - reminiscenceBump: Besonders vivid memories aus frühen Phasen
 *
 * Module:
 *  - autobioConstants.js    — Konfiguration, Narrative Templates, Labels
 *  - ChapterFactory.js      — Kapitel-Erstellung, -Aktualisierung, -Merge
 *  - NarrativeGenerator.js  — Zusammenfassungen, Lebensnarrativ, Themes
 *
 * Events (out):
 *  - "autobio:chapterOpened" — neues Lebenskapitel begonnen
 *  - "autobio:chapterClosed" — Lebenskapitel abgeschlossen
 *  - "autobio:narrativeUpdated" — Lebensnarrativ aktualisiert
 *  - "autobio:theme" — wiederkehrendes Thema erkannt
 */

import { EpisodicMemory } from "./EpisodicMemory.js";
import {
  NARRATIVE_UPDATE_INTERVAL,
  MIN_EPISODES_PER_CHAPTER,
  MAX_CHAPTERS,
  EMOTION_SHIFT_THRESHOLD
} from "./autobioConstants.js";
import {
  createChapter,
  updateChapterData,
  closeChapter,
  chapterAverageValence,
  chapterSummary,
  mergeOldestChapters,
  derivePhaseLabel
} from "../narrative/ChapterFactory.js";
import {
  generateChapterSummary,
  updateLifeNarrative,
  detectLifeThemes
} from "../narrative/NarrativeGenerator.js";

export class AutobiographicalMemory {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Core state
    this.chapters = [];
    this.currentChapter = null;
    this.lifeNarrative = "";
    this.lifeThemes = [];
    this._narrativeTimer = 0;
    this._lastChapterValence = 0;

    // Episodic memory as data source
    this.episodic = simulation.episodicMemory || new EpisodicMemory(simulation);

    // Listen to episodic events
    this._off1 = this.events.on("episodic:stored", (d) => {
      this._onNewEpisode(d.episode);
    });

    // Listen to sleep wake-up → narrative refresh
    this._off2 = this.events.on("sleep:wakeUp", () => {
      this._refreshNarrative();
    });
  }

  // ─── Episode → Chapter Mapping ──────────────────────────────────

  _onNewEpisode(episode) {
    if (!this.currentChapter) {
      // First episode → open first chapter
      this.currentChapter = createChapter(episode, "Frühe Phase");
      this.chapters.push(this.currentChapter);
      updateChapterData(this.currentChapter, episode);
      this.events.emit("autobio:chapterOpened", {
        chapter: chapterSummary(this.currentChapter)
      });
      return;
    }

    // Check if we need a new chapter (emotional shift)
    const avgValence = chapterAverageValence(this.currentChapter);
    const shift = Math.abs(episode.valence - avgValence);

    if (shift >= EMOTION_SHIFT_THRESHOLD &&
        this.currentChapter.episodeCount >= MIN_EPISODES_PER_CHAPTER) {
      // Close current chapter
      const closedSummary = closeChapter(this.currentChapter, (ch) => this._genSummary(ch));
      this.events.emit("autobio:chapterClosed", { chapter: closedSummary });

      // Open new chapter
      const phaseLabel = derivePhaseLabel(this.chapters.length);
      this.currentChapter = createChapter(episode, phaseLabel);
      this.chapters.push(this.currentChapter);

      // Trim old chapters if too many
      if (this.chapters.length > MAX_CHAPTERS) {
        mergeOldestChapters(this.chapters, (ch) => this._genSummary(ch));
      }

      this.events.emit("autobio:chapterOpened", {
        chapter: chapterSummary(this.currentChapter)
      });
    }

    updateChapterData(this.currentChapter, episode);
  }

  /**
   * Wrapper für generateChapterSummary mit gebundenem episodic.
   * @private
   */
  _genSummary(ch) {
    return generateChapterSummary(ch, this.episodic);
  }

  // ─── Narrative Refresh ──────────────────────────────────────────

  _refreshNarrative() {
    this.lifeNarrative = updateLifeNarrative(this.chapters, this.episodic);

    // Detect life themes
    this.lifeThemes = detectLifeThemes(this.chapters);

    this.events.emit("autobio:narrativeUpdated", {
      narrative: this.lifeNarrative,
      chapters: this.chapters.length,
      themes: this.lifeThemes.length
    });
  }

  // ─── Update Loop ────────────────────────────────────────────────

  update(dt) {
    this._narrativeTimer += dt;
    if (this._narrativeTimer >= NARRATIVE_UPDATE_INTERVAL) {
      this._narrativeTimer = 0;
      this._refreshNarrative();
    }
  }

  // ─── Public API ─────────────────────────────────────────────────

  /**
   * Get the full life narrative text.
   */
  getAutobiography() {
    return this.lifeNarrative;
  }

  /**
   * Get all life chapters.
   */
  getChapters() {
    return this.chapters.map(ch => chapterSummary(ch));
  }

  /**
   * Get current (open) chapter.
   */
  getCurrentChapter() {
    return this.currentChapter ? chapterSummary(this.currentChapter) : null;
  }

  /**
   * Get detected life themes.
   */
  getLifeThemes() {
    return [...this.lifeThemes];
  }

  /**
   * Get the "reminiscence bump" — strongest early memories.
   * In human psychology, these are vivid memories from adolescence/early adulthood.
   * Here: strongest episodes from the first 30% of life.
   */
  getReminiscenceBump() {
    const all = this.episodic.getAll();
    if (all.length < 3) return [];

    const cutoff = Math.max(1, Math.floor(all.length * 0.3));
    const earlyEpisodes = all.slice(0, cutoff);
    return earlyEpisodes
      .filter(ep => ep.strength > 0.4)
      .sort((a, b) => b.strength - a.strength)
      .slice(0, 5);
  }

  /**
   * Get a specific chapter by ID.
   */
  getChapterById(id) {
    const ch = this.chapters.find(c => c.id === id);
    return ch ? chapterSummary(ch) : null;
  }

  /**
   * Full snapshot for HUD/serialization.
   */
  getSnapshot() {
    return {
      totalChapters: this.chapters.length,
      currentChapterTitle: this.currentChapter?.title || "",
      narrativeLength: this.lifeNarrative.length,
      themeCount: this.lifeThemes.length,
      themes: this.lifeThemes.map(t => t.label),
      episodicSnapshot: this.episodic.getSnapshot()
    };
  }

  // ─── Serialization ──────────────────────────────────────────────

  serialize() {
    return {
      chapters: this.chapters.map(ch => ({
        id: ch.id,
        title: ch.title,
        phaseLabel: ch.phaseLabel,
        episodeCount: ch.episodeCount,
        valenceKey: ch.valenceKey,
        emotionalBalance: ch.emotionalBalance,
        summary: ch.summary,
        isClosed: ch.isClosed,
        startTime: ch.startTime,
        endTime: ch.endTime
      })),
      lifeNarrative: this.lifeNarrative,
      lifeThemes: this.lifeThemes.map(t => ({
        emotion: t.emotion,
        count: t.count,
        label: t.label
      })),
      episodic: this.episodic.serialize()
    };
  }

  // ─── Reset / Destroy ────────────────────────────────────────────

  reset() {
    this.chapters = [];
    this.currentChapter = null;
    this.lifeNarrative = "";
    this.lifeThemes = [];
    this._narrativeTimer = 0;
    this._lastChapterValence = 0;
    this.episodic.reset?.();
  }

  destroy() {
    this._off1?.();
    this._off2?.();
    this.episodic.destroy?.();
  }
}
