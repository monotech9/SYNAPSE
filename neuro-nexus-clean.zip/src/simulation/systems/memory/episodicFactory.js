/**
 * episodicFactory.js — Episode-Erzeugung
 *
 * Aus EpisodicMemory.js extrahiert. Enthält die Factory-Funktion
 * die aus Story-Events + Emotionalen Snapshots Episoden-Objekte erstellt.
 */

import {
  CRITICAL_EVENT_GRAVITY,
  emotionValence,
  storyEmotionValence
} from "./episodicConstants.js";

let episodeCounter = 0;

/**
 * Erstellt eine neue Episode aus Story-Event, Emotions-Snapshot und Kontext.
 *
 * @param {Object} storyEvent — Das auslösende Story-Event
 * @param {Object} emotionSnapshot — Emotionaler Zustand zum Zeitpunkt des Events
 * @param {Object} context — System-Kontext (Wachstumsstadium, Φ, etc.)
 * @returns {Object} Episode-Objekt
 */
export function createEpisode(storyEvent, emotionSnapshot, context) {
  const valence = storyEmotionValence(storyEvent.emotion) ||
                  emotionValence(emotionSnapshot.dominant?.emotion || "neutral");

  const intensity = emotionSnapshot.dominant?.intensity || 0.5;

  // Initial strength: base on emotional intensity + valence
  // Negative + high intensity = very strong (trauma-like)
  // Positive + high intensity = strong (joyful memory)
  // Neutral + low intensity = weak (forgotten quickly)
  let strength = 0.3 + intensity * 0.5;
  if (valence < 0) strength += 0.2;  // negativity bias (well documented)
  strength = Math.min(1, strength);

  // ─── Memory Physics: Gravity (GDD §11) ──────────────────────
  // Gravity = importance weight (0–1) based on emotional valence +
  // structural relevance. Critical events get near-max gravity.
  let gravity = 0.2 + intensity * 0.4;
  if (valence < 0) gravity += 0.15;          // negativity bias
  if (storyEvent.wasPhaseShift) gravity = CRITICAL_EVENT_GRAVITY;
  if (storyEvent.category === "milestone") gravity = Math.max(gravity, 0.75);
  gravity = Math.min(1, gravity);

  // Tags for resonance matching: emotional tags + growth stage
  const tags = new Set([
    storyEvent.emotion || "neutral",
    `valence:${valence > 0 ? 'pos' : valence < 0 ? 'neg' : 'neutral'}`,
    context.growthStage || "unknown"
  ]);
  // Add cluster IDs from context if available
  if (context.clusterIds) {
    for (const cid of context.clusterIds) tags.add(`cluster:${cid}`);
  }

  return {
    id: `ep_${++episodeCounter}`,
    timestamp: storyEvent.timestamp || 0,
    storyId: storyEvent.id || null,
    text: storyEvent.text || "",
    storyEmotion: storyEvent.emotion || "neutral",
    category: storyEvent.category || "minor",
    wasPhaseShift: storyEvent.wasPhaseShift || false,
    gravity,
    tags: [...tags],

    // Emotional snapshot at time of episode
    dominantEmotion: emotionSnapshot.dominant?.emotion || "neutral",
    dominantIntensity: intensity,
    mood: emotionSnapshot.mood || 0,
    emotionSnapshot: { ...emotionSnapshot.emotions } || {},

    // Context at time of episode
    growthStage: context.growthStage || "unknown",
    phi: context.phi || 0,
    coherence: context.coherence || 0,
    complexity: context.complexity || 0,
    sleepState: context.sleepState || "WAKE",

    // Episode metadata
    valence,  // +1, 0, -1
    strength, // 0-1, how well consolidated
    consolidationCount: 0,  // how many times reinforced by sleep
    age: 0,  // time since creation (in sim seconds)
    createdAt: storyEvent.timestamp || 0
  };
}
