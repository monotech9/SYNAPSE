
import { clamp, lerp } from "../utils/math.js";
export const ClusterRoles = Object.freeze({
  GENESIS: "genesis",
  EXPLORATION: "exploration",
  STABLE: "stable",
  MEMORY: "memory",
  RELAY: "relay"
});

export const ClusterStates = Object.freeze({
  SEEDLING: "seedling",
  FORMING: "forming",
  ACTIVE: "active",
  STABLE: "stable",
  SATURATED: "saturated",
  STRESSED: "stressed",
  DORMANT: "dormant"
});

const ROLE_LIMITS = Object.freeze({
  [ClusterRoles.GENESIS]: { softNodeLimit: 30, hardNodeLimit: 56 },
  [ClusterRoles.EXPLORATION]: { softNodeLimit: 24, hardNodeLimit: 48 },
  [ClusterRoles.STABLE]: { softNodeLimit: 22, hardNodeLimit: 42 },
  [ClusterRoles.MEMORY]: { softNodeLimit: 16, hardNodeLimit: 34 },
  [ClusterRoles.RELAY]: { softNodeLimit: 0, hardNodeLimit: 0 }
});

const ROLE_BIASES = Object.freeze({
  [ClusterRoles.GENESIS]: {
    growthBias: 0.9,
    bridgeBias: 0.75,
    retentionBias: 1.25,
    plasticityBias: 0.85
  },
  [ClusterRoles.EXPLORATION]: {
    growthBias: 1.25,
    bridgeBias: 1.35,
    retentionBias: 0.8,
    plasticityBias: 1.3
  },
  [ClusterRoles.STABLE]: {
    growthBias: 0.75,
    bridgeBias: 0.65,
    retentionBias: 1.35,
    plasticityBias: 0.75
  },
  [ClusterRoles.MEMORY]: {
    growthBias: 0.55,
    bridgeBias: 0.55,
    retentionBias: 1.65,
    plasticityBias: 0.45
  }
});

export function normalizeClusterRole(roleOrType) {
  if (roleOrType === "evolving") return ClusterRoles.EXPLORATION;
  if (roleOrType === "ancient") return ClusterRoles.MEMORY;
  if (roleOrType === "relay") return ClusterRoles.RELAY;
  if (Object.values(ClusterRoles).includes(roleOrType)) return roleOrType;
  return ClusterRoles.EXPLORATION;
}

export function clusterTypeForRole(role) {
  return normalizeClusterRole(role);
}

export function createRoleProfile(role, personality) {
  const normalizedRole = normalizeClusterRole(role);
  const limits = ROLE_LIMITS[normalizedRole] || ROLE_LIMITS[ClusterRoles.EXPLORATION];
  const biases = ROLE_BIASES[normalizedRole] || ROLE_BIASES[ClusterRoles.EXPLORATION];

  return {
    role: normalizedRole,
    softNodeLimit: Math.round(clamp(
      limits.softNodeLimit * lerp(0.86, 1.24, personality.plasticity),
      8,
      limits.hardNodeLimit - 4
    )),
    hardNodeLimit: Math.round(clamp(
      limits.hardNodeLimit * lerp(0.9, 1.16, personality.curiosity),
      limits.softNodeLimit,
      limits.hardNodeLimit + 8
    )),
    ...biases
  };
}

export function chooseBudRole(parent, personality, clusterCount) {
  if (clusterCount <= 1) {
    if (personality.caution > 0.72 && personality.curiosity < 0.58) return ClusterRoles.STABLE;
    return ClusterRoles.EXPLORATION;
  }

  if ((parent.memoryStrength || 0) > 0.54 || personality.attachment > 0.72) return ClusterRoles.MEMORY;
  if (personality.caution > 0.64 && personality.volatility < 0.58) return ClusterRoles.STABLE;
  return ClusterRoles.EXPLORATION;
}
