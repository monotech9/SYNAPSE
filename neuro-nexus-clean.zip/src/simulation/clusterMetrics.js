import { clamp, lerp, average} from "../utils/math.js";
import { ClusterStates } from "./clusterRoles.js";

export function updateClusterMetrics(simulation, dt) {
  for (const cluster of simulation.world.clusters) {
    updateSingleClusterMetrics(simulation, cluster, dt);
  }
}

function updateSingleClusterMetrics(simulation, cluster, dt) {
  const nodes = cluster.nodes;
  // Nutze Per-Cluster Edge-Index statt Full-Scan (O(1) statt O(E))
  const internalEdges = simulation.getInternalEdges(cluster);
  const bridgeEdges = simulation.getClusterBridgeEdges(cluster);

  const localActivity = average(nodes.map((node) => node.activation));
  const activationVariance = average(nodes.map((node) => Math.abs(node.activation - localActivity)));
  const averageEdgeWeight = average(internalEdges.map((edge) => edge.weight));
  const memoryStrength = Math.max(
    average(internalEdges.map((edge) => edge.identityTrace || 0)),
    max(internalEdges.map((edge) => edge.identityTrace || 0)) * 0.72
  );

  const density = clamp(internalEdges.length / Math.max(1, nodes.length * 2.8), 0, 1);
  const nodePressure = clamp(nodes.length / Math.max(1, cluster.softNodeLimit), 0, 1.35);
  const overDensityPressure = clamp((density - 0.58) / 0.42, 0, 1);
  const bridgePressure = clamp(bridgeEdges.length / 4, 0, 1);
  const highActivationPressure = clamp((localActivity - 0.34) / 0.36, 0, 1);
  const volatilityPressure = simulation.personality.volatility;

  const stress = clamp(
    highActivationPressure * 0.35 +
    overDensityPressure * 0.30 +
    bridgePressure * 0.20 +
    volatilityPressure * 0.15,
    0,
    1
  );

  const saturation = clamp(
    nodePressure * 0.35 +
    density * 0.25 +
    memoryStrength * 0.20 +
    cluster.activityMemory * 0.20,
    0,
    1
  );

  const order = clamp(1 - activationVariance * 3.6, 0, 1);
  const stability = clamp(
    cluster.activityMemory * 0.36 +
    averageEdgeWeight * 0.33 +
    memoryStrength * 0.21 +
    order * 0.18 -
    stress * 0.28,
    0,
    1
  );

  const expansionPressure = clamp(
    saturation * 0.40 +
    localActivity * 0.20 +
    memoryStrength * 0.15 +
    simulation.personality.curiosity * 0.15 -
    simulation.personality.caution * 0.10 -
    stress * 0.15,
    0,
    1
  );

  const bridgeStrength = bridgeEdges.length
    ? average(bridgeEdges.map((edge) => edge.weight * edge.birthEase()))
    : 0;

  cluster.localActivity = lerp(cluster.localActivity, localActivity, smoothing(dt, 1.1));
  cluster.recentActivity = lerp(cluster.recentActivity, localActivity, smoothing(dt, 2.4));
  cluster.density = lerp(cluster.density, density, smoothing(dt, 1.3));
  cluster.stress = lerp(cluster.stress, stress, smoothing(dt, 1.1));
  cluster.saturation = lerp(cluster.saturation, saturation, smoothing(dt, 0.9));
  cluster.stability = lerp(cluster.stability, stability, smoothing(dt, 0.95));
  cluster.memoryStrength = lerp(cluster.memoryStrength, memoryStrength, smoothing(dt, 0.8));
  cluster.expansionPressure = lerp(cluster.expansionPressure, expansionPressure, smoothing(dt, 0.8));
  cluster.bridgeStrength = lerp(cluster.bridgeStrength, bridgeStrength, smoothing(dt, 1.2));
  cluster.maturity = clamp(lerp(cluster.maturity, cluster.birthEase(), smoothing(dt, 0.35)) + dt * 0.006, 0, 1);

  cluster.internalEdgeCount = internalEdges.length;
  cluster.bridgeEdgeCount = bridgeEdges.length;
  cluster.age = Math.max(0, simulation.world.age - cluster.createdAtAge);

  updateClusterState(cluster, simulation, dt);
}

function updateClusterState(cluster, simulation, dt) {
  if (cluster.state === ClusterStates.DORMANT) {
    if (cluster.localActivity > 0.16 || cluster.bridgeStrength > 0.24) {
      cluster.state = ClusterStates.FORMING;
      cluster.dormantTimer = 0;
    }
    return;
  }

  if (cluster.localActivity < 0.075 && cluster.bridgeStrength < 0.13 && cluster.age > 180 && cluster.role !== "genesis") {
    cluster.dormantTimer += dt;
    if (cluster.dormantTimer > 12) {
      cluster.state = ClusterStates.DORMANT;
      return;
    }
  } else {
    cluster.dormantTimer = Math.max(0, cluster.dormantTimer - dt * 1.8);
  }

  if (cluster.stress > 0.72) {
    cluster.state = ClusterStates.STRESSED;
    return;
  }

  if (cluster.state === ClusterStates.SEEDLING) {
    if (cluster.stability > 0.18 || cluster.maturity > 0.34 || cluster.age > 18) {
      cluster.state = ClusterStates.FORMING;
    }
    return;
  }

  if (cluster.state === ClusterStates.FORMING) {
    if (cluster.stability > 0.35 && (cluster.bridgeStrength > 0.1 || cluster.role === "genesis")) {
      cluster.state = ClusterStates.ACTIVE;
    }
    return;
  }

  if (cluster.saturation > 0.78) {
    cluster.state = ClusterStates.SATURATED;
    return;
  }

  if (cluster.stability > 0.56 && cluster.memoryStrength > 0.28 && cluster.stress < 0.46) {
    cluster.state = ClusterStates.STABLE;
    return;
  }

  if (cluster.state === ClusterStates.STRESSED && cluster.stress < 0.54) {
    cluster.state = ClusterStates.ACTIVE;
    return;
  }

  if (cluster.state === ClusterStates.SATURATED && cluster.saturation < 0.67) {
    cluster.state = ClusterStates.STABLE;
    return;
  }

  if (cluster.state !== ClusterStates.STABLE && cluster.state !== ClusterStates.SATURATED) {
    cluster.state = ClusterStates.ACTIVE;
  }
}
function max(values) {
  if (!values.length) return 0;
  return values.reduce((highest, value) => Math.max(highest, value), 0);
}

function smoothing(dt, speed) {
  return 1 - Math.exp(-speed * dt);
}
