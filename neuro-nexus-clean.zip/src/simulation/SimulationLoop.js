/**
 * SimulationLoop — Fixed-timestep Accumulator Pattern.
 *
 * Die Simulation läuft mit einer festen Tickrate (default 30 Hz),
 * unabhängig von der Render-Framerate. Der Renderer liest den
 * Simulationszustand jederzeit — die Simulation wird deterministisch.
 *
 * Vorteile:
 *  - Konstante Geschwindigkeit auf schwachen PCs (30 FPS → 1 sim step/frame)
 *  - Identische Simulation unabhängig von FPS (60 FPS → 2 sim steps/frame, 120 FPS → 4)
 *  - Keine Frame-Spirale: maxSubSteps begrenzt die Anzahl der Catch-up-Schritte
 *
 * Usage:
 *   const loop = new SimulationLoop(simulation, { hz: 30 });
 *   // In der rAF-Loop:
 *   const { steps, alpha } = loop.advance(realDt);
 *   // Rendering liest simulation.world direkt (single-threaded, keine Race)
 */
export class SimulationLoop {
  constructor(simulation, options = {}) {
    this.simulation = simulation;
    this.hz = options.hz || 30;
    this.fixedDt = 1 / this.hz;
    this.accumulator = 0;
    this.simTime = 0;

    // Verhindert Spiral-of-Death: wenn die Simulation zu weit hinterherhinkt,
    // verwerfen wir die überschüssige Zeit statt endlos weiter zu rechnen.
    this.maxSubSteps = options.maxSubSteps || 5;
    this.maxAccumulator = this.fixedDt * this.maxSubSteps;

    // Telemetrie
    this.tickCount = 0;
    this.lastTickStats = { steps: 0, alpha: 0, skipped: 0 };
  }

  /**
   * Advanziert die Simulation um realDt Sekunden.
   *
   * Führt 0..maxSubSteps Simulationsschritte aus, jeder mit fixedDt.
   * Gibt { steps, alpha, skipped } zurück, wobei alpha (0..1) angibt,
   * wie weit wir zwischen zwei Sim-Ticks sind (für Interpolation).
   *
   * @param {number} realDt — echte verstrichene Zeit in Sekunden
   * @returns {{ steps: number, alpha: number, skipped: number }}
   */
  advance(realDt) {
    if (realDt <= 0) {
      this.lastTickStats = { steps: 0, alpha: this.accumulator / this.fixedDt, skipped: 0 };
      return this.lastTickStats;
    }

    this.accumulator += realDt;

    // Clamp: zu weit hinterher → Zeit verwerfen
    let skipped = 0;
    if (this.accumulator > this.maxAccumulator) {
      skipped = this.accumulator - this.maxAccumulator;
      this.accumulator = this.maxAccumulator;
    }

    let steps = 0;
    while (this.accumulator >= this.fixedDt && steps < this.maxSubSteps) {
      this.simulation.update(this.fixedDt, this.simTime);
      this.simTime += this.fixedDt;
      this.accumulator -= this.fixedDt;
      this.tickCount++;
      steps++;
    }

    const alpha = this.accumulator / this.fixedDt;
    this.lastTickStats = { steps, alpha, skipped };
    return this.lastTickStats;
  }

  /**
   * Setzt den Accumulator zurück (z.B. nach hardReset oder Tab-Wechsel).
   */
  reset() {
    this.accumulator = 0;
    this.simTime = 0;
    this.tickCount = 0;
  }

  /**
   * Aktuelle Sim-Tickrate (effektiv), gemessen über die letzten Ticks.
   */
  get effectiveHz() {
    return this.hz;
  }
}
