import { CONFIG } from "../config.js";
import { clamp } from "../utils/math.js";

/**
 * CameraController — Viewport-Größe, Kamera-Transformation und Zoom-Logik.
 *
 * Folgt demselben Pattern wie die System-Module:
 * erhält die Simulation im Konstruktor und greift über Getter auf
 * world, camera, … zu.
 */
export class CameraController {
  constructor(simulation) {
    this.simulation = simulation;
  }

  get world() { return this.simulation.world; }
  get camera() { return this.simulation.camera; }

  resize(width, height, dpr) {
    const portrait = height > width;

    this.world.dpr = dpr;
    this.world.width = width;
    this.world.height = height;
    this.world.minSide = Math.min(width, height);
    this.world.centerX = width * 0.5;
    this.world.centerY = portrait ? height * 0.47 : height * 0.5;
    this.world.layoutScale = portrait ? 0.58 : 0.48;

    this.clampCameraOffset();

    for (const cluster of this.world.clusters) {
      cluster.updateRadius();
    }
  }

  screenToScene(point) {
    return {
      x: (point.x - this.world.centerX - this.camera.offsetX) / this.camera.scale + this.world.centerX,
      y: (point.y - this.world.centerY - this.camera.offsetY) / this.camera.scale + this.world.centerY
    };
  }

  clampCameraOffset() {
    const scaleOverflow = Math.max(0, this.camera.targetScale - 1);
    const maxOffsetX = this.world.width * 0.38 * scaleOverflow;
    const maxOffsetY = this.world.height * 0.34 * scaleOverflow;

    this.camera.targetOffsetX = clamp(this.camera.targetOffsetX, -maxOffsetX, maxOffsetX);
    this.camera.targetOffsetY = clamp(this.camera.targetOffsetY, -maxOffsetY, maxOffsetY);

    if (this.camera.targetScale <= 1.01) {
      this.camera.targetOffsetX = 0;
      this.camera.targetOffsetY = 0;
    }
  }

  zoomAt(screenPoint, nextScale) {
    const oldScale = this.camera.targetScale;
    const clampedScale = clamp(nextScale, CONFIG.minZoom, CONFIG.maxZoom);
    const sceneX = (screenPoint.x - this.world.centerX - this.camera.targetOffsetX) / oldScale + this.world.centerX;
    const sceneY = (screenPoint.y - this.world.centerY - this.camera.targetOffsetY) / oldScale + this.world.centerY;

    this.camera.targetScale = clampedScale;
    this.camera.targetOffsetX = screenPoint.x - this.world.centerX - (sceneX - this.world.centerX) * clampedScale;
    this.camera.targetOffsetY = screenPoint.y - this.world.centerY - (sceneY - this.world.centerY) * clampedScale;

    this.clampCameraOffset();
  }
}
