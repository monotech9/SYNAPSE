/**
 * systemFactory.js — Factory für System-Instanziierung
 *
 * Extrahiert die duplizierte System-Erzeugung aus NeuroSimulation.js
 * Constructor und hardResetRuntime() in eine gemeinsame Funktion.
 *
 * Consciousness wird NICHT hier erstellt — es braucht das world-Objekt
 * und wird separat nach world-Init erzeugt.
 */

import { PulseEngine } from "./systems/energy/PulseEngine.js";
import { NetworkBuilder } from "./systems/network/NetworkBuilder.js";
import { NetworkPruning } from "./systems/network/NetworkPruning.js";
import { UpdateLoop } from "./systems/lifecycle/UpdateLoop.js";
import { SignalSystem } from "./systems/energy/SignalSystem.js";
import { GrowthSystem } from "./systems/lifecycle/GrowthSystem.js";
import { CameraController } from "./CameraController.js";
import { SnapshotProvider } from "../diagnostics/SnapshotProvider.js";
import { HeartbeatSystem } from "./systems/lifecycle/HeartbeatSystem.js";
import { ScarSystem } from "./systems/external/ScarSystem.js";
import { EmergenceSystem } from "./systems/emergence/EmergenceSystem.js";
import { EmergenceDetector } from "./systems/emergence/EmergenceDetector.js";
import { StoryMappingEngine } from "./systems/narrative/StoryMappingEngine.js";
import { EmotionEngine } from "./systems/emotion/EmotionEngine.js";
import { SleepCycle } from "./systems/sleep/SleepCycle.js";
import { EpisodicMemory } from "./systems/memory/EpisodicMemory.js";
import { AutobiographicalMemory } from "./systems/memory/AutobiographicalMemory.js";
import { RewardSystem } from "./systems/energy/RewardSystem.js";
import { MoodStateMachine } from "./systems/emotion/MoodStateMachine.js";
import { EchoMemory } from "./systems/memory/EchoMemory.js";
import { ExternalStimuli } from "./systems/external/ExternalStimuli.js";
import { EnergyModel } from "./systems/energy/EnergyModel.js";
import { MultiAgentHub } from "./systems/external/MultiAgentHub.js";
import { RelationshipLayer } from "./systems/external/RelationshipLayer.js";
import { SpontaneityEngine } from "./systems/lifecycle/SpontaneityEngine.js";
import { NetworkMoodBridge } from "./systems/external/NetworkMoodBridge.js";

/**
 * Erstellt alle Subsysteme (außer Consciousness) und weist sie dem
 * Simulation-Objekt zu. Wird vom Constructor und hardResetRuntime()
 * gemeinsam genutzt.
 *
 * @param {NeuroSimulation} sim — Die Simulation-Instanz
 * @param {boolean} destroyOld — Ob alte Systeme zerstört werden sollen (Reset)
 */
export function createSystems(sim, destroyOld = false) {
  if (destroyOld) {
    sim.consciousness?.destroy();
    sim.episodicMemory?.destroy();
    sim.autobiographicalMemory?.destroy();
    sim.relationshipLayer?.destroy();
    sim.networkMoodBridge?.destroy();
    sim.spontaneityEngine?.destroy();
  }

  sim.pulseEngine = new PulseEngine(sim);
  sim.networkBuilder = new NetworkBuilder(sim);
  sim.networkPruning = new NetworkPruning(sim);
  sim.signalSystem = new SignalSystem(sim);
  sim.growthSystem = new GrowthSystem(sim);
  sim.spontaneityEngine = new SpontaneityEngine(sim);
  sim.updateLoop = new UpdateLoop(sim);
  sim.cameraController = new CameraController(sim);
  sim.snapshotProvider = new SnapshotProvider(sim);
  sim.heartbeatSystem = new HeartbeatSystem(sim);
  sim.scarSystem = new ScarSystem(sim);
  sim.emergenceSystem = new EmergenceSystem(sim);
  sim.emergenceDetector = new EmergenceDetector(sim);
  sim.storyEngine = new StoryMappingEngine(sim);
  sim.emotionEngine = new EmotionEngine(sim);
  sim.sleepCycle = new SleepCycle(sim);
  sim.episodicMemory = new EpisodicMemory(sim);
  sim.autobiographicalMemory = new AutobiographicalMemory(sim);
  sim.rewardSystem = new RewardSystem(sim);
  sim.moodStateMachine = new MoodStateMachine(sim);
  sim.echoMemory = new EchoMemory(sim);
  sim.externalStimuli = new ExternalStimuli(sim);
  sim.energyModel = new EnergyModel(sim);
  sim.multiAgentHub = new MultiAgentHub(sim);
  sim.relationshipLayer = new RelationshipLayer(sim);
  sim.networkMoodBridge = new NetworkMoodBridge(sim);
  sim.consciousness = null;  // wird nach world-Init erstellt
}
