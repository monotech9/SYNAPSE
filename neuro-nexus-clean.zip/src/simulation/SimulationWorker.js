/**
 * Web Worker für Neuro Nexus Simulation.
 *
 * Verlegt NeuroSimulation.update() in einen Background-Thread, sodass
 * der Main Thread nur noch für Rendering und Input zuständig ist.
 *
 * Protokoll:
 * - main → worker: { type: "init", seed, rngState, identity, memory, growth, age }
 * - main → worker: { type: "update", dt, timeSeconds }
 * - main → worker: { type: "pointer", x, y, kind: "inject"|"addNode"|"prune" }
 * - main → worker: { type: "save" }
 * - main → worker: { type: "resize", width, height, dpr }
 * - worker → main: { type: "ready" }
 * - worker → main: { type: "frame", snapshot }
 * - worker → main: { type: "saved", state }
 * - worker → main: { type: "stageChange", old, new }
 * - worker → main: { type: "error", message, stack }
 *
 * Aktivierung: ?worker=1 URL-Parameter
 */

// Worker-sicherer Import — keine DOM-Abhängigkeiten
import { NeuroSimulation } from "./NeuroSimulation.js";
import { Random } from "../utils/random.js";
import { createIdentity, serializeIdentity } from "./identity.js";
import { createMemoryState, serializeMemoryState } from "./memory.js";

let simulation = null;

// Worker-sichere Storage-Implementierung (no-op, persistence wird im Main-Thread gehandhabt)
const workerStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
  clear: () => {},
  key: () => null,
  length: 0
};

// Überschreibe localStorage/sessionStorage im Worker-Kontext
if (typeof globalThis.localStorage === "undefined") {
  globalThis.localStorage = workerStorage;
}
if (typeof globalThis.sessionStorage === "undefined") {
  globalThis.sessionStorage = workerStorage;
}

// performance.now() im Worker (manche Browser haben das nicht)
if (typeof performance === "undefined") {
  globalThis.performance = { now: () => Date.now() };
}

// matchMedia im Worker (no-op)
if (typeof globalThis.matchMedia === "undefined") {
  globalThis.matchMedia = () => ({ matches: false, addListener: () => {}, removeListener: () => {} });
}

self.onmessage = function(e) {
  const msg = e.data;

  switch (msg.type) {
    case "init": {
      try {
        // NeuroSimulation() takes no arguments — it loads from persistentState.
        // In the worker, localStorage is a no-op, so it creates a fresh state.
        // We then manually apply the init data from the main thread.
        simulation = new NeuroSimulation();

        // Apply seed + RNG state from main thread
        if (msg.seed !== undefined) {
          simulation.persistentState.seed = msg.seed >>> 0;
          simulation.rng = new Random(msg.seed >>> 0, msg.rngState ?? null);
        }

        // Apply identity
        if (msg.identity) {
          simulation.identity = createIdentity(msg.seed >>> 0, msg.identity);
        }

        // Apply memory state
        if (msg.memory) {
          simulation.memory = createMemoryState(msg.memory);
        }

        // Apply growth stage + accumulated age
        if (msg.age !== undefined) {
          simulation.world.age = msg.age;
          simulation.persistentState.accumulatedAge = msg.age;
        }
        if (msg.growth) {
          simulation.world.growthStage = msg.growth;
          simulation.world.previousGrowthStage = msg.growth;
        }

        simulation.ensureClusters();

        // Stage-Change-Listener an Main-Thread weiterleiten
        simulation.onGrowthStageChange((event) => {
          self.postMessage({ type: "stageChange", old: event.old, new: event.new });
        });

        self.postMessage({ type: "ready" });
      } catch (err) {
        self.postMessage({ type: "error", message: String(err), stack: err.stack });
      }
      break;
    }

    case "update": {
      if (!simulation) return;
      try {
        simulation.update(msg.dt, msg.timeSeconds);
        const snapshot = extractRenderSnapshot(simulation);
        self.postMessage({ type: "frame", snapshot });
      } catch (err) {
        self.postMessage({ type: "error", message: String(err), stack: err.stack });
      }
      break;
    }

    case "pointer": {
      if (!simulation) return;
      try {
        if (msg.kind === "inject") {
          simulation.injectSignal(msg.x, msg.y);
        } else if (msg.kind === "addNode") {
          simulation.addManualNode(msg.x, msg.y);
        } else if (msg.kind === "prune") {
          simulation.pruneArea(msg.x, msg.y);
        }
      } catch (err) {
        self.postMessage({ type: "error", message: String(err) });
      }
      break;
    }

    case "save": {
      if (!simulation) return;
      try {
        const state = {
          seed: simulation.persistentState.seed,
          rngState: simulation.rng.getState(),
          age: simulation.world.age,
          identity: serializeIdentity(simulation.identity),
          memory: serializeMemoryState(simulation.memory),
          growth: simulation.world.growthStage
        };
        self.postMessage({ type: "saved", state });
      } catch (err) {
        self.postMessage({ type: "error", message: String(err) });
      }
      break;
    }

    case "resize": {
      if (!simulation) return;
      simulation.resize(msg.width, msg.height, msg.dpr);
      break;
    }
  }
};

/**
 * Extrahiert einen render-fähigen Snapshot aus der Simulation.
 * Nur die Daten, die der Renderer braucht — nicht die gesamte Welt.
 */
function extractRenderSnapshot(sim) {
  const world = sim.world;
  const time = world.currentTime;

  const clusters = world.clusters.map(c => ({
    id: c.id,
    type: c.type,
    role: c.role,
    state: c.state,
    angle: c.angle,
    distance: c.distance,
    phase: c.phase,
    birthProgress: c.birthProgress,
    pixelRadius: c.pixelRadius,
    activityMemory: c.activityMemory,
    memoryStrength: c.memoryStrength,
    stability: c.stability,
    stress: c.stress,
    saturation: c.saturation,
    isRelay: c.isRelay || false,
    lifespanRemaining: c.lifespanRemaining || 0,
    center: c.center(time),
    nodes: c.nodes.map(n => ({
      index: n.index,
      birthProgress: n.birthProgress,
      activation: n.activation,
      charge: n.charge,
      visualImpact: n.visualImpact || 0,
      mass: n.mass,
      isCore: n.isCore || false,
      position: n.position(time)
    }))
  }));

  const edges = world.edges.map(e => ({
    aIndex: e.a.cluster.id + ":" + e.a.index,
    bIndex: e.b.cluster.id + ":" + e.b.index,
    weight: e.weight,
    memory: e.memory,
    identityTrace: e.identityTrace || 0,
    birthProgress: e.birthProgress,
    bridge: e.bridge,
    fatigue: e.fatigue || 0,
    visualActivity: e.visualActivity || 0,
    pathGlow: e.pathGlow || 0,
    preferredPathScore: e.preferredPathScore || 0,
    isRelayBridge: e.isRelayBridge || false,
    phase: e.phase
  }));

  const pulses = world.pulses.map(p => ({
    edgeIndex: world.edges.indexOf(p.edge),
    t: p.t,
    strength: p.strength,
    visualOnly: p.visualOnly,
    forward: p.from === p.edge.a
  }));

  const waves = (world.injectedWaves || []).map(w => ({
    x: w.x,
    y: w.y,
    radius: w.radius,
    strength: w.strength,
    life: w.life,
    maxLife: w.maxLife,
    rgb: w.rgb
  }));

  return {
    age: world.age,
    maturity: world.maturity,
    growthStage: world.growthStage,
    pointerEnergy: world.pointerEnergy,
    centerX: world.centerX,
    centerY: world.centerY,
    width: world.width,
    height: world.height,
    minSide: world.minSide,
    camera: { ...sim.camera },
    clusters,
    edges,
    pulses,
    waves,
    activeDragLine: world.activeDragLine || null
  };
}
