/**
 * SpatialGrid — Einfaches Grid für räumliche Anfragen.
 *
 * Ersetzt lineares Scannen aller Nodes bei Pointer-Interaktion.
 * Teilt die Szene in Zellen auf und ordnet Nodes zu Zellen zu.
 * findNearest() prüft nur Nodes in benachbarten Zellen statt alle.
 *
 * Performance: O(1) Lookup statt O(n) bei 160+ Nodes.
 */
export class SpatialGrid {
  constructor(cellSize = 80) {
    this.cellSize = cellSize;
    this._cells = new Map();
    this._dirty = false;
  }

  setCellSize(size) {
    if (size !== this.cellSize) {
      this.cellSize = size;
      this._dirty = true;
    }
  }

  clear() {
    this._cells.clear();
    this._dirty = false;
  }

  _key(x, y) {
    const cx = Math.floor(x / this.cellSize);
    const cy = Math.floor(y / this.cellSize);
    return cx * 100000 + cy;
  }

  insert(node, x, y) {
    const key = this._key(x, y);
    if (!this._cells.has(key)) {
      this._cells.set(key, []);
    }
    this._cells.get(key).push({ node, x, y });
  }

  /**
   * Findet den nächsten Node zu (x, y).
   * Prüft die Zelle bei (x,y) und alle 8 Nachbarn.
   * Falls leer, fällt auf lineare Suche zurück.
   */
  findNearest(x, y, maxRadius = 3) {
    const cx = Math.floor(x / this.cellSize);
    const cy = Math.floor(y / this.cellSize);

    let nearest = null;
    let nearestDist = Infinity;

    // Suche in wachsendem Radius um die Ziel-Zelle
    for (let r = 0; r <= maxRadius; r++) {
      for (let dx = -r; dx <= r; dx++) {
        for (let dy = -r; dy <= r; dy++) {
          // Nur den Rand des aktuellen Radius prüfen (innen schon erledigt)
          if (r > 0 && Math.abs(dx) < r && Math.abs(dy) < r) continue;
          const key = (cx + dx) * 100000 + (cy + dy);
          const cell = this._cells.get(key);
          if (!cell) continue;
          for (const entry of cell) {
            const dist = Math.hypot(entry.x - x, entry.y - y);
            if (dist < nearestDist) {
              nearestDist = dist;
              nearest = entry.node;
            }
          }
        }
      }
      // Frühzeitiger Abbruch wenn wir im innersten Ring gefunden haben
      if (nearest && r === 0) return { node: nearest, distance: nearestDist };
    }

    return nearest ? { node: nearest, distance: nearestDist } : null;
  }

  /**
   * Findet alle Nodes innerhalb eines Radius.
   */
  queryRadius(x, y, radius) {
    const results = [];
    const r = Math.ceil(radius / this.cellSize);
    const cx = Math.floor(x / this.cellSize);
    const cy = Math.floor(y / this.cellSize);

    for (let dx = -r; dx <= r; dx++) {
      for (let dy = -r; dy <= r; dy++) {
        const key = (cx + dx) * 100000 + (cy + dy);
        const cell = this._cells.get(key);
        if (!cell) continue;
        for (const entry of cell) {
          const dist = Math.hypot(entry.x - x, entry.y - y);
          if (dist <= radius) {
            results.push({ node: entry.node, distance: dist });
          }
        }
      }
    }
    return results;
  }
}
