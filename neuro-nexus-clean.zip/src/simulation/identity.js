
import { NETWORK_NAMES } from "../content/narrative.js";
import { hashString } from "../utils/math.js";
export function createIdentity(seed, stored = {}) {
  const index = hashString(`${seed}:name`) % NETWORK_NAMES.length;

  return {
    name: typeof stored.name === "string" && stored.name.trim()
      ? stored.name.trim().slice(0, 18).toUpperCase()
      : NETWORK_NAMES[index],
    createdAt: Number(stored.createdAt || Date.now())
  };
}

export function serializeIdentity(identity) {
  return {
    name: identity.name,
    createdAt: identity.createdAt
  };
}
