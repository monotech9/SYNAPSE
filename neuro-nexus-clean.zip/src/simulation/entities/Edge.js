import { clamp, ease, lerp } from "../../utils/math.js";
import { updateEdgeMemory } from "../memory.js";

export class Edge {
  constructor(simulation, a, b, options = {}) {
    const rng = simulation.rng;

    this.simulation = simulation;
    this.a = a;
    this.b = b;
    this.weight = options.weight ?? rng.range(0.18, 0.55);
    this.bridge = options.bridge || false;

    this.birthAge = 0;
    this.birthDuration = options.birthDuration ?? rng.range(3.4, 7.6);
    this.birthProgress = options.instant ? 1 : 0;

    this.cooldown = rng.range(0.2, 1.0);
    this.memory = rng.range(0.08, 0.38);
    this.identityTrace = options.identityTrace ?? rng.range(0.015, 0.08);
    this.visualActivity = options.visualActivity ?? 0;
    this.pathPulseGlow = options.pathPulseGlow ?? 0;

    // Rendering uses these smoothed values instead of raw pulse spikes.
    // Raw values may jump when a visual pulse starts/ends; these fields attack
    // quickly but decay slowly so edges feel alive without hard flicker.
    this.activityGlow = this.visualActivity;
    this.pathGlow = this.pathPulseGlow;
    this.preferredPathScore = 0;

    // traceGlow: smoothed identityTrace for stable preferred-path rendering.
    // Attacks fast (keeps up with reinforcement) but decays very slowly (0.06/s)
    // so well-worn paths stay visibly bright between pulse events.
    this.traceGlow = this.identityTrace;

    this.traceAge = 0;
    this.phase = rng.range(0, Math.PI * 2);

    // === Synaptische Ermüdung (Fatigue) ===
    // 0 = voll leistungsfähig, 1 = vollständig erschöpft.
    // Steigt bei aktivem Pulse-Durchlauf, sinkt langsam bei Ruhe.
    // Erschöpfte Kanten haben geringere Pulse-Wahrscheinlichkeit und leuchten matter.
    this.fatigue = 0;
    // Fatigue-Glow: geglätteter Wert für Rendering (verhindert Flackern)
    this.fatigueGlow = 0;

    // === Nachglühen (Afterglow) ===
    // Persistenter Glow nach Pulse-Durchlauf. Schnelles Attack (sofort hell),
    // langsames Decay über ~3 Sekunden. Macht frisch aktive Verbindungen
    // visuell nachlesbar — man sieht, wo gerade etwas passiert ist.
    this.afterglow = 0;

    // Peak-Tracking: höchste jemals erreichte identityTrace und memory
    // Wird für die Narbenbildung verwendet — eine Kante die einmal wichtig war,
    // hinterlässt eine stärkere Narbe auch wenn sie zum Zeitpunkt des Prunings
    // bereits schwach ist.
    this.peakTrace = this.identityTrace;
    this.peakMemory = this.memory;
    this.peakWeight = this.weight;
  }

  birthEase() {
    return ease(this.birthProgress);
  }

  dominantType() {
    if (this.a.cluster.type === this.b.cluster.type) return this.a.cluster.type;
    return this.bridge ? this.b.cluster.type : this.a.cluster.type;
  }

  /**
   * Wird vom PulseEngine aufgerufen, wenn ein Pulse diese Kante durchläuft.
   * Erhöht die Ermüdung — häufig genutzte Kanten werden vorübergehend schwächer.
   */
  applyFatigue(amount = 0.08) {
    this.fatigue = Math.min(1, this.fatigue + amount);
  }

  update(dt) {
    const rng = this.simulation.rng;
    const { personality } = this.simulation;

    if (this.birthProgress < 1) {
      this.birthAge += dt;
      this.birthProgress = clamp(this.birthAge / this.birthDuration, 0, 1);
    }

    this.cooldown = Math.max(0, this.cooldown - dt);
    this.visualActivity = Math.max(0, this.visualActivity - dt * (this.bridge ? 0.32 : 0.38));
    this.pathPulseGlow = Math.max(0, (this.pathPulseGlow || 0) - dt * (this.bridge ? 0.32 : 0.28));

    // Afterglow: langsames Abklingen über ~3 Sekunden
    this.afterglow = Math.max(0, this.afterglow - dt * 0.33);

    // Peak-Tracking aktualisieren
    this.peakTrace = Math.max(this.peakTrace || 0, this.identityTrace || 0);
    this.peakMemory = Math.max(this.peakMemory || 0, this.memory || 0);
    this.peakWeight = Math.max(this.peakWeight || 0, this.weight || 0);

    // === Fatigue: Erholung bei Ruhe ===
    // Ermüdung klingt mit 0.04/s ab → volle Erholung nach ~25s Ruhe
    this.fatigue = Math.max(0, this.fatigue - dt * 0.04);
    // Fatigue-Glow: schnelles Attack, langsames Decay (verhindert Flackern)
    const fatigueTarget = this.fatigue;
    const fatigueRate = fatigueTarget > this.fatigueGlow ? 4.0 : 0.15;
    this.fatigueGlow = lerp(this.fatigueGlow, fatigueTarget, clamp(dt * fatigueRate, 0, 1));

    updateEdgeMemory(this, dt, personality, this.a.cluster, this.b.cluster);

    const aActive = this.a.activation;
    const bActive = this.b.activation;
    const activeDifference = Math.abs(aActive - bActive);
    const combinedActivity = (aActive + bActive) * 0.5;
    const retention = (this.a.cluster.retentionBias + this.b.cluster.retentionBias) * 0.5;
    const plasticity = (this.a.cluster.plasticityBias + this.b.cluster.plasticityBias) * 0.5;

    const rawActivityTarget = clamp(Math.max(this.visualActivity || 0, combinedActivity * 0.44), 0, 1);
    const rawPathTarget = clamp(Math.max(this.pathPulseGlow || 0, (this.identityTrace || 0) * 0.42), 0, 1);
    const activityRate = rawActivityTarget > (this.activityGlow || 0) ? 6.4 : (this.bridge ? 0.72 : 0.9);
    const pathRate = rawPathTarget > (this.pathGlow || 0) ? 4.8 : 0.52;
    this.activityGlow = lerp(this.activityGlow || 0, rawActivityTarget, clamp(dt * activityRate, 0, 1));
    this.pathGlow = lerp(this.pathGlow || 0, rawPathTarget, clamp(dt * pathRate, 0, 1));

    // traceGlow: fast attack (keeps pace with reinforcement), very slow decay
    // so preferred paths remain visibly distinct for many seconds between pulses.
    const traceTarget = clamp(this.identityTrace || 0, 0, 1);
    const traceRate = traceTarget > (this.traceGlow || 0) ? 5.5 : 0.06;
    this.traceGlow = lerp(this.traceGlow || 0, traceTarget, clamp(dt * traceRate, 0, 1));

    // Passive glow top-up for well-established paths: keeps strong edges quietly
    // lit even when no pulse is actively traversing them.
    if ((this.identityTrace || 0) > 0.55 && !this.bridge) {
      this.pathPulseGlow = Math.max(this.pathPulseGlow || 0, (this.identityTrace - 0.55) * 0.38);
    }

    const preferredTarget = clamp((this.identityTrace || 0) * 1.18 + (this.pathGlow || 0) * 0.34 + this.weight * 0.12, 0, 1);
    // Lowered decay rate (0.24 → 0.14) so preferredPathScore holds longer between pulses.
    const preferredRate = preferredTarget > (this.preferredPathScore || 0) ? 1.55 : 0.14;
    this.preferredPathScore = lerp(this.preferredPathScore || 0, preferredTarget, clamp(dt * preferredRate, 0, 1));

    this.memory = lerp(this.memory, combinedActivity, dt * 0.36 * personality.memoryLearningMultiplier * retention);

    if (this.birthProgress >= 0.2 && combinedActivity > 0.46 && activeDifference < 0.31) {
      this.weight = clamp(this.weight + dt * 0.012 * personality.learningRateMultiplier * plasticity, 0.06, 0.9);
    } else {
      this.weight = clamp(this.weight - dt * 0.0035 * personality.pruningRateMultiplier / Math.max(0.72, retention), 0.06, 0.9);
    }

    if (this.birthProgress < 0.72) return;

    if (this.cooldown <= 0 && combinedActivity > 0.12) {
      const bridgePenalty = this.bridge ? 0.72 : 1;
      const traceBoost = clamp(this.identityTrace || 0, 0, 1) * 0.012;
      // === Fatigue dämpft die Pulse-Wahrscheinlichkeit ===
      // Bei fatigue=1 wird die Wahrscheinlichkeit auf 30% des Basiswerts reduziert.
      const fatiguePenalty = 1 - this.fatigue * 0.7;
      const probability = 0.0038 * bridgePenalty * fatiguePenalty * (0.84 + personality.volatility * 0.28 + personality.rhythm * 0.28);

      if (rng.chance(probability + this.weight * 0.004 * fatiguePenalty + traceBoost * 0.68)) {
        const forward = aActive >= bActive;
        this.simulation.pulseEngine.spawnPulse(this, forward, Math.max(0.12, combinedActivity * this.weight + (this.identityTrace || 0) * 0.14));
        // Fatigue durch Pulse-Auslösung erhöhen
        this.applyFatigue(0.08);
        this.afterglow = Math.min(1, this.afterglow + 0.45);
        this.cooldown = rng.range(0.52, this.bridge ? 1.65 : 1.05);
      }
    }
  }
}
