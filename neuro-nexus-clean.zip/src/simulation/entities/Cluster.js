import { CLUSTER_TYPES } from "../../config.js";
import { clamp, ease, lerp } from "../../utils/math.js";
import { ClusterStates, createRoleProfile, normalizeClusterRole } from "../clusterRoles.js";
import { Node } from "./Node.js";

export class Cluster {
  constructor(simulation, blueprint, index, instant) {
    const rng = simulation.rng;
    const role = normalizeClusterRole(blueprint.role || blueprint.type);
    const type = blueprint.type || role;
    const typeConfig = CLUSTER_TYPES[type] || CLUSTER_TYPES[role] || CLUSTER_TYPES.exploration;
    const roleProfile = createRoleProfile(role, simulation.personality);

    this.simulation = simulation;
    this.id = blueprint.id;
    this.type = typeConfig === CLUSTER_TYPES.evolving ? "exploration" : typeConfig === CLUSTER_TYPES.ancient ? "memory" : type;
    this.role = roleProfile.role;
    this.state = blueprint.state || (this.role === "genesis" ? ClusterStates.ACTIVE : ClusterStates.SEEDLING);
    this.parentId = blueprint.parentId || null;
    this.index = index;
    this.threshold = blueprint.threshold || 0;
    this.angle = blueprint.angle || 0;
    this.distance = blueprint.distance || 0;
    this.createdAtAge = Number.isFinite(blueprint.createdAtAge) ? blueprint.createdAtAge : simulation.world.age;

    this.phase = rng.range(0, Math.PI * 2);
    // Atemphase: subtile, kontinuierliche Skalierungs-Oszillation für lebende Cluster
    this.breathPhase = rng.range(0, Math.PI * 2);
    this.rotation = rng.range(-0.24, 0.24);
    this.radiusFactor = typeConfig.radius * rng.range(0.94, 1.1);
    this.pixelRadius = 1;
    this.motionBias = this.role === "exploration" ? 1.18 : this.role === "memory" ? 0.72 : this.role === "stable" ? 0.82 : 1;

    this.birthAge = instant ? 999 : 0;
    this.birthDuration = blueprint.birthDuration || rng.range(10, 18);
    this.birthProgress = instant ? 1 : 0;

    this.nodes = [];
    this.activityMemory = rng.range(0.10, 0.26);

    this.maturity = Number(blueprint.maturity || 0);
    this.density = Number(blueprint.density || 0);
    this.stability = Number(blueprint.stability || 0);
    this.stress = Number(blueprint.stress || 0);
    this.saturation = Number(blueprint.saturation || 0);
    this.memoryStrength = Number(blueprint.memoryStrength || 0);
    this.expansionPressure = Number(blueprint.expansionPressure || 0);
    this.localActivity = Number(blueprint.localActivity || 0);
    this.recentActivity = Number(blueprint.recentActivity || 0);
    this.bridgeStrength = Number(blueprint.bridgeStrength || 0);
    this.internalEdgeCount = 0;
    this.bridgeEdgeCount = 0;
    this.age = 0;

    this.softNodeLimit = Number(blueprint.softNodeLimit || roleProfile.softNodeLimit);
    this.hardNodeLimit = Number(blueprint.hardNodeLimit || roleProfile.hardNodeLimit);
    this.growthBias = Number(blueprint.growthBias || roleProfile.growthBias);
    this.bridgeBias = Number(blueprint.bridgeBias || roleProfile.bridgeBias);
    this.retentionBias = Number(blueprint.retentionBias || roleProfile.retentionBias);
    this.plasticityBias = Number(blueprint.plasticityBias || roleProfile.plasticityBias);

    this.budCooldown = Number(blueprint.budCooldown || 0);
    this.dormantTimer = Number(blueprint.dormantTimer || 0);

    // Relay-Cluster: temporär, ohne eigene Nodes, nur Bridge-Hub
    this.isRelay = (this.type === "relay");
    this.lifespan = blueprint.lifespan || 0;  // 0 = permanent; >0 = Relay mit Timer
    this.lifespanRemaining = this.isRelay ? this.lifespan : 0;
    this.relayConnectedClusters = [];  // Cluster-Paare, die dieser Relay verbindet

    const initialNodes = Number.isFinite(blueprint.initialNodes) ? blueprint.initialNodes : typeConfig.initialNodes;
    if (!this.isRelay) {
      this.createInitialNodes(initialNodes, instant);
    }
  }

  birthEase() {
    return ease(this.birthProgress);
  }

  maxNodes() {
    return this.hardNodeLimit;
  }

  createInitialNodes(count, instant) {
    const rng = this.simulation.rng;

    this.nodes.push(new Node(this.simulation, this, {
      index: 0,
      originLocalX: 0,
      originLocalY: 0,
      targetLocalX: 0,
      targetLocalY: 0,
      mass: 1.65,
      phase: rng.range(0, Math.PI * 2),
      birthDuration: rng.range(3.8, 7.2),
      isCore: true,
      instant
    }));

    for (let i = 1; i <= count; i += 1) {
      const goldenAngle = 2.399963229728653;
      const indexRatio = i / Math.max(1, count + 1);
      const baseAngle = this.role === "genesis"
        ? this.phase + i * goldenAngle + rng.range(-0.22, 0.22)
        : this.phase + i * goldenAngle + rng.range(-0.38, 0.38);
      const seedlingScale = this.state === ClusterStates.SEEDLING ? 0.54 : 1;
      const roleScale = this.role === "genesis" ? 0.82 : this.role === "memory" ? 0.62 : 0.74;
      const radius = clamp(
        (0.18 + Math.sqrt(indexRatio) * 0.58 + rng.range(-0.035, 0.05)) * seedlingScale * roleScale,
        0.12,
        this.state === ClusterStates.SEEDLING ? 0.56 : 0.86
      );
      const elliptic = this.role === "genesis" ? rng.range(0.94, 1.06) : rng.range(0.88, 1.12);

      this.nodes.push(new Node(this.simulation, this, {
        index: i,
        originLocalX: 0,
        originLocalY: 0,
        targetLocalX: Math.cos(baseAngle) * radius * elliptic,
        targetLocalY: Math.sin(baseAngle) * radius / elliptic,
        mass: rng.range(0.5, 1.42),
        phase: rng.range(0, Math.PI * 2),
        birthDuration: instant ? 1 : rng.range(5.8, 14.5),
        instant
      }));
    }
  }

  center(timeSeconds) {
    const world = this.simulation.world;
    const layoutRadius = world.minSide * world.layoutScale;
    const birthPull = this.birthEase();

    const angle = this.angle + Math.sin(timeSeconds * 0.032 + this.phase) * 0.06;
    const distance = this.distance * layoutRadius * birthPull;

    // Zustandsabhängige Bewegungscharakteristik:
    //  - DORMANT: sehr langsam, schwer (schlafende Entität)
    //  - SEEDLING: sanft, zögerlich (neu entstehend)
    //  - ACTIVE/FORMING: lebhaft, responsiv
    const stateConfig = {
      [ClusterStates.DORMANT]:  { driftMul: 0.22, driftSpeed: 0.04, breathSpeed: 0.18, breathAmp: 0.015 },
      [ClusterStates.SEEDLING]: { driftMul: 0.68, driftSpeed: 0.07, breathSpeed: 0.32, breathAmp: 0.022 },
      [ClusterStates.FORMING]:  { driftMul: 0.82, driftSpeed: 0.09, breathSpeed: 0.38, breathAmp: 0.028 },
      [ClusterStates.ACTIVE]:   { driftMul: 1.0,  driftSpeed: 0.11, breathSpeed: 0.45, breathAmp: 0.032 },
    };
    const sc = stateConfig[this.state] || stateConfig[ClusterStates.ACTIVE];

    const drift = Math.sin(timeSeconds * sc.driftSpeed + this.phase) * 6 * birthPull
      * this.simulation.personality.driftMultiplier * this.motionBias * sc.driftMul;

    return {
      x: world.centerX + Math.cos(angle) * distance + Math.cos(this.phase) * drift,
      y: world.centerY + Math.sin(angle) * distance * 0.78 + Math.sin(this.phase) * drift
    };
  }

  /**
   * Atemzyklus-Wert (0..1) für visuelle Lesbarkeit.
   * Lebende Cluster atmen subtil — die Frequenz hängt vom Zustand ab,
   * die Amplitude von der Aktivität.
   *
   * Der Renderer nutzt dies für eine sanfte Skalierungs-Oszillation
   * der Cluster-Glow-Felder und Atmosphäre-Ringe.
   */
  breath(timeSeconds) {
    if (this.state === ClusterStates.DORMANT) return 0.5; // Dormanat: keine Atmung
    const stateConfig = {
      [ClusterStates.SEEDLING]: { speed: 0.32, amp: 0.022 },
      [ClusterStates.FORMING]:  { speed: 0.38, amp: 0.028 },
      [ClusterStates.ACTIVE]:   { speed: 0.45, amp: 0.032 },
    };
    const sc = stateConfig[this.state] || stateConfig[ClusterStates.ACTIVE];
    // Aktivität moduliert die Atemamplitude
    const activityBoost = 0.5 + this.activityMemory * 0.8;
    const raw = Math.sin(timeSeconds * sc.speed + this.breathPhase);
    return 1 + raw * sc.amp * activityBoost;
  }

  updateRadius() {
    const world = this.simulation.world;
    const portraitBoost = world.height > world.width ? 1.42 : 1.12;
    const stateScale = this.state === ClusterStates.SEEDLING
      ? 0.62
      : this.state === ClusterStates.FORMING
        ? 0.78
        : this.state === ClusterStates.DORMANT
          ? 0.76
          : 1;

    const nodeScale = clamp(this.nodes.length / Math.max(5, this.softNodeLimit), 0.78, 1.36);
    this.pixelRadius = Math.max(52, world.minSide * this.radiusFactor * portraitBoost * stateScale * nodeScale);
  }

  update(dt, timeSeconds) {
    if (this.birthProgress < 1) {
      this.birthAge += dt;
      this.birthProgress = clamp(this.birthAge / this.birthDuration, 0, 1);
    }

    this.budCooldown = Math.max(0, this.budCooldown - dt);

    let activitySum = 0;

    for (const node of this.nodes) {
      node.update(dt, timeSeconds);
      activitySum += node.activation;
    }

    const averageActivity = activitySum / Math.max(1, this.nodes.length);
    const rhythm = this.simulation.personality.rhythm;
    const stateMemory = this.state === ClusterStates.DORMANT ? 0.18 : this.retentionBias;
    this.activityMemory = lerp(this.activityMemory, averageActivity, dt * (0.36 + rhythm * 0.18) * stateMemory);

    // Relay-Lebenszyklus: Countdown bis zum Verblassen
    if (this.isRelay && this.lifespanRemaining > 0) {
      this.lifespanRemaining -= dt;
      // In den letzten 15s: sanftes Ausblenden über birthProgress
      if (this.lifespanRemaining < 15) {
        this.birthProgress = clamp(this.lifespanRemaining / 15, 0, 1);
      }
    }
  }

  /**
   * Gibt true zurück, wenn dieser Relay-Cluster abgelaufen ist.
   */
  isExpired() {
    return this.isRelay && this.lifespanRemaining <= 0;
  }
}
