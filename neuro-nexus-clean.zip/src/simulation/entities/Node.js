import { CONFIG } from "../../config.js";
import { clamp, ease, lerp } from "../../utils/math.js";
import { ClusterStates } from "../clusterRoles.js";

export class Node {
  constructor(simulation, cluster, options) {
    const rng = simulation.rng;

    this.simulation = simulation;
    this.cluster = cluster;
    this.index = options.index;
    this.originLocalX = options.originLocalX;
    this.originLocalY = options.originLocalY;
    this.targetLocalX = options.targetLocalX;
    this.targetLocalY = options.targetLocalY;
    this.mass = options.mass;
    this.phase = options.phase;
    this.isCore = options.isCore || false;

    this.birthAge = 0;
    this.birthDuration = Math.max(0.1, options.birthDuration);
    this.birthProgress = options.instant ? 1 : 0;

    this.activation = options.instant ? rng.range(0.05, 0.22) : rng.range(0.02, 0.12);
    this.charge = rng.range(0.02, 0.18);
    this.refractory = 0;
    this.visualImpact = options.visualImpact ?? (options.instant ? rng.range(0.08, 0.28) : 1);

    // Causal signal delay: when a pulse arrives, energy is staged here and
    // bleeds into activation/visualImpact after a short delay (see update()).
    this.incomingPulseEnergy = 0;
    this.incomingPulseTimer = 0;

    // Thermal load: accumulates when the node is heavily activated/signalled.
    // High thermalLoad slows decay and shifts node colour toward warm tones.
    this.thermalLoad = 0;

    // Scars: permanent marks of past intense activity.
    this.scarLevel = 0;
  }

  activationLimit() {
    return this.isCore ? CONFIG.maxCoreActivation : CONFIG.maxActivation;
  }

  setActivation(value) {
    this.activation = clamp(value, 0, this.activationLimit());
  }

  birthEase() {
    return ease(this.birthProgress);
  }

  localPosition() {
    const birth = this.birthEase();

    return {
      x: lerp(this.originLocalX, this.targetLocalX, birth),
      y: lerp(this.originLocalY, this.targetLocalY, birth)
    };
  }

  position(timeSeconds) {
    const cluster = this.cluster;
    const center = cluster.center(timeSeconds);
    const local = this.localPosition();
    const birth = this.birthEase();

    const stateMotion = cluster.state === ClusterStates.SEEDLING ? 1.35 : cluster.state === ClusterStates.DORMANT ? 0.48 : 1;
    const breath = 1 + Math.sin(timeSeconds * 0.32 + this.phase) * 0.025 * stateMotion;
    const driftScale = this.simulation.personality.driftMultiplier * stateMotion * cluster.motionBias;
    const driftX = Math.sin(timeSeconds * 0.47 + this.phase * 1.7) * this.mass * 1.4 * birth * driftScale;
    const driftY = Math.cos(timeSeconds * 0.41 + this.phase * 1.3) * this.mass * 1.4 * birth * driftScale;

    return {
      x: center.x + local.x * cluster.pixelRadius * breath + driftX,
      y: center.y + local.y * cluster.pixelRadius * breath + driftY
    };
  }

  update(dt, timeSeconds) {
    if (this.birthProgress < 1) {
      this.birthAge += dt;
      this.birthProgress = clamp(this.birthAge / this.birthDuration, 0, 1);
      this.activation = Math.max(this.activation, 0.16 * (1 - this.birthProgress));
    }

    // Causal signal delay: count down then apply staged pulse energy.
    if (this.incomingPulseTimer > 0) {
      this.incomingPulseTimer = Math.max(0, this.incomingPulseTimer - dt);
      if (this.incomingPulseTimer === 0 && this.incomingPulseEnergy > 0) {
        this.setActivation(Math.max(this.activation, this.incomingPulseEnergy));
        this.visualImpact = Math.max(this.visualImpact || 0, 0.42 + this.incomingPulseEnergy * 0.38);
        this.incomingPulseEnergy = 0;
      }
    }

    // Thermal load: accumulates when activation is high or node is frequently signalled.
    // Decays slowly so the warm state persists after bursts.
    const thermalTarget = this.activation > 0.62 ? 1 : (this.visualImpact || 0) > 0.5 ? 0.6 : 0;
    const thermalRate = thermalTarget > (this.thermalLoad || 0) ? 1.8 : 0.08;
    this.thermalLoad = clamp(lerp(this.thermalLoad || 0, thermalTarget, clamp(dt * thermalRate, 0, 1)), 0, 1);

    // Scars: If a node is repeatedly pushed to high thermal load, it develops a permanent scar.
    if (this.thermalLoad > 0.88) {
      this.scarLevel = Math.min(1, (this.scarLevel || 0) + dt * 0.008);
    }

    // When thermally loaded, visualImpact decays more slowly (retained signal).
    const thermalImpactDecay = 0.42 * (1 - (this.thermalLoad || 0) * 0.44);
    this.refractory = Math.max(0, this.refractory - dt);
    this.visualImpact = Math.max(0, this.visualImpact - dt * thermalImpactDecay);

    const clusterBaseline = this.cluster.state === ClusterStates.DORMANT ? 0.006 : 0.016;
    const baseline =
      clusterBaseline +
      Math.sin(timeSeconds * 0.26 + this.phase) * 0.005 +
      this.birthEase() * 0.006;

    const roleRetention = this.cluster.retentionBias;
    const stateDecay = this.cluster.state === ClusterStates.STRESSED ? 1.18 : this.cluster.state === ClusterStates.DORMANT ? 1.34 : 1;
    // Thermal load slows activation decay slightly (node holds its state longer).
    const thermalRetention = 1 + (this.thermalLoad || 0) * 0.32;
    const decay = CONFIG.nodeDecayPerSecond * this.simulation.personality.decayMultiplier * stateDecay * dt * (this.refractory > 0 ? 0.68 : 1) / (Math.max(0.72, roleRetention) * thermalRetention);

    this.setActivation(Math.max(baseline, this.activation - decay));
    this.charge = Math.max(0, this.charge - dt * 0.46);
  }
}
