import { CONFIG } from "../config.js";
import { clamp, average} from "../utils/math.js";
import { ClusterStates } from "./clusterRoles.js";
import { GrowthStages } from "./growthStages.js";

export const GrowthIntent = Object.freeze({
  ADD_NODE: "add_node",
  ADD_INTERNAL_EDGE: "add_internal_edge",
  STRENGTHEN_MEMORY_PATH: "strengthen_memory_path",
  CREATE_BRIDGE: "create_bridge",
  CREATE_BUD: "create_bud",
  PAUSE: "pause"
});

export function chooseGrowthIntent(simulation) {
  const { world, personality, rng } = simulation;
  const averageStress = average(world.clusters.map((cluster) => cluster.stress));
  const averageSaturation = average(world.clusters.map((cluster) => cluster.saturation));
  const core = world.clusters.find((cluster) => cluster.role === "genesis") || world.clusters[0];
  const minimumCoreNodes = world.age >= 86 ? 14 : world.age >= 52 ? 12 : world.age >= 20 ? 10 : 0;

  if (
    core &&
    (world.growthStage === GrowthStages.GENESIS || world.growthStage === GrowthStages.ACTIVATION || world.growthStage === GrowthStages.GROWTH) &&
    core.nodes.length < minimumCoreNodes
  ) {
    return { type: GrowthIntent.ADD_NODE, cluster: core };
  }

  const earlyAge = world.age < 120 ? 1 : 0;
  const pauseChance = clamp(
    0.16 + averageStress * 0.24 + averageSaturation * 0.16 + personality.caution * 0.14 + earlyAge * 0.08,
    0.12,
    0.52
  );

  if (rng.chance(pauseChance)) {
    return { type: GrowthIntent.PAUSE };
  }

  const budCandidate = findBuddingCandidate(simulation);
  if (budCandidate) {
    return { type: GrowthIntent.CREATE_BUD, cluster: budCandidate };
  }

  if (world.growthStage === GrowthStages.GENESIS || world.growthStage === GrowthStages.ACTIVATION || world.growthStage === GrowthStages.GROWTH) {
    const core = world.clusters.find((cluster) => cluster.role === "genesis") || world.clusters[0];
    return core ? chooseLocalIntent(simulation, core, true) : { type: GrowthIntent.PAUSE };
  }

  if (world.age >= 180 && (world.growthStage === GrowthStages.NETWORK || world.growthStage === GrowthStages.CONSTELLATION)) {
    const bridgeCount = world.bridgeEdges.length;
    if (world.clusters.length >= 2 && bridgeCount < CONFIG.maxBridgeEdges && rng.chance(personality.bridgeBias * 0.08)) {
      return { type: GrowthIntent.CREATE_BRIDGE };
    }
  }

  const cluster = chooseClusterForLocalGrowth(simulation);
  return cluster ? chooseLocalIntent(simulation, cluster, false) : { type: GrowthIntent.PAUSE };
}

function chooseLocalIntent(simulation, cluster, forceCoreStage) {
  const { rng } = simulation;

  if (!cluster || cluster.state === ClusterStates.DORMANT || cluster.state === ClusterStates.STRESSED) {
    return { type: GrowthIntent.PAUSE };
  }

  if (cluster.saturation >= 0.76) {
    return { type: GrowthIntent.STRENGTHEN_MEMORY_PATH, cluster };
  }

  if (forceCoreStage && cluster.density < 0.58 && cluster.nodes.length >= 9 && rng.chance(0.72)) {
    return { type: GrowthIntent.ADD_INTERNAL_EDGE, cluster };
  }

  if (cluster.nodes.length < Math.min(cluster.softNodeLimit, cluster.hardNodeLimit) && shouldAddNode(simulation, cluster, forceCoreStage)) {
    return { type: GrowthIntent.ADD_NODE, cluster };
  }

  if (cluster.density < 0.54 || rng.chance(cluster.plasticityBias * 0.18)) {
    return { type: GrowthIntent.ADD_INTERNAL_EDGE, cluster };
  }

  if (cluster.memoryStrength > 0.18 || cluster.state === ClusterStates.STABLE || rng.chance(cluster.retentionBias * 0.24)) {
    return { type: GrowthIntent.STRENGTHEN_MEMORY_PATH, cluster };
  }

  if (cluster.nodes.length < cluster.hardNodeLimit && rng.chance(cluster.growthBias * 0.2)) {
    return { type: GrowthIntent.ADD_NODE, cluster };
  }

  return { type: GrowthIntent.PAUSE };
}

function shouldAddNode(simulation, cluster, forceCoreStage) {
  const { rng, personality, world } = simulation;

  if (cluster.nodes.length >= cluster.hardNodeLimit) return false;
  if (cluster.state === ClusterStates.STABLE && rng.chance(0.62)) return false;
  if (cluster.role === "memory" && rng.chance(0.72)) return false;

  // Early morphology budget: first the genesis core must become legible and dense.
  if (forceCoreStage) {
    if (world.age < 32 && cluster.nodes.length >= 10) return false;
    if (world.age < 70 && cluster.nodes.length >= 13) return false;
    if (world.age < 112 && cluster.nodes.length >= 15) return false;
  }

  // A bud should stay visibly fragile in the first two minutes.
  if (cluster.role !== "genesis") {
    if (cluster.age < 32 && cluster.nodes.length >= 4) return false;
    if (cluster.age < 70 && cluster.nodes.length >= 6) return false;
    if (world.age < 135 && cluster.nodes.length >= 7) return false;
  }

  const growthChance = clamp(
    0.24 +
    cluster.growthBias * 0.18 +
    personality.curiosity * 0.12 +
    personality.plasticity * 0.08 -
    personality.caution * 0.14 -
    cluster.saturation * 0.28,
    forceCoreStage ? 0.18 : 0.10,
    forceCoreStage ? 0.56 : 0.46
  );

  return rng.chance(growthChance);
}

function findBuddingCandidate(simulation) {
  const { world, personality } = simulation;

  if (world.growthStage !== GrowthStages.BUDDING) return null;
  if (world.age < 96) return null;
  if (world.clusters.length >= CONFIG.maxClusters) return null;
  if (world.clusters.some((cluster) => cluster.state === ClusterStates.SEEDLING || cluster.state === ClusterStates.FORMING)) return null;

  const candidates = world.clusters.filter((cluster) => {
    return (
      cluster.birthProgress > 0.72 &&
      cluster.budCooldown <= 0 &&
      cluster.stability >= 0.14 &&
      cluster.saturation >= 0.32 &&
      cluster.expansionPressure >= 0.07 &&
      cluster.memoryStrength >= 0.10 &&
      cluster.state !== ClusterStates.DORMANT &&
      cluster.state !== ClusterStates.STRESSED
    );
  });

  if (!candidates.length) return null;

  candidates.sort((a, b) => buddingScore(b, personality) - buddingScore(a, personality));
  return candidates[0];
}

function buddingScore(cluster, personality) {
  return (
    cluster.expansionPressure * 0.45 +
    cluster.saturation * 0.25 +
    cluster.stability * 0.15 +
    personality.curiosity * 0.10 -
    cluster.stress * 0.20
  );
}

function chooseClusterForLocalGrowth(simulation) {
  const { world, rng } = simulation;
  const candidates = world.clusters.filter((cluster) => {
    return cluster.birthProgress > 0.28 && cluster.state !== ClusterStates.DORMANT && cluster.state !== ClusterStates.STRESSED;
  });

  if (!candidates.length) return null;

  const weighted = candidates.map((cluster) => {
    const growthNeed = clamp(1 - cluster.nodes.length / Math.max(1, cluster.softNodeLimit), 0, 1);
    const score =
      growthNeed * 0.34 +
      cluster.localActivity * 0.22 +
      cluster.stability * 0.18 +
      cluster.growthBias * 0.12 +
      rng.range(0, 0.16) -
      cluster.saturation * 0.16;

    return { cluster, score };
  });

  weighted.sort((a, b) => b.score - a.score);
  return weighted[0].cluster;
}
