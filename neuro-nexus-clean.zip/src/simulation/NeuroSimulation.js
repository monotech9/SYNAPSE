/**
 * NeuroSimulation.js — Zentrale Fassade der Simulation
 *
 * Verkabelt alle Subsysteme über EventBus und stellt eine einheitliche
 * API für Renderer, HUD und Input bereit.
 *
 * System-Instanziierung ist in systemFactory.js ausgelagert,
 * Edge-Verwaltung in EdgeManager.js, Interaktionen in InteractionHandler.js.
 */

import {CONFIG} from "../config.js";
import { createInitialState, loadPersistentState, savePersistentState } from "../persistence.js";
import { createIdentity, serializeIdentity } from "./identity.js";
import {createMemoryState, serializeMemoryState} from "./memory.js";
import { createPersonality } from "./personality.js";
import { ClusterRoles, ClusterStates } from "./clusterRoles.js";
import { GrowthStages } from "./growthStages.js";
import { Random } from "../utils/random.js";
import { createDiagnosticCounters } from "../diagnostics/DiagnosticsRecorder.js";
import { EventBus } from "./EventBus.js";
import { SpatialGrid } from "./SpatialGrid.js";
import { createSystems } from "./systemFactory.js";
import { ConsciousnessSystem } from "./consciousness/ConsciousnessSystem.js";

// Edge-Verwaltung und Interaktionen ausgelagert
import {
  edgeKey, hasEdge as _hasEdge, addEdge as _addEdge,
  removeEdge as _removeEdge, removeEdges as _removeEdges,
  removeEdgesOfNode as _removeEdgesOfNode,
  getInternalEdges as _getInternalEdges,
  getClusterBridgeEdges as _getClusterBridgeEdges
} from "./EdgeManager.js";
import {
  injectSignal as _injectSignal,
  forceBridge as _forceBridge,
  addManualNode as _addManualNode,
  pruneArea as _pruneArea
} from "./InteractionHandler.js";


export class NeuroSimulation {
  constructor() {
    this.events = new EventBus();
    this.spatialGrid = new SpatialGrid(80);  // Grid für Hit-Testing
    this._gridDirty = true;  // Grid muss neu aufgebaut werden
    this.persistentState = loadPersistentState();
    this.rng = new Random(this.persistentState.seed, this.persistentState.rngState);
    this.personality = createPersonality(this.persistentState.seed);
    this.identity = createIdentity(this.persistentState.seed, this.persistentState.identity || {});
    this.memory = createMemoryState(this.persistentState.memory || {});

    // Alle Subsysteme über Factory erstellen (außer Consciousness)
    createSystems(this);

    this.world = this._createWorld();

    // Consciousness nach world-Init erstellen (braucht world-Referenz)
    this.consciousness = new ConsciousnessSystem(this);

    this.camera = {
      scale: 1.12,
      targetScale: 1.12,
      offsetX: 0,
      offsetY: 0,
      targetOffsetX: 0,
      targetOffsetY: 0
    };

    this.diagnosticCounters = createDiagnosticCounters();
  }

  /**
   * Erstellt das World-State-Objekt mit initialen Werten.
   * Wird von Constructor und hardResetRuntime gemeinsam genutzt.
   */
  _createWorld() {
    return {
      width: 1,
      height: 1,
      dpr: 1,
      minSide: 1,
      centerX: 0,
      centerY: 0,
      layoutScale: 1,

      age: this.persistentState.accumulatedAge ?? 0,
      maturity: 0,
      growthStage: this.persistentState.growth?.stage || GrowthStages.GENESIS,
      previousGrowthStage: this.persistentState.growth?.stage || GrowthStages.GENESIS,

      clusters: [],
      edges: [],
      edgeSet: new Set(),        // O(1) Lookup für hasEdge()
      bridgeEdges: [],           // Separate Liste für Bridge-Kanten
      clusterEdgeIndex: new Map(), // Per-Cluster Edge-Index: Map<Cluster, { internal: [], bridge: [] }>
      pulses: [],
      injectedWaves: [],
      scars: [],

      spontaneousTimer: 0.4,
      ambientActivityTimer: 0.25,
      pathSignalTimer: 0.75,
      growthTimer: 0.5,
      connectionGrowthTimer: 1.2,
      // Bridge ping: deliberate inter-cluster glow moments after age 60.
      bridgePingTimer: 10.0,
      memoryFlashTimer: 15.0,
      saveTimer: 0,
      dirty: false,   // Wird bei jeder strukturellen Mutation gesetzt; Save nur wenn true.

      pointerEnergy: 0,
      signatureNoise: this.rng.int(100, 999),
      currentTime: 0
    };
  }

  hardResetRuntime() {
    this.persistentState = createInitialState();
    this.rng = new Random(this.persistentState.seed);
    this.personality = createPersonality(this.persistentState.seed);
    this.identity = createIdentity(this.persistentState.seed, {});
    this.memory = createMemoryState({});

    // Alle Subsysteme neu erstellen (zerstört alte zuerst)
    createSystems(this, true);

    // World zurücksetzen
    this.world.age = 0;
    this.world.maturity = 0;
    this.world.growthStage = GrowthStages.GENESIS;
    this.world.previousGrowthStage = GrowthStages.GENESIS;
    this.world.clusters = [];
    this.world.edges = [];
    this.world.edgeSet = new Set();
    this.world.bridgeEdges = [];
    this.world.clusterEdgeIndex = new Map();
    this.world.pulses = [];
    this.world.injectedWaves = [];
    this.world.scars = [];
    this.world.spontaneousTimer = 0.4;
    this.world.ambientActivityTimer = 0.25;
    this.world.pathSignalTimer = 0.75;
    this.world.growthTimer = 0.5;
    this.world.connectionGrowthTimer = 1.2;
    this.world.bridgePingTimer = 10.0;
    this.world.memoryFlashTimer = 15.0;
    this.world.saveTimer = 0;
    this.world.pointerEnergy = 0;
    this.world.signatureNoise = this.rng.int(100, 999);

    // Consciousness nach World-Reset neu erstellen
    this.consciousness = new ConsciousnessSystem(this);

    this.diagnosticCounters = createDiagnosticCounters();

    this.ensureClusters();
    return this;
  }

  // ─── Camera (delegates to CameraController) ───────────────────────

  resize(width, height, dpr) {
    this.cameraController.resize(width, height, dpr);
  }

  screenToScene(point) {
    return this.cameraController.screenToScene(point);
  }

  clampCameraOffset() {
    this.cameraController.clampCameraOffset();
  }

  zoomAt(screenPoint, nextScale) {
    this.cameraController.zoomAt(screenPoint, nextScale);
  }

  // ─── Counts ───────────────────────────────────────────────────────

  totalNodeCount() {
    return this.world.clusters.reduce((sum, cluster) => sum + cluster.nodes.length, 0);
  }

  bridgeEdgeCount() {
    return this.world.bridgeEdges.length;
  }

  // ─── Edge management (delegates to EdgeManager) ───────────────────

  _edgeKey(a, b) { return edgeKey(a, b); }

  hasEdge(a, b) { return _hasEdge(this.world, a, b); }

  addEdge(a, b, options = {}) { return _addEdge(this, a, b, options); }

  removeEdge(edge) { return _removeEdge(this.world, edge); }

  removeEdges(predicate) { return _removeEdges(this.world, predicate); }

  removeEdgesOfNode(node) { return _removeEdgesOfNode(this.world, node); }

  getInternalEdges(cluster) { return _getInternalEdges(this.world, cluster); }

  getClusterBridgeEdges(cluster) { return _getClusterBridgeEdges(this.world, cluster); }

  // ─── Node finding ─────────────────────────────────────────────────

  findNearestNode(screenX, screenY) {
    const scenePoint = this.screenToScene({ x: screenX, y: screenY });
    const now = this.world.currentTime || performance.now() / 1000;

    // Spatial Grid: nur bei Bedarf neu aufbauen (Strukturänderung)
    if (this._gridDirty) {
      this._rebuildSpatialGrid(now);
      this._gridDirty = false;
    }

    // Grid-basierte Suche (O(1) statt O(n))
    const result = this.spatialGrid.findNearest(scenePoint.x, scenePoint.y);
    if (result) return result;

    // Fallback: lineare Suche falls Grid leer
    let nearest = null;
    let nearestDistance = Infinity;
    for (const cluster of this.world.clusters) {
      for (const node of cluster.nodes) {
        const position = node.position(now);
        const distance = Math.hypot(position.x - scenePoint.x, position.y - scenePoint.y);
        if (distance < nearestDistance) {
          nearest = node;
          nearestDistance = distance;
        }
      }
    }
    return nearest ? { node: nearest, distance: nearestDistance } : null;
  }

  /** Baut das Spatial Grid aus allen Cluster-Nodes neu auf. */
  _rebuildSpatialGrid(now) {
    this.spatialGrid.clear();
    for (const cluster of this.world.clusters) {
      for (const node of cluster.nodes) {
        const pos = node.position(now);
        this.spatialGrid.insert(node, pos.x, pos.y);
      }
    }
  }

  /** Markiert das Spatial Grid als dirty (neuer Node / Pruning). */
  invalidateSpatialGrid() {
    this._gridDirty = true;
  }

  // ─── Interaction entry points (delegates to InteractionHandler) ────

  injectSignal(screenX, screenY) {
    _injectSignal(this, screenX, screenY);
  }

  forceBridge(nodeA, nodeB) {
    _forceBridge(this, nodeA, nodeB);
  }

  addManualNode(screenX, screenY) {
    _addManualNode(this, screenX, screenY);
  }

  pruneArea(screenX, screenY) {
    _pruneArea(this, screenX, screenY);
  }

  // ─── Delegating stubs to systems ──────────────────────────────────

  update(dt, timeSeconds) {
    this.updateLoop.update(dt, timeSeconds);
  }

  ensureClusters() {
    this.growthSystem.ensureClusters();
  }

  executeGrowthIntent(intent) {
    return this.growthSystem.executeGrowthIntent(intent);
  }

  handleGrowthStageTransition(previousStage, nextStage) {
    this.growthSystem.handleGrowthStageTransition(previousStage, nextStage);
  }

  onGrowthStageChange(listener) {
    const off1 = this.growthSystem.onGrowthStageChange(listener);
    const off2 = this.events.on("growth:stageChange", listener);
    return () => { off1(); off2(); };
  }

  removeStageChangeListener(listener) {
    this.growthSystem.removeStageChangeListener(listener);
  }

  wakeCluster(cluster, energy) {
    this.growthSystem.wakeCluster(cluster, energy);
  }

  serializeGrowthState() {
    return this.growthSystem.serializeGrowthState();
  }

  reinforceNodeEdges(node, amount) {
    this.signalSystem.reinforceNodeEdges(node, amount);
  }

  createInjectedWave(x, y, radius, options = {}) {
    this.signalSystem.createInjectedWave(x, y, radius, options);
  }

  createNodeBirthWave(node, strength = 0.32) {
    this.signalSystem.createNodeBirthWave(node, strength);
  }

  createClusterBirthWave(cluster, strength = 0.58) {
    this.signalSystem.createClusterBirthWave(cluster, strength);
  }

  // ─── Stage change listener access (backward compat) ──────────────

  get stageChangeListeners() {
    return this.growthSystem.stageChangeListeners;
  }

  // ─── Snapshots (delegates to SnapshotProvider) ───────────────────

  getDiagnosticSnapshot(elapsedSeconds = 0) {
    return this.snapshotProvider.getDiagnosticSnapshot(elapsedSeconds);
  }

  getDiagnosticClusterSnapshot(cluster) {
    return this.snapshotProvider.getDiagnosticClusterSnapshot(cluster);
  }

  getCompactSnapshot(elapsedSeconds = 0) {
    return this.snapshotProvider.getCompactSnapshot(elapsedSeconds);
  }

  // ─── Persistence ──────────────────────────────────────────────────

  save() {
    if (globalThis.NEURO_NEXUS_SKIP_SAVE) return;
    this.world.dirty = false;
    // RNG-Zustand persistieren, damit der Zufallsstrom nach Reload fortgesetzt wird
    this.persistentState.rngState = this.rng.getState();
    savePersistentState(
      this.persistentState,
      this.world.age,
      serializeIdentity(this.identity),
      serializeMemoryState(this.memory),
      this.serializeGrowthState(),
      this.relationshipLayer?.serialize() ?? null
    );
  }

}
