/**
 * InteractionHandler — User-Interaktionen mit dem Netzwerk
 *
 * Behandelt alle direkten Benutzer-Interaktionen:
 *  - Signal injection (Klick/Tap)
 *  - Bridge-Erstellung zwischen zwei Nodes
 *  - Manuelles Hinzufügen von Nodes
 *  - Area-Pruning (Kanten/Nodes entfernen)
 *
 * Wird von NeuroSimulation aufgerufen; nicht direkt instanziiert.
 */

import { CONFIG } from "../config.js";
import { ClusterRoles, ClusterStates } from "./clusterRoles.js";
import {
  removeEdge, removeEdges, removeEdgesOfNode
} from "./EdgeManager.js";

/**
 * Injects a signal at screen coordinates.
 * @param {NeuroSimulation} sim
 * @param {number} screenX
 * @param {number} screenY
 */
export function injectSignal(sim, screenX, screenY) {
  sim.signalSystem.injectSignal(screenX, screenY);
  sim.relationshipLayer?.onPlayerAction("signal", { intensity: 1.0 });
}

/**
 * Forces a bridge between two nodes.
 * @param {NeuroSimulation} sim
 * @param {Node} nodeA
 * @param {Node} nodeB
 */
export function forceBridge(sim, nodeA, nodeB) {
  sim.signalSystem.forceBridge(nodeA, nodeB);
  sim.relationshipLayer?.onPlayerAction("bridge");
}

/**
 * Adds a manual node at screen coordinates.
 * If near an existing cluster, adds to that cluster.
 * Otherwise creates a new exploration cluster.
 *
 * @param {NeuroSimulation} sim
 * @param {number} screenX
 * @param {number} screenY
 */
export function addManualNode(sim, screenX, screenY) {
  const scenePoint = sim.screenToScene({ x: screenX, y: screenY });
  const nearestResult = sim.findNearestNode(screenX, screenY);
  const now = sim.world.currentTime || performance.now() / 1000;

  // Nearest node exists and is within 150 radius?
  if (nearestResult && nearestResult.distance < 150 / sim.camera.scale) {
    const cluster = nearestResult.node.cluster;
    if (cluster.nodes.length >= cluster.hardNodeLimit) {
      cluster.hardNodeLimit += 1; // force allow growth
    }
    const center = cluster.center(now);
    const manualTargetLocal = {
      x: (scenePoint.x - center.x) / cluster.pixelRadius,
      y: (scenePoint.y - center.y) / cluster.pixelRadius
    };
    sim.networkBuilder.addNodeToCluster(cluster, { manualTargetLocal, instant: true });
  } else {
    if (sim.world.clusters.length >= CONFIG.maxClusters) return;

    const dx = scenePoint.x - sim.world.centerX;
    const dy = scenePoint.y - sim.world.centerY;
    const layoutDy = dy / 0.78; // Reverse the 0.78 Y-squeeze in center()

    const angle = Math.atan2(layoutDy, dx);
    const rawDistance = Math.hypot(dx, layoutDy);
    const distance = rawDistance / (sim.world.minSide * sim.world.layoutScale);

    const role = ClusterRoles.EXPLORATION;
    const type = "exploration";
    const id = `manual-${Math.round(sim.world.age)}-${sim.world.clusters.length}`;

    const cluster = sim.networkBuilder.addCluster({
      id, type, role, state: ClusterStates.SEEDLING,
      parentId: sim.world.clusters[0]?.id || id,
      threshold: 0, angle, distance, initialNodes: 1,
      birthDuration: 5, createdAtAge: sim.world.age
    }, { instant: true, wake: true });

    // Override exact position
    if (cluster) {
      cluster.angle = angle;
      cluster.distance = distance;
    }
  }

  sim.signalSystem.createInjectedWave(
    scenePoint.x, scenePoint.y, 40 / sim.camera.scale,
    { strength: 1.0, life: 1.0, rgb: [200, 255, 200] }
  );
}

/**
 * Prunes edges/nodes at screen coordinates.
 * Direct hit on a node removes it entirely.
 * Otherwise prunes weak edges in the area and cools down nodes.
 *
 * @param {NeuroSimulation} sim
 * @param {number} screenX
 * @param {number} screenY
 */
export function pruneArea(sim, screenX, screenY) {
  const scenePoint = sim.screenToScene({ x: screenX, y: screenY });
  const nearestResult = sim.findNearestNode(screenX, screenY);
  const now = sim.world.currentTime || performance.now() / 1000;
  const world = sim.world;

  // Direct hit on a node? Delete it entirely!
  if (nearestResult && nearestResult.distance < 25 / sim.camera.scale) {
    const nodeToRemove = nearestResult.node;
    const cluster = nodeToRemove.cluster;

    // Remove node from cluster
    cluster.nodes = cluster.nodes.filter(n => n !== nodeToRemove);

    // Remove all connected edges
    removeEdgesOfNode(world, nodeToRemove);

    // If cluster is empty, remove cluster
    if (cluster.nodes.length === 0) {
      world.clusters = world.clusters.filter(c => c !== cluster);
      removeEdges(world, (e) => e.a.cluster === cluster || e.b.cluster === cluster);
    }

    sim.signalSystem.createInjectedWave(
      scenePoint.x, scenePoint.y, 60 / sim.camera.scale,
      { strength: 1.0, life: 1.2, rgb: [255, 50, 50] }
    );
    return;
  }

  // Otherwise standard edge pruning
  const radius = 60 / sim.camera.scale;

  const toRemove = world.edges.filter(edge => {
    const posA = edge.a.position(now);
    const posB = edge.b.position(now);
    const midX = (posA.x + posB.x) / 2;
    const midY = (posA.y + posB.y) / 2;
    const dist = Math.hypot(midX - scenePoint.x, midY - scenePoint.y);

    return dist < radius && edge.weight < 0.6;
  });
  for (const edge of toRemove) removeEdge(world, edge);
  const removedEdges = toRemove.length;

  // Also cool down nodes
  for (const cluster of world.clusters) {
    for (const node of cluster.nodes) {
      const pos = node.position(now);
      if (Math.hypot(pos.x - scenePoint.x, pos.y - scenePoint.y) < radius) {
        node.activation *= 0.2;
        node.thermalLoad *= 0.2;
        node.visualImpact = 0;
      }
    }
  }

  if (removedEdges > 0) {
    sim.signalSystem.createInjectedWave(
      scenePoint.x, scenePoint.y, radius,
      { strength: 0.8, life: 1.0, rgb: [255, 80, 80] }
    );
  }
}
