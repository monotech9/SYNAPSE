/**
 * EdgeManager — Kanten-Verwaltung für NeuroSimulation
 *
 * Zentrale Verwaltung aller Kanten (Edges): Hinzufügen, Entfernen,
 * Indizierung und Abfragen. Hält edgeSet, bridgeEdges und den
 * Per-Cluster Edge-Index synchron.
 *
 * Wird als Mixin in NeuroSimulation verwendet; nicht direkt instanziiert.
 */

import { CONFIG } from "../config.js";
import { Edge } from "./entities/Edge.js";

/**
 * Erzeugt einen konsistenten Edge-Key für zwei Nodes.
 * @param {Node} a
 * @param {Node} b
 * @returns {string}
 */
export function edgeKey(a, b) {
  const ak = `${a.cluster?.id ?? "?"}-${a.index ?? "?"}`;
  const bk = `${b.cluster?.id ?? "?"}-${b.index ?? "?"}`;
  return ak < bk ? `${ak}|${bk}` : `${bk}|${ak}`;
}

/**
 * Prüft, ob eine Kante zwischen zwei Nodes existiert.
 * @param {Object} world — simulation.world
 * @param {Node} a
 * @param {Node} b
 * @returns {boolean}
 */
export function hasEdge(world, a, b) {
  return world.edgeSet.has(edgeKey(a, b));
}

/**
 * Fügt eine neue Kante hinzu, mit Limits-Checking und Indizierung.
 * @param {NeuroSimulation} sim
 * @param {Node} a
 * @param {Node} b
 * @param {Object} [options]
 * @returns {Edge|null} — null wenn Limits erreicht oder schon existiert
 */
export function addEdge(sim, a, b, options = {}) {
  const world = sim.world;

  if (!a || !b || a === b) return null;
  if (world.edges.length >= CONFIG.maxTotalEdges) return null;

  if (options.bridge) {
    if (sim.bridgeEdgeCount() >= CONFIG.maxBridgeEdges) return null;
    const pairBridgeCount = world.bridgeEdges.filter((edge) => {
      return (
        (edge.a.cluster === a.cluster && edge.b.cluster === b.cluster) ||
        (edge.a.cluster === b.cluster && edge.b.cluster === a.cluster)
      );
    }).length;
    const pairLimit = world.age < 180 ? 1 : 2;
    if (pairBridgeCount >= pairLimit) return null;
  }

  if (hasEdge(world, a, b)) return null;

  const edge = new Edge(sim, a, b, options);
  world.edges.push(edge);
  world.edgeSet.add(edgeKey(a, b));
  if (edge.bridge) world.bridgeEdges.push(edge);
  indexEdge(world, edge);
  world.dirty = true;
  return edge;
}

/**
 * Entfernt eine Kante — hält edgeSet, bridgeEdges und Index synchron.
 * @param {Object} world — simulation.world
 * @param {Edge} edge
 */
export function removeEdge(world, edge) {
  const idx = world.edges.indexOf(edge);
  if (idx >= 0) world.edges.splice(idx, 1);
  world.edgeSet.delete(edgeKey(edge.a, edge.b));
  if (edge.bridge) {
    const bidx = world.bridgeEdges.indexOf(edge);
    if (bidx >= 0) world.bridgeEdges.splice(bidx, 1);
  }
  unindexEdge(world, edge);
  world.dirty = true;
}

/**
 * Entfernt alle Kanten, die mit dem gegebenen Prädikat übereinstimmen.
 * @param {Object} world
 * @param {function} predicate
 */
export function removeEdges(world, predicate) {
  const toRemove = world.edges.filter(predicate);
  for (const edge of toRemove) removeEdge(world, edge);
}

/**
 * Entfernt alle Kanten, die mit dem gegebenen Node verbunden sind.
 * @param {Object} world
 * @param {Node} node
 */
export function removeEdgesOfNode(world, node) {
  removeEdges(world, (edge) => edge.a === node || edge.b === node);
}

// ─── Per-Cluster Edge-Index ──────────────────────────────────────────

/**
 * Indiziert eine Kante im Per-Cluster Edge-Index.
 * @param {Object} world
 * @param {Edge} edge
 */
export function indexEdge(world, edge) {
  const index = world.clusterEdgeIndex;
  for (const cluster of [edge.a.cluster, edge.b.cluster]) {
    if (!index.has(cluster)) index.set(cluster, { internal: [], bridge: [] });
    const bucket = index.get(cluster);
    const list = edge.bridge && edge.a.cluster !== edge.b.cluster ? bucket.bridge : bucket.internal;
    list.push(edge);
  }
}

/**
 * Entfernt eine Kante aus dem Per-Cluster Edge-Index.
 * @param {Object} world
 * @param {Edge} edge
 */
export function unindexEdge(world, edge) {
  const index = world.clusterEdgeIndex;
  for (const cluster of [edge.a.cluster, edge.b.cluster]) {
    const bucket = index.get(cluster);
    if (!bucket) continue;
    const list = edge.bridge && edge.a.cluster !== edge.b.cluster ? bucket.bridge : bucket.internal;
    const i = list.indexOf(edge);
    if (i >= 0) list.splice(i, 1);
  }
}

/**
 * Gibt alle internen Kanten eines Clusters zurück.
 * @param {Object} world
 * @param {Cluster} cluster
 * @returns {Edge[]}
 */
export function getInternalEdges(world, cluster) {
  const bucket = world.clusterEdgeIndex.get(cluster);
  return bucket ? bucket.internal : [];
}

/**
 * Gibt alle Bridge-Kanten eines Clusters zurück.
 * @param {Object} world
 * @param {Cluster} cluster
 * @returns {Edge[]}
 */
export function getClusterBridgeEdges(world, cluster) {
  const bucket = world.clusterEdgeIndex.get(cluster);
  return bucket ? bucket.bridge : [];
}
