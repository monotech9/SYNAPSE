
import { ClusterStates } from "./clusterRoles.js";
export const GrowthStages = Object.freeze({
  GENESIS: "genesis",
  ACTIVATION: "activation",
  GROWTH: "growth",
  BUDDING: "budding",
  NETWORK: "network",
  CONSTELLATION: "constellation"
});

export function resolveGrowthStage(simulation) {
  const { world, persistentState, memory } = simulation;
  const clusters = world.clusters;
  const core = clusters.find((cluster) => cluster.role === "genesis") || clusters[0];
  const stableClusterCount = clusters.filter((cluster) => {
    return cluster.state === ClusterStates.STABLE || cluster.state === ClusterStates.SATURATED;
  }).length;
  const bridgeCount = world.bridgeEdges.filter((edge) => edge.birthProgress > 0.45).length;
  const globalCoherence = calculateGlobalCoherence(clusters);

  if (clusters.length >= 3 && stableClusterCount >= 2 && globalCoherence >= 0.42 && memory.autonomousMoments >= 2) {
    return GrowthStages.CONSTELLATION;
  }

  const nonGenesis = clusters.find((cluster) => cluster.role !== "genesis" && cluster.state !== "dormant");
  const nonGenesisAge = nonGenesis ? Math.max(0, world.age - nonGenesis.createdAtAge) : 0;

  // A second region should feel like a fragile continuation first, not an instant finished network.
  if (
    world.age >= 135 &&
    nonGenesis &&
    bridgeCount >= 1 &&
    nonGenesisAge >= 36 &&
    nonGenesis.nodes.length >= 6 &&
    nonGenesis.stability >= 0.2
  ) {
    return GrowthStages.NETWORK;
  }

  if (
    core &&
    world.age >= 96 &&
    core.saturation >= 0.32 &&
    core.nodes.length >= Math.min(10, core.softNodeLimit * 0.42) &&
    core.expansionPressure >= 0.07 &&
    core.memoryStrength >= 0.10
  ) {
    return GrowthStages.BUDDING;
  }

  if (core && world.age >= 44 && core.nodes.length >= 10 && core.stability >= 0.14) {
    return GrowthStages.GROWTH;
  }

  if (world.age >= 18 || persistentState.interactionCount >= 2 || (core && core.localActivity >= 0.2)) {
    return GrowthStages.ACTIVATION;
  }

  return GrowthStages.GENESIS;
}

function calculateGlobalCoherence(clusters) {
  if (!clusters.length) return 0;

  const activityMean = clusters.reduce((sum, cluster) => sum + cluster.localActivity, 0) / clusters.length;
  const stabilityMean = clusters.reduce((sum, cluster) => sum + cluster.stability, 0) / clusters.length;
  const stressMean = clusters.reduce((sum, cluster) => sum + cluster.stress, 0) / clusters.length;

  return Math.max(0, Math.min(1, activityMean * 0.35 + stabilityMean * 0.75 - stressMean * 0.32));
}
