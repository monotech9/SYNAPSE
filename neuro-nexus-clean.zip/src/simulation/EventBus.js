/**
 * EventBus — Lightweight pub/sub für System-Kommunikation.
 *
 * Reduziert die direkte Kopplung zwischen Systems. Statt dass
 * Systems sich gegenseitig referenzieren, publishen sie Events
 * und andere Systems subscriben.
 *
 * Events (Beispiele):
 *  - "growth:stageChange"   { from, to, age }
 *  - "growth:nodeAdded"     { cluster, node }
 *  - "growth:edgeAdded"     { edge }
 *  - "network:bridgeCreated" { edge, count }
 *  - "network:nodePruned"   { node, reason }
 *  - "signal:injected"      { x, y, strength }
 *  - "pulse:spike"          { count }
 *  - "memory:flash"         { cluster }
 *  - "scar:created"         { scar }
 *  - "emergence:moment"     { type, intensity }
 */
export class EventBus {
  constructor() {
    this._listeners = new Map();
  }

  on(event, callback) {
    if (!this._listeners.has(event)) {
      this._listeners.set(event, new Set());
    }
    this._listeners.get(event).add(callback);
    return () => this.off(event, callback);
  }

  once(event, callback) {
    const off = this.on(event, (data) => {
      off();
      callback(data);
    });
    return off;
  }

  off(event, callback) {
    const set = this._listeners.get(event);
    if (set) set.delete(callback);
  }

  emit(event, data) {
    const set = this._listeners.get(event);
    if (!set) return;
    for (const cb of set) {
      try { cb(data); } catch (e) { console.warn(`[EventBus] Error in "${event}" handler:`, e); }
    }
  }

  clear() {
    this._listeners.clear();
  }
}
