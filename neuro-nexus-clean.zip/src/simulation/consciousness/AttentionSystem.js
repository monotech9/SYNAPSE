/**
 * AttentionSystem — Focus / Awareness Trigger
 *
 * Based on Attention Schema Theory (AST).
 *
 * Decides WHERE the system's "conscious spotlight" should point.
 * Uses novelty + prediction error + relevance to determine if
 * an ignition event should fire — making a specific cluster/node
 * temporarily "conscious" (boosted activity + visibility).
 *
 * Also modulates the camera to create a gentle "gaze" effect.
 */

const IGNITION_THRESHOLD = 0.45;
const IGNITION_COOLDOWN  = 2.5;  // seconds between ignitions
const GAZE_LERP          = 0.015;

export class AttentionSystem {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Current attention state
    this.attention = {
      target: null,       // { x, y, clusterId, type, strength }
      strength: 0,        // 0–1, how strongly the system is attending
      lastIgnitionAge: -10,
      ignitionCount: 0
    };

    // Ignition flash (visual feedback for the conscious moment)
    this.ignitionFlash = 0;

    // Listen for ignition events from GlobalWorkspace
    this.events.on("consciousness:ignition", (d) => this._handleIgnition(d));
    this.events.on("prediction:surprise", (d) => this._handleSurprise(d));
    this.events.on("prediction:boredom", (d) => this._handleBoredom(d));
  }

  /**
   * Ignition = a signal wins the workspace competition and becomes "conscious".
   * The system focuses on its source location.
   */
  _handleIgnition(data) {
    const age = this.sim.world.age;
    if (age - this.attention.lastIgnitionAge < IGNITION_COOLDOWN) return;

    this.attention.lastIgnitionAge = age;
    this.attention.ignitionCount++;

    // Determine focus target
    let target = null;

    if (data.type === "signal" || data.type === "pulse") {
      // Focus on the most active cluster
      const cl = this._findMostActiveCluster();
      if (cl) {
        const ctr = cl.center(this.sim.world.currentTime);
        target = { x: ctr.x, y: ctr.y, clusterId: cl.id, type: "activity", strength: data.salience };
      }
    } else if (data.type === "growth" || data.type === "connection" || data.type === "bridge") {
      // Focus on newest cluster
      const cl = this._findNewestCluster();
      if (cl) {
        const ctr = cl.center(this.sim.world.currentTime);
        target = { x: ctr.x, y: ctr.y, clusterId: cl.id, type: "growth", strength: data.salience };
      }
    } else if (data.type === "emergence") {
      // Focus on geometric center (whole-network event)
      target = { x: 0, y: 0, clusterId: null, type: "global", strength: data.salience };
    } else if (data.type === "scar") {
      // Focus on scar location if available
      const scars = this.sim.world.scars;
      if (scars.length > 0) {
        const s = scars[scars.length - 1];
        target = { x: s.x || 0, y: s.y || 0, clusterId: null, type: "scar", strength: data.salience };
      }
    }

    if (target) {
      this.attention.target = target;
      this.attention.strength = target.strength;
      this.ignitionFlash = 1.0;

      // Boost the attended cluster's activity (consciousness = amplified processing)
      if (target.clusterId !== null) {
        const cl = this.sim.world.clusters.find(c => c.id === target.clusterId);
        if (cl) {
          cl.activityMemory = Math.min(1, (cl.activityMemory || 0) + 0.15 * target.strength);
        }
      }

      // Emit attention shift event
      this.events.emit("attention:shift", {
        from: null, // could track previous
        to: target,
        strength: target.strength,
        age
      });
    }
  }

  /**
   * Surprise = prediction error spike. Increases attention strength
   * and may trigger a "what was that?" gaze shift.
   */
  _handleSurprise(data) {
    // Surprise boosts attention toward the error source
    const cl = this._findMostActiveCluster();
    if (cl && (!this.attention.target || this.attention.strength < 0.5)) {
      const ctr = cl.center(this.sim.world.currentTime);
      this.attention.target = {
        x: ctr.x, y: ctr.y, clusterId: cl.id,
        type: "surprise", strength: Math.min(1, data.error)
      };
      this.attention.strength = Math.min(1, data.error);
      this.ignitionFlash = Math.max(this.ignitionFlash, 0.6);
    }
  }

  /**
   * Boredom = consistently low prediction error.
   * The system becomes curious and seeks novelty → boosts growth rate.
   */
  _handleBoredom(data) {
    // Emit a curiosity-driven exploration event
    this.events.emit("consciousness:curiosity", {
      age: data.age,
      error: data.error
    });

    // Subtly boost spontaneous activity to break the boredom
    this.sim.world.spontaneousTimer = Math.min(this.sim.world.spontaneousTimer, 0.1);
  }

  _findMostActiveCluster() {
    const clusters = this.sim.world.clusters.filter(c => c.state !== "dormant");
    if (!clusters.length) return null;
    let best = clusters[0], bestAct = best.activityMemory || 0;
    for (const cl of clusters) {
      if ((cl.activityMemory || 0) > bestAct) { best = cl; bestAct = cl.activityMemory || 0; }
    }
    return best;
  }

  _findNewestCluster() {
    const clusters = this.sim.world.clusters.filter(c => c.state !== "dormant");
    if (!clusters.length) return null;
    return clusters[clusters.length - 1];
  }

  /**
   * Per-tick: decay attention, apply gentle camera gaze, flash fade.
   */
  update(dt) {
    // Decay attention strength
    this.attention.strength *= 0.985;
    if (this.attention.strength < 0.05) {
      this.attention.target = null;
      this.attention.strength = 0;
    }

    // Fade ignition flash
    this.ignitionFlash = Math.max(0, this.ignitionFlash - dt * 2.5);

    // Gentle camera gaze: nudge camera offset toward attention target
    if (this.attention.target && this.attention.strength > 0.2) {
      const t = this.attention.target;
      const cam = this.sim.camera;
      // Only a subtle drift, not a hard pan
      const driftX = t.x * 0.03 * this.attention.strength;
      const driftY = t.y * 0.03 * this.attention.strength;
      cam.targetOffsetX = cam.targetOffsetX * (1 - GAZE_LERP) + driftX * GAZE_LERP;
      cam.targetOffsetY = cam.targetOffsetY * (1 - GAZE_LERP) + driftY * GAZE_LERP;
    }
  }

  /** Get current attention state for rendering / HUD */
  getAttention() { return this.attention; }
  getIgnitionFlash() { return this.ignitionFlash; }

  serialize() {
    return {
      ignitionCount: this.attention.ignitionCount
    };
  }

  destroy() {
    this.attention.target = null;
  }
}
