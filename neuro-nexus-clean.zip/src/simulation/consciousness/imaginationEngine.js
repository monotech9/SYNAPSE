/**
 * imaginationEngine — "Was passiert wenn ich X tue?"
 *
 * Based on WebEvolver (2025) + Sophisticated Inference (Friston 2020):
 * The system generates hypothetical futures by simulating forward
 * from the current state under different action hypotheses.
 *
 * Generiert 3 Szenarien (explore / steady / integrate) und bewertet
 * diese nach Preferability (high Φ, low FE, high coherence).
 */

/**
 * Projektiert mögliche Zukünfte aus dem aktuellen Zustand.
 * @param {Object} con — ConsciousnessSystem
 * @param {Object} meta — Meta-Kognition State
 * @param {Object} sim — Simulation
 * @returns {{ projections: Array, preferredAction: string|null }}
 */
export function projectFuture(con, meta, sim) {
  const pred = con.prediction;
  if (!pred?._history || pred._history.length < 10) {
    return { projections: [], preferredAction: null };
  }

  const recent = pred._history.slice(-10);
  const first = recent[0], last = recent[recent.length - 1];
  const dt = last.age - first.age;
  if (dt < 0.001) return { projections: [], preferredAction: null };

  // Current state baseline
  const currentPulses = last.pulseCount;
  const currentNodes = last.nodeCount;
  const currentActivity = last.activity;
  const currentFE = pred.getFreeEnergy();
  const currentPhi = con.selfModel?.selfModel.phi || 0;
  const currentCoherence = con.selfModel?.selfModel.coherence || 0;

  // Action-conditioned imagination: 3 Szenarien
  const scenarios = [
    {
      label: "explore",
      action: "explore",
      expectedPulses: Math.round(currentPulses * 1.4),
      expectedNodes: Math.round(currentNodes + 3),
      expectedActivity: clamp01(currentActivity * 1.2),
      expectedFE: clamp01(currentFE * 0.7),
      expectedPhi: clamp01(currentPhi * 1.1),
      expectedCoherence: clamp01(currentCoherence * 0.95),
      probability: estimateProbability("growth", meta.predictionAccuracy)
    },
    {
      label: "steady",
      action: "maintain",
      expectedPulses: Math.round(currentPulses * 1.05),
      expectedNodes: Math.round(currentNodes + 1),
      expectedActivity: currentActivity,
      expectedFE: currentFE,
      expectedPhi: currentPhi,
      expectedCoherence: currentCoherence,
      probability: estimateProbability("steady", meta.predictionAccuracy)
    },
    {
      label: "integrate",
      action: "integrate",
      expectedPulses: Math.round(currentPulses * 0.9),
      expectedNodes: currentNodes,
      expectedActivity: clamp01(currentActivity * 0.85),
      expectedFE: clamp01(currentFE * 0.5),
      expectedPhi: clamp01(currentPhi * 1.3),
      expectedCoherence: clamp01(currentCoherence * 1.25),
      probability: estimateProbability("steady", meta.predictionAccuracy) * 0.8
    }
  ];

  // Evaluate preferability: system prefers high Φ, low FE, high coherence
  for (const s of scenarios) {
    s.preference = clamp01(
      s.expectedPhi * 0.35 +
      (1 - s.expectedFE) * 0.30 +
      s.expectedCoherence * 0.25 +
      s.expectedActivity * 0.10
    );
  }

  const projections = scenarios.sort((a, b) => b.preference - a.preference);
  const preferredAction = projections[0]?.action || null;

  return { projections, preferredAction };
}

/**
 * Schätzt die Wahrscheinlichkeit eines Szenario-Labels.
 */
function estimateProbability(label, accuracy) {
  if (label === "steady") return 0.4 + accuracy * 0.3;
  if (label === "growth") return 0.25 + (1 - accuracy) * 0.15;
  if (label === "decline") return 0.15 + (1 - accuracy) * 0.2;
  return 0.33;
}

function clamp01(v) { return Math.max(0, Math.min(1, v)); }
