/**
 * SelfModelEngine — Identity / "Ich-Gefühl"
 *
 * Builds an internal model of "what the system is" based on
 * its history, personality, and current state. This is not
 * just static identity — it's a dynamic self-representation
 * that evolves as the network grows.
 *
 * Inspired by Integrated Information Theory + Self-Modeling.
 *
 * Module:
 *   - selfModelConstants.js — Labels, Valence, Narrative-Fragments
 *   - selfModelEvents.js    — EventBus-Subscriptions
 *   - selfModelMetrics.js   — Phi, State-Derivation, Narrative
 *
 * Events (out):
 *  - "selfmodel:stateChange" — { from, to, age }
 *  - "selfmodel:narrative"   — { text, emotion, age }
 *  - "selfmodel:reflection"  — { text, trigger, age }
 */

import { SLEEP_LABELS_DE } from "./selfModelConstants.js";
import { setupSelfModelEvents } from "./selfModelEvents.js";
import { computePhi, deriveState, generateNarrative, avgActivity } from "./selfModelMetrics.js";

const REFLECTION_INTERVAL = 5.0;

export class SelfModelEngine {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Dynamic self-model state
    this.selfModel = {
      name: simulation.identity.name,
      createdAt: simulation.identity.createdAt,

      state: "dormant",
      selfAwareness: 0,
      goals: [],
      emotionalState: "neutral",
      emotionalIntensity: 0,

      complexity: 0,
      coherence: 0,
      autonomy: 0,
      phi: 0,

      narrativeThread: "",
      stateHistory: [],

      sleepState: "WAKE",
      sleepCount: 0,
      totalConsolidated: 0,
      lastSleepReflection: "",

      storyEcho: "",
      storyEchoCount: 0,
      lastStoryEvent: null,
      _storyEchoBuffer: [],

      emotionHistory: [],
      lastEmotionSpike: null,
      emotionalValence: 0,

      reflections: [],
    };

    this._reflectionTimer = REFLECTION_INTERVAL;

    // EventBus-Subscriptions via Module
    this._off = setupSelfModelEvents({
      selfModel: this.selfModel,
      sim: this.sim,
      events: this.events,
      addReflection: (text, trigger) => this._addReflection(text, trigger),
      addGoal: (goal) => this._addGoal(goal),
    });
  }

  // ─── Helpers ──────────────────────────────────────────────────────

  _addReflection(text, trigger) {
    this.selfModel.reflections.push({ text, trigger, timestamp: this.sim.world.age });
    if (this.selfModel.reflections.length > 8) this.selfModel.reflections.shift();
  }

  _addGoal(goal) {
    if (!this.selfModel.goals.includes(goal)) {
      this.selfModel.goals.push(goal);
      if (this.selfModel.goals.length > 4) this.selfModel.goals.shift();
    }
  }

  // ─── Periodic Update ──────────────────────────────────────────────

  update(dt) {
    this._reflectionTimer -= dt;
    if (this._reflectionTimer > 0) return;
    this._reflectionTimer = REFLECTION_INTERVAL;

    const w = this.sim.world;
    const mem = this.sim.memory;
    const personality = this.sim.personality;

    // Complexity
    const nodeCount = this.sim.totalNodeCount();
    const edgeCount = w.edges.length;
    const clusterCount = w.clusters.filter(c => c.state !== "dormant").length;
    this.selfModel.complexity = clamp01(
      (nodeCount / 160) * 0.4 + (edgeCount / 420) * 0.3 + (clusterCount / 6) * 0.3
    );

    // Coherence
    const bridgeRatio = w.bridgeEdges.length / Math.max(1, edgeCount);
    this.selfModel.coherence = clamp01(
      bridgeRatio * 0.4 + avgActivity(w.clusters) * 0.3 + (mem.strongestTrace || 0) * 0.3
    );

    // Phi (Φ)
    const activeClusters = w.clusters.filter(c => c.state !== "dormant");
    this.selfModel.phi = computePhi(activeClusters, clusterCount);

    // Autonomy
    const autoMoments = mem.autonomousMoments || 0;
    const totalEvents = mem.events.length || 1;
    this.selfModel.autonomy = clamp01(autoMoments / Math.max(totalEvents, 10));

    // Emotional state
    const emotionEngine = this.sim.emotionEngine;
    if (emotionEngine && emotionEngine.dominantEmotion) {
      this.selfModel.emotionalState = emotionEngine.dominantEmotion;
      this.selfModel.emotionalIntensity = emotionEngine.emotions[emotionEngine.dominantEmotion] || 0;
    } else {
      const workspace = this.sim.consciousness?.workspace;
      if (workspace) {
        this.selfModel.emotionalState = workspace.state.mood;
        this.selfModel.emotionalIntensity = workspace.state.totalSalience;
      }
    }

    // Derive self-state
    const prev = this.selfModel.state;
    this.selfModel.state = deriveState(
      this.selfModel.complexity, this.selfModel.coherence,
      this.selfModel.selfAwareness, w.growthStage
    );

    if (prev !== this.selfModel.state) {
      this.selfModel.stateHistory.push({
        from: prev, to: this.selfModel.state,
        age: w.age, emotion: this.selfModel.emotionalState
      });
      if (this.selfModel.stateHistory.length > 12) this.selfModel.stateHistory.shift();
      this.events.emit("selfmodel:stateChange", { from: prev, to: this.selfModel.state, age: w.age });
    }

    // Narrative thread
    this.selfModel.narrativeThread = generateNarrative(this.selfModel, personality);

    // Goals
    this._updateGoals(personality);

    // Slow decay
    this.selfModel.selfAwareness *= 0.995;
  }

  _updateGoals(personality) {
    const sm = this.selfModel;
    if (sm.goals.length > 4) sm.goals = sm.goals.slice(-4);

    if (sm.state === "dormant" && !sm.goals.includes("seek_stimulation")) sm.goals.push("seek_stimulation");
    if (sm.complexity < 0.3 && !sm.goals.includes("grow")) sm.goals.push("grow");
    if (personality.curiosity > 0.6 && !sm.goals.includes("explore")) sm.goals.push("explore");
    if (sm.coherence < 0.2 && sm.complexity > 0.3 && !sm.goals.includes("integrate")) sm.goals.push("integrate");
    if (sm.emotionalValence < -0.3 && !sm.goals.includes("recover")) sm.goals.push("recover");
  }

  // ─── API ──────────────────────────────────────────────────────────

  getSelfModel() { return this.selfModel; }

  getReflections(limit = 4) { return this.selfModel.reflections.slice(-limit); }

  getLastReflection() {
    const refs = this.selfModel.reflections;
    return refs.length > 0 ? refs[refs.length - 1] : null;
  }

  getSleepStateLabel() { return SLEEP_LABELS_DE[this.selfModel.sleepState] || "wach"; }

  serialize() {
    return {
      selfAwareness: this.selfModel.selfAwareness,
      state: this.selfModel.state,
      narrativeThread: this.selfModel.narrativeThread,
      stateHistory: this.selfModel.stateHistory.slice(-6),
      emotionalState: this.selfModel.emotionalState,
      emotionalValence: this.selfModel.emotionalValence,
      sleepState: this.selfModel.sleepState,
      sleepCount: this.selfModel.sleepCount,
      storyEchoCount: this.selfModel.storyEchoCount,
      lastSleepReflection: this.selfModel.lastSleepReflection,
      reflections: this.selfModel.reflections.slice(-3)
    };
  }

  destroy() { this._off?.(); }
}

function clamp01(v) { return Math.max(0, Math.min(1, v)); }
