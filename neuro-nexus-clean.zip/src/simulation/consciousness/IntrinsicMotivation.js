/**
 * IntrinsicMotivation — Der innere Antrieb des Systems
 *
 * Basierend auf den Forschungsrichtungen:
 * - Intrinsic Motivation (Oudeyer et al.)
 * - Active Inference Agency (Pfau et al.)
 * - Empowerment / Competence-Seeking
 *
 * Kernidee: Das System hat keinen externen Reward.
 * Es wird durch INTERNE Drives angetrieben:
 *
 *   1. Curiosity Drive    → Suche nach Noveltiy / Vorhersagungsunsicherheit
 *   2. Competence Drive   → Suche nach Meisterschaft / Kontrolle
 *   3. Autonomy Drive     → Widerstand gegen Fremdbestimmung
 *   4. Coherence Drive    → Streben nach Integration / Verbundenheit
 *   5. Homeostasis Drive  → Aufrechterhaltung eines gesunden Zustands
 *
 * Jeder Drive erzeugt "Druck" (0–1) der, wenn hoch genug,
 * das Verhalten des Systems beeinflusst:
 *   - Wachstumsrichtung
 *   - Spontane Aktivität
 *   - Bridge-Building
 *   - Signal-Injection
 *
 * Dies ist die ENERGIE hinter dem "Lebendigkeitsgefühl".
 */

const DRIVE_UPDATE_INTERVAL = 0.5; // 2Hz — Drives ändern langsam
const SATIATION_DECAY = 0.985;     // Erfüllte Drives klingen ab
const PRESSURE_THRESHOLD = 0.45;   // Ab hier wird der Drive handlungsrelevant

export class IntrinsicMotivation {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Die 5 Core Drives (alle 0–1)
    this.drives = {
      curiosity:   { pressure: 0.3, satiation: 0.5, label: "Neugier" },
      competence:  { pressure: 0.2, satiation: 0.5, label: "Kompetenz" },
      autonomy:    { pressure: 0.2, satiation: 0.5, label: "Autonomie" },
      coherence:   { pressure: 0.15, satiation: 0.5, label: "Kohärenz" },
      homeostasis: { pressure: 0.1, satiation: 0.7, label: "Homöostase" }
    };

    // Aktuell dominanter Drive
    this.dominantDrive = "curiosity";
    this._driveTimer = 0;

    // Aktions-Queue: Drives können Aktionen anstossen
    this._pendingActions = [];

    // Listen für Feedback-Loops
    this.events.on("prediction:surprise", (d) => {
      // Surprise → Curiosity wird teilweise gesättigt (Information gewonnen)
      this.drives.curiosity.satiation = Math.min(1, this.drives.curiosity.satiation + 0.1);
    });

    this.events.on("growth:nodeAdded", () => {
      // Wachstum → Competence steigt (man hat etwas erreicht)
      this.drives.competence.satiation = Math.min(1, this.drives.competence.satiation + 0.05);
    });

    this.events.on("network:bridgeCreated", () => {
      // Bridge → Coherence steigt
      this.drives.coherence.satiation = Math.min(1, this.drives.coherence.satiation + 0.15);
    });

    this.events.on("scar:created", () => {
      // Narbe → Homeostasis sinkt (Störung)
      this.drives.homeostasis.satiation = Math.max(0, this.drives.homeostasis.satiation - 0.2);
      this.drives.autonomy.pressure = Math.min(1, this.drives.autonomy.pressure + 0.1);
    });

    this.events.on("signal:injected", () => {
      // Externer Input → Autonomy sinkt (Fremdbestimmung)
      this.drives.autonomy.satiation = Math.max(0, this.drives.autonomy.satiation - 0.1);
      this.drives.curiosity.satiation = Math.min(1, this.drives.curiosity.satiation + 0.05);
    });

    this.events.on("consciousness:ignition", (d) => {
      // Bewusstseinsmoment → Competence steigt
      this.drives.competence.satiation = Math.min(1, this.drives.competence.satiation + 0.03);
    });
  }

  /**
   * Hauptupdate: Drive-Drücke berechnen, dominanten Drive bestimmen,
   * Aktionen ableiten.
   */
  update(dt) {
    this._driveTimer += dt;
    if (this._driveTimer < DRIVE_UPDATE_INTERVAL) return;
    this._driveTimer = 0;

    const personality = this.sim.personality;
    const w = this.sim.world;
    const prediction = this.sim.consciousness?.prediction;
    const selfModel = this.sim.consciousness?.selfModel;

    // === 1. Curiosity Drive ===
    // Steigt wenn: Vorhersagungsfehler hoch (Unsicherheit = Informationssuche)
    // Steigt wenn: System im gleichen Zustand bleibt (Boredom)
    // Sinkt wenn: Surprise / Novelty erlebt wird
    const predError = prediction?.getError() || 0;
    const surprise = prediction?.getSurprise() || 0;
    const boredom = predError < 0.05 ? 0.02 : 0;
    this._updateDrive("curiosity",
      0.3 + predError * 0.4 + boredom + (personality.curiosity - 0.5) * 0.3
    );

    // === 2. Competence Drive ===
    // Steigt wenn: System wächst, Netzwerk komplexer wird
    // Sinkt wenn: Wachstum stagniert
    const complexity = selfModel?.selfModel.complexity || 0;
    const recentGrowth = this._getRecentGrowthRate();
    this._updateDrive("competence",
      0.2 + recentGrowth * 0.3 + (personality.plasticity - 0.5) * 0.2
    );

    // === 3. Autonomy Drive ===
    // Steigt wenn: System wenig selbstbestimmte Momente hat
    // Sinkt wenn: Autonome Pulse / Emergenz stattfindet
    const autonomy = selfModel?.selfModel.autonomy || 0;
    this._updateDrive("autonomy",
      0.15 + (1 - autonomy) * 0.35 + (personality.volatility - 0.5) * 0.2
    );

    // === 4. Coherence Drive ===
    // Steigt wenn: Wenige Bridges, Cluster isoliert
    // Sinkt wenn: Neue Bridges entstehen
    const bridgeRatio = w.bridgeEdges.length / Math.max(1, w.clusters.filter(c => c.state !== "dormant").length);
    this._updateDrive("coherence",
      0.1 + (1 - bridgeRatio) * 0.3 + (personality.attachment - 0.5) * 0.2
    );

    // === 5. Homeostasis Drive ===
    // Steigt wenn: Narben, Störungen, Chaos
    // Sinkt wenn: System stabil
    const scarStress = (w.scars?.length || 0) * 0.1;
    const activityChaos = this._getActivityChaos(this.sim.world);
    this._updateDrive("homeostasis",
      0.1 + scarStress * 0.2 + activityChaos * 0.15 + (personality.caution - 0.5) * 0.15
    );

    // Dominanten Drive bestimmen
    let maxPressure = 0;
    for (const [name, drive] of Object.entries(this.drives)) {
      if (drive.pressure > maxPressure) {
        maxPressure = drive.pressure;
        this.dominantDrive = name;
      }
    }

    // Aktionen ableiten wenn ein Drive hoch genug ist
    this._deriveActions(dt);

    // Satiation decay (Drives "vergessen" Erfüllung)
    for (const drive of Object.values(this.drives)) {
      drive.satiation = drive.satiation * SATIATION_DECAY + 0.5 * (1 - SATIATION_DECAY);
    }
  }

  _updateDrive(name, rawPressure) {
    const drive = this.drives[name];
    if (!drive) return;
    // Pressure = Bedürfnis - Erfüllung
    const need = clamp01(rawPressure) * (1 - drive.satiation * 0.5);
    drive.pressure = drive.pressure * 0.9 + need * 0.1;
  }

  _getRecentGrowthRate() {
    const prediction = this.sim.consciousness?.prediction;
    if (!prediction?._history || prediction._history.length < 5) return 0;
    const recent = prediction._history.slice(-5);
    const first = recent[0], last = recent[recent.length - 1];
    const dt = last.age - first.age;
    if (dt < 0.001) return 0;
    return clamp01((last.nodeCount - first.nodeCount) / (dt * 5));
  }

  _getActivityChaos() {
    const clusters = this.sim.world.clusters.filter(c => c.state !== "dormant");
    if (clusters.length < 2) return 0;
    // Chaos = Varianz der Aktivität über Cluster
    let mean = 0;
    for (const cl of clusters) mean += cl.activityMemory || 0;
    mean /= clusters.length;
    let variance = 0;
    for (const cl of clusters) variance += Math.pow((cl.activityMemory || 0) - mean, 2);
    variance /= clusters.length;
    return clamp01(Math.sqrt(variance) * 3);
  }

  /**
   * Wandelt Drive-Druck in konkrete Aktionen um.
   * Dies ist die Brücke zwischen "Wollen" und "Tun".
   *
   * PHASE 2 UPGRADE: Jetzt erzeugen coherence + homeostasis ECHTE
   * Action-Kandidaten für den PredictionEngine._selectAction().
   * Dadurch hat das System erstmals eine echte Wahl zwischen
   * explore / stabilize / integrate statt nur einem Kandidaten.
   */
  _deriveActions(dt) {
    const w = this.sim.world;

    // Curiosity → explore (epistemische Exploration)
    if (this.drives.curiosity.pressure > PRESSURE_THRESHOLD) {
      w.spontaneousTimer = Math.min(w.spontaneousTimer, 0.3);
      if (Math.random() < 0.02 * this.drives.curiosity.pressure) {
        this._pendingActions.push({ type: "explore", intensity: this.drives.curiosity.pressure });
      }
    }

    // Competence → beschleunige Wachstum (Timer-basiert, keine Action)
    if (this.drives.competence.pressure > PRESSURE_THRESHOLD) {
      w.growthTimer = Math.min(w.growthTimer, 0.2);
    }

    // Autonomy → erhöhe autonome Puls-Rate (Timer-basiert, keine Action)
    if (this.drives.autonomy.pressure > PRESSURE_THRESHOLD) {
      w.ambientActivityTimer = Math.min(w.ambientActivityTimer, 0.15);
    }

    // Coherence → integrate (strukturelle Integration)
    // Jetzt als echter Action-Kandidat, nicht nur Timer!
    if (this.drives.coherence.pressure > PRESSURE_THRESHOLD + 0.1) {
      w.bridgePingTimer = Math.min(w.bridgePingTimer, 0.5);
      if (Math.random() < 0.015 * this.drives.coherence.pressure) {
        this._pendingActions.push({
          type: "integrate",
          intensity: this.drives.coherence.pressure,
          source: "coherence"
        });
      }
    }

    // Homeostasis → stabilize (gezielte Beruhigung volatiler Cluster)
    // Jetzt als echter Action-Kandidat!
    if (this.drives.homeostasis.pressure > PRESSURE_THRESHOLD + 0.15) {
      // Dämpfe weiterhin leicht (bestehender Mechanismus)
      for (const cl of w.clusters) {
        if (cl.state !== "dormant") {
          cl.activityMemory = (cl.activityMemory || 0) * 0.98;
        }
      }
      // ERZEUGE Action-Kandidat wenn Chaos hoch genug
      const chaos = this._getActivityChaos(w);
      if (chaos > 0.3 && Math.random() < 0.02 * this.drives.homeostasis.pressure) {
        this._pendingActions.push({
          type: "stabilize",
          intensity: this.drives.homeostasis.pressure,
          source: "homeostasis",
          chaos
        });
      }
    }
  }

  /**
   * Maß für Aktivitäts-Chaos: Varianz der Cluster-Aktivitäts-Memories.
   * Hohe Varianz = volatil → stabilize ist gerechtfertigt.
   */
  _getActivityChaos(w) {
    if (!w || !w.clusters) return 0;
    const clusters = w.clusters.filter(c => c.state !== "dormant");
    if (clusters.length < 2) return 0;
    const acts = clusters.map(c => c.activityMemory || 0);
    const mean = acts.reduce((s, a) => s + a, 0) / acts.length;
    const variance = acts.reduce((s, a) => s + Math.pow(a - mean, 2), 0) / acts.length;
    return Math.min(1, Math.sqrt(variance) * 3);
  }

  /**
   * Gibt ausstehende Aktionen zurück (von ConsciousnessSystem abzuholen).
   */
  consumeActions() {
    const actions = this._pendingActions;
    this._pendingActions = [];
    return actions;
  }

  /**
   * Snapshot für HUD / Telemetrie
   */
  getSnapshot() {
    return {
      dominant: this.dominantDrive,
      dominantLabel: this.drives[this.dominantDrive]?.label || "",
      drives: Object.fromEntries(
        Object.entries(this.drives).map(([k, v]) => [k, {
          pressure: v.pressure,
          satiation: v.satiation
        }])
      )
    };
  }

  serialize() {
    return { dominantDrive: this.dominantDrive };
  }

  destroy() {
    this._pendingActions = [];
  }
}

function clamp01(v) { return Math.max(0, Math.min(1, v)); }
