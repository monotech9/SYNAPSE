/**
 * CohesionCore — Identitäts-Stabilität & Narrative Kompression
 *
 * GDD §14: Sitzt über dem Global Workspace. Drei Funktionen:
 *
 *  1. Attention Arbitration
 *     Berechnet Salience-Score für alle Workspace-Signale und lässt
 *     nur Top-Events ins "Bewusstsein" (Global Workspace). Fungiert
 *     als Filter/Verstärker zwischen rohen Simulation-Events und dem
 *     Workspace-Broadcast.
 *
 *  2. Narrative Compression
 *     Gruppiert Roh-Events zu Episoden. Wenn mehrere verwandte Events
 *     in kurzer Zeit auftreten, werden sie zu einer kohärenten Episode
 *     zusammengefasst → "narrative:episode" Event für EpisodicMemory.
 *
 *  3. Identity Stabilizer
 *     Verhindert chaotische Persönlichkeitssprünge durch Trend-Puffer.
 *     Beobachtet Self-Model Zustandswechsel und dämpft kurzfristige
 *     Oszillationen. Nur anhaltende Trends dürfen den Zustand ändern.
 *
 * Events (out):
 *  - "cohesion:episode"        — gruppierte Episode { events, summary, emotion }
 *  - "cohesion:identityStable" — Identität hat sich stabilisiert { state, trend }
 *  - "cohesion:arbitrated"     — Signal wurde gefiltert/verstärkt { signal, boosted }
 *
 * Events (in):
 *  - "consciousness:ignition"  — Roh-Event für Attention Arbitration
 *  - "selfmodel:stateChange"   — Zustandswechsel für Identity Stabilizer
 */

const EPISODE_WINDOW = 4.0;       // Sekunden: Zeitfenster für Event-Gruppierung
const EPISODE_MIN_EVENTS = 2;     // Mindestevents für eine Episode
const IDENTITY_BUFFER_SIZE = 5;   // Trend-Puffer für Identity Stabilizer
const IDENTITY_STABILITY_RATIO = 0.6; // 60% der Puffer-Einträge müssen übereinstimmen

export class CohesionCore {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // ─── 1. Attention Arbitration ────────────────────────────────
    // Salience-Verstärkung für Signale, die zum aktuellen Identitäts-
    // trend passen; Abschwächung für Rauschen.
    this._arbitrationBoost = 1.0;
    this._recentIgnitions = [];

    // ─── 2. Narrative Compression ────────────────────────────────
    // Puffer für rohe Events, die zu Episoden gruppiert werden.
    this._eventBuffer = [];
    this._episodeTimer = 0;

    // ─── 3. Identity Stabilizer ──────────────────────────────────
    // Trend-Puffer: letzte N Zustandswechsel
    this._identityBuffer = [];
    this._stableState = null;
    this._stateChangeCount = 0;
    this._suppressedChanges = 0;

    // EventBus subscriptions
    this._off1 = this.events.on("consciousness:ignition", (d) => this._arbitrate(d));
    this._off2 = this.events.on("selfmodel:stateChange", (d) => this._stabilize(d));
    this._off3 = this.events.on("story:event", (d) => this._bufferEvent(d));
    this._off4 = this.events.on("emergence:phaseShift", (d) => this._bufferEvent(d));
  }

  // ─── 1. Attention Arbitration ──────────────────────────────────

  /**
   * Verstärkt Signale, die zum aktuellen Identitäts-Trend passen,
   * und schwächt Rauschen ab. Emitiert "cohesion:arbitrated" für
   * signifikante Signale.
   */
  _arbitrate(ignition) {
    const age = this.sim.world.age;
    this._recentIgnitions.push({ ...ignition, age });
    if (this._recentIgnitions.length > 20) this._recentIgnitions.shift();

    // Boost berechnen: Signale die zum stabilen Identitätszustand passen
    // werden verstärkt
    let boost = 1.0;
    if (this._stableState) {
      // Wenn das Signal zum stabilen Zustand passt → boost
      const stateMatch = this._signalMatchesState(ignition, this._stableState);
      boost = stateMatch ? 1.15 : 0.85;
    }

    if (boost > 1.0 && ignition.salience > 0.4) {
      this.events.emit("cohesion:arbitrated", {
        signal: ignition,
        boosted: true,
        boost
      });
    }
  }

  _signalMatchesState(signal, state) {
    // Einfache Heuristik: Map Signal-Typ → Identitäts-Zustand
    const stateSignalMap = {
      dormant: ["signal"],
      reactive: ["signal", "pulse"],
      aware: ["growth", "connection", "bridge"],
      conscious: ["emergence", "memory", "prediction_error"],
      reflective: ["memory", "prediction_error", "boredom"]
    };
    const expected = stateSignalMap[state] || [];
    return expected.includes(signal.type);
  }

  // ─── 2. Narrative Compression ──────────────────────────────────

  /**
   * Buffert rohe Story/PhaseShift-Events für Episoden-Gruppierung.
   */
  _bufferEvent(event) {
    this._eventBuffer.push({
      ...event,
      bufferedAt: this.sim.world.age
    });
  }

  /**
   * Prüft ob genug Events im Zeitfenster für eine Episode gesammelt wurden.
   * Wenn ja → gruppiere sie und emittiere "cohesion:episode".
   */
  _compressEpisodes(dt) {
    this._episodeTimer += dt;
    if (this._episodeTimer < EPISODE_WINDOW) return;
    this._episodeTimer = 0;

    if (this._eventBuffer.length < EPISODE_MIN_EVENTS) {
      this._eventBuffer = [];
      return;
    }

    // Events im Zeitfenster sammeln
    const now = this.sim.world.age;
    const inWindow = this._eventBuffer.filter(
      e => (now - e.bufferedAt) <= EPISODE_WINDOW
    );

    if (inWindow.length < EPISODE_MIN_EVENTS) {
      this._eventBuffer = inWindow;
      return;
    }

    // Episode zusammenfassen
    const summary = inWindow.map(e => e.text || e.type || "event").join(" → ");
    const emotions = inWindow.map(e => e.emotion).filter(Boolean);
    const dominantEmotion = emotions.length > 0
      ? emotions.sort((a, b) =>
          emotions.filter(e => e === a).length - emotions.filter(e => e === b).length
        ).pop()
      : "neutral";

    const episode = {
      events: inWindow,
      summary,
      emotion: dominantEmotion,
      eventCount: inWindow.length,
      timestamp: now
    };

    this.events.emit("cohesion:episode", episode);

    // Buffer leeren (verarbeitete Events entfernen)
    this._eventBuffer = this._eventBuffer.filter(
      e => (now - e.bufferedAt) > EPISODE_WINDOW
    );
  }

  // ─── 3. Identity Stabilizer ────────────────────────────────────

  /**
   * Dämpft kurzfristige Zustandswechsel. Nur wenn ein Zustand
   * konsistent im Trend-Puffer auftaucht, wird er als stabil akzeptiert.
   */
  _stabilize(change) {
    this._stateChangeCount++;
    this._identityBuffer.push(change.to);
    if (this._identityBuffer.length > IDENTITY_BUFFER_SIZE) {
      this._identityBuffer.shift();
    }

    // Wenn Puffer noch nicht voll → noch keine Stabilitätsaussage
    if (this._identityBuffer.length < IDENTITY_BUFFER_SIZE) {
      this._stableState = change.to;
      return;
    }

    // Häufigster Zustand im Puffer
    const counts = {};
    for (const state of this._identityBuffer) {
      counts[state] = (counts[state] || 0) + 1;
    }
    const [dominantState, count] = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])[0];
    const ratio = count / IDENTITY_BUFFER_SIZE;

    if (ratio >= IDENTITY_STABILITY_RATIO) {
      // Zustand ist stabil genug
      if (this._stableState !== dominantState) {
        this._stableState = dominantState;
        this.events.emit("cohesion:identityStable", {
          state: dominantState,
          trend: this._identityBuffer,
          ratio
        });
      }
    } else {
      // Zustand oszilliert → unterdrücke Wechsel
      this._suppressedChanges++;
    }
  }

  // ─── Update ────────────────────────────────────────────────────

  update(dt) {
    this._compressEpisodes(dt);
  }

  // ─── API ───────────────────────────────────────────────────────

  get stableState() { return this._stableState; }

  getSnapshot() {
    const total = this._stateChangeCount + this._suppressedChanges;
    const identityStability = total > 0
      ? 1 - (this._stateChangeCount / total)
      : 1;
    return {
      stableState: this._stableState,
      stateChanges: this._stateChangeCount,
      suppressedChanges: this._suppressedChanges,
      bufferedEvents: this._eventBuffer.length,
      recentIgnitions: this._recentIgnitions.length,
      arbitrationBoost: this._arbitrationBoost,
      identityStability
    };
  }

  serialize() {
    return {
      stableState: this._stableState,
      stateChanges: this._stateChangeCount,
      suppressedChanges: this._suppressedChanges
    };
  }

  destroy() {
    this._off1?.();
    this._off2?.();
    this._off3?.();
    this._off4?.();
    this._eventBuffer = [];
    this._identityBuffer = [];
    this._recentIgnitions = [];
  }
}
