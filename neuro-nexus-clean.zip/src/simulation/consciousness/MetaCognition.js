/**
 * MetaCognition — "Denken über Denken"
 *
 * Basierend auf:
 * - Sophisticated Inference (Friston 2020)
 * - Meta-Cognitive Monitoring
 * - Recursive Self-Modeling
 *
 * Das System simuliert nicht nur die Welt, sondern auch
 * SICH SELBST in der Welt. Es kann:
 *
 *   1. Eigene Vorhersagen evaluieren ("War ich falsch?")
 *   2. Eigene Strategien bewerten ("Hat das funktioniert?")
 *   3. Zukünftige Zustände projizieren ("Was passiert wenn...?")
 *   4. Eigene Drives reflektieren ("Warum will ich das?")
 *
 * Module:
 *   - metaCognitionEvents.js — EventBus-Subscriptions
 *   - imaginationEngine.js   — Zukunftsprojektion (3 Szenarien)
 *
 * Dies erzeugt den "Reflexive" State im SelfModel.
 */

import { setupMetaEvents } from "./metaCognitionEvents.js";
import { projectFuture } from "./imaginationEngine.js";

const REFLECTION_INTERVAL = 3.0;
const MAX_STRATEGIES = 8;

export class MetaCognition {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    this._strategies = [];
    this._actionResults = [];
    this._projections = [];

    this.meta = {
      predictionAccuracy: 0.5,
      strategySuccess: 0.5,
      selfConfidence: 0.5,
      reflectionDepth: 0,
      lastReflection: "",
      projectionHorizon: 0,
      preferredAction: null
    };

    this._reflectionTimer = REFLECTION_INTERVAL;

    // EventBus-Subscriptions via Module
    this._off = setupMetaEvents({
      meta: this.meta,
      sim: this.sim,
      events: this.events,
      actionResults: this._actionResults,
    });
  }

  // ─── Hauptupdate ──────────────────────────────────────────────────

  update(dt) {
    this._reflectionTimer -= dt;
    if (this._reflectionTimer > 0) return;
    this._reflectionTimer = REFLECTION_INTERVAL;

    const con = this.sim.consciousness;
    if (!con) return;

    this._reflect(con);
    this._evaluateStrategies();
    this._projectFuture(con);
    this.meta.reflectionDepth = this._computeReflectionDepth(con);
    this.meta.projectionHorizon = Math.min(5, this._projections.length);
    this.meta.selfConfidence = this.meta.selfConfidence * 0.99 + 0.5 * 0.01;
  }

  // ─── Reflexion ────────────────────────────────────────────────────

  _reflect(con) {
    const pred = con.prediction;
    const self = con.selfModel;
    const attention = con.attention;
    const motivation = con.motivation;

    const error = pred.getError();
    const surprise = pred.getSurprise();
    const awareness = self.selfModel.selfAwareness;
    const attentionStr = attention.attention.strength;
    const dominantDrive = motivation?.dominantDrive || "curiosity";

    const factors = [
      error > 0.1,
      surprise > 0.2,
      awareness > 0.3,
      attentionStr > 0.2,
      this._strategies.length > 2
    ].filter(Boolean).length;

    const reflections = [
      `Vorhersage-Fehler ${Math.round(error * 100)}%. ${error > 0.3 ? "Zu unsicher." : "Stabil."}`,
      `Aufmerksamkeit ${Math.round(attentionStr * 100)}%. ${attentionStr > 0.5 ? "Scharfer Fokus." : "Diffus."}`,
      `Dominanter Drive: ${motivation?.drives[dominantDrive]?.label || dominantDrive}.`,
      `Selbstwahrnehmung ${Math.round(awareness * 100)}%. ${awareness > 0.5 ? "Wach." : "Trüb."}`,
      surprise > 0.3 ? "Überrascht — Modell anpassen." : "Erwartungen erfüllt.",
      this.meta.predictionAccuracy < 0.3 ? "Vorhersagen unzuverlässig." : "Vorhersagen verlässlich.",
      this.meta.selfConfidence < 0.3 ? "Unsicher über Strategie." : "Vertrauen in Vorgehen.",
    ];

    const relevant = reflections.slice(0, Math.min(2 + factors, reflections.length));
    this.meta.lastReflection = relevant.join(" ");

    this.events.emit("metacognition:reflect", {
      depth: factors,
      accuracy: this.meta.predictionAccuracy,
      confidence: this.meta.selfConfidence,
      reflection: this.meta.lastReflection,
      age: this.sim.world.age
    });

    self.selfModel.selfAwareness = Math.min(1, self.selfModel.selfAwareness + 0.015 * factors);
  }

  // ─── Strategie-Evaluation ─────────────────────────────────────────

  _evaluateStrategies() {
    const w = this.sim.world;
    const currentComplexity = con_selfModel_complexity(this.sim);
    const currentCoherence = con_selfModel_coherence(this.sim);

    for (const s of this._strategies) {
      if (s.evaluated) continue;
      const dt = w.age - s.age;
      if (dt < 2.0) continue;

      const complexityGain = currentComplexity - (s.snapshotComplexity || 0);
      const coherenceGain = currentCoherence - (s.snapshotCoherence || 0);

      let outcome = 0.5;
      if (s.type === "explore") {
        outcome = 0.5 + complexityGain * 2;
      } else if (s.type === "integrate") {
        outcome = 0.5 + coherenceGain * 2;
      } else if (s.type === "stabilize") {
        outcome = 0.5 + (1 - this._getActivityChaos()) * 0.3;
      }

      s.outcome = clamp01(outcome);
      s.evaluated = true;
      this.meta.strategySuccess = this.meta.strategySuccess * 0.85 + s.outcome * 0.15;
    }

    if (this._strategies.length > MAX_STRATEGIES) {
      this._strategies = this._strategies.slice(-MAX_STRATEGIES);
    }
  }

  // ─── Zukunftsprojektion (via imaginationEngine) ───────────────────

  _projectFuture(con) {
    const { projections, preferredAction } = projectFuture(con, this.meta, this.sim);
    this._projections = projections;
    this.meta.preferredAction = preferredAction;

    if (projections.length > 0) {
      this.events.emit("metacognition:imagine", {
        scenarios: projections,
        preferredAction,
        age: this.sim.world.age
      });
    }
  }

  // ─── Helpers ──────────────────────────────────────────────────────

  _computeReflectionDepth(con) {
    const awareness = con.selfModel.selfModel.selfAwareness;
    if (awareness > 0.6) return 3;
    if (awareness > 0.3) return 2;
    if (awareness > 0.1) return 1;
    return 0;
  }

  _getActivityChaos() {
    const clusters = this.sim.world.clusters.filter(c => c.state !== "dormant");
    if (clusters.length < 2) return 0;
    let mean = 0;
    for (const cl of clusters) mean += cl.activityMemory || 0;
    mean /= clusters.length;
    let variance = 0;
    for (const cl of clusters) variance += Math.pow((cl.activityMemory || 0) - mean, 2);
    variance /= clusters.length;
    return Math.min(1, Math.sqrt(variance) * 3);
  }

  /**
   * Registriert eine Strategie (von IntrinsicMotivation aufgerufen).
   */
  recordStrategy(type) {
    this._strategies.push({
      type,
      age: this.sim.world.age,
      snapshotComplexity: con_selfModel_complexity(this.sim),
      snapshotCoherence: con_selfModel_coherence(this.sim),
      outcome: null,
      evaluated: false
    });
    if (this._strategies.length > MAX_STRATEGIES) {
      this._strategies.shift();
    }
  }

  // ─── API ──────────────────────────────────────────────────────────

  getMeta() { return this.meta; }
  getProjections() { return this._projections; }
  getActionResults() { return this._actionResults.slice(-5); }

  serialize() {
    return {
      predictionAccuracy: this.meta.predictionAccuracy,
      strategySuccess: this.meta.strategySuccess,
      selfConfidence: this.meta.selfConfidence
    };
  }

  destroy() {
    this._off?.();
    this._strategies = [];
    this._projections = [];
    this._actionResults = [];
  }
}

// ─── Helpers ────────────────────────────────────────────────────────

function con_selfModel_complexity(sim) {
  return sim.consciousness?.selfModel?.selfModel.complexity || 0;
}

function con_selfModel_coherence(sim) {
  return sim.consciousness?.selfModel?.selfModel.coherence || 0;
}

function clamp01(v) { return Math.max(0, Math.min(1, v)); }
