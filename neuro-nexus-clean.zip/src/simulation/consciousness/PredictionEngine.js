/**
 * PredictionEngine — Predictive Processing Layer
 *
 * The system constantly generates predictions about its own
 * state (activity level, growth rate, pulse frequency) and
 * compares them against reality. The resulting prediction error
 * drives learning, attention shifts, and surprise signals.
 *
 * Inspired by Predictive Processing / Active Inference.
 */

const HISTORY_SIZE = 60;   // ~2 seconds at 30Hz
const PREDICTION_HORIZON = 3; // predict 3 ticks ahead

export class PredictionEngine {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Observable state history: [{ age, pulseCount, nodeCount, edgeCount, activity, clusters }]
    this._history = [];

    // Current predictions (made H ticks ago, compared now)
    this._predictions = [];

    // Running prediction error (0–1)
    this.error = 0;
    this.errorHistory = [];

    // Learned model: exponential moving averages of state variables
    this._model = {
      pulseRate: 0,       // expected pulses per tick
      growthRate: 0,      // expected nodes added per tick
      activityLevel: 0,   // expected average activity
      stabilityIndex: 0   // expected cluster stability
    };

    // Surprise accumulator
    this.surprise = 0;

    // Free Energy (Expected Surprise) — Active Inference
    this.freeEnergy = 0;
    this.freeEnergyHistory = [];

    // Active Inference: Precision / Confidence weights
    this.precision = {
      pulse: 1.0,      // wie zuverlässig ist die Puls-Vorhersage
      growth: 1.0,     // wie zuverlässig ist die Wachstums-Vorhersage
      activity: 1.0    // wie zuverlässig ist die Aktivitäts-Vorhersage
    };

    // Action selection: welche Aktion minimiert erwartete Free Energy?
    this._actionCandidates = [];
    this.selectedAction = null;
  }

  /**
   * Record current state into history and generate predictions.
   */
  _observe() {
    const w = this.sim.world;
    const obs = {
      age: w.age,
      pulseCount: w.pulses.length,
      nodeCount: this.sim.totalNodeCount(),
      edgeCount: w.edges.length,
      activity: this._computeActivityLevel(),
      clusterCount: w.clusters.filter(c => c.state !== "dormant").length
    };

    this._history.push(obs);
    if (this._history.length > HISTORY_SIZE) this._history.shift();

    // Update internal model with EMA
    const lr = 0.05; // learning rate
    this._model.pulseRate     = this._model.pulseRate * (1 - lr) + obs.pulseCount * lr;
    this._model.growthRate    = this._model.growthRate * (1 - lr) + obs.nodeCount * lr;
    this._model.activityLevel = this._model.activityLevel * (1 - lr) + obs.activity * lr;

    return obs;
  }

  _computeActivityLevel() {
    const clusters = this.sim.world.clusters;
    if (!clusters.length) return 0;
    let sum = 0, count = 0;
    for (const cl of clusters) {
      if (cl.state === "dormant") continue;
      sum += cl.activityMemory || 0;
      count++;
    }
    return count > 0 ? sum / count : 0;
  }

  /**
   * Generate predictions for the state PREDICTION_HORIZON ticks ahead.
   * Uses simple linear extrapolation from recent history.
   */
  _predict() {
    if (this._history.length < 5) return null;

    const recent = this._history.slice(-10);
    const first = recent[0], last = recent[recent.length - 1];
    const dt = last.age - first.age;
    if (dt < 0.001) return null;

    // Linear extrapolation
    const pulseRate = (last.pulseCount - first.pulseCount) / dt;
    const nodeRate = (last.nodeCount - first.nodeCount) / dt;
    const actRate = (last.activity - first.activity) / dt;

    const pred = {
      targetAge: last.age + (PREDICTION_HORIZON / 30),
      expectedPulseCount: Math.max(0, last.pulseCount + pulseRate * PREDICTION_HORIZON / 30),
      expectedNodeCount: Math.max(0, last.nodeCount + nodeRate * PREDICTION_HORIZON / 30),
      expectedActivity: clamp01(last.activity + actRate * PREDICTION_HORIZON / 30),
      createdAt: this._history.length
    };

    this._predictions.push(pred);
    if (this._predictions.length > PREDICTION_HORIZON + 2) this._predictions.shift();

    return pred;
  }

  /**
   * Compare oldest prediction against current reality.
   * Returns normalized error (0–1).
   */
  _computeError(currentObs) {
    if (this._predictions.length < PREDICTION_HORIZON) return 0;

    const pred = this._predictions[0];
    if (!pred) return 0;

    // Normalize errors relative to model expectations
    const pulseError = pred.expectedPulseCount > 0
      ? Math.abs(currentObs.pulseCount - pred.expectedPulseCount) / Math.max(pred.expectedPulseCount, 10)
      : Math.min(1, currentObs.pulseCount / 10);

    const nodeError = pred.expectedNodeCount > 0
      ? Math.abs(currentObs.nodeCount - pred.expectedNodeCount) / Math.max(pred.expectedNodeCount, 5)
      : 0;

    const actError = Math.abs(currentObs.activity - pred.expectedActivity);

    // Weighted combination
    const totalError = clamp01(pulseError * 0.4 + nodeError * 0.2 + actError * 0.4);

    // Shift prediction queue
    this._predictions.shift();

    // EMA of error
    this.error = this.error * 0.85 + totalError * 0.15;
    this.errorHistory.push(this.error);
    if (this.errorHistory.length > 30) this.errorHistory.shift();

    return totalError;
  }

  /**
   * Main update: observe → predict → compare → emit surprise
   */
  update(dt) {
    const obs = this._observe();
    this._predict();

    const rawError = this._computeError(obs);

    // Surprise = spike in prediction error
    if (rawError > 0.3 && rawError > this.error * 1.5) {
      this.surprise = Math.min(1, this.surprise + rawError * 0.5);

      // Emit surprise event to workspace
      this.events.emit("prediction:surprise", {
        error: rawError,
        observed: obs,
        age: this.sim.world.age
      });
    } else {
      this.surprise *= 0.92;
    }

    // If prediction error is consistently low, the system is "bored" → emit curiosity
    if (this.error < 0.05 && this._history.length > 20 && Math.random() < 0.003) {
      this.events.emit("prediction:boredom", {
        error: this.error,
        age: this.sim.world.age
      });
    }

    // === Free Energy Computation (Active Inference) ===
    // F = Expected Surprise = E[−log P(observation | model)]
    // Approximation: weighted prediction error + entropy of model
    this._computeFreeEnergy();

    // === Precision Updating (Meta-Learning) ===
    // Precision = inverse variance of prediction errors per channel
    this._updatePrecision();

    // === Active Inference Action Selection ===
    // Das System wählt intern die Aktion, die die erwartete Free Energy minimiert
    this._selectAction();
  }

  /**
   * Free Energy = Surprise + KL(model || prior)
   * Approximation: weighted error + model entropy
   */
  _computeFreeEnergy() {
    // Surprise component
    const surpriseFE = this.surprise * 0.4 + this.error * 0.3;

    // Entropy component: wie "verstreut" ist das Modell?
    const pulseEntropy = this._model.pulseRate > 0 ? Math.min(1, Math.log(1 + this._model.pulseRate) / 5) : 0;
    const actEntropy = this._model.activityLevel > 0 ? -this._model.activityLevel * Math.log(this._model.activityLevel + 0.01) : 0;
    const modelEntropy = (pulseEntropy + actEntropy) * 0.15;

    this.freeEnergy = clamp01(surpriseFE + modelEntropy);
    this.freeEnergyHistory.push(this.freeEnergy);
    if (this.freeEnergyHistory.length > 30) this.freeEnergyHistory.shift();

    // Emit free energy signal for other systems
    if (this.freeEnergy > 0.5 && Math.random() < 0.05) {
      this.events.emit("prediction:highFreeEnergy", {
        freeEnergy: this.freeEnergy,
        error: this.error,
        age: this.sim.world.age
      });
    }
  }

  /**
   * Update precision weights based on recent prediction accuracy.
   * High precision = confident prediction = strong error signal.
   */
  _updatePrecision() {
    if (this.errorHistory.length < 5) return;

    // Recent average error
    const recent = this.errorHistory.slice(-10);
    const avgError = recent.reduce((s, e) => s + e, 0) / recent.length;

    // Precision = 1 / (1 + error) — je kleiner der Fehler, desto höher die Precision
    const newPrecision = 1 / (1 + avgError * 3);

    // Smooth update
    this.precision.pulse = this.precision.pulse * 0.9 + newPrecision * 0.1;
    this.precision.activity = this.precision.activity * 0.9 + newPrecision * 0.1;
  }

  /**
   * Active Inference: Select the action that minimizes expected free energy.
   *
   * Based on Sajid et al. (2021): Expected Free Energy G(π) =
   *   Risk (expected surprise under prior preferences)
   * + Epistemic Value (expected information gain / uncertainty reduction)
   * + Ambiguity (expected observational ambiguity)
   *
   * The agent PREFERS actions with HIGH epistemic value when uncertain,
   * and actions with LOW risk when confident.
   */
  _selectAction() {
    if (this._actionCandidates.length === 0) return;

    let bestAction = null;
    let minExpectedFE = Infinity;
    let bestEpistemicValue = 0;

    // Current uncertainty = prediction error variance
    const uncertainty = this._computeUncertainty();
    // Precision = inverse uncertainty (high precision = confident)
    const precision = 1 / (1 + uncertainty * 3);

    for (const candidate of this._actionCandidates) {
      // === 1. Epistemic Value: expected information gain ===
      // "How much would this action reduce my uncertainty?"
      let epistemicValue = 0;

      if (candidate.type === "explore") {
        // Exploration directly reduces uncertainty → high epistemic value
        epistemicValue = uncertainty * 0.6 * candidate.intensity;
      } else if (candidate.type === "stabilize") {
        // Stabilization reduces variance in activity → moderate epistemic value
        epistemicValue = uncertainty * 0.3;
      } else if (candidate.type === "integrate") {
        // Integration reduces structural uncertainty (fragmentation)
        const coherence = this.sim.consciousness?.selfModel?.selfModel.coherence || 0;
        epistemicValue = (1 - coherence) * 0.4;
      }

      // === 2. Risk: expected surprise under prior preferences ===
      // Low risk = action keeps system in preferred states
      let risk = this.freeEnergy * 0.5;
      if (candidate.type === "explore" && precision < 0.3) {
        // Exploring when very uncertain = risky
        risk *= 1.3;
      } else if (candidate.type === "stabilize" && this.freeEnergy > 0.4) {
        // Stabilizing when system is chaotic = low risk
        risk *= 0.6;
      }

      // === 3. Ambiguity: expected observational ambiguity ===
      let ambiguity = 0.1;
      if (candidate.type === "explore") {
        // Exploration leads to ambiguous observations (by definition)
        ambiguity = 0.2 * (1 - precision);
      }

      // === Expected Free Energy = Risk - Epistemic Value + Ambiguity ===
      // (Epistemic value is SUBTRACTED because information gain REDUCES free energy)
      const expectedFE = risk - epistemicValue + ambiguity;

      // Track best epistemic value for logging
      if (epistemicValue > bestEpistemicValue) {
        bestEpistemicValue = epistemicValue;
      }

      if (expectedFE < minExpectedFE) {
        minExpectedFE = expectedFE;
        bestAction = candidate;
        bestAction.epistemicValue = epistemicValue;
        bestAction.expectedFE = expectedFE;
      }
    }

    this.selectedAction = bestAction;
    this._actionCandidates = [];

    if (bestAction) {
      this.events.emit("prediction:actionSelected", {
        action: bestAction.type,
        expectedFreeEnergy: minExpectedFE,
        epistemicValue: bestAction.epistemicValue || 0,
        uncertainty,
        precision,
        age: this.sim.world.age
      });
    }
  }

  /**
   * Compute current uncertainty as variance of recent prediction errors.
   * High variance = high uncertainty = system should explore (epistemic foraging).
   */
  _computeUncertainty() {
    if (this.errorHistory.length < 3) return 0.5;
    const recent = this.errorHistory.slice(-10);
    const mean = recent.reduce((s, e) => s + e, 0) / recent.length;
    const variance = recent.reduce((s, e) => s + Math.pow(e - mean, 2), 0) / recent.length;
    return clamp01(Math.sqrt(variance) * 2 + this.error * 0.3);
  }

  /** Register action candidates from IntrinsicMotivation */
  registerActions(actions) {
    this._actionCandidates.push(...actions);
  }

  /** Get free energy for external consumers */
  getFreeEnergy() { return this.freeEnergy; }
  getPrecision() { return this.precision; }

  /** Get prediction error for external consumers */
  getError() { return this.error; }
  getSurprise() { return this.surprise; }

  serialize() {
    return {
      error: this.error,
      surprise: this.surprise,
      model: { ...this._model }
    };
  }

  destroy() {
    this._history = [];
    this._predictions = [];
    this.errorHistory = [];
  }
}

function clamp01(v) { return Math.max(0, Math.min(1, v)); }
