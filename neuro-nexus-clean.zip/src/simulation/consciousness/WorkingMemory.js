/**
 * WorkingMemory — Kurzzeit-Puffer zwischen Wahrnehmung und Episodischem Gedächtnis
 *
 * GDD §9 (Memory layer): WorkingMemory sitzt vor EpisodicMemory.
 * Es hält eine kleine Menge aktueller "Salience-Items" für wenige Sekunden
 * im Blickfeld, bevor diese entweder ins episodische Gedächtnis konsolidiert
 * oder verworfen werden.
 *
 * Funktion:
 *  1. Sammelt Salience-Items aus dem Global Workspace (Top-K pro Tick)
 *  2. Hält sie mit zeitlichem Decay (~5-10s)
 *  3. Items die lange genug "im Blickfeld" bleiben und eine Salience-
 *     Schwelle überschreiten → werden als "working:consolidated" Event
 *     emittiert (EpisodicMemory kann sie dann übernehmen)
 *  4. Bietet getActive() für andere Systeme (z.B. PredictionEngine
 *     kann aktuelle Items als Kontext nutzen)
 *
 * Events (out):
 *  - "working:consolidated" — Item hat Schwelle erreicht { item, holdTime }
 *  - "working:evicted"      — Item verblasst { item, reason }
 *
 * Events (in):
 *  - "consciousness:ignition" — neues Salience-Item aufnehmen
 */

const MAX_ITEMS = 7;          // Miller's magical number (minus 2)
const ITEM_DECAY_RATE = 0.85; // pro Tick (10Hz)
const CONSOLIDATION_THRESHOLD = 0.35;  // Salience-Schwelle für Konsolidierung
const MIN_HOLD_TIME = 3.0;    // Mindestens 3s im WM bevor Konsolidierung

export class WorkingMemory {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Active items: { type, channel, salience, data, holdTime, age }
    this._items = [];

    // Abgewiesene Items (debug)
    this._evicted = [];

    // EventBus: ignition → neues Item
    this.events.on("consciousness:ignition", (d) => {
      this._ingest(d);
    });
  }

  /**
   * Nimmt ein Signal in den Working Memory Puffer auf.
   * Wenn Puffer voll, wird das schwächste Item verdrängt.
   */
  _ingest(signal) {
    if (this._items.length >= MAX_ITEMS) {
      // Schwächstes Item verdrängen
      let minIdx = 0, minSal = Infinity;
      for (let i = 0; i < this._items.length; i++) {
        if (this._items[i].salience < minSal) {
          minSal = this._items[i].salience;
          minIdx = i;
        }
      }
      const evicted = this._items.splice(minIdx, 1)[0];
      this._evicted.push({ type: evicted.type, reason: "overflow" });
      if (this._evicted.length > 10) this._evicted.shift();
    }

    this._items.push({
      type: signal.type || "unknown",
      channel: signal.channel || "internal",
      salience: Math.min(1, signal.salience || 0.3),
      data: signal.data || {},
      holdTime: 0,
      age: this.sim.world.age
    });
  }

  /**
   * Per-Tick Update (läuft mit 10Hz via ConsciousnessSystem).
   * Decay + Konsolidierungs-Check.
   */
  update(dt) {
    for (let i = this._items.length - 1; i >= 0; i--) {
      const item = this._items[i];
      item.holdTime += dt;

      // Short-term decay
      item.salience *= ITEM_DECAY_RATE;

      // Konsolidierung: Item hat lange genug gehalten + Salience hoch genug
      if (item.holdTime >= MIN_HOLD_TIME && item.salience > CONSOLIDATION_THRESHOLD) {
        this.events.emit("working:consolidated", {
          item: { ...item },
          holdTime: item.holdTime
        });
        this._items.splice(i, 1);
        continue;
      }

      // Verblasst
      if (item.salience < 0.03) {
        this._evicted.push({ type: item.type, reason: "decay" });
        if (this._evicted.length > 10) this._evicted.shift();
        this._items.splice(i, 1);
        this.events.emit("working:evicted", {
          item: { ...item },
          reason: "decay"
        });
      }
    }
  }

  /**
   * Aktuelle Working Memory Items (für PredictionEngine, CohesionCore, etc.)
   */
  getActive() {
    return [...this._items];
  }

  /**
   * Aggregierte Salience des WM (Gesamt-Aktivierung).
   */
  get totalSalience() {
    return this._items.reduce((s, item) => s + item.salience, 0);
  }

  /**
   * Dominanter Item-Typ (was hält das System gerade "im Kopf"?).
   */
  get dominantType() {
    if (this._items.length === 0) return null;
    const counts = {};
    for (const item of this._items) {
      counts[item.type] = (counts[item.type] || 0) + item.salience;
    }
    return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
  }

  serialize() {
    return {
      activeCount: this._items.length,
      totalSalience: this.totalSalience,
      dominantType: this.dominantType,
      evicted: this._evicted.length
    };
  }

  destroy() {
    this._items = [];
    this._evicted = [];
  }
}
