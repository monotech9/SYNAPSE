/**
 * selfModelEvents — EventBus-Subscriptions für SelfModelEngine
 *
 * Kapselt alle Event-Handler, die SelfModelEngine abonniert:
 *  - consciousness:ignition  → selfAwareness boost
 *  - emergence:moment         → selfAwareness + goal
 *  - emotion:change           → emotionalState + history
 *  - emotion:spike            → reflection + narrative
 *  - story:event              → storyEcho + goals
 *  - story:milestone          → stateHistory + reflection
 *  - sleep:wakeUp             → sleepCount + reflection
 *  - sleep:stateChange        → sleepState tracking
 */

import {
  EMOTION_LABELS_DE, EMOTION_VALENCE,
  SLEEP_REFLECTIONS, EMOTION_SPIKE_REFLECTIONS,
  STORY_ECHO_PREFIX,
} from "./selfModelConstants.js";

/**
 * Verbindet alle EventBus-Listeners für SelfModelEngine.
 * @param {Object} ctx — { selfModel, sim, events, addReflection, addGoal, emit }
 * @returns {function} — cleanup (deregistriert alle Listener)
 */
export function setupSelfModelEvents(ctx) {
  const { selfModel, sim, events, addReflection, addGoal } = ctx;
  const offs = [];

  // consciousness:ignition
  offs.push(events.on("consciousness:ignition", () => {
    selfModel.selfAwareness = Math.min(1, selfModel.selfAwareness + 0.02);
  }));

  // emergence:moment
  offs.push(events.on("emergence:moment", (d) => {
    selfModel.selfAwareness = Math.min(1, selfModel.selfAwareness + (d.intensity || 0.3) * 0.08);
    addGoal("emergence_response");
  }));

  // emotion:change
  offs.push(events.on("emotion:change", (d) => {
    selfModel.emotionalState = d.to || "neutral";
    selfModel.emotionalIntensity = d.intensity || 0;

    selfModel.emotionHistory.push({
      emotion: d.to, intensity: d.intensity,
      timestamp: d.timestamp || sim.world.age
    });
    if (selfModel.emotionHistory.length > 20) selfModel.emotionHistory.shift();

    const valence = EMOTION_VALENCE[d.to] || 0;
    selfModel.emotionalValence = selfModel.emotionalValence * 0.7 + valence * 0.3;

    if (d.intensity > 0.5) {
      selfModel.selfAwareness = Math.min(1, selfModel.selfAwareness + (d.intensity - 0.5) * 0.04);
    }
  }));

  // emotion:spike
  offs.push(events.on("emotion:spike", (d) => {
    const emotion = d.emotion;
    const intensity = d.intensity || 0.7;

    selfModel.selfAwareness = Math.min(1, selfModel.selfAwareness + intensity * 0.06);

    const reflFn = EMOTION_SPIKE_REFLECTIONS[emotion];
    const reflectionText = reflFn
      ? reflFn(intensity)
      : `Intensive ${EMOTION_LABELS_DE[emotion] || emotion}. ${Math.round(intensity * 100)}%.`;

    selfModel.lastEmotionSpike = {
      emotion, intensity, reflection: reflectionText,
      timestamp: d.timestamp || sim.world.age
    };
    addReflection(reflectionText, `emotion:spike:${emotion}`);

    const valence = EMOTION_VALENCE[emotion] || 0;
    if (valence < 0 && intensity > 0.7) addGoal("recover");
    if (valence > 0 && intensity > 0.7) addGoal("explore");

    events.emit("selfmodel:narrative", { text: reflectionText, emotion, age: sim.world.age });
  }));

  // story:event
  offs.push(events.on("story:event", (d) => {
    selfModel.lastStoryEvent = d;
    selfModel.storyEchoCount++;

    const prefix = STORY_ECHO_PREFIX[d.category] || " Moment: ";
    const echoText = (d.text || "").substring(0, 80);
    const buffer = selfModel._storyEchoBuffer || (selfModel._storyEchoBuffer = []);
    buffer.push(prefix + echoText);
    if (buffer.length > 5) buffer.shift();
    selfModel.storyEcho = buffer.join("");

    selfModel.selfAwareness = Math.min(1, selfModel.selfAwareness + 0.01);

    if (d.emotion === "loss" || d.emotion === "tension") addGoal("recover");
    else if (d.emotion === "wonder" || d.emotion === "exploration") addGoal("explore");
    else if (d.emotion === "growth" || d.emotion === "transformation") addGoal("grow");
  }));

  // story:milestone
  offs.push(events.on("story:milestone", (d) => {
    selfModel.selfAwareness = Math.min(1, selfModel.selfAwareness + 0.05);

    selfModel.stateHistory.push({
      type: "milestone", emotion: d.emotion, text: d.text,
      age: d.timestamp || sim.world.age
    });
    if (selfModel.stateHistory.length > 12) selfModel.stateHistory.shift();

    const reflText = `Wendepunkt: ${d.text || "etwas hat sich verändert."}`;
    addReflection(reflText, "story:milestone");
    events.emit("selfmodel:narrative", { text: reflText, emotion: d.emotion, age: sim.world.age });
  }));

  // sleep:wakeUp
  offs.push(events.on("sleep:wakeUp", (d) => {
    selfModel.sleepCount++;
    selfModel.totalConsolidated += d.consolidated || 0;

    let reflFn = SLEEP_REFLECTIONS.stable;
    if (d.drift !== undefined && d.drift > 0.15) reflFn = SLEEP_REFLECTIONS.drift;
    else if (d.creativeDreams && d.creativeDreams > 0) reflFn = SLEEP_REFLECTIONS.creative;
    else if (d.duration > 20) reflFn = SLEEP_REFLECTIONS.long;
    else if (d.duration < 5) reflFn = SLEEP_REFLECTIONS.short;

    const reflText = reflFn(d);
    selfModel.lastSleepReflection = reflText;
    addReflection(reflText, "sleep:wakeUp");
    selfModel.selfAwareness = Math.min(1, selfModel.selfAwareness + 0.03);

    if (!d.identityStable) addGoal("integrate");

    events.emit("selfmodel:narrative", {
      text: reflText,
      emotion: d.identityStable ? "calm" : "tension",
      age: sim.world.age
    });
  }));

  // sleep:stateChange
  offs.push(events.on("sleep:stateChange", (d) => {
    selfModel.sleepState = d.to || "WAKE";
  }));

  // Cleanup-Funktion: deregistriert alle Listener
  return () => offs.forEach(off => off?.());
}
