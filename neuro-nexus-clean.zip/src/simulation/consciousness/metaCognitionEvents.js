/**
 * metaCognitionEvents — EventBus-Subscriptions für MetaCognition
 *
 * Kapselt alle Event-Handler, die MetaCognition abonniert:
 *  - action:executed       → Strategy-Success Update
 *  - prediction:surprise   → Accuracy sinkt
 *  - prediction:boredom    → Strategy war nicht gut
 *  - consciousness:ignition → Confidence steigt
 *  - emergence:moment      → Strategy + Confidence
 *  - scar:created          → Confidence + Accuracy sinkt
 */

/**
 * Verbindet alle EventBus-Listeners für MetaCognition.
 * @param {Object} ctx — { meta, sim, events, actionResults }
 * @returns {function} — cleanup
 */
export function setupMetaEvents(ctx) {
  const { meta, sim, events, actionResults } = ctx;
  const offs = [];

  // action:executed — echte Vorher/Nachher-Ergebnisse
  offs.push(events.on("action:executed", (data) => {
    actionResults.push({
      action: data.action,
      age: data.age,
      deltaError: data.delta,
      beforeError: data.beforeError,
      afterError: data.afterError,
      coherenceGain: (data.afterCoherence || 0) - (data.beforeCoherence || 0),
      phiGain: (data.afterPhi || 0) - (data.beforePhi || 0)
    });
    if (actionResults.length > 20) actionResults.shift();

    const success = data.delta < 0;
    if (success) {
      meta.strategySuccess = Math.min(1, meta.strategySuccess * 0.8 + 0.8 * 0.2);
    } else {
      meta.strategySuccess = meta.strategySuccess * 0.85 + 0.2 * 0.15;
    }
  }));

  // prediction:surprise — schlechte Vorhersage
  offs.push(events.on("prediction:surprise", () => {
    meta.predictionAccuracy = meta.predictionAccuracy * 0.85 + 0.0 * 0.15;
  }));

  // prediction:boredom — perfekte Vorhersage aber nichts passiert
  offs.push(events.on("prediction:boredom", () => {
    meta.strategySuccess = meta.strategySuccess * 0.9 + 0.1 * 0.1;
  }));

  // consciousness:ignition — etwas erreicht
  offs.push(events.on("consciousness:ignition", () => {
    meta.selfConfidence = Math.min(1, meta.selfConfidence + 0.03);
  }));

  // emergence:moment — unerwartet Positives
  offs.push(events.on("emergence:moment", () => {
    meta.strategySuccess = Math.min(1, meta.strategySuccess * 0.85 + 0.6 * 0.15);
    meta.selfConfidence = Math.min(1, meta.selfConfidence + 0.05);
  }));

  // scar:created — etwas schiefgelaufen
  offs.push(events.on("scar:created", () => {
    meta.selfConfidence = Math.max(0, meta.selfConfidence - 0.08);
    meta.predictionAccuracy = Math.max(0, meta.predictionAccuracy - 0.05);
  }));

  return () => offs.forEach(off => off?.());
}
