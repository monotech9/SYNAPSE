/**
 * selfModelMetrics — Phi-Berechnung, State-Derivation & Narrative-Generierung
 *
 * Reine Funktionen ohne Klassen-Abhängigkeit.
 * Werden von SelfModelEngine.update() aufgerufen.
 */

import { NARRATIVE_FRAGMENTS } from "./selfModelConstants.js";

/**
 * clamp01 — Hilfsfunktion
 */
function clamp01(v) { return Math.max(0, Math.min(1, v)); }

// ─── Phi (Φ) — Integrated Information ────────────────────────────────

/**
 * Berechnet Φ (Integrated Information) aus Cluster-Aktivitäten.
 * @param {Array} clusters — Aktive Cluster
 * @param {number} clusterCount — Anzahl aktiver Cluster
 * @returns {number} — Φ-Wert [0, 1]
 */
export function computePhi(clusters, clusterCount) {
  if (clusters.length < 2) return 0;

  const activities = clusters.map(c => c.activityMemory || 0);
  const jointH = jointEntropy(activities);

  let sumPartH = 0;
  for (const a of activities) sumPartH += binaryEntropy(a);

  const phi = Math.max(0, jointH - sumPartH * 0.7);
  return clamp01(phi * (1 + clusterCount * 0.1));
}

/**
 * Binäre Entropie H(p) = -p·log₂(p) - (1-p)·log₂(1-p)
 */
function binaryEntropy(p) {
  p = Math.max(0.01, Math.min(0.99, p));
  return -(p * Math.log2(p) + (1 - p) * Math.log2(1 - p));
}

/**
 * Joint Entropy — approximiert durch paarweise Korrelationen.
 */
function jointEntropy(activities) {
  if (activities.length < 2) return 0;

  const n = activities.length;
  let totalCorr = 0, pairCount = 0;

  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      totalCorr += 1 - Math.abs(activities[i] - activities[j]);
      pairCount++;
    }
  }

  const avgCorr = pairCount > 0 ? totalCorr / pairCount : 0;
  const baseH = activities.reduce((s, a) => s + binaryEntropy(a), 0) / n;
  return baseH * (0.5 + avgCorr * 0.5) * n;
}

// ─── State Derivation ────────────────────────────────────────────────

/**
 * Leitet den Self-Model-State aus Metriken ab.
 * @returns {string} — dormant | awakening | active | reflective | flowing
 */
export function deriveState(complexity, coherence, awareness, growthStage) {
  if (growthStage === "genesis") return "dormant";
  if (awareness > 0.6 && complexity > 0.5) return "flowing";
  if (awareness > 0.4) return "reflective";
  if (complexity > 0.2 || growthStage !== "genesis") return "active";
  if (growthStage === "activation") return "awakening";
  return "dormant";
}

// ─── Narrative Generation ────────────────────────────────────────────

/**
 * Generiert den narrativen Thread aus dem Self-Model-State.
 * @param {Object} sm — selfModel Zustand
 * @param {Object} personality — Personality-Objekt
 * @returns {string} — narrativer Text
 */
export function generateNarrative(sm, personality) {
  const profile = personality.profile || "balanced";
  sm._profile = profile;

  const phiPct = Math.round((sm.phi || 0) * 100);
  const emo = sm.emotionalState;
  const stateFn = NARRATIVE_FRAGMENTS[sm.state] || NARRATIVE_FRAGMENTS.dormant;

  let thread = stateFn(sm, emo, phiPct);

  if (sm.storyEcho && sm.state !== "dormant") {
    thread += sm.storyEcho.substring(0, 120);
  }

  return thread;
}

// ─── Average Activity ────────────────────────────────────────────────

/**
 * Durchschnittliche Cluster-Aktivität.
 * @param {Array} clusters — Alle Cluster (filtert selbst auf active)
 * @returns {number}
 */
export function avgActivity(clusters) {
  const active = clusters.filter(c => c.state !== "dormant");
  if (!active.length) return 0;
  return active.reduce((s, cl) => s + (cl.activityMemory || 0), 0) / active.length;
}
