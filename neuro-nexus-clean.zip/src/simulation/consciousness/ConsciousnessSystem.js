/**
 * ConsciousnessSystem — Orchestrator for the Conscious Core
 *
 * Wires together the four consciousness modules into a single
 * coherent cycle that runs alongside the simulation:
 *
 *   Perception → Workspace Competition → Prediction Error
 *      → Attention Shift → Self-Model Update → Broadcast
 *
 * This is NOT a replacement for the existing simulation systems.
 * It's a meta-layer that reads simulation state, derives "conscious"
 * properties, and feeds them back as subtle behavioral modulation.
 *
 * Cycle runs at 10Hz (every 100ms) — lighter than the 30Hz sim loop.
 */

import { GlobalWorkspace }    from "./GlobalWorkspace.js";
import { PredictionEngine }   from "./PredictionEngine.js";
import { AttentionSystem }    from "./AttentionSystem.js";
import { SelfModelEngine }    from "./SelfModelEngine.js";
import { IntrinsicMotivation } from "./IntrinsicMotivation.js";
import { MetaCognition }       from "./MetaCognition.js";
import { ActionExecutor }      from "./ActionExecutor.js";
import { WorkingMemory }     from "./WorkingMemory.js";
import { CohesionCore }      from "./CohesionCore.js";

const CYCLE_INTERVAL = 0.1; // 10Hz

export class ConsciousnessSystem {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Create sub-modules
    this.workspace      = new GlobalWorkspace(simulation);
    this.prediction     = new PredictionEngine(simulation);
    this.attention      = new AttentionSystem(simulation);
    this.selfModel      = new SelfModelEngine(simulation);
    this.motivation     = new IntrinsicMotivation(simulation);
    this.metaCognition  = new MetaCognition(simulation);
    this.actionExecutor = new ActionExecutor(simulation);
    this.workingMemory   = new WorkingMemory(simulation);
    this.cohesionCore    = new CohesionCore(simulation);

    // Cycle timing
    this._cycleTimer = 0;
    this._active = true;

    // Expose on simulation for cross-system access
    simulation.consciousness = this;

    // Hook: emit workspace signals from prediction surprise
    this.events.on("prediction:surprise", (d) => {
      this.workspace._ingest("prediction_error", "cognitive", {
        predictionError: d.error,
        x: 0, y: 0
      });
    });

    // Hook: boredom triggers curiosity-driven signal ingestion
    this.events.on("prediction:boredom", (d) => {
      this.workspace._ingest("boredom", "cognitive", {
        predictionError: 0.02,
        novelty: 0.1
      });
    });

    // Hook: attention shifts update the camera (handled in AttentionSystem)
    // Hook: self-model state changes broadcast to HUD
    this.events.on("selfmodel:stateChange", (d) => {
      // Could trigger audio cues, visual effects, etc.
    });

    // Hook: ignition events feed back into the simulation as subtle boosts
    this.events.on("consciousness:ignition", (d) => {
      const w = this.sim.world;
      // Ignition creates a small ambient pulse burst
      if (d.salience > 0.6) {
        w.spontaneousTimer = Math.min(w.spontaneousTimer, 0.15);
      }
    });
  }

  /**
   * Main update — called from UpdateLoop at 30Hz,
   * but internally throttled to 10Hz.
   */
  update(dt) {
    if (!this._active) return;

    this._cycleTimer += dt;
    if (this._cycleTimer < CYCLE_INTERVAL) return;
    this._cycleTimer = 0;

    // The Conscious Cycle:
    // 1. Perception: collect signals from simulation
    this.workspace.update(dt);
    // 2. Prediction: generate expectations + free energy
    this.prediction.update(dt);
    // 3. Motivation: compute drives + generate action candidates
    this.motivation.update(dt);
    // 4. Action Selection: pick action minimizing free energy
    const actions = this.motivation.consumeActions();
    if (actions.length > 0) {
      this.prediction.registerActions(actions);
      // Record strategies in meta-cognition for later evaluation
      for (const a of actions) {
        this.metaCognition.recordStrategy(a.type);
      }
    }
    // 5. Meta-Cognition: reflect on predictions + strategies
    this.metaCognition.update(dt);
    // 6. Attention: focus on what matters now
    this.attention.update(dt);
    // 7. Self-Model: update identity + narrative
    this.selfModel.update(dt);
    // 8. Working Memory: short-term consolidation
    this.workingMemory.update(dt);
    // 9. Cohesion Core: narrative compression + identity stabilization
    this.cohesionCore.update(dt);
  }

  /**
   * Get a unified consciousness snapshot for HUD / telemetry.
   */
  getSnapshot() {
    const mot = this.motivation.getSnapshot();
    const meta = this.metaCognition.getMeta();
    return {
      // Workspace
      mood: this.workspace.state.mood,
      arousal: this.workspace.state.totalSalience,
      ignitionCount: this.workspace.state.ignitionCount,
      ignitionFlash: this.attention.getIgnitionFlash(),
      // Attention
      attentionTarget: this.attention.attention.target,
      attentionStrength: this.attention.attention.strength,
      // Prediction (Active Inference)
      predictionError: this.prediction.getError(),
      surprise: this.prediction.getSurprise(),
      freeEnergy: this.prediction.getFreeEnergy(),
      epistemicValue: this.prediction.selectedAction?.epistemicValue || 0,
      precision: this.prediction.getPrecision(),
      // Motivation
      dominantDrive: mot.dominant,
      dominantDriveLabel: mot.dominantLabel,
      drives: mot.drives,
      // Meta-Cognition
      predictionAccuracy: meta.predictionAccuracy,
      strategySuccess: meta.strategySuccess,
      selfConfidence: meta.selfConfidence,
      reflectionDepth: meta.reflectionDepth,
      lastReflection: meta.lastReflection,
      // Self-Model
      selfState: this.selfModel.selfModel.state,
      selfAwareness: this.selfModel.selfModel.selfAwareness,
      phi: this.selfModel.selfModel.phi || 0,
      narrative: this.selfModel.selfModel.narrativeThread,
      complexity: this.selfModel.selfModel.complexity,
      coherence: this.selfModel.selfModel.coherence,
      autonomy: this.selfModel.selfModel.autonomy,
      goals: this.selfModel.selfModel.goals,
      // Action Executor Stats (Phase 1-3)
      actionStats: this.actionExecutor.getSnapshot(),
      // Working Memory
      workingMemory: this.workingMemory.serialize(),
      // Cohesion Core
      cohesionCore: this.cohesionCore.getSnapshot(),
      // Mood State Machine (GDD §5)
      moodState: this.sim.moodStateMachine?.getSnapshot()
    };
  }

  serialize() {
    return {
      workspace: this.workspace.serialize(),
      prediction: this.prediction.serialize(),
      attention: this.attention.serialize(),
      selfModel: this.selfModel.serialize(),
      motivation: this.motivation.serialize(),
      metaCognition: this.metaCognition.serialize(),
      workingMemory: this.workingMemory.serialize(),
      cohesionCore: this.cohesionCore.serialize()
    };
  }

  destroy() {
    this.workspace.destroy();
    this.prediction.destroy();
    this.attention.destroy();
    this.selfModel.destroy();
    this.motivation.destroy();
    this.metaCognition.destroy();
    this.actionExecutor.destroy();
    this.workingMemory.destroy();
    this.cohesionCore.destroy();
    this._active = false;
  }
}
