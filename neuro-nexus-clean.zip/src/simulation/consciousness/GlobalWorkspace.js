/**
 * GlobalWorkspace — "Conscious Broadcast Hub"
 *
 * Based on Global Neuronal Workspace Theory (GNW).
 * Collects signals from all sensory/cognitive channels,
 * evaluates their salience, and broadcasts the top-K as
 * the single "active conscious state" of the system.
 *
 * Integration: subscribes to EventBus, produces `workspace.state`
 * which other systems can read to modulate their behavior.
 */

const MAX_SIGNALS = 32;
const BROADCAST_K = 3;     // top-K signals become "conscious"
const DECAY_RATE  = 0.92;  // signal salience decay per tick

export class GlobalWorkspace {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;

    // Signal queue: { source, type, salience, novelty, emotionalWeight, predictionError, age }
    this._signals = [];

    // Current broadcasted state (the "conscious moment")
    this.state = {
      activeSignals: [],   // top-K that won the competition
      totalSalience: 0,    // overall arousal level (0–1)
      ignitionCount: 0,    // how many ignition events this session
      lastIgnitionAt: 0,   // sim-age of last ignition
      mood: "neutral",     // derived emotional tone
      focus: null          // { clusterId, nodeId, x, y } — what the system "attends to"
    };

    // Subscribe to sensory events
    this.events.on("signal:injected", (d) => this._ingest("signal", "external", d));
    this.events.on("pulse:spike", (d) => this._ingest("pulse", "internal", d));
    this.events.on("growth:nodeAdded", (d) => this._ingest("growth", "structural", d));
    this.events.on("growth:edgeAdded", (d) => this._ingest("connection", "structural", d));
    this.events.on("network:bridgeCreated", (d) => this._ingest("bridge", "structural", d));
    this.events.on("emergence:moment", (d) => this._ingest("emergence", "cognitive", d));
    this.events.on("scar:created", (d) => this._ingest("scar", "emotional", d));
    this.events.on("memory:flash", (d) => this._ingest("memory", "cognitive", d));
  }

  /**
   * Ingest a signal into the workspace.
   * Each signal type has a baseline salience + modifiers.
   */
  _ingest(type, channel, data = {}) {
    if (this._signals.length >= MAX_SIGNALS) {
      // Drop weakest signal
      let minIdx = 0, minSal = Infinity;
      for (let i = 0; i < this._signals.length; i++) {
        if (this._signals[i].salience < minSal) { minSal = this._signals[i].salience; minIdx = i; }
      }
      this._signals.splice(minIdx, 1);
    }

    const personality = this.sim.personality;
    const age = this.sim.world.age;

    // Compute salience components
    const novelty = this._computeNovelty(type, data);
    const emotionalWeight = this._computeEmotionalWeight(type, channel, data, personality);
    const predictionError = data.predictionError || 0;
    const attentionScore = this._computeAttention(novelty, emotionalWeight, predictionError, personality);

    const salience = attentionScore * (0.4 + novelty * 0.3 + emotionalWeight * 0.2 + predictionError * 0.1);

    this._signals.push({
      type, channel, data,
      salience: Math.min(1, salience),
      novelty,
      emotionalWeight,
      predictionError,
      age
    });
  }

  _computeNovelty(type, data) {
    // Novel = hasn't been seen recently in memory
    const mem = this.sim.memory;
    if (type === "emergence") return 0.85 + Math.random() * 0.15;
    if (type === "bridge") return 0.60 + (mem.clusterPairActivity ? 0.2 : 0);
    if (type === "signal") return 0.40;
    if (type === "scar") return 0.70;
    if (type === "growth") return 0.25;
    if (type === "connection") return 0.20;
    if (type === "pulse") return 0.10 + Math.random() * 0.15;
    if (type === "memory") return 0.30;
    return 0.30;
  }

  _computeEmotionalWeight(type, channel, data, personality) {
    // Personality modulates how strongly events resonate
    const sensitivity = personality.sensitivity || 0.5;
    const attachment = personality.attachment || 0.5;
    const volatility = personality.volatility || 0.5;

    let base = 0.2;
    if (type === "scar") base = 0.65 * sensitivity;
    if (type === "emergence") base = 0.50 * volatility;
    if (type === "bridge") base = 0.35 * attachment;
    if (type === "memory") base = 0.30 * sensitivity;
    if (type === "signal") base = 0.20;
    if (type === "growth") base = 0.15 * attachment;
    return Math.min(1, base + Math.random() * 0.1);
  }

  _computeAttention(novelty, emotional, predError, personality) {
    const curiosity = personality.curiosity || 0.5;
    const caution = personality.caution || 0.5;
    // Curiosity amplifies novelty; caution amplifies prediction error
    return clamp01(
      novelty * (0.3 + curiosity * 0.4) +
      emotional * 0.3 +
      predError * (0.2 + caution * 0.3) +
      0.1
    );
  }

  /**
   * Per-tick update: decay old signals, run competition, broadcast winners.
   */
  update(dt) {
    // Decay all signals
    for (let i = this._signals.length - 1; i >= 0; i--) {
      this._signals[i].salience *= DECAY_RATE;
      if (this._signals[i].salience < 0.05) {
        this._signals.splice(i, 1);
      }
    }

    // Sort by salience (descending)
    this._signals.sort((a, b) => b.salience - a.salience);

    // Select top-K as "conscious" broadcast
    const winners = this._signals.slice(0, BROADCAST_K);
    const totalSalience = this._signals.reduce((s, sig) => s + sig.salience, 0);

    // Update broadcast state
    this.state.activeSignals = winners;
    this.state.totalSalience = clamp01(totalSalience / MAX_SIGNALS);

    // Derive mood from dominant signal types
    this.state.mood = this._deriveMood(winners);

    // Derive focus from strongest signal
    if (winners.length > 0 && winners[0].salience > 0.3) {
      const top = winners[0];
      if (top.data.x !== undefined) {
        this.state.focus = {
          type: top.type,
          x: top.data.x, y: top.data.y,
          clusterId: top.data.clusterId || null,
          salience: top.salience
        };
      }
    } else if (this.state.focus && this.state.focus.salience > 0) {
      this.state.focus.salience *= 0.95;
      if (this.state.focus.salience < 0.1) this.state.focus = null;
    }

    // Broadcast ignition if a signal crossed threshold
    for (const sig of winners) {
      if (sig.salience > 0.55 && sig.age !== this.state.lastIgnitionAt) {
        this.state.ignitionCount++;
        this.state.lastIgnitionAt = this.sim.world.age;
        this.events.emit("consciousness:ignition", {
          type: sig.type,
          channel: sig.channel,
          salience: sig.salience,
          age: this.sim.world.age
        });
        break; // one ignition per tick
      }
    }
  }

  _deriveMood(winners) {
    if (winners.length === 0) return "neutral";
    const types = winners.map(w => w.type);
    if (types.includes("scar")) return "distressed";
    if (types.includes("emergence")) return "curious";
    if (types.includes("bridge")) return "connected";
    if (types.includes("signal")) return "alert";
    if (types.includes("growth") || types.includes("connection")) return "content";
    if (types.includes("memory")) return "reflective";
    return "neutral";
  }

  /** Snapshot for persistence / telemetry */
  serialize() {
    return {
      ignitionCount: this.state.ignitionCount,
      mood: this.state.mood
    };
  }

  destroy() {
    this._signals = [];
  }
}

function clamp01(v) { return Math.max(0, Math.min(1, v)); }
