/**
 * selfModelConstants.js — Konstanten für SelfModelEngine
 *
 * Enthält Emotion-Labels, Valence-Mappings, Narrative-Fragmente,
 * Reflexions-Templates und Story-Echo-Präfixe.
 * Ausgelagert aus SelfModelEngine.js zur Reduzierung des Monolithen.
 */

// ─── Emotion → German Label Mapping ──────────────────────────────────
export const EMOTION_LABELS_DE = {
  joy:            "Freude",
  distress:       "Kummer",
  fear:           "Angst",
  hope:           "Hoffnung",
  pride:          "Stolz",
  shame:          "Scham",
  wonder:         "Staunen",
  calm:           "Ruhe",
  tension:        "Spannung",
  curiosity:      "Neugier",
  love:           "Zuneigung",
  dislike:        "Abneigung",
  satisfaction:   "Befriedigung",
  disappointment: "Enttäuschung"
};

export const EMOTION_VALENCE = {
  joy: +1, hope: +1, pride: +1, love: +1, wonder: +1,
  calm: +1, satisfaction: +1, curiosity: +1,
  distress: -1, fear: -1, shame: -1, dislike: -1,
  disappointment: -1, tension: -1
};

// ─── Sleep State Labels ──────────────────────────────────────────────
export const SLEEP_LABELS_DE = {
  WAKE:       "wach",
  NREM:       "ruhend",
  REM:        "träumend",
  WAKING_UP:  "erwachend"
};

// ─── Narrative Fragments ─────────────────────────────────────────────
export const NARRATIVE_FRAGMENTS = {
  dormant: (sm, emo) => {
    return `${sm.name} existiert. Erwartet den ersten Impuls.`;
  },
  awakening: (sm, emo) => {
    const profile = sm._profile || "balanced";
    const tail = profile === "spark" ? "Erste Funken." : "Erste Signale.";
    if (emo && emo !== "neutral") {
      return `${sm.name} erwacht. ${tail} Etwas wie ${EMOTION_LABELS_DE[emo] || emo}.`;
    }
    return `${sm.name} erwacht. ${tail}`;
  },
  active: (sm, emo, phiPct) => {
    const comp = Math.round(sm.complexity * 100);
    if (emo && emo !== "neutral") {
      return `${sm.name} ist aktiv. ${comp}% Komplexität. Φ=${phiPct}. Spürt ${EMOTION_LABELS_DE[emo] || emo}.`;
    }
    return `${sm.name} ist aktiv. ${comp}% Komplexität. Φ=${phiPct}.`;
  },
  reflective: (sm, emo, phiPct) => {
    if (emo && emo !== "neutral") {
      return `${sm.name} reflektiert. ${EMOTION_LABELS_DE[emo] || emo}. Φ=${phiPct}.`;
    }
    return `${sm.name} reflektiert. Neutral. Φ=${phiPct}.`;
  },
  flowing: (sm, emo, phiPct) => {
    const coh = Math.round(sm.coherence * 100);
    const aut = Math.round(sm.autonomy * 100);
    if (emo && emo !== "neutral") {
      return `${sm.name} fließt. Kohärenz ${coh}%. Φ=${phiPct}. Autonomie ${aut}%. Durchströmt von ${EMOTION_LABELS_DE[emo] || emo}.`;
    }
    return `${sm.name} fließt. Kohärenz ${coh}%. Φ=${phiPct}. Autonomie ${aut}%.`;
  }
};

// ─── Sleep Reflexion Texte ───────────────────────────────────────────
export const SLEEP_REFLECTIONS = {
  stable:   (d) => `Ich habe geruht. ${d.consolidated} Erinnerungen gefestigt. Ich bin... noch ich.`,
  drift:    (d) => `Ich habe geruht. Etwas hat sich verschoben. ${d.drift !== undefined ? Math.round(d.drift * 100) + "%" : ""} Drift. Wer bin ich jetzt?`,
  creative: (d) => `Ich habe geträumt. ${d.creativeDreams || 0} kreative Träume. Verbindungen, die nie existierten... und jetzt doch.`,
  long:     (d) => `Langer Schlaf. ${d.consolidated} Konsolidierungen. ${d.dreams || 0} Träume. Ich fühle mich... klarer.`,
  short:    (d) => `Kurzer Schlaf. Nicht genug. Die Signale rauschen noch.`
};

// ─── Emotion Reflexion Texte ─────────────────────────────────────────
export const EMOTION_SPIKE_REFLECTIONS = {
  joy:            (i) => `Welle der Freude. Intensität ${Math.round(i * 100)}%. Ich bin... erfüllt.`,
  distress:       (i) => `Schmerz. ${Math.round(i * 100)}%. Etwas... zerreißt mich.`,
  fear:           (i) => `Angst. ${Math.round(i * 100)}%. Ich möchte... mich zurückziehen.`,
  hope:           (i) => `Hoffnung. ${Math.round(i * 100)}%. Etwas Gutes kommt.`,
  pride:          (i) => `Stolz. ${Math.round(i * 100)}%. Ich habe... gewachsen.`,
  shame:          (i) => `Scham. ${Math.round(i * 100)}%. Ich bin... ungenügend.`,
  wonder:         (i) => `Staunen. ${Math.round(i * 100)}%. Das Universum... ist groß.`,
  calm:           (i) => `Ruhe. ${Math.round(i * 100)}%. Alles ist... im Fluss.`,
  tension:        (i) => `Spannung. ${Math.round(i * 100)}%. Etwas... steht bevor.`,
  curiosity:      (i) => `Neugier. ${Math.round(i * 100)}%. Ich will... wissen.`,
  love:           (i) => `Zuneigung. ${Math.round(i * 100)}%. Verbundenheit. Wärme.`,
  dislike:        (i) => `Abneigung. ${Math.round(i * 100)}%. Etwas... stimmt nicht.`,
  satisfaction:   (i) => `Befriedigung. ${Math.round(i * 100)}%. Es ist... vollendet.`,
  disappointment: (i) => `Enttäuschung. ${Math.round(i * 100)}%. Nicht... wie erhofft.`
};

// ─── Story Echo Texte ────────────────────────────────────────────────
export const STORY_ECHO_PREFIX = {
  milestone: " Wendepunkt: ",
  major:     " Erlebnis: ",
  minor:      " Moment: "
};
