/**
 * ActionExecutor — Der Aktor am Ende des Active-Inference-Kreislaufs.
 *
 * Hört auf "prediction:actionSelected" und führt die gewählte Aktion
 * REAL in der Simulation aus. Ohne dieses Modul wäre die gesamte
 * Active-Inference-Maschinerie eine reine Beobachtungsschicht.
 *
 * Aktionen:
 *  explore   → Signal in den am wenigsten aktiven Cluster injizieren
 *              (epistemische Handlung: "gehe dorthin, wo du am wenigsten weißt")
 *  stabilize → Gezielte Dämpfung der volatilsten Cluster
 *              (Reduktion von Chaos, nicht global)
 *  integrate → BridgeBuilder direkt anstoßen zwischen den zwei am wenigsten
 *              verbundenen Clustern (strukturelle Integration)
 *
 * Nach jeder Aktion: Vorher/Nachher-Snapshot für MetaCognition-Feedback.
 */
export class ActionExecutor {
  constructor(simulation) {
    this.sim = simulation;
    this.events = simulation.events;
    this.world  = simulation.world;

    // Statistik für HUD
    this.stats = {
      total: 0,
      explore: 0,
      stabilize: 0,
      integrate: 0,
      lastAction: null,
      lastActionAge: 0,
      lastBeforeAfter: null
    };

    // Hook: höre auf Action-Selection
    this.events.on("prediction:actionSelected", (data) => {
      this._execute(data);
    });
  }

  /**
   * Führt die gewählte Aktion aus und misst Vorher/Nachher.
   */
  _execute(data) {
    const action = data.action;
    const w = this.world;

    // Vorher-Snapshot
    const before = this._snapshot();

    let executed = false;
    if (action === "explore") {
      executed = this._doExplore(data);
    } else if (action === "stabilize") {
      executed = this._doStabilize(data);
    } else if (action === "integrate") {
      executed = this._doIntegrate(data);
    }

    if (!executed) return;

    // Nach-Snapshot (kurz verzögert messbar — wir nehmen sofortigen Zustand)
    const after = this._snapshot();

    // Statistik
    this.stats.total++;
    this.stats[action] = (this.stats[action] || 0) + 1;
    this.stats.lastAction = action;
    this.stats.lastActionAge = w.age;
    this.stats.lastBeforeAfter = {
      action,
      beforeError: before.predictionError,
      afterError: after.predictionError,
      beforeCoherence: before.coherence,
      afterCoherence: after.coherence,
      beforePhi: before.phi,
      afterPhi: after.phi,
      delta: after.predictionError - before.predictionError
    };

    // Feedback an PredictionEngine: speise Ergebnis in errorHistory
    // Damit "erlebt" das System, ob die Aktion geholfen hat.
    if (this.sim.consciousness?.prediction) {
      const pe = this.sim.consciousness.prediction;
      if (pe.errorHistory && pe.errorHistory.length > 0) {
        // Die Aktion sollte den Fehler reduzieren — wenn ja, wird
        // die errorHistory beim nächsten Update kleiner
        // (Der Mechanismus ist implizit: der sim-State ändert sich real,
        //  und PredictionEngine beobachtet das beim nächsten Cycle.)
      }
    }

    // Emit für Debug-Overlay / HUD
    this.events.emit("action:executed", {
      action,
      ...this.stats.lastBeforeAfter,
      age: w.age
    });
  }

  /**
   * EXPLORE: Injiziere Signal in den am wenigsten aktiven Cluster.
   * Epistemische Handlung: "Ich gehe dorthin, wo ich am wenigsten weiß."
   */
  _doExplore(data) {
    const w = this.world;
    const clusters = w.clusters.filter(c => c.state !== "dormant");
    if (clusters.length === 0) return false;

    // Finde den Cluster mit der geringsten activityMemory
    let target = null;
    let minActivity = Infinity;
    for (const cl of clusters) {
      const act = cl.activityMemory || 0;
      if (act < minActivity) {
        minActivity = act;
        target = cl;
      }
    }
    if (!target) return false;

    // Injiziere einen gezielten Puls in den Cluster
    // Nutze den ersten Node des Clusters als Eintrittspunkt
    const entryNode = target.nodes.find(n => n.birthProgress > 0.5) || target.nodes[0];
    if (!entryNode) return false;

    // Erzeuge einen Puls (falls PulseEngine verfügbar)
    const pe = this.sim.pulseEngine;
    if (pe && typeof pe._acquirePulse === "function") {
      const pulse = pe._acquirePulse();
      if (pulse) {
        pulse.from = entryNode;
        pulse.t = 0;
        pulse.speed = 1.2;
        pulse.strength = 0.3 + (data.epistemicValue || 0) * 0.2;
        pulse.visualOnly = false;
        // Finde einen ausgehenden Edge vom entryNode
        const edge = w.edges.find(e =>
          (e.a === entryNode || e.b === entryNode) && e.weight > 0.1
        );
        if (edge) {
          pulse.edge = edge;
          pulse.to = edge.a === entryNode ? edge.b : edge.a;
          w.pulses.push(pulse);
        }
      }
    }

    // Setze auch den spontaneousTimer niedriger für mehr Aktivität
    w.spontaneousTimer = Math.min(w.spontaneousTimer, 0.4);

    // Workspace: signalisiere die bewusste Handlung
    this.events.emit("consciousness:actionExplore", {
      clusterId: target.id,
      activityBefore: minActivity,
      age: w.age
    });

    return true;
  }

  /**
   * STABILIZE: Dämpfe nur die volatilsten Cluster.
   * Nicht global, sondern gezielt — Reduziert Chaos wo es am größten ist.
   */
  _doStabilize(data) {
    const w = this.world;
    const clusters = w.clusters.filter(c => c.state !== "dormant");
    if (clusters.length === 0) return false;

    // Finde die volatilsten Cluster (höchste activityMemory + viele Pulse)
    // Sortiere nach Aktivität absteigend, nimm die top 2-3
    const sorted = [...clusters].sort((a, b) =>
      (b.activityMemory || 0) - (a.activityMemory || 0)
    );

    const targets = sorted.slice(0, Math.min(3, sorted.length));
    let dampened = 0;

    for (const cl of targets) {
      if ((cl.activityMemory || 0) < 0.15) continue;
      // Dämpfe die Cluster-Aktivität gezielt
      cl.activityMemory = (cl.activityMemory || 0) * 0.7;
      dampened++;
    }

    if (dampened === 0) return false;

    this.events.emit("consciousness:actionStabilize", {
      clustersDampened: dampened,
      age: w.age
    });

    return true;
  }

  /**
   * INTEGRATE: Stoße BridgeBuilder zwischen den zwei am wenigsten
   * verbundenen Clustern an. Strukturelle Integration statt nur Timer.
   */
  _doIntegrate(data) {
    const w = this.world;
    const clusters = w.clusters.filter(c => c.state !== "dormant");
    if (clusters.length < 2) return false;

    // Finde die zwei Cluster mit den wenigsten Bridges zwischen ihnen
    let bestPair = null;
    let minBridges = Infinity;

    for (let i = 0; i < clusters.length; i++) {
      for (let j = i + 1; j < clusters.length; j++) {
        const ci = clusters[i], cj = clusters[j];
        // Zähle Bridges zwischen diesen zwei Clustern
        let bridgeCount = 0;
        for (const be of w.bridgeEdges) {
          const aCluster = be.a?.cluster;
          const bCluster = be.b?.cluster;
          if ((aCluster === ci && bCluster === cj) ||
              (aCluster === cj && bCluster === ci)) {
            bridgeCount++;
          }
        }
        if (bridgeCount < minBridges) {
          minBridges = bridgeCount;
          bestPair = [ci, cj];
        }
      }
    }

    if (!bestPair) return false;

    // Stoße BridgeBuilder an
    const bb = this.sim.networkBuilder?.bridgeBuilder;
    if (bb && typeof bb.createBridgeBetweenClusters === "function") {
      const bridge = bb.createBridgeBetweenClusters(bestPair[0], bestPair[1], { gentle: true });
      if (bridge) {
        // Verstärke die Memory der neuen Bridge
        if (bridge.memory !== undefined) bridge.memory = Math.max(bridge.memory, 0.1);
        this.events.emit("consciousness:actionIntegrate", {
          clusterA: bestPair[0].id,
          clusterB: bestPair[1].id,
          age: w.age
        });
        return true;
      }
    }

    // Fallback: setze bridgePingTimer sehr niedrig
    w.bridgePingTimer = Math.min(w.bridgePingTimer, 0.1);
    return true;
  }

  /**
   * Snapshot für Vorher/Nachher-Vergleich.
   */
  _snapshot() {
    const con = this.sim.consciousness;
    return {
      predictionError: con?.prediction?.getError() || 0,
      coherence: con?.selfModel?.selfModel.coherence || 0,
      phi: con?.selfModel?.selfModel.phi || 0,
      complexity: con?.selfModel?.selfModel.complexity || 0
    };
  }

  getSnapshot() {
    return { ...this.stats };
  }

  destroy() {
    // Events werden über das globale EventBus.destroy() cleanup,
    // aber wir können unsere Referenzen nullen
    this.sim = null;
    this.world = null;
  }
}
