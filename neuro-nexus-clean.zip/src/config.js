export const STORAGE_KEY = "neuro-nexus.preferred-paths.v1";
export const FORCE_FRESH_SESSION_KEY = "neuro-nexus.force-fresh-start";
export const LEGACY_STORAGE_KEYS = [
  "neuro-nexus.anti-flicker.v1",
  "neuro-nexus.activity-boost.v2",
  "neuro-nexus.growth-pacing-morphology.v1",
  "neuro-nexus.reset-fix.v1",
  "neuro-nexus.visual-feedback.v1",
  "neuro-nexus.debug-split.v1",
  "neuro-nexus.diagnostics.v1",
  "neuro-nexus.adaptive-growth.v1",
  "neuro-nexus.identity.v1",
  "neuro-nexus.state.v1",
  "neuro-nexus.organic-growth.v079"
];

export const CONFIG = Object.freeze({
  maxDevicePixelRatio: 3,

  maturitySeconds: 240,
  saveIntervalSeconds: 2.5,

  nodeDecayPerSecond: 0.95,
  bloomThreshold: 0.48,

  spontaneousSignalMin: 1.35,
  spontaneousSignalMax: 3.4,

  // Visual-only neural traffic. This increases perceived life without adding nodes,
  // edges, memory pressure, or growth acceleration.
  ambientSignalMin: 0.86,
  ambientSignalMax: 1.55,

  // Visual-only remembered-path traffic. It makes preferred connections legible
  // without changing learning, growth pressure, node count, or edge count.
  pathSignalMin: 1.15,
  pathSignalMax: 2.1,

  growthIntervalMin: 2.35,
  growthIntervalMax: 4.9,
  connectionIntervalMin: 4.4,
  connectionIntervalMax: 8.2,

  maxClusters: 4,
  maxTotalNodes: 160,
  maxTotalEdges: 420,
  maxBridgeEdges: 2,
  maxPulses: 340,
  maxInjectedWaves: 34,

  maxActivation: 0.84,
  maxCoreActivation: 0.7,

  minZoom: 0.82,
  maxZoom: 3.4,
  zoomSmoothing: 0.18,
  panSmoothing: 0.22,
  tapMoveTolerance: 8,

  // Puls-Refraktärzeit: Wie viele Pulse (recentPulseCount) dürfen innerhalb
  // von edgeRefractoryWindow Sekunden auf einer Kante erscheinen, bevor
  // weitere Pulse geblockt werden. visualOnly-Pulse tolerieren das Doppelte.
  edgeRefractoryMaxPulses: 4,
  edgeRefractoryWindow: 0.55,

  // Relay-Cluster: temporärer Bridge-Hub, entsteht nach CONSTELLATION
  relayLifespan: 90,          // Sekunden Lebensdauer
  relaySpawnInterval: [35, 70], // Spawn-Intervall (min, max) in Sekunden
  relayMaxActive: 1,           // Maximal gleichzeitige Relay-Cluster
  relaySpawnMinAge: 180,       // Earliest spawn age
  relaySpawnMinStage: "constellation"
});

export const CLUSTER_TYPES = Object.freeze({
  genesis: {
    label: "Genesis Core",
    rgb: [18, 145, 255],
    softRgb: [82, 190, 255],
    initialNodes: 5,
    maxNodes: 56,
    radius: 0.205,
    baseWeight: 0.5
  },
  exploration: {
    label: "Exploration",
    rgb: [132, 82, 255],
    softRgb: [188, 140, 255],
    initialNodes: 3,
    maxNodes: 48,
    radius: 0.168,
    baseWeight: 0.43
  },
  stable: {
    label: "Stable",
    rgb: [18, 218, 255],
    softRgb: [104, 242, 255],
    initialNodes: 3,
    maxNodes: 42,
    radius: 0.158,
    baseWeight: 0.54
  },
  memory: {
    label: "Memory",
    rgb: [255, 178, 90],
    softRgb: [255, 218, 156],
    initialNodes: 2,
    maxNodes: 34,
    radius: 0.142,
    baseWeight: 0.46
  },

  // Compatibility aliases for older saved states.
  evolving: {
    label: "Exploration",
    rgb: [132, 82, 255],
    softRgb: [188, 140, 255],
    initialNodes: 3,
    maxNodes: 48,
    radius: 0.135,
    baseWeight: 0.43
  },
  ancient: {
    label: "Memory",
    rgb: [255, 178, 90],
    softRgb: [255, 218, 156],
    initialNodes: 2,
    maxNodes: 34,
    radius: 0.115,
    baseWeight: 0.46
  },
  relay: {
    label: "Relay",
    rgb: [255, 255, 160],
    softRgb: [255, 255, 200],
    initialNodes: 0,
    maxNodes: 0,
    radius: 0.06,
    baseWeight: 0.72
  }
});

export const GENESIS_BLUEPRINT = Object.freeze({
  id: "genesis-core",
  type: "genesis",
  role: "genesis",
  state: "active",
  threshold: 0,
  angle: 0,
  distance: 0,
  initialNodes: 5
});
