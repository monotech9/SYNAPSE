/**
 * Generatives Audio-Feedback für Neuro Nexus.
 *
 * Nutzt die Web Audio API, um prozedurale Klänge zu erzeugen:
 * - Pulse-Durchlauf: weicher Sinus-Tone, Frequenz basierend auf Cluster-Typ
 * - Node-Geburt: hauchiges "Awake"-Geräusch
 * - Stage-Transition: tiefer, anhaltender Akkord
 * - Pointer-Interaktion: dezentes Klick-Geräusch
 *
 * Keine externen Audio-Dateien — alles wird synthetisiert.
 * Audio ist standardmäßig deaktiviert und muss vom Nutzer aktiviert werden.
 */

// Cluster-Typ → Basisfrequenz (Hz)
const CLUSTER_FREQ = {
  genesis: 110,      // A2 — tief, warm
  exploration: 220,  // A3 — mittel, neugierig
  stable: 165,       // E3 — ruhig, fest
  memory: 138,       // C#3 — warm, erinnernd
  relay: 196,        // G3 — hell, verbindend
  default: 180
};

// Personality → Tonart-Modifier (Semitone)
const PERSONALITY_PITCH = {
  seeker: 1.0,     // etwas höher
  guardian: -1.0,  // etwas tiefer
  spark: 2.0,      // am höchsten
  rooted: -2.0,    // am tiefsten
  balanced: 0
};

export class AmbientAudio {
  constructor(simulation) {
    this.simulation = simulation;
    this.enabled = false;
    this.ctx = null;
    this.masterGain = null;
    this._stageListener = null;

    // Throttling: nicht jeden Pulse einzeln abspielen
    this._lastPulseTime = 0;
    this._minPulseInterval = 0.08;
    this._lastBirthTime = 0;
    this._minBirthInterval = 0.15;
  }

  /**
   * Aktiviert das Audio — muss durch eine Nutzer-Interaktion erfolgen
   * (Browser-Autoplay-Policy).
   */
  enable() {
    if (this.enabled) return true;

    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return false;

      this.ctx = new AudioCtx();

      // iOS: AudioContext startet im Zustand 'suspended' —
      // muss durch User-Interaktion (dieser Klick) aufgeweckt werden
      if (this.ctx.state === "suspended") {
        this.ctx.resume().catch(() => {});
      }
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.0;
      this.masterGain.connect(this.ctx.destination);

      // Sanftes Einblenden
      this.masterGain.gain.linearRampToValueAtTime(0.18, this.ctx.currentTime + 1.5);

      // Einfacher Reverb-Ersatz: Delay-Feedback
      this.delayNode = this.ctx.createDelay(1.0);
      this.delayNode.delayTime.value = 0.28;
      this.delayGain = this.ctx.createGain();
      this.delayGain.gain.value = 0.22;
      this.delayFilter = this.ctx.createBiquadFilter();
      this.delayFilter.type = "lowpass";
      this.delayFilter.frequency.value = 1800;

      this.masterGain.connect(this.delayNode);
      this.delayNode.connect(this.delayFilter);
      this.delayFilter.connect(this.delayGain);
      this.delayGain.connect(this.delayNode);
      this.delayGain.connect(this.ctx.destination);

      this.enabled = true;

      // Stage-Change-Listener für Akkorde
      if (this.simulation.onGrowthStageChange) {
        this._stageListener = (event) => this.playStageTransition(event);
        this.simulation.onGrowthStageChange(this._stageListener);
      }

      return true;
    } catch (e) {
      console.warn("Audio-Initialisierung fehlgeschlagen:", e);
      return false;
    }
  }

  disable() {
    if (!this.enabled || !this.ctx) return;

    try {
      this.masterGain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.5);
      setTimeout(() => {
        if (this.ctx) {
          this.ctx.close();
          this.ctx = null;
        }
      }, 600);
    } catch (_) {}

    this.enabled = false;

    if (this._stageListener && this.simulation.removeStageChangeListener) {
      this.simulation.removeStageChangeListener(this._stageListener);
      this._stageListener = null;
    }
  }

  toggle() {
    if (this.enabled) {
      this.disable();
      return false;
    }
    return this.enable();
  }

  /**
   * Spielt einen Pulse-Tone beim Durchlauf einer Kante.
   */
  playPulse(edge, strength = 0.3) {
    if (!this.enabled || !this.ctx) return;

    const now = this.ctx.currentTime;
    if (now - this._lastPulseTime < this._minPulseInterval) return;
    this._lastPulseTime = now;

    const clusterType = edge.a.cluster?.type || "default";
    const baseFreq = CLUSTER_FREQ[clusterType] || CLUSTER_FREQ.default;
    const personality = this.simulation.personality?.profile || "balanced";
    const pitchMod = PERSONALITY_PITCH[personality] || 0;

    const freq = baseFreq * Math.pow(2, pitchMod / 12) * (0.98 + Math.random() * 0.04);
    const isBridge = edge.bridge || false;
    const oscType = isBridge ? "triangle" : "sine";

    this._playTone(freq, strength * 0.15, 0.4, oscType, now);
  }

  /**
   * Spielt ein hauchiges "Awake"-Geräusch bei Node-Geburt.
   */
  playNodeBirth(cluster) {
    if (!this.enabled || !this.ctx) return;

    const now = this.ctx.currentTime;
    if (now - this._lastBirthTime < this._minBirthInterval) return;
    this._lastBirthTime = now;

    const clusterType = cluster?.type || "default";
    const baseFreq = (CLUSTER_FREQ[clusterType] || CLUSTER_FREQ.default) * 2;

    this._playTone(baseFreq, 0.08, 0.8, "sine", now);
    this._playTone(baseFreq * 1.005, 0.06, 0.8, "sine", now + 0.02);
  }

  /**
   * Spielt einen tiefen, anhaltenden Akkord bei Stage-Transition.
   */
  playStageTransition(event) {
    if (!this.enabled || !this.ctx) return;

    const now = this.ctx.currentTime;
    const baseFreq = 82;
    const notes = [baseFreq, baseFreq * 1.5, baseFreq * 2.0];
    for (let i = 0; i < notes.length; i++) {
      this._playTone(notes[i], 0.06, 3.0, "sine", now + i * 0.08);
    }
  }

  /**
   * Spielt ein dezentes Klick-Geräusch bei Pointer-Interaktion.
   */
  playPointerInteraction(intensity = 0.5) {
    if (!this.enabled || !this.ctx) return;

    const now = this.ctx.currentTime;
    const freq = 320 + Math.random() * 80;
    this._playTone(freq, intensity * 0.08, 0.12, "triangle", now);
  }

  /**
   * Interner Helper: spielt einen einzelnen Tone mit ADSR-Envelope.
   */
  _playTone(freq, gain, duration, type, startTime) {
    if (!this.ctx || !this.masterGain) return;

    try {
      const osc = this.ctx.createOscillator();
      const env = this.ctx.createGain();

      osc.type = type || "sine";
      osc.frequency.value = freq;
      osc.connect(env);
      env.connect(this.masterGain);

      const attack = 0.02;
      const decay = 0.06;
      const sustainLevel = gain * 0.6;
      const release = duration * 0.6;

      env.gain.setValueAtTime(0, startTime);
      env.gain.linearRampToValueAtTime(gain, startTime + attack);
      env.gain.linearRampToValueAtTime(sustainLevel, startTime + attack + decay);
      env.gain.linearRampToValueAtTime(0, startTime + duration + release);

      osc.start(startTime);
      osc.stop(startTime + duration + release + 0.1);
    } catch (e) {
      // Stille Fehler — Audio soll nie die Simulation bremsen
    }
  }

  /**
   * Herzschlag-Ton: ein tiefer, Zustand-abhängiger Ton.
   * Ruhe → langsam und tief, Stress → schnell und hoch.
   */
  playHeartbeat(strength, state) {
    if (!this.enabled || !this._ctx) return;
    try {
      const now = this._ctx.currentTime;
      const baseFreq = state === "stress" ? 55 : state === "learning" ? 48 : state === "uncertain" ? 42 : 38;
      const freq = baseFreq + strength * 12;

      const osc = this._ctx.createOscillator();
      const env = this._ctx.createGain();

      osc.type = "sine";
      osc.frequency.value = freq;

      const gain = strength * 0.08;
      const duration = 0.4 + strength * 0.3;

      osc.connect(env);
      env.connect(this.masterGain);

      env.gain.setValueAtTime(0, now);
      env.gain.linearRampToValueAtTime(gain, now + 0.04);
      env.gain.exponentialRampToValueAtTime(0.001, now + duration);

      osc.start(now);
      osc.stop(now + duration + 0.1);
    } catch (e) {}
  }

  /**
   * Narben-Echo: ein sehr leiser, geisterhafter Ton.
   */
  playScarEcho(scar) {
    if (!this.enabled || !this._ctx) return;
    try {
      const now = this._ctx.currentTime;
      const osc = this._ctx.createOscillator();
      const env = this._ctx.createGain();

      osc.type = "sine";
      osc.frequency.value = 220 + scar.formerTrace * 200;

      const gain = 0.03;
      const duration = 1.5;

      osc.connect(env);
      env.connect(this.masterGain);

      env.gain.setValueAtTime(0, now);
      env.gain.linearRampToValueAtTime(gain, now + 0.3);
      env.gain.exponentialRampToValueAtTime(0.001, now + duration);

      osc.start(now);
      osc.stop(now + duration + 0.1);
    } catch (e) {}
  }

  /**
   * Beobachter-Modus-Eintritt: ein sanfter Akkord.
   */
  playObserverModeEnter() {
    if (!this.enabled || !this._ctx) return;
    try {
      const now = this._ctx.currentTime;
      const freqs = [261.63, 329.63, 392.0]; // C-Dur Akkord
      for (const freq of freqs) {
        const osc = this._ctx.createOscillator();
        const env = this._ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = freq;
        const gain = 0.02;
        const duration = 2.0;
        osc.connect(env);
        env.connect(this.masterGain);
        env.gain.setValueAtTime(0, now);
        env.gain.linearRampToValueAtTime(gain, now + 0.5);
        env.gain.exponentialRampToValueAtTime(0.001, now + duration);
        osc.start(now);
        osc.stop(now + duration + 0.1);
      }
    } catch (e) {}
  }
}
