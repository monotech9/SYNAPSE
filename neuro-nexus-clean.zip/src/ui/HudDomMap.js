/**
 * HudDomMap — DOM-Element-Query für das HUD
 *
 * Zentrale Liste aller DOM-IDs, die das HUD verwendet.
 * Ermöglicht einfaches Hinzufügen/Entfernen von Elementen
 * ohne den Orchestrator zu verändern.
 */

/**
 * Queryt alle DOM-Elemente anhand ihrer IDs.
 * @returns {Object} — Map von ID → HTMLElement
 */
export function queryEls() {
  const ids = [
    // Canvas / Visual
    "eegCanvas", "vitalCanvas", "fmriGrid", "memoryRingsSvg",
    "radarCanvas", "phaseCanvas", "emotionCanvas",

    // Log / Epoch
    "logFeed", "epochLog", "logCountBadge",

    // Labels
    "resonanceLabel",

    // Trigger
    "triggerBtn",

    // Menu
    "menuBtn", "menuClose", "gameMenu",
    "menuImpuls", "menuNeuron", "menuReset",
    "menuNewGame", "menuSaveGame", "menuLoadGame", "menuExportConnectome",

    // Settings
    "settingAudio", "settingTheme", "settingObserver",

    // Menu Stats
    "menuStage", "menuNodes", "menuEdges", "menuAge",
    "menuClusters", "menuEpoch",

    // Glance Bar
    "glanceStage", "glanceNodes", "glanceEdges", "glanceAge",
    "glanceCluster", "glanceFps",

    // Achievements
    "epochAchievements",

    // Telemetry
    "telemetryText", "telemetryDot",

    // Drawer / Sidebar
    "drawerToggle", "drawerLabel", "sidebar",

    // Bottom Dock
    "bottomDock", "dockHud", "dockImpuls", "dockNeuron", "dockObserver",
    "dockTabKognition", "dockTabMonitor", "dockTabSystem",

    // Sleep Indicator
    "sleepIndicator", "sleepIndicatorText",

    // Tabs
    "tab-monitor", "tab-kognition", "tab-system",

    // Emotion Panel
    "emotionDominantBadge", "emotionMoodBar", "emotionMoodVal",
    "emotionGrowthBar", "emotionGrowthVal",
    "emotionThresholdBar", "emotionThresholdVal",
    "emotionExplorationBar", "emotionExplorationVal",

    // Consciousness Panel
    "consciousState", "consciousAware",

    // NOVA Status Card
    "novaPulse", "novaStateLabel", "novaPhiVal", "novaMoodVal", "novaDriveVal",

    // Consciousness Bar Values
    "consciousAwareVal", "consciousPredVal",
    "consciousFreeEnergyVal", "consciousConfidenceVal", "consciousEpistemicVal",
    "consciousEnergyVal", "consciousDopamineVal", "consciousCohesionVal",
    "consciousEnergy", "consciousDopamine", "consciousCohesion",

    // DNA Archetype
    "novaArchetype", "dnaExploration", "dnaResonance", "dnaDynamism",
    "novaMoodState", "novaEnergy", "novaDopamine", "novaEchoCount",

    // DNA State Grid
    "dnaArchetypeBadge", "dnaArchetypeCard", "dnaArchetypeIcon",
    "dnaArchetypeName", "dnaArchetypeDesc",
    "dnaAxisExplorationVal", "dnaAxisExplorationFill", "dnaAxisExplorationClass",
    "dnaAxisResonanceVal", "dnaAxisResonanceFill", "dnaAxisResonanceClass",
    "dnaAxisDynamismVal", "dnaAxisDynamismFill", "dnaAxisDynamismClass",
    "dnaAxisArchetypeName",

    // Echo Memory
    "echoBadge", "echoActiveCount", "echoStrongest", "echoPatternTotal",
    "echoMemoryList",

    // ── Standalone-HUD Widgets (merged) ─────────────────────────────

    // Gauge Widget (System-Auslastung)
    "gaugeCanvasCpu", "gaugeCanvasMem", "gaugeCanvasNet",
    "gaugeLblCpu", "gaugeLblMem", "gaugeLblNet",

    // Heatmap Widget (Aktivitäts-Heatmap)
    "activityHeatmap",

    // Phase Arc Widget (Phasen-Transition)
    "phaseArcCanvas", "phaseArcPct",
    "phaseArcCurrent", "phaseArcNext",

    // Connection Widget (Verbindungsstärke)
    "connectionBody",

    // Alert Widget (System-Alarme)
    "alertFeed", "alertBadge",

    // Sys-Ticker (Dock)
    "sysTicker", "sysTickerMsg",

    // Dock badges
    "dockBadgeLog", "dockBadgeAlert",
  ];

  const els = {};
  ids.forEach(id => { els[id] = document.getElementById(id); });
  return els;
}
