/**
 * hudConstants.js — Re-Export-Facade für UI-Konstanten
 *
 * Alle Konstanten sind in src/ui/constants/ als einzelne Module aufgeteilt.
 * Diese Datei re-exportiert alles für Code der direkt aus "./hudConstants.js" importiert.
 *
 * Aktiv genutzt von: TooltipSystem.js
 */

export { GROWTH_LABELS, CLUSTER_LABELS } from "./constants/growthLabels.js";
export { LOG } from "./constants/logTemplates.js";
export { maybeAIThought, SLEEP_MESSAGES } from "./constants/aiThoughts.js";
export { TOOLTIP_DATA } from "./constants/tooltipData.js";
export { SLEEP_INDICATOR_MAP } from "./constants/sleepStates.js";
export { EMOTION_COLORS, MOOD_STATE_COLORS, MOOD_STATE_LABELS_DE } from "./constants/emotionColors.js";
export { DRIVE_COLORS } from "./constants/driveColors.js";
export { ARCHETYPE_ICONS, ARCHETYPE_NAMES_DE, getArchetypeMeta, getArchetypeNameDe } from "./constants/archetypeData.js";
