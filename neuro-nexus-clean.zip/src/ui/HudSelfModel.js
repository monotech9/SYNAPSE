/**
 * HudSelfModel — SelfModel-Event-Integration
 *
 * Verbindet SelfModel-Events (narrative, stateChange) mit dem
 * EpochLogWidget, sodass NOVAs Selbst-Reflexionen im Log erscheinen.
 *
 * Wird von HudPanel verwendet; nicht direkt instanziiert.
 */

/**
 * Verbindet SelfModel-Events mit dem Log-Widget.
 * @param {Object} ctx — { sim, getLogWidget }
 * @returns {{ off: function }} — Cleanup-Funktion
 */
export function connectSelfModel(ctx) {
  const { sim, getLogWidget } = ctx;
  const events = sim?.events;
  if (!events) return { off: () => {} };

  const offNarrative = events.on("selfmodel:narrative", (d) => {
    const logWidget = getLogWidget();
    if (!logWidget || !d.text) return;
    setTimeout(() => {
      logWidget?.addLog(`<span class="log-hl-ai">NOVA:</span> "${d.text}"`, sim.world.age);
    }, 80);
  });

  const offStateChange = events.on("selfmodel:stateChange", (d) => {
    const logWidget = getLogWidget();
    if (!logWidget) return;
    const stateLabels = {
      dormant: "Existenz",
      awakening: "Erwachen",
      active: "Aktivität",
      reflective: "Reflexion",
      flowing: "Fluss"
    };
    const label = stateLabels[d.to] || d.to;
    logWidget.addLog(`<span class="log-hl-ai">NOVA:</span> Übergang → ${label}`, sim.world.age);
  });

  return {
    off: () => { offNarrative(); offStateChange(); }
  };
}
