/**
 * HudDataUpdater — Thin Facade (rückwärtskompatibel)
 *
 * Alle DOM-Updater sind jetzt in src/ui/updaters/ als einzelne
 * Module extrahiert. Diese Datei dient nur noch als
 * Kompatibilitäts-Fassade für bestehenden Code.
 *
 * Für neuen Code: importiere die einzelnen Updater direkt oder
 * verwende die Registry (updaters/registry.js).
 */

import { VitalityUpdater }       from "./updaters/vitals/VitalityUpdater.js";
import { MemoryRingsUpdater }    from "./updaters/memory/MemoryRingsUpdater.js";
import { StageLabelUpdater }     from "./updaters/vitals/StageLabelUpdater.js";
import { MenuStatsUpdater }      from "./updaters/vitals/MenuStatsUpdater.js";
import { GlanceBarUpdater }      from "./updaters/vitals/GlanceBarUpdater.js";
import { TelemetryUpdater }      from "./updaters/nav/TelemetryUpdater.js";
import { GaugeWidgetUpdater }    from "./updaters/widgets/GaugeWidgetUpdater.js";
import { HeatmapWidgetUpdater }  from "./updaters/widgets/HeatmapWidgetUpdater.js";
import { PhaseArcWidgetUpdater } from "./updaters/widgets/PhaseArcWidgetUpdater.js";
import { SysTickerUpdater }      from "./updaters/vitals/SysTickerUpdater.js";
import { A11yStatusUpdater }     from "./updaters/vitals/A11yStatusUpdater.js";
import { ConsciousnessHUD }      from "./ConsciousnessHUD.js";

// Singleton-Instanzen für Fassaden-Aufrufe
const _vitality     = new VitalityUpdater();
const _memoryRings  = new MemoryRingsUpdater();
const _a11y         = new A11yStatusUpdater();
const _stageLabel   = new StageLabelUpdater();
const _glanceBar    = new GlanceBarUpdater();
const _telemetry    = new TelemetryUpdater();
const _gauge        = new GaugeWidgetUpdater();
const _heatmap      = new HeatmapWidgetUpdater();
const _phaseArc     = new PhaseArcWidgetUpdater();
const _sysTicker    = new SysTickerUpdater();

export function updateVitality(sim, vitalWidget) {
  _vitality._doUpdate({ sim, widgets: { vitalWidget } });
}

export function updateMemoryRings(sim, ringsWidget) {
  _memoryRings._doUpdate({ sim, widgets: { ringsWidget } });
}

export function updateA11yStatus(sim) {
  _a11y._doUpdate({ sim });
}

export function updateStageLabel(els, sim) {
  _stageLabel._doUpdate({ sim, els });
}

export function updateMenuStats(els, sim, unlockedEpochs) {
  const updater = new MenuStatsUpdater(unlockedEpochs);
  updater._doUpdate({ sim, els });
}

export function updateGlanceBar(els, sim, telemetry) {
  _glanceBar._doUpdate({ sim, els, telemetry });
}

export function updateTelemetry(els, sim, telemetry, pulseRatio, chaosVar) {
  _telemetry._doUpdate({ sim, els, telemetry, derived: { pulseRatio, chaosVar } });
}

export function updateGaugeWidget(sim, gaugeWidget, telemetry) {
  _gauge._doUpdate({ sim, widgets: { gaugeWidget }, telemetry });
}

export function updateHeatmapWidget(sim, heatmapWidget) {
  _heatmap._doUpdate({ sim, widgets: { heatmapWidget } });
}

export function updatePhaseArcWidget(sim, phaseArcWidget) {
  _phaseArc._doUpdate({ sim, widgets: { phaseArcWidget } });
}

export function updateSysTicker(sim) {
  _sysTicker._doUpdate({ sim });
}

// Re-export ConsciousnessHUD für Code, der beide importiert
export { ConsciousnessHUD };
