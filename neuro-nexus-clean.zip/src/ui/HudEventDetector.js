/**
 * HudEventDetector — Erkennt Simulations-Events und loggt sie
 *
 * Detektiert Veränderungen im Netzwerk-Zustand (neue Nodes, Edges,
 * Bridges, Stage-Übergänge, Pulse-Spikes, Memory-Flashes) und leitet
 * sie an das EpochLogWidget weiter.
 *
 * Wird von HudPanel verwendet; nicht direkt instanziiert.
 */

import {
  GROWTH_LABELS, CLUSTER_LABELS, LOG, maybeAIThought
} from "./hudConstants.js";

/**
 * Erzeugt einen Event-Detektor, der Simulationszustands-Änderungen ins Log schreibt.
 * @param {Object} ctx — { sim, els, logWidget, oscWidget, prev, unlockedEpochs }
 * @returns {function} — detectEvents(age) Funktion
 */
export function createEventDetector(ctx) {
  const { sim, els, getLogWidget, getOscWidget, prev, unlockedEpochs } = ctx;

  return function detectEvents() {
    const w = sim.world, age = w.age;
    const logWidget = getLogWidget();
    if (!logWidget) return;

    // Node count
    const nc = sim.totalNodeCount();
    if (nc > prev.nodeCount && prev.nodeCount > 0) {
      const cl = biggest(w.clusters);
      logWidget.addLog(LOG.nodeAdded({ cluster: cl ? clusterName(cl) : "Netzwerk" }), age);
    }
    prev.nodeCount = nc;

    // Edge count
    const ec = w.edges.length;
    if (ec > prev.edgeCount && prev.edgeCount > 0) {
      logWidget.addLog(LOG.edgeAdded({
        id: (sim.diagnosticCounters.internalEdgesAdded % 256).toString(16).toUpperCase().padStart(2, "0")
      }), age);
      getOscWidget()?.spikeGamma(0.18);
    }
    prev.edgeCount = ec;

    // Bridge count
    const bc = w.bridgeEdges.length;
    if (bc > prev.bridgeCount && prev.bridgeCount >= 0) {
      logWidget.addLog(LOG.bridgeCreated(), age);
      logWidget.addEpoch("Bridge-Link", `Inter-cluster-Verbindung (${bc} total)`, "milestone", age);
      if (bc <= 2) {
        const bridgeThought = maybeAIThought("awakening", 0.3);
        if (bridgeThought) setTimeout(() => logWidget.addLog(bridgeThought, age + 0.1), 250);
      }
    }
    prev.bridgeCount = bc;

    // Growth stage change
    if (w.growthStage !== prev.growthStage && prev.growthStage !== "") {
      const label = GROWTH_LABELS[w.growthStage] || w.growthStage.toUpperCase();
      logWidget.addLog(LOG.stageChanged({ stage: label }), age);
      logWidget.addEpoch(`Epoche: ${label}`, `Stadium ${label} erreicht`, "milestone", age);
      const stageKey = label.toLowerCase().includes("gen") ? "genesis"
                     : label.toLowerCase().includes("knos") || label.toLowerCase().includes("bud") ? "budding"
                     : label.toLowerCase().includes("erw") || label.toLowerCase().includes("awak") ? "awakening"
                     : "flourishing";
      const aiThought = maybeAIThought(stageKey, 0.6);
      if (aiThought) setTimeout(() => logWidget.addLog(aiThought, age + 0.1), 300);
    }
    prev.growthStage = w.growthStage;

    // Pulse spike
    const pc = w.pulses.length;
    if (pc > 90 && pc > prev.pulseCount + 32) {
      logWidget.addLog(LOG.pulseSpike({ count: pc }), age);
      // Feed alert widget
      const alertWidget = ctx.getAlertWidget?.();
      if (alertWidget) {
        const load = Math.round((pc / 180) * 100);
        if (load > 90)
          alertWidget.addAlert("#ef4444", "✕ Hohe Synaptische Last", `Netz-Auslastung > ${load}%`);
      }
    }
    prev.pulseCount = pc;

    // Memory flash
    if (w.memoryFlashTimer > prev.memFlash + 0.5) {
      const cl = strongest(w.clusters);
      logWidget.addLog(LOG.memoryFlash({ cluster: cl ? clusterName(cl) : "Netzwerk" }), age);
      const memThought = maybeAIThought("scar", 0.15);
      if (memThought) setTimeout(() => logWidget.addLog(memThought, age + 0.1), 200);
    }
    prev.memFlash = w.memoryFlashTimer;

    // Log count badge (sidebar + dock)
    if (els.logCountBadge) els.logCountBadge.textContent = logWidget.total;
    const dockBadgeLog = document.getElementById("dockBadgeLog");
    if (dockBadgeLog) {
      const count = logWidget.total;
      dockBadgeLog.textContent = count > 99 ? "99+" : count;
      dockBadgeLog.hidden = count === 0;
    }
  };
}

// ─── Cluster Helpers ─────────────────────────────────────────────────

export function biggest(clusters) {
  return clusters.length
    ? clusters.reduce((a, b) => a.nodes.length >= b.nodes.length ? a : b)
    : null;
}

export function strongest(clusters) {
  const active = clusters.filter(c => c.state !== "dormant");
  return active.length
    ? active.reduce((a, b) => a.memoryStrength >= b.memoryStrength ? a : b)
    : null;
}

export function clusterName(c) {
  const label = CLUSTER_LABELS[c.type] || c.role || "Cluster";
  const id = (typeof c.id === "number" && isFinite(c.id)) ? (c.id % 256) : 0;
  return `${label} #${id.toString(16).toUpperCase().padStart(2, "0")}`;
}
