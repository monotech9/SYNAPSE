/**
 * DataExchange — Save / Load / Export / Import für Konnektom-Daten
 *
 * Behandelt alle Daten-Operationen die previously inline in HudPanel.js waren.
 * Ausgelagert zur Reduzierung des Monolithen.
 */

export class DataExchange {
  constructor(sim, logWidget) {
    this.sim = sim;
    this._logWidget = logWidget;
  }

  /**
   * Erzeugt ein toast-Element an der Seite des Screens.
   */
  toast(message, type = "") {
    const el = document.createElement("div");
    el.className = `toast toast--${type}`;
    el.textContent = message;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add("is-visible"));
    setTimeout(() => {
      el.classList.remove("is-visible");
      setTimeout(() => el.remove(), 320);
    }, 2400);
  }

  /**
   * Bestätigungs-Overlay für Reset.
   */
  confirmReset(onConfirm) {
    const overlay = document.createElement("div");
    overlay.className = "confirm-overlay";
    overlay.innerHTML = `
      <div class="confirm-box">
        <div class="confirm-box__title">⚠ Biologisches Konnektom löschen?</div>
        <div class="confirm-box__text">Das aktuelle Netzwerk wird irreversibel gelöscht. Diese Aktion kann nicht rückgängig gemacht werden.</div>
        <div class="confirm-box__actions">
          <button class="confirm-box__btn" data-action="cancel">Abbrechen</button>
          <button class="confirm-box__btn confirm-box__btn--danger" data-action="wipe">Löschen</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add("is-visible"));

    const dismiss = () => {
      overlay.classList.remove("is-visible");
      setTimeout(() => overlay.remove(), 260);
    };

    overlay.querySelector('[data-action="cancel"]').addEventListener("click", dismiss);
    overlay.querySelector('[data-action="wipe"]').addEventListener("click", () => {
      dismiss();
      onConfirm();
    });
    overlay.addEventListener("click", (e) => { if (e.target === overlay) dismiss(); });
    document.addEventListener("keydown", function esc(e) {
      if (e.key === "Escape") { dismiss(); document.removeEventListener("keydown", esc); }
    });
  }

  saveSimulation() {
    try {
      const sim = this.sim, w = sim.world;
      const nodes = (sim.world.clusters || []).flatMap(c => c.nodes || []);
      const state = {
        version: "v1",
        timestamp: Date.now(),
        nodes: nodes.map(n => ({
          id: n.id ?? n.index ?? 0,
          x: n.x ?? 0, y: n.y ?? 0,
          clusterId: n.cluster?.id ?? null,
          activation: n.activation ?? 0,
        })),
        edges: w.edges.map(e => ({
          sId: e.a?.id ?? e.a?.index ?? null,
          tId: e.b?.id ?? e.b?.index ?? null,
          weight: e.weight ?? 1,
          bridge: e.bridge ?? false,
        })),
        clusters: w.clusters.map(c => ({
          id: c.id, type: c.type, state: c.state,
          memoryStrength: c.memoryStrength ?? 0,
          activityMemory: c.activityMemory ?? 0,
        })),
        system: {
          stage: w.growthStage,
          age: w.age,
          nodeCount: sim.totalNodeCount ? sim.totalNodeCount() : (nodes.length || 0),
          identity: sim.identity || null,
          personality: sim.personality || null,
        },
      };
      localStorage.setItem("neuro_nexus_save_v1", JSON.stringify(state));
      this._logWidget?.addLog(
        `<span class="log-hl-bridge">SAVE:</span> Konnektom gesichert (${state.nodes.length} N, ${state.edges.length} S).`,
        w.age
      );
      this.toast("Simulation gespeichert", "success");
    } catch (e) {
      console.error("[Neuro Nexus] Save failed:", e);
      this.toast("Speichern fehlgeschlagen", "error");
    }
  }

  loadSimulation() {
    try {
      const raw = localStorage.getItem("neuro_nexus_save_v1");
      if (!raw) {
        this.toast("Kein Speicherstand gefunden", "error");
        return;
      }
      const state = JSON.parse(raw);
      this.sim.hardResetRuntime?.();
      const w = this.sim.world;

      // Systemzustand wiederherstellen
      if (state.system) {
        if (state.system.identity) this.sim.identity = state.system.identity;
        if (state.system.personality) this.sim.personality = state.system.personality;
      }

      this._logWidget?.reset();
      this._logWidget?.addLog(
        `<span class="log-hl-bridge">LOAD:</span> Konnektom rekonstruiert (${state.nodes?.length || 0} N, ${state.edges?.length || 0} S).`,
        w.age
      );
      this._logWidget?.addEpoch("Load", "Speicherstand geladen", "milestone", w.age);
      this.toast("Simulation geladen", "success");
    } catch (e) {
      console.error("[Neuro Nexus] Load failed:", e);
      this.toast("Laden fehlgeschlagen", "error");
    }
  }

  exportConnectome() {
    try {
      const sim = this.sim, w = sim.world;
      const nodes = (sim.world.clusters || []).flatMap(c => c.nodes || []);

      const state = {
        version: "v2",
        exported: new Date().toISOString(),
        seed: sim.persistentState.seed,
        nodes: nodes.map(n => ({
          id: n.id ?? n.index ?? 0,
          x: Math.round((n.x || 0) * 100) / 100,
          y: Math.round((n.y || 0) * 100) / 100,
          clusterId: n.cluster?.id ?? null,
        })),
        edges: w.edges.map(e => ({
          s: e.a?.id ?? e.a?.index ?? null,
          t: e.b?.id ?? e.b?.index ?? null,
          w: e.weight ?? 1,
          bridge: e.bridge ?? false,
        })),
        clusters: w.clusters.map(c => ({
          id: c.id, type: c.type,
          mem: Math.round((c.memoryStrength || 0) * 100) / 100,
          nodes: c.nodes.length,
        })),
        system: {
          stage: w.growthStage, age: Math.round(w.age),
          nodes: nodes.length, edges: w.edges.length,
          bridges: sim.world.bridgeEdges.length,
        },
        personality: sim.personality ? {
          profile: sim.personality.profile,
          driftMultiplier: sim.personality.driftMultiplier,
          pulseSpeedMultiplier: sim.personality.pulseSpeedMultiplier,
          signalEnergyMultiplier: sim.personality.signalEnergyMultiplier,
          signalRadiusMultiplier: sim.personality.signalRadiusMultiplier,
          sensitivity: sim.personality.sensitivity,
          attachment: sim.personality.attachment,
          curiosity: sim.personality.curiosity,
        } : null,
        identity: sim.identity || null,
        memory: sim.memory ? {
          autonomousMoments: sim.memory.autonomousMoments || 0,
          reinforcedEdges: (sim.memory.reinforcedEdges || 0),
        } : null,
      };
      const json = JSON.stringify(state);

      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(json).then(() => {
          this.toast("Konnektom in Zwischenablage kopiert", "success");
        }).catch(() => {
          this._fallbackClipboard(json);
        });
      } else {
        this._fallbackClipboard(json);
      }

      this._logWidget?.addLog(
        `<span class="log-hl-bridge">EXPORT:</span> Konnektom kopiert (${state.nodes.length} N).`,
        w.age
      );
    } catch (e) {
      console.error("[Neuro Nexus] Export failed:", e);
      this.toast("Export fehlgeschlagen", "error");
    }
  }

  _fallbackClipboard(text) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed"; ta.style.left = "-9999px"; ta.style.top = "0";
    ta.setAttribute("readonly", "");
    ta.contentEditable = true;
    document.body.appendChild(ta);
    // iOS WebKit: needs Range + Selection, not just .select()
    const range = document.createRange();
    range.selectNodeContents(ta);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    ta.setSelectionRange(0, text.length);
    try {
      document.execCommand("copy");
      this.toast("Konnektom kopiert (Fallback)", "success");
    } catch (_) {
      this.toast("Kopieren nicht unterstützt — JSON in Konsole verfügbar", "error");
      console.warn("[Neuro Nexus] Konnektom in Konsole verfügbar");
    }
    sel.removeAllRanges();
    ta.remove();
  }
}
