/**
 * HudFrameLoop — Render-Loop für das HUD (refactored v2)
 *
 * Treibt alle Widgets pro Frame an, mit unterschiedlichen Throttling-Stufen:
 *  - Canvas-Widgets: jeden Frame (60 FPS)
 *  - fMRI: ~10 FPS
 *  - DOM-Updater: ~4.5 FPS (via Registry, jedes Updater-Modul hat eigene Taktung)
 *
 * Berechnet auch abgeleitete Metriken (chaosVar, coherence, pulseRatio)
 * die von mehreren Widgets benötigt werden.
 *
 * v2: Verwendet die Updater-Registry statt direkter Funktionsaufrufe.
 *     Um ein Element hinzuzufügen/zu entfernen, nur die Registry anpassen.
 *
 * Rückgabe: { onFrame(now, ms), destroy() }
 */

import { createUpdaters, updateMenu, destroyUpdaters } from "./updaters/registry.js";

/**
 * Erzeugt eine Frame-Loop mit zugehörigem Cleanup.
 * @param {Object} ctx — { sim, telemetry, els, widgets, detectEvents, isMenuOpen, unlockedEpochs }
 * @returns {{ onFrame: function, destroy: function }}
 */
export function createFrameLoop(ctx) {
  const {
    sim, telemetry, els, widgets, detectEvents,
    isMenuOpen, unlockedEpochs,
  } = ctx;

  // Updater-Instanzen erstellen
  const updaters = createUpdaters(unlockedEpochs);

  // Throttling State für Canvas-Widgets
  let lastFmri = 0;
  let lastDom = 0;
  const domMs = 220;

  function onFrame(now, _ms) {
    const world = sim.world;

    // ─── Canvas-Widgets: jeden Frame (60 FPS) ──────────────────────

    const pulseRatio = Math.min(1, world.pulses.length / 180);
    widgets.oscWidget?.update(pulseRatio, now);
    widgets.oscWidget?.draw(now);
    widgets.vitalWidget?.draw(now);

    // ─── fMRI: gedrosselt auf ~10 FPS ──────────────────────────────

    if (now - lastFmri >= 100) {
      lastFmri = now;
      if (world.pulses?.length && widgets.fmriWidget) {
        for (const p of world.pulses) {
          if (!p.active) continue;
          const nx = p.to || p.from;
          if (nx && typeof nx.x === "number") {
            widgets.fmriWidget.notifyFire(
              world.width ? nx.x / world.width : nx.x,
              world.height ? nx.y / world.height : nx.y
            );
          }
        }
      }
      widgets.fmriWidget?.update(world);
    }

    // ─── Radar + Phasenraum (60 FPS) ───────────────────────────────

    widgets.radarWidget?.update(world);
    widgets.radarWidget?.draw(now);

    // Abgeleitete Metriken berechnen (für Phasenraum + Telemetry)
    const pulseRatio2 = Math.min(1, world.pulses.length / 180);
    const clusters2 = world.clusters.filter(c => c.state !== "dormant");
    const acts2 = clusters2.map(c => c.activityMemory || 0);
    const mean2 = acts2.length ? acts2.reduce((s, a) => s + a, 0) / acts2.length : 0;
    const variance2 = acts2.length
      ? acts2.reduce((s, a) => s + (a - mean2) ** 2, 0) / acts2.length
      : 0;
    const chaosVar = Math.min(1, Math.sqrt(variance2) * 3);
    const conSnap = sim.consciousness?.getSnapshot();
    const coherence = conSnap?.coherence || 0;

    widgets.phaseWidget?.update(pulseRatio2, chaosVar, coherence);
    widgets.phaseWidget?.draw(now);

    // ─── Emotion Widget (60 FPS) ───────────────────────────────────

    if (widgets.emotionWidget && sim.emotionEngine) {
      widgets.emotionWidget.update(sim.emotionEngine.getSnapshot());
      widgets.emotionWidget.draw(now);
    }

    // ─── Kontext für alle Updater ──────────────────────────────────

    const updaterCtx = {
      sim, els, widgets, telemetry,
      consciousness: sim.consciousness,
      emotionEngine: sim.emotionEngine,
      snap: conSnap,
      derived: { pulseRatio: pulseRatio2, chaosVar, coherence },
    };

    // ─── Selbst-drosselnde Updater (Telemetry 1/s, Heatmap 5s) ────

    updaters.all.forEach(u => {
      if (u.throttleMs > 0) u.update(updaterCtx, now);
    });

    // ─── DOM-Updates: gedrosselt auf ~4.5 FPS ──────────────────────

    if (now - lastDom < domMs) return;
    lastDom = now;

    // Alle Updater ohne eigenes Throttling (werden durch domMs gedrosselt)
    updaters.all.forEach(u => {
      if (u.throttleMs === 0) u.update(updaterCtx, now);
    });

    // Event-Detection + Menu-Stats
    detectEvents();
    if (isMenuOpen()) {
      updateMenu(updaters.menu, updaterCtx, now);
    }
  }

  function destroy() {
    destroyUpdaters(updaters);
  }

  return { onFrame, destroy };
}
