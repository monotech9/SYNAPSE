import { CLUSTER_TYPES } from "../config.js";
import { clamp } from "../utils/math.js";

const CLUSTER_TYPE_LABELS = {
  genesis: "Genesis",
  exploration: "Exploration",
  stable: "Stabil",
  memory: "Gedächtnis",
  relay: "Relay"
};

/**
 * ResonanceLabel — schwebendes Label über dem Cluster mit der
 * höchsten Aktivierung während Pointer-Interaktion.
 *
 * Wird pro Frame via update(now, simulation) angetrieben.
 */
export class ResonanceLabel {
  constructor() {
    this.el = document.createElement("div");
    this.el.id = "pointer-resonance-label";
    this.el.style.cssText = [
      "position:fixed",
      "pointer-events:none",
      "z-index:10",
      "font-size:11px",
      "font-weight:500",
      "letter-spacing:0.04em",
      "color:rgba(200,230,255,0.85)",
      "text-shadow:0 0 8px rgba(0,80,180,0.6)",
      "opacity:0",
      "transition:opacity 0.4s ease",
      "transform:translate(-50%,-50%)",
      "white-space:nowrap"
    ].join(";");
    document.body.appendChild(this.el);

    this._lastCluster = null;
    this._fadeTimer = 0;
  }

  update(now, simulation) {
    if (simulation.world.pointerEnergy > 0.05 && simulation.world.clusters.length > 0) {
      let strongestCluster = null;
      let strongestActivity = 0;
      for (const cluster of simulation.world.clusters) {
        if (cluster.state === "dormant") continue;
        if (cluster.activityMemory > strongestActivity) {
          strongestActivity = cluster.activityMemory;
          strongestCluster = cluster;
        }
      }

      if (strongestCluster && strongestCluster !== this._lastCluster) {
        this._lastCluster = strongestCluster;
        const typeConfig = CLUSTER_TYPES[strongestCluster.type];
        const label = (CLUSTER_TYPE_LABELS[strongestCluster.type] || strongestCluster.role) + " reagiert";
        this.el.textContent = label;
        const rgb = typeConfig ? typeConfig.rgb : [100, 180, 255];
        this.el.style.color = `rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.9)`;
        this.el.style.textShadow = `0 0 8px rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.5)`;
      }

      if (strongestCluster) {
        const center = strongestCluster.center(now / 1000);
        const screenX = simulation.world.centerX + (center.x - simulation.world.centerX) * simulation.camera.scale + simulation.camera.offsetX;
        const screenY = simulation.world.centerY + (center.y - simulation.world.centerY) * simulation.camera.scale + simulation.camera.offsetY;
        this.el.style.left = `${screenX}px`;
        this.el.style.top = `${screenY - strongestCluster.pixelRadius * simulation.camera.scale - 24}px`;
        this.el.style.opacity = clamp(simulation.world.pointerEnergy * 1.2, 0, 0.9);
      }
      this._fadeTimer = 1.5;
    } else {
      this._fadeTimer -= 0.016;
      if (this._fadeTimer <= 0) {
        this.el.style.opacity = "0";
        this._lastCluster = null;
      } else {
        this.el.style.opacity = String(clamp(this._fadeTimer * 0.5, 0, 0.6));
      }
    }
  }
}
