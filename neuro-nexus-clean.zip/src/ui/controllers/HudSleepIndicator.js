/**
 * HudSleepIndicator — Schlafzustand-UI
 *
 * Reagiert auf sleep:stateChange Events und aktualisiert den
 * Sleep-Indikator + loggt NOVA-Gedanken bei Übergängen.
 * Extrahiert aus HudInteractionController.js.
 */

import { SLEEP_INDICATOR_MAP } from "../constants/sleepStates.js";
import { SLEEP_MESSAGES } from "../constants/aiThoughts.js";

/**
 * Initialisiert den Sleep-Indikator.
 * @param {Object} ctx — { sim, getLogWidget }
 */
export function initSleepIndicator(ctx) {
  const { sim } = ctx;
  const sleepEl = document.getElementById("sleepIndicator");
  const sleepText = document.getElementById("sleepIndicatorText");
  if (!sleepEl) return;

  let lastSleepState = null;

  if (sim?.events) {
    sim.events.on("sleep:stateChange", (data) => {
      const state = data.to;
      const info = SLEEP_INDICATOR_MAP[state] || SLEEP_INDICATOR_MAP.WAKE;
      sleepEl.className = `sleep-indicator ${info.cls}`;
      if (sleepText) sleepText.textContent = info.label;

      if (lastSleepState && lastSleepState !== state) {
        const w = sim?.world;
        if (SLEEP_MESSAGES[state] && w) {
          ctx.getLogWidget()?.addLog(SLEEP_MESSAGES[state], w.age);
        }
      }
      lastSleepState = state;
    });
  }
}
