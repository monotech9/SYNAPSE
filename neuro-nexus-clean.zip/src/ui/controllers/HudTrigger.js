/**
 * HudTrigger — Trigger-Button (Impuls-Auslösung)
 *
 * Extrahiert aus HudInteractionController.js.
 */

import { LOG } from "../constants/logTemplates.js";

/**
 * Initialisiert den Trigger-Button.
 * @param {Object} ctx — { sim, els, getOscWidget, getLogWidget, onFire }
 * @returns {function} — fireImpuls(btn) Funktion
 */
export function initTrigger(ctx) {
  const { sim, els, onFire } = ctx;

  els.triggerBtn?.addEventListener("click", () => {
    fireImpuls(els.triggerBtn);
  });

  function fireImpuls(btn) {
    const w = sim.world;
    const active = w.clusters.filter(c => c.state !== "dormant");
    let sx, sy;
    if (active.length) {
      const cl = active[Math.floor(Math.random() * active.length)];
      const ct = cl.center(w.currentTime);
      sx = w.centerX + (ct.x - w.centerX) * sim.camera.scale + sim.camera.offsetX;
      sy = w.centerY + (ct.y - w.centerY) * sim.camera.scale + sim.camera.offsetY;
    } else {
      sx = w.width / 2 + (Math.random() - 0.5) * w.width * 0.4;
      sy = w.height / 2 + (Math.random() - 0.5) * w.height * 0.4;
    }
    sim.injectSignal(sx, sy);
    ctx.getOscWidget()?.triggerImpulse();
    if (btn) { btn.classList.add("firing"); setTimeout(() => btn.classList.remove("firing"), 500); }
    ctx.getLogWidget()?.addLog(LOG.impulse(), w.age);
    ctx.getLogWidget()?.addEpoch("Impuls", `Manueller Impuls bei ${Math.round(w.age)}s`, "event", w.age);
    window.dispatchEvent(new CustomEvent("neuro:impulse"));
    sim.events.emit("signal:injected", { x: 0, y: 0, strength: 1.0 });
    showImpulseRipple();
    onFire?.();
  }

  return fireImpuls;
}

function showImpulseRipple() {
  const ripple = document.createElement("div");
  ripple.className = "impulse-ripple";
  document.body.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
}
