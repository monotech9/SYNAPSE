/**
 * HudBottomDock — Bottom-Dock-Navigation
 *
 * Verwaltet die Dock-Buttons (HUD-Toggle, Impuls, Neuron, Observer)
 * und die Dock-Tab-Buttons für direkten Tab-Sprung.
 * Extrahiert aus HudNavigationController.js.
 */

/**
 * Initialisiert das Bottom Dock.
 * @param {Object} ctx — { sim, els, openDrawer, closeDrawer, fireImpuls, observer, getLogWidget }
 */
export function setupBottomDock(ctx) {
  const { sim, els, openDrawer, closeDrawer, fireImpuls, observer } = ctx;

  // ── Dock initial versteckt, dann nach kurzer Verzögerung einblenden ──
  const dock = document.getElementById("bottomDock");
  if (dock) {
    // Nach 800ms mit Bounce-Animation einfahren
    setTimeout(() => {
      dock.classList.add("dock-visible");
      // Swipe-Hinweis nach erstmaligem Erscheinen kurz zeigen
      const hint = document.getElementById("dockSwipeHint");
      if (hint) {
        hint.style.opacity = "0.7";
        // Hinweis nach 4.5s ausblenden
        setTimeout(() => {
          hint.style.transition = "opacity 0.6s";
          hint.style.opacity = "0";
          setTimeout(() => hint.remove(), 700);
        }, 4500);
      }
    }, 800);

    // Auto-Hide beim Scrollen (Sidebar scrollt, nicht window)
    let lastScrollY = 0;
    let hideTimer = null;
    let isAutoHidden = false;

    const sidebar = els.sidebar || document.querySelector(".hud-sidebar");

    const showDock = () => {
      if (isAutoHidden) {
        dock.classList.add("dock-visible");
        isAutoHidden = false;
      }
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => {
        // Nur auto-verstecken wenn Sidebar nicht offen
        if (!sidebar?.classList.contains("is-open")) {
          dock.classList.remove("dock-visible");
          isAutoHidden = true;
        }
      }, 3500);
    };

    // Auf Touch-Geräten: beim Wischen von unten nach oben Dock zeigen
    let touchStartY = 0;
    document.addEventListener("touchstart", (e) => {
      touchStartY = e.touches[0].clientY;
    }, { passive: true });

    document.addEventListener("touchend", (e) => {
      const deltaY = touchStartY - e.changedTouches[0].clientY;
      const startedNearBottom = touchStartY > window.innerHeight * 0.75;
      // Wisch nach oben vom unteren Bildschirmrand → Dock zeigen
      if (startedNearBottom && deltaY > 30) {
        showDock();
      }
      // Wisch nach unten → Dock verstecken
      if (deltaY < -40 && dock.classList.contains("dock-visible")) {
        dock.classList.remove("dock-visible");
        isAutoHidden = true;
        clearTimeout(hideTimer);
      }
    }, { passive: true });

    // Beim Antippen des Dock-Bereichs unten Timer neu starten
    dock.addEventListener("touchstart", () => {
      clearTimeout(hideTimer);
    }, { passive: true });
    dock.addEventListener("touchend", () => {
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => {
        if (!sidebar?.classList.contains("is-open")) {
          dock.classList.remove("dock-visible");
          isAutoHidden = true;
        }
      }, 4000);
    }, { passive: true });
    // Unsichtbare Edge-Zone: Tippen am unteren Rand zeigt Dock
    const edgeTrigger = document.getElementById("dockEdgeTrigger");
    if (edgeTrigger) {
      edgeTrigger.addEventListener("touchstart", () => {
        showDock();
      }, { passive: true });
      edgeTrigger.addEventListener("click", () => {
        showDock();
      });
    }
  }

  els.dockHud?.addEventListener("click", () => {
    const sidebar = els.sidebar;
    if (!sidebar) return;
    sidebar.classList.contains("is-open") ? closeDrawer?.() : openDrawer?.();
  });

  els.dockImpuls?.addEventListener("click", () => {
    fireImpuls(els.triggerBtn || els.dockImpuls);
  });

  els.dockNeuron?.addEventListener("click", () => {
    const ww = sim.world;
    sim.addManualNode(ww.width / 2, ww.height / 2);
    ctx.getLogWidget()?.addLog(`<span class="log-hl-neuron">NEURON:</span> Manuell gepflanzt.`, ww.age);
  });

  els.dockObserver?.addEventListener("click", () => {
    observer?.toggle();
  });

  // Dock-Tab-Buttons: Sidebar öffnen + direkt zum Tab springen
  const dockTabBtns = [
    els.dockTabKognition,
    els.dockTabProtokolll,
    els.dockTabMonitor,
    els.dockTabSystem,
  ];
  dockTabBtns.forEach(btn => {
    if (!btn) return;
    btn.addEventListener("click", () => {
      const targetTab = btn.dataset.tab;
      if (!targetTab) return;

      const sidebar = els.sidebar;
      if (sidebar && !sidebar.classList.contains("is-open")) openDrawer?.();

      document.querySelectorAll(".hud-sidebar__tabs .tab-btn").forEach(tb => {
        const isTarget = tb.dataset.tab === targetTab;
        tb.classList.toggle("tab-btn--active", isTarget);
        tb.setAttribute("aria-selected", String(isTarget));
      });
      document.querySelectorAll(".tab-panel").forEach(panel => {
        const isTarget = panel.id === `tab-${targetTab}`;
        panel.classList.toggle("tab-panel--active", isTarget);
        isTarget ? panel.removeAttribute("hidden") : panel.setAttribute("hidden", "");
      });

      dockTabBtns.forEach(b => { if (b) b.classList.toggle("dock-tab-active", b === btn); });
    });
  });
}
