/**
 * HudTabSystem — Tab-System in der Sidebar
 *
 * Verwaltet das Umschalten zwischen Tabs (Kognition, Monitor, System)
 * inkl. Widget-Pause/Resume bei Tab-Wechsel.
 * Extrahiert aus HudNavigationController.js.
 */

/**
 * Initialisiert das Tab-System.
 * @param {Object} ctx — { els, allWidgets, radarWidget, phaseWidget }
 * @returns {{ switchTab: function, syncWidgetPauseState: function, activeTab: string }}
 */
export function setupTabSystem(ctx) {
  const { els, allWidgets } = ctx;
  const sidebar = els.sidebar;
  if (!sidebar) return { switchTab: () => {}, syncWidgetPauseState: () => {}, activeTab: "kognition" };

  let activeTab = "kognition";

  sidebar.querySelectorAll(".tab-panel").forEach(p => {
    const isActive = p.id === `tab-${activeTab}`;
    if (!isActive) { p.setAttribute("hidden", ""); p.style.display = "none"; }
    else { p.removeAttribute("hidden"); p.style.display = "flex"; p.classList.add("tab-panel--active"); }
  });

  sidebar.querySelectorAll(".tab-btn[data-tab]").forEach(btn => {
    btn.addEventListener("click", (e) => { e.stopPropagation(); switchTab(btn.dataset.tab); });
  });

  function syncWidgetPauseState() {
    const monitorActive = activeTab === "monitor";
    if (monitorActive) {
      ctx.radarWidget?.resume();
      ctx.phaseWidget?.resume();
    } else {
      ctx.radarWidget?.pause();
      ctx.phaseWidget?.pause();
    }
  }

  function switchTab(tabId) {
    sidebar.querySelectorAll(".tab-btn[data-tab]").forEach(b => {
      const isTarget = b.dataset.tab === tabId;
      b.classList.toggle("tab-btn--active", isTarget);
      b.setAttribute("aria-selected", String(isTarget));
    });

    sidebar.querySelectorAll(".tab-panel").forEach(p => {
      const isActive = p.id === `tab-${tabId}`;
      p.classList.toggle("tab-panel--active", isActive);
      if (isActive) { p.removeAttribute("hidden"); p.style.display = "flex"; }
      else { p.setAttribute("hidden", ""); p.style.display = "none"; }
    });

    activeTab = tabId;
    syncWidgetPauseState();
    if (sidebar.scrollTop > 0) sidebar.scrollTop = 0;

    requestAnimationFrame(() => {
      allWidgets.forEach(w => { if (w && typeof w.resize === "function") w.resize(); });
    });
    setTimeout(() => {
      allWidgets.forEach(w => { if (w && typeof w.resize === "function") w.resize(); });
    }, 200);
  }

  return { switchTab, syncWidgetPauseState, get activeTab() { return activeTab; } };
}
