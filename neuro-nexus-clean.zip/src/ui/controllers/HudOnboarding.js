/**
 * HudOnboarding — Onboarding-Overlay (Erststart)
 *
 * Zeigt ein Overlay beim ersten Start und speichert
 * den "onboarded" Status in localStorage.
 * Extrahiert aus HudInteractionController.js.
 */

/**
 * Initialisiert das Onboarding-Overlay.
 */
export function initOnboarding() {
  const overlay = document.getElementById("onboardingOverlay");
  const closeBtn = document.getElementById("onboardingClose");
  if (!overlay || !closeBtn) return;

  try {
    const seen = localStorage.getItem("neuro-nexus-onboarded");
    if (!seen) overlay.hidden = false;
  } catch (e) { /* localStorage nicht verfügbar */ }

  const dismiss = () => {
    overlay.hidden = true;
    try { localStorage.setItem("neuro-nexus-onboarded", "1"); } catch (e) {}
  };

  closeBtn.addEventListener("click", dismiss);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) dismiss(); });
}
