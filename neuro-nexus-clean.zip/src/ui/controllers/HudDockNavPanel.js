/**
 * HudDockNavPanel — Ausklappbares Nav-Panel im Bottom Dock
 *
 * Zeigt Tab-Schnellzugriff + Live-Statuswerte.
 * Extrahiert aus HudNavigationController.js.
 */

/**
 * Initialisiert das Dock Nav-Panel.
 * @param {Object} ctx — { switchTab, openDrawer }
 * @returns {{ open: function, close: function }}
 */
export function setupDockNavPanel(ctx) {
  const { switchTab, openDrawer } = ctx;

  const navBtn   = document.getElementById("dockNav");
  const navPanel = document.getElementById("dockNavPanel");
  const navClose = document.getElementById("dockNavClose");
  if (!navBtn || !navPanel) return;

  let isOpen = false;

  const open = () => {
    navPanel.removeAttribute("hidden");
    navBtn.classList.add("is-active");
    navBtn.setAttribute("aria-expanded", "true");
    isOpen = true;
  };

  const close = () => {
    navPanel.setAttribute("hidden", "");
    navBtn.classList.remove("is-active");
    navBtn.setAttribute("aria-expanded", "false");
    isOpen = false;
  };

  navBtn.addEventListener("click", () => { isOpen ? close() : open(); });
  navClose?.addEventListener("click", close);

  // Tab-Buttons im Nav-Panel
  navPanel.querySelectorAll(".dock-nav-tab[data-tab]").forEach(btn => {
    btn.addEventListener("click", () => {
      const tabId = btn.dataset.tab;
      openDrawer?.();
      switchTab?.(tabId);
      navPanel.querySelectorAll(".dock-nav-tab").forEach(b => {
        b.classList.toggle("dock-nav-tab--active", b === btn);
      });
      setTimeout(close, 180);
    });
  });

  // Klick außerhalb schließt Panel
  document.addEventListener("pointerdown", (e) => {
    if (!isOpen) return;
    if (!navPanel.contains(e.target) && !navBtn.contains(e.target)) close();
  }, { passive: true });

  return { open, close };
}
