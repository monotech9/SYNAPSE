/**
 * HudDrawer — Mobile Sidebar (Drawer)
 *
 * Verwaltet das Öffnen/Schließen der mobilen Sidebar
 * mit Widget-Resize bei Transitions.
 * Extrahiert aus HudNavigationController.js.
 */

/**
 * Initialisiert den Drawer.
 * @param {Object} ctx — { els, allWidgets }
 * @returns {{ open: function, close: function }}
 */
export function initDrawer(ctx) {
  const { els, allWidgets } = ctx;
  const sidebar = els.sidebar;
  if (!sidebar) return { open: () => {}, close: () => {} };

  const toggle  = els.drawerToggle || null;
  const label   = els.drawerLabel  || null;
  const dockHud = els.dockHud       || null;

  const resizeAllWidgets = () => {
    allWidgets.forEach(w => { if (w && typeof w.resize === "function") w.resize(); });
  };

  sidebar.addEventListener("transitionend", (ev) => {
    if (ev.propertyName !== "transform" && ev.propertyName !== "opacity") return;
    resizeAllWidgets();
  });

  const open = () => {
    sidebar.classList.add("is-open");
    toggle?.classList.add("is-open");
    toggle?.setAttribute("aria-expanded", "true");
    dockHud?.setAttribute("aria-expanded", "true");
    if (label) label.textContent = "Schließen";
    document.body.classList.add("drawer-open");
    requestAnimationFrame(() => resizeAllWidgets());
    setTimeout(() => resizeAllWidgets(), 150);
    setTimeout(() => resizeAllWidgets(), 420);
  };

  const close = () => {
    sidebar.classList.remove("is-open");
    toggle?.classList.remove("is-open");
    toggle?.setAttribute("aria-expanded", "false");
    dockHud?.setAttribute("aria-expanded", "false");
    if (label) label.textContent = "HUD";
    document.body.classList.remove("drawer-open");
  };

  if (toggle) {
    toggle.addEventListener("click", () => {
      sidebar.classList.contains("is-open") ? close() : open();
    });
  }

  document.addEventListener("pointerdown", (e) => {
    if (!sidebar.classList.contains("is-open")) return;
    const onSidebar = sidebar.contains(e.target);
    const onToggle  = toggle && toggle.contains(e.target);
    const onDockHud = dockHud && dockHud.contains(e.target);
    if (!onSidebar && !onToggle && !onDockHud) close();
  }, { passive: true });

  return { open, close };
}
