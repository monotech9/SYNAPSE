/**
 * HudMenu — Hauptmenü (Hamburger-Button)
 *
 * Initialisiert das Hauptmenü mit allen Buttons.
 * Extrahiert aus HudMenuController.js.
 */

/**
 * Initialisiert das Hauptmenü.
 * @param {Object} ctx — { sim, els, dataExchange, getLogWidget, unlockedEpochs, fireImpuls, onMenuOpen, onUpdateAchievements }
 * @returns {{ open: function, close: function, isOpen: function }}
 */
export function initMenu(ctx) {
  const { sim, els, dataExchange, getLogWidget, unlockedEpochs, fireImpuls } = ctx;
  const { menuBtn, menuClose, gameMenu } = els;
  if (!menuBtn || !gameMenu) return { open: () => {}, close: () => {}, isOpen: () => false };

  let menuOpen = false;

  const open = () => {
    menuOpen = true; gameMenu.hidden = false;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      gameMenu.classList.add("is-open"); menuBtn.classList.add("is-open");
      menuBtn.setAttribute("aria-expanded", "true");
    }));
    ctx.onMenuOpen?.();
  };

  const close = () => {
    menuOpen = false; gameMenu.classList.remove("is-open"); menuBtn.classList.remove("is-open");
    menuBtn.setAttribute("aria-expanded", "false");
    setTimeout(() => { gameMenu.hidden = true; }, 240);
  };

  menuBtn.addEventListener("click", (e) => { e.stopPropagation(); menuOpen ? close() : open(); });
  els.menuClose?.addEventListener("click", close);
  document.addEventListener("pointerdown", (e) => {
    if (!menuOpen) return;
    if (!gameMenu.contains(e.target) && !menuBtn.contains(e.target)) close();
  }, { passive: true });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && menuOpen) close(); });

  els.menuImpuls?.addEventListener("click", () => { close(); fireImpuls(els.triggerBtn); });
  els.menuNeuron?.addEventListener("click", () => {
    close();
    const ww = sim.world;
    sim.addManualNode(ww.width / 2, ww.height / 2);
    getLogWidget()?.addLog(`<span class="log-hl-neuron">NEURON:</span> Manuell gepflanzt.`, ww.age);
  });
  els.menuReset?.addEventListener("click", () => { close(); doReset(ctx); });
  els.menuNewGame?.addEventListener("click", () => { close(); doReset(ctx); });
  els.menuSaveGame?.addEventListener("click", () => { close(); dataExchange.saveSimulation(); });
  els.menuLoadGame?.addEventListener("click", () => { close(); dataExchange.loadSimulation(); });
  els.menuExportConnectome?.addEventListener("click", () => { close(); dataExchange.exportConnectome(); });

  return { open, close, isOpen: () => menuOpen };
}

/**
 * Führt einen Reset durch mit Bestätigungs-Dialog.
 */
export function doReset(ctx) {
  const { sim, dataExchange, getLogWidget, unlockedEpochs, onUpdateAchievements } = ctx;
  dataExchange.confirmReset(() => {
    sim.hardResetRuntime?.();
    getLogWidget()?.reset();
    getLogWidget()?.addLog(`<span class="log-hl-warn">RESET:</span> Netzwerk neu gestartet.`, sim.world.age);
    getLogWidget()?.addEpoch("Reset", "Netzwerk neu initialisiert", "milestone", sim.world.age);
    unlockedEpochs.clear();
    onUpdateAchievements?.();
    dataExchange.toast("Netzwerk zurückgesetzt", "success");
  });
}
