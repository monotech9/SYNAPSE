/**
 * HudSettings — Settings-Pane (Audio, Observer, Theme)
 *
 * Extrahiert aus HudMenuController.js.
 */

/**
 * Initialisiert die Settings-Pane.
 * @param {Object} ctx — { sim, els, observer, dataExchange }
 */
export function initSettings(ctx) {
  const { sim, els, observer, dataExchange } = ctx;

  // Audio toggle
  const audioChk = els.settingAudio;
  if (audioChk) {
    audioChk.addEventListener("change", () => {
      if (sim.audio && audioChk.checked !== sim.audio.enabled) sim.audio.toggle();
    });
  }

  // Observer mode toggle
  const obsChk = els.settingObserver;
  if (obsChk) {
    obsChk.checked = false;
    obsChk.addEventListener("change", () => {
      if (observer) { obsChk.checked ? observer.activate() : observer.deactivate(); }
      else document.body.classList.toggle("observer-active", obsChk.checked);
    });
  }

  // Theme selector
  const themeSel = els.settingTheme;
  if (themeSel) {
    const saved = localStorage.getItem("neuro_theme");
    if (saved) { themeSel.value = saved; document.documentElement.dataset.theme = saved; }
    else document.documentElement.dataset.theme = "deep-space";
    themeSel.addEventListener("change", () => {
      const theme = themeSel.value;
      document.documentElement.dataset.theme = theme;
      try { localStorage.setItem("neuro_theme", theme); } catch (_) {}
      dataExchange.toast(`Thema: ${themeSel.options[themeSel.selectedIndex].text}`, "success");
    });
  }
}
