/**
 * KeyboardController
 * 
 * Keyboard shortcuts and accessibility features.
 * Enables navigation and control via keyboard for power users and accessible workflows.
 * 
 * Features:
 * - Keyboard shortcuts (p=pause, s=save, ?=help, etc.)
 * - Focus management
 * - Keyboard navigation
 * - Accessible dialogs
 * - Focus trap in modals
 */

export class KeyboardController {
  constructor(simulation, hudPanel, eventBus) {
    this.simulation = simulation;
    this.hudPanel = hudPanel;
    this.eventBus = eventBus;

    this.shortcuts = new Map();
    this.isModalOpen = false;
    this.focusStack = []; // For focus restoration
    this.modalElements = [];

    this._registerDefaultShortcuts();
    this._attachEventListeners();
  }

  /**
   * Register all default keyboard shortcuts
   */
  _registerDefaultShortcuts() {
    // Playback Control
    this.register('Space', () => this._togglePlayPause(), {
      description: 'Play/Pause simulation',
      category: 'Playback',
    });

    this.register('p', () => this._togglePlayPause(), {
      description: 'Play/Pause simulation',
      category: 'Playback',
    });

    this.register('r', () => this._resetSimulation(), {
      description: 'Reset simulation',
      category: 'Playback',
      confirm: true,
    });

    // Data Operations
    this.register('s', () => this._saveGame(), {
      description: 'Save simulation state',
      category: 'Data',
    });

    this.register('l', () => this._loadGame(), {
      description: 'Load last saved state',
      category: 'Data',
    });

    this.register('e', () => this._exportData(), {
      description: 'Export connectome as JSON',
      category: 'Data',
    });

    // UI Navigation
    this.register('Tab', (e) => this._handleTabNavigation(e), {
      description: 'Navigate between panels',
      category: 'Navigation',
    });

    this.register('Escape', () => this._closeModal(), {
      description: 'Close dialogs/menus',
      category: 'Navigation',
    });

    // Help & Documentation
    this.register('?', () => this._toggleHelp(), {
      description: 'Show keyboard shortcuts',
      category: 'Help',
    });

    this.register('/', () => this._toggleHelp(), {
      description: 'Show keyboard shortcuts',
      category: 'Help',
    });

    // Simulation Control
    this.register('i', () => this._sendImpulse(), {
      description: 'Send impulse to network',
      category: 'Simulation',
    });

    this.register('n', () => this._addNeuron(), {
      description: 'Add neuron to network',
      category: 'Simulation',
    });

    // View Control
    this.register('1', () => this._switchTab('kognition'), {
      description: 'Switch to NOVA tab',
      category: 'View',
    });

    this.register('2', () => this._switchTab('monitor'), {
      description: 'Switch to Sensors tab',
      category: 'View',
    });

    this.register('3', () => this._switchTab('system'), {
      description: 'Switch to System tab',
      category: 'View',
    });

    // Debug/Admin
    this.register('d', () => this._toggleDebugMode(), {
      description: 'Toggle debug mode',
      category: 'Debug',
    });

    this.register('v', () => this._togglePerformanceMonitor(), {
      description: 'Toggle performance monitor',
      category: 'Debug',
    });

    this.register('m', () => this._toggleMenu(), {
      description: 'Toggle main menu',
      category: 'Navigation',
    });

    // Accessibility
    this.register('Shift+Alt+L', () => this._toggleLogging(), {
      description: 'Toggle accessibility logging',
      category: 'Accessibility',
    });
  }

  /**
   * Register a keyboard shortcut
   */
  register(key, handler, options = {}) {
    this.shortcuts.set(key.toLowerCase(), {
      key,
      handler,
      description: options.description || '',
      category: options.category || 'Other',
      confirm: options.confirm || false,
      ctrlKey: options.ctrlKey ?? key.includes('Ctrl'),
      shiftKey: options.shiftKey ?? key.includes('Shift'),
      altKey: options.altKey ?? key.includes('Alt'),
    });
  }

  /**
   * Attach main event listeners
   */
  _attachEventListeners() {
    document.addEventListener('keydown', (e) => this._handleKeyDown(e));
    document.addEventListener('keyup', (e) => this._handleKeyUp(e));
    document.addEventListener('focus', (e) => this._handleFocus(e), true);
  }

  /**
   * Handle keydown events
   */
  _handleKeyDown(event) {
    // Don't intercept if user is typing in input
    if (this._isInInputField(event.target)) {
      return;
    }

    const key = this._getKeyString(event);
    const shortcut = this.shortcuts.get(key);

    if (shortcut) {
      event.preventDefault();
      event.stopPropagation();

      if (shortcut.confirm) {
        const confirmed = confirm(`${shortcut.description}. Are you sure?`);
        if (!confirmed) return;
      }

      try {
        shortcut.handler(event);
        this._announceAction(shortcut.description);
      } catch (error) {
        console.error(`Error executing shortcut ${key}:`, error);
        this._announceError(`Error: ${shortcut.description}`);
      }
    }
  }

  /**
   * Get normalized key string
   */
  _getKeyString(event) {
    let keyStr = event.key.toLowerCase();

    // Handle special keys
    if (event.code === 'Space') keyStr = 'space';
    if (event.code === 'Tab') keyStr = 'tab';
    if (event.code === 'Escape') keyStr = 'escape';
    if (event.code === 'Enter') keyStr = 'enter';

    // Add modifier prefix
    const mods = [];
    if (event.ctrlKey || event.metaKey) mods.push('ctrl');
    if (event.shiftKey) mods.push('shift');
    if (event.altKey) mods.push('alt');

    return mods.length > 0 ? `${mods.join('+')}+${keyStr}` : keyStr;
  }

  /**
   * Check if user is typing in an input field
   */
  _isInInputField(element) {
    const tagName = element.tagName?.toLowerCase();
    const contentEditable = element.getAttribute?.('contenteditable');

    return (
      tagName === 'input' ||
      tagName === 'textarea' ||
      tagName === 'select' ||
      contentEditable === 'true'
    );
  }

  /**
   * ════ SHORTCUT HANDLERS ════
   */

  _togglePlayPause() {
    if (this.simulation.paused) {
      this.simulation.resume();
    } else {
      this.simulation.pause();
    }
    const state = this.simulation.paused ? 'PAUSED' : 'PLAYING';
    this._announceAction(`Simulation ${state}`);
  }

  _resetSimulation() {
    if (confirm('Reset simulation? All progress will be lost.')) {
      this.simulation.reset();
      this._announceAction('Simulation reset');
    }
  }

  _sendImpulse() {
    this.eventBus?.emit('simulation:impulse');
    this._announceAction('Impulse sent');
  }

  _addNeuron() {
    this.eventBus?.emit('simulation:add-neuron');
    this._announceAction('Neuron added');
  }

  _saveGame() {
    this.simulation.saveToLocalStorage();
    this._announceAction('Game saved');
  }

  _loadGame() {
    if (confirm('Load last saved state? Current progress will be lost.')) {
      this.simulation.loadFromLocalStorage();
      this._announceAction('Game loaded');
    }
  }

  _exportData() {
    this.eventBus?.emit('ui:export-connectome');
    this._announceAction('Connectome exported');
  }

  _toggleHelp() {
    this._showHelpDialog();
  }

  _toggleMenu() {
    const menuBtn = document.getElementById('menuBtn');
    if (menuBtn) {
      menuBtn.click();
    }
  }

  _toggleDebugMode() {
    const isDebug = localStorage.getItem('neuro-nexus.debug') === 'true';
    localStorage.setItem('neuro-nexus.debug', String(!isDebug));
    this._announceAction(`Debug mode ${!isDebug ? 'enabled' : 'disabled'}`);
    window.location.reload();
  }

  _togglePerformanceMonitor() {
    const pm = document.getElementById('performanceMonitor');
    if (pm) {
      pm.classList.toggle('hidden');
      this._announceAction(
        `Performance monitor ${pm.classList.contains('hidden') ? 'hidden' : 'visible'}`
      );
    }
  }

  _switchTab(tabName) {
    const tabBtn = document.querySelector(`[data-tab="${tabName}"]`);
    if (tabBtn) {
      tabBtn.click();
      this._announceAction(`Switched to ${tabName} tab`);
    }
  }

  _toggleLogging() {
    const loggingEnabled = localStorage.getItem('neuro-nexus.a11y-logging') === 'true';
    localStorage.setItem('neuro-nexus.a11y-logging', String(!loggingEnabled));
    this._announceAction(`Accessibility logging ${!loggingEnabled ? 'enabled' : 'disabled'}`);
  }

  _handleTabNavigation(event) {
    if (!this.isModalOpen) return;

    // Focus trap within modal
    event.preventDefault();

    const focusableElements = Array.from(
      this.modalElements[this.modalElements.length - 1]?.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      ) || []
    );

    if (focusableElements.length === 0) return;

    const currentIndex = focusableElements.indexOf(document.activeElement);
    let nextIndex = event.shiftKey ? currentIndex - 1 : currentIndex + 1;

    if (nextIndex >= focusableElements.length) nextIndex = 0;
    if (nextIndex < 0) nextIndex = focusableElements.length - 1;

    focusableElements[nextIndex]?.focus();
  }

  _closeModal() {
    if (this.isModalOpen && this.modalElements.length > 0) {
      const modal = this.modalElements.pop();
      modal.hidden = true;
      this.isModalOpen = this.modalElements.length > 0;

      // Restore focus
      if (this.focusStack.length > 0) {
        const prevFocus = this.focusStack.pop();
        prevFocus?.focus();
      }
    }
  }

  _handleKeyUp(event) {
    // Placeholder for key release handling
  }

  _handleFocus(event) {
    // Announce focus changes for accessibility
    const element = event.target;
    if (
      element &&
      element !== document.body &&
      element !== document.documentElement
    ) {
      const label =
        element.getAttribute('aria-label') ||
        element.textContent?.substring(0, 20) ||
        'Element';

      this._announceAction(`Focused: ${label}`);
    }
  }

  /**
   * Show help dialog with all shortcuts
   */
  _showHelpDialog() {
    const groupedShortcuts = new Map();

    // Group by category
    for (const [key, shortcut] of this.shortcuts) {
      if (!groupedShortcuts.has(shortcut.category)) {
        groupedShortcuts.set(shortcut.category, []);
      }
      groupedShortcuts.get(shortcut.category).push({ key, ...shortcut });
    }

    // Build HTML
    let html = `
      <div class="keyboard-help-dialog glass-panel">
        <div class="keyboard-help-header">
          <h2>⌨️ Keyboard Shortcuts</h2>
          <button class="keyboard-help-close" aria-label="Close">✕</button>
        </div>
        <div class="keyboard-help-content">
    `;

    for (const [category, shortcuts] of groupedShortcuts) {
      html += `<div class="keyboard-help-group">
        <h3 class="keyboard-help-group-title">${category}</h3>
        <div class="keyboard-help-list">`;

      for (const shortcut of shortcuts) {
        html += `
          <div class="keyboard-help-item">
            <kbd class="keyboard-help-key">${shortcut.key}</kbd>
            <span class="keyboard-help-description">${shortcut.description}</span>
          </div>
        `;
      }

      html += `</div></div>`;
    }

    html += `
        </div>
      </div>
    `;

    // Create modal
    const modal = document.createElement('div');
    modal.className = 'keyboard-help-modal';
    modal.innerHTML = html;
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Keyboard shortcuts');
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector('.keyboard-help-close');
    const backdrop = modal;

    const close = () => {
      modal.remove();
      this.isModalOpen = false;
      this.modalElements.pop();
      if (this.focusStack.length > 0) {
        this.focusStack.pop()?.focus();
      }
    };

    closeBtn?.addEventListener('click', close);
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) close();
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') close();
    });

    this.isModalOpen = true;
    this.modalElements.push(modal);
    this.focusStack.push(document.activeElement);

    closeBtn?.focus();
    this._announceAction('Keyboard shortcuts dialog opened');
  }

  /**
   * Announce action to screen readers
   */
  _announceAction(message) {
    const liveRegion = document.getElementById('a11yStatus');
    if (liveRegion) {
      liveRegion.textContent = message;
      liveRegion.setAttribute('role', 'status');
      liveRegion.setAttribute('aria-live', 'polite');
    }
  }

  /**
   * Announce error to screen readers
   */
  _announceError(message) {
    const liveRegion = document.getElementById('a11yStatus');
    if (liveRegion) {
      liveRegion.textContent = `Error: ${message}`;
      liveRegion.setAttribute('role', 'alert');
      liveRegion.setAttribute('aria-live', 'assertive');
    }
  }

  /**
   * Get all registered shortcuts
   */
  getShortcuts() {
    return Array.from(this.shortcuts.values());
  }

  /**
   * Export shortcuts as JSON
   */
  exportShortcuts() {
    return JSON.stringify(
      Array.from(this.shortcuts.entries()).map(([key, shortcut]) => ({
        key,
        description: shortcut.description,
        category: shortcut.category,
      })),
      null,
      2
    );
  }
}

/**
 * CSS Styles for keyboard help dialog
 * (Should be in hud.css, included here for reference)
 */
export const KEYBOARD_HELP_STYLES = `
.keyboard-help-modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  animation: fadeIn 0.2s ease;
}

.keyboard-help-dialog {
  max-width: 600px;
  max-height: 80vh;
  overflow-y: auto;
  border-radius: 8px;
  padding: 24px;
}

.keyboard-help-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  border-bottom: 1px solid rgba(80, 180, 255, 0.2);
  padding-bottom: 12px;
}

.keyboard-help-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.keyboard-help-close {
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  font-size: 18px;
  cursor: pointer;
  padding: 4px 8px;
}

.keyboard-help-close:hover {
  color: rgba(80, 180, 255, 0.8);
}

.keyboard-help-group {
  margin-bottom: 20px;
}

.keyboard-help-group-title {
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  color: rgba(80, 180, 255, 0.7);
  letter-spacing: 1px;
  margin: 0 0 12px 0;
}

.keyboard-help-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.keyboard-help-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px;
  border-radius: 4px;
  background: rgba(80, 180, 255, 0.05);
}

.keyboard-help-key {
  background: rgba(80, 180, 255, 0.1);
  border: 1px solid rgba(80, 180, 255, 0.3);
  border-radius: 4px;
  padding: 4px 8px;
  font-size: 11px;
  font-weight: 600;
  color: rgba(80, 180, 255, 0.8);
  font-family: 'Courier New', monospace;
  min-width: 60px;
  text-align: center;
}

.keyboard-help-description {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.7);
  flex: 1;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
`;
