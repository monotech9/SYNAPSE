/**
 * HudPanel v14 — Pure Orchestrator (modularisiert)
 *
 * HudPanel ist nur noch der Orchestrator: er verkabelt die Module
 * und hält sie zusammen, ohne selbst Implementierungsdetails zu enthalten.
 *
 * v14-Änderung: Alle Controller und Updater sind jetzt in eigenen
 * Unterverzeichnissen (controllers/, updaters/, constants/).
 * Der Frame-Loop verwendet eine Updater-Registry statt direkter Aufrufe.
 *
 * Modulstruktur:
 *  src/ui/
 *    constants/     — Farb-Mappings, Labels, Templates (je Domain eine Datei)
 *    updaters/      — DOM-Updater (je HUD-Element eine Datei) + Registry
 *    controllers/   — UI-Controller (je Concern eine Datei)
 *    HudDomMap.js   — DOM-Element-Query
 *    HudWidgetManager.js — Widget-Initialisierung & Lifecycle
 *    HudFrameLoop.js — Render-Loop (verwendet Updater-Registry)
 *    TooltipSystem.js — Fachbegriff-Tooltips
 *    DataExchange.js — Save/Load/Export/Import + Toast
 *    ObserverMode.js — Beobachtungsmodus
 *    ResonanceLabel.js — Schwebendes Cluster-Label
 *    hudUtils.js    — Gemeinsame DOM-Helper
 */

import { queryEls } from "./HudDomMap.js";
import { initWidgets } from "./HudWidgetManager.js";
import { createFrameLoop } from "./HudFrameLoop.js";
import { connectSelfModel } from "./HudSelfModel.js";
import { createEventDetector } from "./HudEventDetector.js";
import { TooltipSystem } from "./TooltipSystem.js";
import { DataExchange }  from "./DataExchange.js";

// Controllers — jedes Concern in eigener Datei
import { initMenu }     from "./controllers/HudMenu.js";
import { initSettings } from "./controllers/HudSettings.js";
import { initDrawer }        from "./controllers/HudDrawer.js";
import { setupTabSystem }    from "./controllers/HudTabSystem.js";
import { setupBottomDock }   from "./controllers/HudBottomDock.js";
import { setupDockNavPanel } from "./controllers/HudDockNavPanel.js";
import { initTrigger }        from "./controllers/HudTrigger.js";
import { initSleepIndicator } from "./controllers/HudSleepIndicator.js";
import { initOnboarding }     from "./controllers/HudOnboarding.js";

export class HudPanel {
  constructor(simulation, telemetry, observer) {
    this.sim = simulation;
    this.telemetry = telemetry;
    this.observer = observer;
    this._ready = false;

    // Event-Tracking State
    this._prev = { nodeCount: 0, edgeCount: 0, bridgeCount: 0, growthStage: "", pulseCount: 0, memFlash: 0 };
    this._unlockedEpochs = new Set();

    // Drawer stubs
    this._openDrawer  = () => {};
    this._closeDrawer = () => {};

    // DOM + Subsysteme
    this._els = queryEls();
    this._tooltipSystem = new TooltipSystem();
    this._dataExchange = new DataExchange(simulation, null);
  }

  // ─── START ────────────────────────────────────────────────────────

  start() {
    // Widgets erstellen
    const wm = initWidgets({
      sim: this.sim,
      els: this._els,
      dataExchange: this._dataExchange,
    });
    this._wm = wm;
    this._widgets = wm.widgets;
    this._allWidgets = wm.allWidgets;

    // SelfModel-Events verbinden
    this._selfModel = connectSelfModel({
      sim: this.sim,
      getLogWidget: () => wm.logWidget,
    });

    // Event-Detektor erstellen
    this._detectEvents = createEventDetector({
      sim: this.sim,
      els: this._els,
      getLogWidget: () => wm.logWidget,
      getOscWidget: () => wm.oscWidget,
      getAlertWidget: () => wm.alertWidget,
      prev: this._prev,
      unlockedEpochs: this._unlockedEpochs,
    });

    // Frame-Loop erstellen (gibt { onFrame, destroy } zurück)
    const fl = createFrameLoop({
      sim: this.sim,
      telemetry: this.telemetry,
      els: this._els,
      widgets: wm.widgets,
      detectEvents: () => this._detectEvents(),
      isMenuOpen: () => this._menuController?.isOpen() ?? false,
      unlockedEpochs: this._unlockedEpochs,
    });
    this.onFrame = fl.onFrame;
    this._frameLoopDestroy = fl.destroy;

    // Subsysteme initialisieren
    this._tooltipSystem.init();
    initOnboarding();
    initSleepIndicator({ sim: this.sim, getLogWidget: () => wm.logWidget });

    this._fireImpuls = initTrigger({
      sim: this.sim,
      els: this._els,
      getOscWidget: () => wm.oscWidget,
      getLogWidget: () => wm.logWidget,
    });

    this._menuController = initMenu({
      sim: this.sim,
      els: this._els,
      dataExchange: this._dataExchange,
      getLogWidget: () => wm.logWidget,
      unlockedEpochs: this._unlockedEpochs,
      fireImpuls: (btn) => this._fireImpuls?.(btn),
      onMenuOpen: () => {
        // Menu-Stats werden über den MenuStatsUpdater im Frame-Loop aktualisiert
      },
      onUpdateAchievements: () => {
        const container = this._els.epochAchievements;
        if (!container) return;
        container.querySelectorAll(".epoch-ach-item").forEach(item => {
          if (this._unlockedEpochs.has(item.dataset.stage)) item.classList.add("is-unlocked");
        });
      },
    });

    initSettings({
      sim: this.sim,
      els: this._els,
      observer: this.observer,
      dataExchange: this._dataExchange,
    });

    const { open, close } = initDrawer({
      els: this._els,
      allWidgets: this._allWidgets,
    });
    this._openDrawer  = open;
    this._closeDrawer = close;

    this._tabController = setupTabSystem({
      els: this._els,
      allWidgets: this._allWidgets,
      radarWidget: wm.radarWidget,
      phaseWidget: wm.phaseWidget,
    });

    setupDockNavPanel({
      switchTab: (tabId) => this._tabController?.switchTab(tabId),
      openDrawer: () => open(),
    });

    setupBottomDock({
      sim: this.sim,
      els: this._els,
      openDrawer: () => this._openDrawer?.(),
      closeDrawer: () => this._closeDrawer?.(),
      fireImpuls: (btn) => this._fireImpuls?.(btn),
      observer: this.observer,
      getLogWidget: () => wm.logWidget,
    });

    this._ready = true;
  }

  // ─── DESTROY ──────────────────────────────────────────────────────

  destroy() {
    this._frameLoopDestroy?.();
    this._wm?.destroy();
    this._selfModel?.off();
  }
}
