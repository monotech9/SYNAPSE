/**
 * ObserverMode — reine Beobachtung ohne Ablenkung.
 *
 *  - Auto-Aktivierung nach 30s Inaktivität (nur wenn nicht via Menu deaktiviert)
 *  - Versteckt: HUD, Telemetrie, Signature, Cursor
 *  - Jede Interaktion bringt UI für 5s zurück
 *  - Toggle läuft über das Game Menu (kein separater Eye-Button mehr)
 */
export class ObserverMode {
  constructor(options = {}) {
    this.autoActivateDelay = options.autoActivateDelay || 30;
    this.uiGracePeriod    = options.uiGracePeriod || 5;
    this.enabled          = options.enabled !== false;

    this.isActive         = false;
    this._inactivityTimer = 0;
    this._uiGraceTimer    = 0;
    this._cursorHidden    = false;

    this.onActivate   = options.onActivate   || (() => {});
    this.onDeactivate = options.onDeactivate || (() => {});

    this._setupEventListeners();
  }

  _setupEventListeners() {
    if (typeof document === "undefined") return;
    const onActivity = () => this._onUserActivity();
    document.addEventListener("pointermove", onActivity, { passive: true });
    document.addEventListener("pointerdown", onActivity, { passive: true });
    document.addEventListener("keydown",     onActivity, { passive: true });
    document.addEventListener("wheel",       onActivity, { passive: true });
  }

  update(dtSeconds) {
    if (!this.enabled) return;
    this._inactivityTimer += dtSeconds;
    if (!this.isActive && this._inactivityTimer >= this.autoActivateDelay) {
      this.activate();
    }
    if (this._uiGraceTimer > 0) {
      this._uiGraceTimer -= dtSeconds;
      if (this._uiGraceTimer <= 0 && this.isActive) this._hideUI();
    }
  }

  _onUserActivity() {
    this._inactivityTimer = 0;
    if (this.isActive) {
      this._uiGraceTimer = this.uiGracePeriod;
      this._showUI();
    }
  }

  activate() {
    if (this.isActive) return;
    this.isActive = true;
    document.body.classList.add("observer-active");
    this._hideUI();
    this.onActivate();
  }

  deactivate() {
    if (!this.isActive) return;
    this.isActive = false;
    document.body.classList.remove("observer-active");
    this._showUI();
    this._inactivityTimer = 0;
    this.onDeactivate();
  }

  toggle() {
    this.isActive ? this.deactivate() : this.activate();
  }

  _hideUI() {
    if (typeof document === "undefined") return;

    // Bottom Dock verstecken
    const dock = document.getElementById("bottomDock");
    if (dock) { dock.classList.add("is-hidden"); dock.classList.remove("dock-visible"); }

    // Signature unten links
    const sig = document.getElementById("signature");
    if (sig) { sig.style.opacity = "0"; }

    // Telemetrie
    const tel = document.querySelector(".telemetry");
    if (tel) { tel.style.opacity = "0"; }

    // Cursor auf Canvas
    const canvas = document.getElementById("neuroCanvas");
    if (canvas) { canvas.style.cursor = "none"; this._cursorHidden = true; }
  }

  _showUI() {
    // Bottom Dock wieder zeigen
    const dock = document.getElementById("bottomDock");
    if (dock) { dock.classList.remove("is-hidden"); dock.classList.add("dock-visible"); }
    if (typeof document === "undefined") return;

    const sig = document.getElementById("signature");
    if (sig) { sig.style.opacity = ""; }

    const tel = document.querySelector(".telemetry");
    if (tel) { tel.style.opacity = ""; }

    if (this._cursorHidden) {
      const canvas = document.getElementById("neuroCanvas");
      if (canvas) canvas.style.cursor = "";
      this._cursorHidden = false;
    }
  }
}
