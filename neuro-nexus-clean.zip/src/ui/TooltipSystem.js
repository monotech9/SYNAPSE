/**
 * TooltipSystem — Fachbegriff-Tooltips für das HUD
 *
 * Zeigt Erklärungen bei Hover/Tap auf Labels mit data-tip Attribut.
 * Ausgelagert aus HudPanel.js.
 */

import { TOOLTIP_DATA } from "./hudConstants.js";

export class TooltipSystem {
  constructor() {
    this._tooltip = null;
    this._tooltipTimeout = null;
    this._tooltipData = TOOLTIP_DATA;
  }

  init() {
    this._tooltip = document.getElementById("infoTooltip");
    if (!this._tooltip) return;

    this._attachEvents();
    this._attachLabelData();
  }

  _attachEvents() {
    const showTip = (e) => {
      const el = e.target.closest("[data-tip]");
      if (!el) return;
      const key = el.getAttribute("data-tip");
      const data = this._tooltipData[key];
      if (!data) return;

      clearTimeout(this._tooltipTimeout);
      this._tooltip.innerHTML =
        `<div class="info-tooltip__title">${data.title}</div>` +
        `<div class="info-tooltip__body">${data.body}</div>`;
      this._tooltip.hidden = false;

      const rect = el.getBoundingClientRect();
      this._tooltip.style.left = `${rect.left + rect.width / 2}px`;
      this._tooltip.style.top = `${rect.top}px`;
    };

    const hideTip = () => {
      this._tooltipTimeout = setTimeout(() => {
        if (this._tooltip) this._tooltip.hidden = true;
      }, 200);
    };

    document.addEventListener("mouseover", showTip);
    document.addEventListener("mouseout", hideTip);
    document.addEventListener("touchstart", showTip, { passive: true });
    document.addEventListener("touchend", hideTip, { passive: true });
  }

  _attachLabelData() {
    const allLabels = document.querySelectorAll(
      ".stat-label, .vital-label, .widget-label, .hud-stat__label"
    );
    allLabels.forEach(el => {
      const text = el.textContent?.trim() || "";
      for (const [key] of Object.entries(this._tooltipData)) {
        if (text.includes(key) || text.toLowerCase().includes(key.toLowerCase())) {
          if (!el.getAttribute("data-tip")) {
            el.setAttribute("data-tip", key);
            el.style.cursor = "help";
          }
        }
      }
    });
  }
}
