/**
 * ConsciousnessHUD — Thin Facade (rückwärtskompatibel)
 *
 * Alle Bewusstseins-Updater sind jetzt in src/ui/updaters/ als
 * einzelne Module extrahiert. Diese Datei dient nur noch als
 * Kompatibilitäts-Fassade für bestehenden Code, der
 * ConsciousnessHUD.updateConsciousness() / .updateEmotion() aufruft.
 *
 * Für neuen Code: importiere die einzelnen Updater direkt.
 */

import { EmotionUpdater }           from "./updaters/emotion/EmotionUpdater.js";
import { ConsciousnessStateUpdater } from "./updaters/consciousness/ConsciousnessStateUpdater.js";
import { PredictionErrorUpdater }   from "./updaters/consciousness/PredictionErrorUpdater.js";
import { SelfAwarenessUpdater }     from "./updaters/consciousness/SelfAwarenessUpdater.js";
import { DriveUpdater }             from "./updaters/consciousness/DriveUpdater.js";
import { FreeEnergyUpdater }        from "./updaters/consciousness/FreeEnergyUpdater.js";
import { PhiUpdater }               from "./updaters/consciousness/PhiUpdater.js";
import { EnergyModelUpdater }       from "./updaters/vitals/EnergyModelUpdater.js";
import { DopamineUpdater }          from "./updaters/consciousness/DopamineUpdater.js";
import { CohesionUpdater }          from "./updaters/consciousness/CohesionUpdater.js";
import { DnaArchetypeUpdater }      from "./updaters/emotion/DnaArchetypeUpdater.js";
import { EchoMemoryUpdater }        from "./updaters/memory/EchoMemoryUpdater.js";
import { ActionStatsUpdater }       from "./updaters/consciousness/ActionStatsUpdater.js";
import { IgnitionFlashUpdater }     from "./updaters/consciousness/IgnitionFlashUpdater.js";

// Singleton-Instanzen für Fassaden-Aufrufe
const _emotionUpdater     = new EmotionUpdater();
const _stateUpdater       = new ConsciousnessStateUpdater();
const _predErrorUpdater   = new PredictionErrorUpdater();
const _selfAwareUpdater   = new SelfAwarenessUpdater();
const _driveUpdater       = new DriveUpdater();
const _freeEnergyUpdater  = new FreeEnergyUpdater();
const _phiUpdater         = new PhiUpdater();
const _energyUpdater      = new EnergyModelUpdater();
const _dopamineUpdater    = new DopamineUpdater();
const _cohesionUpdater    = new CohesionUpdater();
const _dnaUpdater         = new DnaArchetypeUpdater();
const _echoUpdater        = new EchoMemoryUpdater();
const _actionUpdater      = new ActionStatsUpdater();
const _ignitionUpdater    = new IgnitionFlashUpdater();

// Bewusstseins-Updater (alle außer Emotion)
const _consciousnessUpdaters = [
  _stateUpdater, _predErrorUpdater, _selfAwareUpdater,
  _driveUpdater, _freeEnergyUpdater, _phiUpdater,
  _energyUpdater, _dopamineUpdater, _cohesionUpdater,
  _dnaUpdater, _echoUpdater, _actionUpdater, _ignitionUpdater,
];

export class ConsciousnessHUD {
  /**
   * Aktualisiert die Emotions-Anzeige im HUD.
   * @deprecated — verwende EmotionUpdater direkt
   */
  static updateEmotion(engine, els) {
    _emotionUpdater._doUpdate({ emotionEngine: engine, els });
  }

  /**
   * Aktualisiert alle Bewusstseins-Metriken im HUD.
   * @deprecated — verwende die einzelnen Updater direkt oder die Registry
   */
  static updateConsciousness(consciousness, oscWidget) {
    if (!consciousness) return;
    const snap = consciousness.getSnapshot();
    const sim = consciousness.sim;
    const ctx = { sim, snap, widgets: { oscWidget } };
    for (const u of _consciousnessUpdaters) {
      u._doUpdate(ctx);
    }
  }
}
