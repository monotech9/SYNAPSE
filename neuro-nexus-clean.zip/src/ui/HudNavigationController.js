/**
 * HudNavigationController — Thin Facade (rückwärtskompatibel)
 *
 * Drawer, Tab-System, Bottom Dock und Dock Nav-Panel sind jetzt
 * in src/ui/controllers/ als einzelne Module extrahiert.
 */

import { initDrawer }        from "./controllers/HudDrawer.js";
import { setupTabSystem }    from "./controllers/HudTabSystem.js";
import { setupBottomDock }   from "./controllers/HudBottomDock.js";
import { setupDockNavPanel } from "./controllers/HudDockNavPanel.js";

// Re-export mit den alten Funktionsnamen für Abwärtskompatibilität
export { initDrawer, setupTabSystem, setupBottomDock, setupDockNavPanel };

/**
 * Aktualisiert die Live-Status-Werte im Nav-Panel.
 * @deprecated — verwende NavPanelUpdater aus updaters/
 */
export function updateNavPanelStatus({ stage, archetype, mood, energy }) {
  const navStage     = document.getElementById("navStage");
  const navArchetype = document.getElementById("navArchetype");
  const navMood      = document.getElementById("navMood");
  const navEnergy    = document.getElementById("navEnergy");

  if (navStage && stage)     { navStage.textContent = stage; }
  if (navArchetype && archetype) {
    navArchetype.textContent = archetype;
    navArchetype.style.color = "#a78bfa";
  }
  if (navMood && mood) { navMood.textContent = mood; }
  if (navEnergy && energy !== null && energy !== undefined) {
    const pct = (energy * 100).toFixed(0) + "%";
    navEnergy.textContent = pct;
    navEnergy.style.color = energy < 0.2 ? "#ef4444" : energy < 0.4 ? "#fbbf24" : "#34d399";
  }
}
