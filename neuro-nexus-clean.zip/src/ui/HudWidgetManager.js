/**
 * HudWidgetManager — Widget-Initialisierung und Lifecycle
 *
 * Erstellt alle Widget-Instanzen, verwaltet Visibility-PAUSE/RESUME
 * und Drawer-Visibility für mobile.
 *
 * Wird von HudPanel verwendet; nicht direkt instanziiert.
 */

import { OscilloscopeWidget } from "../widgets/OscilloscopeWidget.js";
import { VitalityWidget }      from "../widgets/VitalityWidget.js";
import { FmriWidget }          from "../widgets/FmriWidget.js";
import { MemoryRingsWidget }   from "../widgets/MemoryRingsWidget.js";
import { EpochLogWidget }      from "../widgets/EpochLogWidget.js";
import { EmotionWidget }       from "../widgets/EmotionWidget.js";
import { RadarWidget }         from "../widgets/RadarWidget.js";
import { PhaseSpaceWidget }    from "../widgets/PhaseSpaceWidget.js";
import { GaugeWidget }         from "../widgets/GaugeWidget.js";
import { HeatmapWidget }       from "../widgets/HeatmapWidget.js";
import { PhaseArcWidget }      from "../widgets/PhaseArcWidget.js";
import { ConnectionWidget }    from "../widgets/ConnectionWidget.js";
import { AlertWidget }         from "../widgets/AlertWidget.js";

/**
 * Erstellt alle Widgets und initialisiert Lifecycle-Handler.
 * @param {Object} ctx — { sim, els, dataExchange }
 * @returns {Object} — { widgets: {...}, allWidgets: [], logWidget, oscWidget, destroy }
 */
export function initWidgets(ctx) {
  const { sim, els, dataExchange } = ctx;

  // ─── Widgets erstellen ────────────────────────────────────────────

  const oscWidget   = new OscilloscopeWidget(els.eegCanvas);
  const vitalWidget = new VitalityWidget(els.vitalCanvas);

  vitalWidget.onBoost = () => {
    const active = sim.world.clusters.filter(c => c.state !== "dormant");
    if (active.length) {
      const cl = active[Math.floor(Math.random() * active.length)];
      const ct = cl.center(sim.world.currentTime);
      sim.injectSignal(
        sim.world.centerX + ct.x * sim.camera.scale + sim.camera.offsetX,
        sim.world.centerY + ct.y * sim.camera.scale + sim.camera.offsetY
      );
    }
  };

  const fmriWidget   = new FmriWidget(els.fmriGrid);
  const ringsWidget  = new MemoryRingsWidget(els.memoryRingsSvg);
  const logWidget    = new EpochLogWidget(els.logFeed, els.epochLog);
  dataExchange._logWidget = logWidget;
  const radarWidget  = new RadarWidget(els.radarCanvas);
  const phaseWidget  = new PhaseSpaceWidget(els.phaseCanvas);
  const emotionWidget = new EmotionWidget(els.emotionCanvas);

  // ── Standalone-HUD Widgets (merged) ────────────────────────────────

  const gaugeWidget = new GaugeWidget(
    {
      cpu: els.gaugeCanvasCpu,
      mem: els.gaugeCanvasMem,
      net: els.gaugeCanvasNet,
    },
    {
      cpu: els.gaugeLblCpu,
      mem: els.gaugeLblMem,
      net: els.gaugeLblNet,
    }
  );

  const heatmapWidget    = new HeatmapWidget(els.activityHeatmap);
  const phaseArcWidget   = new PhaseArcWidget(els.phaseArcCanvas, els.phaseArcPct);
  const connectionWidget = new ConnectionWidget(els.connectionBody);
  const alertWidget      = new AlertWidget(els.alertFeed, els.alertBadge);

  const allWidgets = [
    oscWidget, vitalWidget, fmriWidget,
    ringsWidget, logWidget, radarWidget,
    phaseWidget, emotionWidget,
    gaugeWidget, heatmapWidget,
    phaseArcWidget, connectionWidget, alertWidget,
  ];

  // ─── Visibility API: pausiere alle Widgets wenn Tab im Hintergrund ──

  const onVisibilityChange = () => {
    if (document.hidden) allWidgets.forEach(w => w?.pause?.());
    else allWidgets.forEach(w => w?.resume?.());
  };
  document.addEventListener("visibilitychange", onVisibilityChange);

  // ─── Drawer-Visibility für mobile ─────────────────────────────────

  let drawerObserver = null;

  const checkDrawerVisibility = () => {
    const sidebar = els.sidebar;
    if (!sidebar) return;
    const isDesktop = window.matchMedia("(min-width: 861px)").matches;
    if (isDesktop) return;
    const isOpen = sidebar.classList.contains("is-open");
    if (!isOpen) {
      radarWidget?.pause();
      phaseWidget?.pause();
    } else {
      radarWidget?.resume();
      phaseWidget?.resume();
    }
  };

  if (els.sidebar && typeof MutationObserver !== "undefined") {
    drawerObserver = new MutationObserver(() => checkDrawerVisibility());
    drawerObserver.observe(els.sidebar, { attributes: true, attributeFilter: ["class"] });
  }

  // ─── Destroy ──────────────────────────────────────────────────────

  function destroy() {
    allWidgets.forEach(w => w?.destroy());
    document.removeEventListener("visibilitychange", onVisibilityChange);
    drawerObserver?.disconnect();
  }

  return {
    widgets: {
      oscWidget, vitalWidget, fmriWidget, ringsWidget,
      logWidget, radarWidget, phaseWidget, emotionWidget,
      gaugeWidget, heatmapWidget,
      phaseArcWidget, connectionWidget, alertWidget,
    },
    allWidgets,
    // Direkte References für convenience
    oscWidget, vitalWidget, fmriWidget, ringsWidget,
    logWidget, radarWidget, phaseWidget, emotionWidget,
    gaugeWidget, heatmapWidget,
    phaseArcWidget, connectionWidget, alertWidget,
    destroy,
  };
}
