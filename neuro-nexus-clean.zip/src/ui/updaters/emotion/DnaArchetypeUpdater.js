/**
 * DnaArchetypeUpdater — DNA-Archetyp und Achsen-Werte (GDD §3-4)
 *
 * Aktualisiert: novaArchetype, dnaArchetypeBadge/Card/Icon/Name/Desc,
 * dnaAxisExploration/Resonance/Dynamism (Val + Fill + Class),
 * dnaAxisArchetypeName.
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { getArchetypeMeta, getArchetypeNameDe } from "../../constants/archetypeData.js";

export class DnaArchetypeUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim } = ctx;
    const dna = sim?.personality?.dna;
    if (!dna || !dna.archetype) return;

    const archId = dna.archetype.id;
    const archName = getArchetypeNameDe(archId, dna.archetype.name);
    const archMeta = getArchetypeMeta(archId);

    // NOVA card archetype
    const novaArchEl = document.getElementById("novaArchetype");
    if (novaArchEl) {
      novaArchEl.textContent = archName;
      novaArchEl.style.color = archMeta.color;
    }

    // DNA archetype badge + card
    const badgeEl = document.getElementById("dnaArchetypeBadge");
    if (badgeEl) {
      badgeEl.textContent = archName.toUpperCase();
      badgeEl.style.color = archMeta.color;
    }
    const archNameEl = document.getElementById("dnaArchetypeName");
    if (archNameEl) archNameEl.textContent = archName;
    const archDescEl = document.getElementById("dnaArchetypeDesc");
    if (archDescEl && dna.archetype.description) {
      archDescEl.textContent = dna.archetype.description;
    }
    const archIconEl = document.getElementById("dnaArchetypeIcon");
    if (archIconEl) {
      archIconEl.textContent = archMeta.icon;
      archIconEl.style.color = archMeta.color;
    }
    const archCardEl = document.getElementById("dnaArchetypeCard");
    if (archCardEl) {
      archCardEl.style.borderColor = archMeta.color + "44";
      archCardEl.style.boxShadow = `0 0 20px ${archMeta.color}11`;
    }

    // DNA axes
    const axes = [
      { id: "Exploration", val: dna.axes.exploration, cls: dna.classified.exploration },
      { id: "Resonance",   val: dna.axes.resonance,   cls: dna.classified.resonance },
      { id: "Dynamism",    val: dna.axes.dynamism,    cls: dna.classified.dynamism },
    ];
    axes.forEach(ax => {
      const valEl = document.getElementById(`dnaAxis${ax.id}Val`);
      const fillEl = document.getElementById(`dnaAxis${ax.id}Fill`);
      const clsEl = document.getElementById(`dnaAxis${ax.id}Class`);
      if (valEl) valEl.textContent = (ax.val * 100).toFixed(0) + "%";
      if (fillEl) {
        fillEl.style.width = (ax.val * 100).toFixed(0) + "%";
        fillEl.style.background = `linear-gradient(90deg, ${archMeta.color}66, ${archMeta.color})`;
      }
      if (clsEl) clsEl.textContent = ax.cls;
    });

    const archAxisNameEl = document.getElementById("dnaAxisArchetypeName");
    if (archAxisNameEl) {
      archAxisNameEl.textContent = archName;
      archAxisNameEl.style.color = archMeta.color;
    }
  }
}
