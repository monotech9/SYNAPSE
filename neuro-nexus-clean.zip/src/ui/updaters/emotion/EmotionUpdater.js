/**
 * EmotionUpdater — Aktualisiert die Emotions-Anzeige im HUD
 *
 * Schreibt dominant emotion, mood bar und Modulations-Werte ins DOM.
 * Extrahiert aus ConsciousnessHUD.js.
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { EMOTION_COLORS } from "../../constants/emotionColors.js";
import { setElText, setElBar } from "../../hudUtils.js";

export class EmotionUpdater extends BaseUpdater {
  constructor() {
    super(0); // wird vom Frame-Loop gedrosselt
  }

  _doUpdate(ctx) {
    const { emotionEngine, els } = ctx;
    if (!emotionEngine) return;
    const snap = emotionEngine.getSnapshot();
    const dom = snap.dominant;

    // Dominant emotion badge
    const badge = els.emotionDominantBadge;
    if (badge) {
      badge.textContent = dom.label.toUpperCase();
      const c = EMOTION_COLORS[dom.emotion] || "#48ffa3";
      badge.style.color = c;
      badge.style.background = c + "1a";
    }

    // Mood bar (bipolar: -1 → +1)
    const moodEl = els.emotionMoodBar;
    if (moodEl) {
      moodEl.style.width = `${Math.abs(snap.mood) * 50}%`;
      moodEl.style.marginLeft = snap.mood >= 0 ? "50%" : `${50 - Math.abs(snap.mood) * 50}%`;
      moodEl.style.background = snap.mood >= 0 ? "#48ffa3" : "#ff7878";
    }
    setElText(els, "emotionMoodVal", snap.mood.toFixed(2));

    // Modulation bars
    const mod = snap.modulation;
    setElBar(els, "emotionGrowth",      mod.growthRateMultiplier);
    setElBar(els, "emotionThreshold",   mod.firingThresholdMultiplier);
    setElBar(els, "emotionExploration", mod.explorationNoiseMultiplier);
  }
}
