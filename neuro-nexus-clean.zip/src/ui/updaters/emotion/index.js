/**
 * emotion/index.js — Barrel-Export für emotion-Updater
 */

export * from './EmotionUpdater.js';
export * from './DnaArchetypeUpdater.js';
