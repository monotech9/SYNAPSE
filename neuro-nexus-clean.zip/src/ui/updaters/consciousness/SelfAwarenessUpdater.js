/**
 * SelfAwarenessUpdater — Self-Awareness-Bar
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { setBarWidth } from "../../hudUtils.js";

export class SelfAwarenessUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { snap } = ctx;
    if (!snap) return;
    setBarWidth("consciousAware", snap.selfAwareness * 100);
  }
}
