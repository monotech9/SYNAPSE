/**
 * ActionStatsUpdater — Action-Executor Statistiken
 *
 * Aktualisiert: consciousActions, consciousActionDelta.
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class ActionStatsUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { snap } = ctx;
    if (!snap?.actionStats) return;
    const s = snap.actionStats;

    const actionEl = document.getElementById("consciousActions");
    if (actionEl) {
      const parts = [];
      if (s.total > 0) {
        parts.push(`${s.total} Aktionen`);
        if (s.explore > 0) parts.push(`explore:${s.explore}`);
        if (s.stabilize > 0) parts.push(`stabilize:${s.stabilize}`);
        if (s.integrate > 0) parts.push(`integrate:${s.integrate}`);
        if (s.lastAction) parts.push(`← ${s.lastAction}`);
      } else {
        parts.push("— wartend —");
      }
      actionEl.textContent = parts.join(" · ");
    }

    const deltaEl = document.getElementById("consciousActionDelta");
    if (deltaEl && s.lastBeforeAfter) {
      const ba = s.lastBeforeAfter;
      const deltaSign = ba.delta < 0 ? "↓" : "↑";
      const deltaCol = ba.delta < 0 ? "rgba(72,255,163,0.8)" : "rgba(255,100,100,0.8)";
      deltaEl.textContent = `Δerror ${deltaSign}${Math.abs(ba.delta * 100).toFixed(1)}%`;
      deltaEl.style.color = deltaCol;
    }
  }
}
