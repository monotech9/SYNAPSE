/**
 * CohesionUpdater — Cohesion Core / Identitäts-Stabilität (GDD §14)
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class CohesionUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { snap } = ctx;
    const cohesionSnap = snap?.cohesionCore;
    if (!cohesionSnap) return;

    const cohesionPct = (cohesionSnap.identityStability ?? 0) * 100;
    const cohesionBar = document.getElementById("consciousCohesion");
    if (cohesionBar) cohesionBar.style.width = cohesionPct.toFixed(0) + "%";
    const cohesionVal = document.getElementById("consciousCohesionVal");
    if (cohesionVal) cohesionVal.textContent = cohesionPct.toFixed(0) + "%";
  }
}
