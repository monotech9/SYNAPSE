/**
 * PredictionErrorUpdater — Prädiktionsfehler-Bar
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { setBarWidth } from "../../hudUtils.js";

export class PredictionErrorUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { snap } = ctx;
    if (!snap) return;
    setBarWidth("consciousPred", snap.predictionError * 100);
  }
}
