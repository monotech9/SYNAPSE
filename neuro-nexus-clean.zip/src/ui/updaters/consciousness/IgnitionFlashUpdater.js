/**
 * IgnitionFlashUpdater — Ignition-Flash → Oscilloscope Gamma-Spike
 *
 * Wenn snap.ignitionFlash > 0.1, triggert einen Gamma-Spike im Oscilloscope.
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class IgnitionFlashUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { snap, widgets } = ctx;
    if (!snap) return;
    if (snap.ignitionFlash > 0.1 && widgets?.oscWidget) {
      widgets.oscWidget.spikeGamma(snap.ignitionFlash * 0.4);
    }
  }
}
