/**
 * ConsciousnessStateUpdater — State-Label, Mood und Narrative
 *
 * Aktualisiert: consciousState, novaStateLabel, protokollNovaState,
 * protokollNarrative, protokollNovaDot, consciousMood, novaMoodVal, novaMoodState.
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { setText, setNovaState } from "../../hudUtils.js";
import { MOOD_STATE_COLORS } from "../../constants/emotionColors.js";

export class ConsciousnessStateUpdater extends BaseUpdater {
  constructor() {
    super(0);
  }

  _doUpdate(ctx) {
    const { snap } = ctx;
    if (!snap) return;

    // State label
    const stateEl = document.getElementById("consciousState");
    if (stateEl) {
      stateEl.textContent = snap.selfState.toUpperCase();
      stateEl.style.opacity = snap.selfAwareness > 0.1 ? "1" : "0.4";
    }
    setNovaState(snap.selfState.toUpperCase());

    // Protokoll card
    const protStatEl = document.getElementById("protokollNovaState");
    if (protStatEl) protStatEl.textContent = snap.selfState.toUpperCase();
    const protNarrEl = document.getElementById("protokollNarrative");
    if (protNarrEl && snap.narrative) protNarrEl.textContent = snap.narrative;
    const protDotEl = document.getElementById("protokollNovaDot");
    if (protDotEl) protDotEl.style.opacity = snap.selfAwareness > 0.1 ? "1" : "0.3";

    // Workspace mood (string)
    const moodEl = document.getElementById("consciousMood");
    if (moodEl && typeof snap.mood === "string") {
      moodEl.textContent = snap.mood.toUpperCase();
    }

    // MoodStateMachine (8 Stimmungen)
    const moodSnap = snap.moodState;
    if (moodSnap) {
      const novaMoodEl = document.getElementById("novaMoodVal");
      if (novaMoodEl) {
        novaMoodEl.textContent = moodSnap.label.toUpperCase();
        novaMoodEl.style.color = MOOD_STATE_COLORS[moodSnap.current] || "#38bdf8";
      }
      const novaMoodStateEl = document.getElementById("novaMoodState");
      if (novaMoodStateEl) {
        novaMoodStateEl.textContent = moodSnap.label.toUpperCase();
        novaMoodStateEl.style.color = MOOD_STATE_COLORS[moodSnap.current] || "#38bdf8";
      }
    }

    // Narrative + Reflection
    setText("consciousNarrative", snap.narrative || "");
    setText("consciousReflection", snap.lastReflection || "");
  }
}
