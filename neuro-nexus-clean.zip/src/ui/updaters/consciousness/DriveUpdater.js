/**
 * DriveUpdater — Dominanter Drive + Farbe
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { DRIVE_COLORS } from "../../constants/driveColors.js";

export class DriveUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { snap } = ctx;
    if (!snap) return;
    const label = (snap.dominantDriveLabel || snap.dominantDrive || "—").toUpperCase();
    const color = DRIVE_COLORS[snap.dominantDrive] || "rgba(110,155,205,0.7)";

    const driveEl = document.getElementById("consciousDrive");
    if (driveEl) {
      driveEl.textContent = label;
      driveEl.style.color = color;
    }
    const novaDriveEl = document.getElementById("novaDriveVal");
    if (novaDriveEl) {
      novaDriveEl.textContent = label;
      novaDriveEl.style.color = color;
    }
  }
}
