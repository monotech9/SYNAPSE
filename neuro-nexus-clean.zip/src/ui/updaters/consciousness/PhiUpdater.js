/**
 * PhiUpdater — Phi (IIT) + Epistemic Value
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { setBarWidth } from "../../hudUtils.js";

export class PhiUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { snap } = ctx;
    if (!snap) return;

    const phiVal = snap.phi || 0;
    const phiEl = document.getElementById("consciousPhi");
    if (phiEl) {
      phiEl.textContent = "Φ " + Math.round(phiVal * 100);
      phiEl.style.opacity = phiVal > 0.05 ? "1" : "0.4";
    }
    const novaPhiEl = document.getElementById("novaPhiVal");
    if (novaPhiEl) {
      novaPhiEl.textContent = Math.round(phiVal * 100);
      novaPhiEl.style.opacity = phiVal > 0.05 ? "1" : "0.4";
    }

    setBarWidth("consciousEpistemic", (snap.epistemicValue || 0) * 100);
  }
}
