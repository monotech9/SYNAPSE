/**
 * FreeEnergyUpdater — Freie-Energie-Bar + Self-Confidence
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { setBarWidth } from "../../hudUtils.js";

export class FreeEnergyUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { snap } = ctx;
    if (!snap) return;
    setBarWidth("consciousFreeEnergy", snap.freeEnergy * 100);
    setBarWidth("consciousConfidence", snap.selfConfidence * 100);
  }
}
