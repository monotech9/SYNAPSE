/**
 * DopamineUpdater — Dopamin / Reward-System (GDD §12)
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class DopamineUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim } = ctx;
    const dopamineLevel = sim?.rewardSystem?.dopamine ?? 0.5;
    const dopaminePct = dopamineLevel * 100;

    const dopamineBar = document.getElementById("consciousDopamine");
    if (dopamineBar) {
      dopamineBar.style.width = dopaminePct.toFixed(0) + "%";
      dopamineBar.style.background = "linear-gradient(90deg,#ec4899,#f9a8d4)";
    }
    const dopamineVal = document.getElementById("consciousDopamineVal");
    if (dopamineVal) dopamineVal.textContent = dopaminePct.toFixed(0) + "%";

    const novaDopamine = document.getElementById("novaDopamine");
    if (novaDopamine) novaDopamine.textContent = dopamineLevel.toFixed(2);
  }
}
