/**
 * BaseUpdater — Einheitliches Interface für alle DOM-Updater
 *
 * Jeder Updater erbt von BaseUpdater und implementiert _doUpdate(ctx).
 * Der Frame-Loop ruft update(ctx, now) auf; Throttling wird automatisch
 * basierend auf this.throttleMs gehandhabt.
 *
 * Lifecycle:
 *   init(ctx)      — einmalig bei Start (optional)
 *   update(ctx, now) — pro Frame (mit Throttling)
 *   destroy()      — Cleanup
 *
 * ctx enthält mindestens:
 *   { sim, els, widgets, telemetry, consciousness, emotionEngine, snap }
 */

export class BaseUpdater {
  /**
   * @param {number} [throttleMs=0] — minimale Zeit zwischen Updates (0 = jeder Frame)
   */
  constructor(throttleMs = 0) {
    this.throttleMs = throttleMs;
    this._lastUpdate = 0;
    this._destroyed = false;
    /** @type {string} — Anzeigename für Debugging/Registry */
    this.name = this.constructor.name;
  }

  /** Wird einmalig beim Start aufgerufen. Override in Subclass falls nötig. */
  init(_ctx) {}

  /**
   * Pro-Frame-Update mit Throttling.
   * Ruft _doUpdate(ctx) auf, wenn Throttling-Zeit verstrichen.
   */
  update(ctx, now = 0) {
    if (this._destroyed) return;
    if (this.throttleMs > 0 && now - this._lastUpdate < this.throttleMs) return;
    this._lastUpdate = now;
    this._doUpdate(ctx);
  }

  /**
   * Eigentliche Update-Logik. Override in Subclass.
   * @param {Object} _ctx — Kontext-Objekt
   */
  _doUpdate(_ctx) {}

  /** Cleanup. Override in Subclass falls nötig. */
  destroy() {
    this._destroyed = true;
  }
}
