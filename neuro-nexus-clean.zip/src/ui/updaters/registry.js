/**
 * updaterRegistry — Zentrale Registry für alle DOM-Updater
 *
 * Sammelt alle Updater-Instanzen und bietet:
 *   - createUpdaters(unlockedEpochs) → { all, fast, menu }
 *   - updateAll(updaters, ctx, now)  → ruft alle auf (mit Throttling)
 *   - updateMenu(updaters, ctx, now) → ruft nur den MenuStatsUpdater auf
 *   - destroyUpdaters(updaters)      → Cleanup aller Updater
 *
 * Um ein Element hinzuzufügen/zu ersetzen/zu entfernen:
 *   1. Eigene Updater-Klasse in src/ui/updaters/ erstellen (erbt BaseUpdater)
 *   2. Hier importieren + im entsprechenden Array registrieren
 *   3. Fertig — der Frame-Loop ruft sie automatisch auf
 */

import { EmotionUpdater }           from "./emotion/EmotionUpdater.js";
import { ConsciousnessStateUpdater } from "./consciousness/ConsciousnessStateUpdater.js";
import { PredictionErrorUpdater }   from "./consciousness/PredictionErrorUpdater.js";
import { SelfAwarenessUpdater }     from "./consciousness/SelfAwarenessUpdater.js";
import { DriveUpdater }             from "./consciousness/DriveUpdater.js";
import { FreeEnergyUpdater }        from "./consciousness/FreeEnergyUpdater.js";
import { PhiUpdater }               from "./consciousness/PhiUpdater.js";
import { EnergyModelUpdater }       from "./vitals/EnergyModelUpdater.js";
import { DopamineUpdater }          from "./consciousness/DopamineUpdater.js";
import { CohesionUpdater }          from "./consciousness/CohesionUpdater.js";
import { DnaArchetypeUpdater }      from "./emotion/DnaArchetypeUpdater.js";
import { EchoMemoryUpdater }        from "./memory/EchoMemoryUpdater.js";
import { ActionStatsUpdater }       from "./consciousness/ActionStatsUpdater.js";
import { IgnitionFlashUpdater }     from "./consciousness/IgnitionFlashUpdater.js";
import { VitalityUpdater }          from "./vitals/VitalityUpdater.js";
import { MemoryRingsUpdater }       from "./memory/MemoryRingsUpdater.js";
import { StageLabelUpdater }        from "./vitals/StageLabelUpdater.js";
import { GlanceBarUpdater }         from "./vitals/GlanceBarUpdater.js";
import { A11yStatusUpdater }        from "./vitals/A11yStatusUpdater.js";
import { NavPanelUpdater }          from "./nav/NavPanelUpdater.js";
import { GaugeWidgetUpdater }       from "./widgets/GaugeWidgetUpdater.js";
import { PhaseArcWidgetUpdater }    from "./widgets/PhaseArcWidgetUpdater.js";
import { TelemetryUpdater }         from "./nav/TelemetryUpdater.js";
import { SysTickerUpdater }         from "./vitals/SysTickerUpdater.js";
import { HeatmapWidgetUpdater }     from "./widgets/HeatmapWidgetUpdater.js";
import { MenuStatsUpdater }         from "./vitals/MenuStatsUpdater.js";

/**
 * Erstellt alle Updater-Instanzen.
 * @param {Set} unlockedEpochs — für MenuStatsUpdater
 * @returns {{ all: BaseUpdater[], menu: MenuStatsUpdater }}
 */
export function createUpdaters(unlockedEpochs) {
  // Consciousness-Metriken (alle 4.5 FPS via Frame-Loop-Drosselung)
  const consciousnessUpdaters = [
    new ConsciousnessStateUpdater(),
    new PredictionErrorUpdater(),
    new SelfAwarenessUpdater(),
    new DriveUpdater(),
    new FreeEnergyUpdater(),
    new PhiUpdater(),
    new EnergyModelUpdater(),
    new DopamineUpdater(),
    new CohesionUpdater(),
    new DnaArchetypeUpdater(),
    new EchoMemoryUpdater(),
    new ActionStatsUpdater(),
    new IgnitionFlashUpdater(),
    new EmotionUpdater(),
  ];

  // Allgemeine DOM-Updates (gleiche Drosselung)
  const generalUpdaters = [
    new VitalityUpdater(),
    new MemoryRingsUpdater(),
    new StageLabelUpdater(),
    new GlanceBarUpdater(),
    new A11yStatusUpdater(),
    new NavPanelUpdater(),
    new GaugeWidgetUpdater(),
    new PhaseArcWidgetUpdater(),
  ];

  // Selbst-drosselnde Updater (eigene Taktung)
  const selfThrottled = [
    new TelemetryUpdater(),   // 1/s
    new SysTickerUpdater(),   // 1/s
    new HeatmapWidgetUpdater(), // 5s
  ];

  // Menu-Stats (nur wenn Menü offen)
  const menuUpdater = new MenuStatsUpdater(unlockedEpochs);

  const all = [
    ...consciousnessUpdaters,
    ...generalUpdaters,
    ...selfThrottled,
    menuUpdater,
  ];

  return { all, menu: menuUpdater };
}

/**
 * Ruft alle Updater auf (mit individuellem Throttling).
 * @param {BaseUpdater[]} updaters
 * @param {Object} ctx — Kontext für alle Updater
 * @param {number} now — aktueller Timestamp
 */
export function updateAll(updaters, ctx, now) {
  for (const u of updaters) {
    u.update(ctx, now);
  }
}

/**
 * Ruft nur den Menu-Stats-Updater auf.
 */
export function updateMenu(menuUpdater, ctx, now) {
  menuUpdater.update(ctx, now);
}

/**
 * Zerstört alle Updater.
 */
export function destroyUpdaters(updaters) {
  updaters.all.forEach(u => u.destroy());
}
