/**
 * TelemetryUpdater — Telemetry-Ribbon + Health-Dot
 *
 * Rotiert durch Status-Meldungen und aktualisiert die detaillierte
 * Telemetry-Tabelle (#telemetryRoot).
 */

import { BaseUpdater } from "../BaseUpdater.js";

let _telemetryIndex = 0;

export class TelemetryUpdater extends BaseUpdater {
  constructor() {
    super(1000); // 1× pro Sekunde
  }

  _doUpdate(ctx) {
    const { sim, els, telemetry, derived } = ctx;
    const world = sim.world;
    const chaosVar = derived?.chaosVar ?? 0;
    const pulseRatio = derived?.pulseRatio ?? 0;

    const t = els.telemetryText;
    const dot = els.telemetryDot;

    // Rotating status message
    const totalNodes = world.clusters.reduce((s, c) => s + (c.nodes?.length || 0), 0);
    const load = ((world.pulses.length / 180) * 100).toFixed(1);
    const syncErr = (chaosVar * 0.15).toFixed(3);
    const flowRate = Math.round(world.pulses.length * 4 + totalNodes * 0.3);
    const phi = sim.consciousness?.getSnapshot()?.phi || 0;

    const messages = [
      `NEXUS_CORE: OK`,
      `LOAD: ${load}%`,
      `SYNC_ERR: ${syncErr}`,
      `FLOW_RATE: ${flowRate} n/s`,
      `Φ: ${phi.toFixed(2)}`,
    ];
    _telemetryIndex = (_telemetryIndex + 1) % messages.length;
    if (t) t.textContent = messages[_telemetryIndex];

    // Health dot
    if (dot) {
      const health = 1 - chaosVar;
      const r = Math.round(255 * (1 - health));
      const g = Math.round(72 + health * 183);
      const b = Math.round(163 - chaosVar * 80);
      dot.style.background = `rgba(${r}, ${g}, ${b}, 0.8)`;
      dot.style.boxShadow = `0 0 6px rgba(${r}, ${g}, ${b}, 0.6)`;
    }

    // Detailed telemetry table
    const telRoot = document.getElementById("telemetryRoot");
    if (!telRoot) return;
    const setVal = (sel, v) => { const el = telRoot.querySelector(sel); if (el) el.textContent = v; };

    const fps = telemetry?.current?.fps ?? "—";
    const tps = telemetry?.current?.tps ?? "—";
    const simHz = telemetry?.simLoop?.hz || 30;
    const edgeCount = world.edges?.length ?? 0;
    const clusterCount = world.clusters?.length ?? 0;
    const avgActivity = clusterCount > 0
      ? (world.clusters.reduce((s, c) => s + (c.activityMemory || 0), 0) / clusterCount * 100).toFixed(1) + "%"
      : "—";
    const avgMem = clusterCount > 0
      ? (world.clusters.reduce((s, c) => s + (c.memoryStrength || 0), 0) / clusterCount * 100).toFixed(1) + "%"
      : "—";
    const age = world.age?.toFixed(0) + "s" ?? "—";
    const memUsed = (typeof performance !== "undefined" && performance.memory)
      ? (performance.memory.usedJSHeapSize / 1048576).toFixed(1) + " MB" : "n/a";

    setVal('.tel-val[data-stat="fps"]',      fps + "");
    setVal('.tel-val[data-stat="tps"]',      tps + "/" + simHz);
    setVal('.tel-val[data-stat="nodes"]',    totalNodes + "");
    setVal('.tel-val[data-stat="edges"]',    edgeCount + "");
    setVal('.tel-val[data-stat="clusters"]', clusterCount + "");
    setVal('.tel-val[data-stat="activity"]', avgActivity);
    setVal('.tel-val[data-stat="memory"]',   avgMem);
    setVal('.tel-val[data-stat="age"]',      age);
    setVal('.tel-val[data-stat="cpm"]',      "0");
    setVal('.tel-val[data-stat="mem"]',      memUsed);

    const fpsSys = document.getElementById("menuFps");
    if (fpsSys) fpsSys.textContent = fps + "";
  }
}
