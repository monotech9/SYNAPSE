/**
 * NavPanelUpdater — Live-Status-Werte im Dock Nav-Panel
 *
 * Aktualisiert: navStage, navArchetype, navMood, navEnergy.
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { ARCHETYPE_NAMES_DE } from "../../constants/archetypeData.js";
import { MOOD_STATE_LABELS_DE } from "../../constants/emotionColors.js";

export class NavPanelUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim, snap } = ctx;
    if (!snap) return;

    const dna = sim?.personality?.dna;
    const energySnap = sim?.energyModel?.getSnapshot();
    const archId = dna?.archetype?.id;
    const moodId = snap.moodState?.current;

    const stage     = sim.world?.stage || "—";
    const archetype = archId ? (ARCHETYPE_NAMES_DE[archId] || archId) : "—";
    const mood      = moodId ? (MOOD_STATE_LABELS_DE[moodId] || moodId) : "—";
    const energy    = energySnap?.energy;

    const navStage     = document.getElementById("navStage");
    const navArchetype = document.getElementById("navArchetype");
    const navMood      = document.getElementById("navMood");
    const navEnergy    = document.getElementById("navEnergy");

    if (navStage && stage) navStage.textContent = stage;
    if (navArchetype && archetype) {
      navArchetype.textContent = archetype;
      navArchetype.style.color = "#a78bfa";
    }
    if (navMood && mood) navMood.textContent = mood;
    if (navEnergy && energy !== null && energy !== undefined) {
      const pct = (energy * 100).toFixed(0) + "%";
      navEnergy.textContent = pct;
      navEnergy.style.color = energy < 0.2 ? "#ef4444" : energy < 0.4 ? "#fbbf24" : "#34d399";
    }
  }
}
