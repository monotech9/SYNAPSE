/**
 * VitalityUpdater — Metabolismus, Plastizität, Resilienz + VitalityWidget
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class VitalityUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim, widgets } = ctx;
    const vitalWidget = widgets?.vitalWidget;
    const clusters = sim.world.clusters.filter(c => c.state !== "dormant");

    if (!clusters.length) {
      vitalWidget?.update(0, 0, 0);
      this._setVitalLabels(0, 0, 0);
      return;
    }

    const avgAct = clusters.reduce((s, c) => s + c.activityMemory, 0) / clusters.length;
    const ctr = sim.diagnosticCounters;
    const growth = ctr.nodesAdded + ctr.internalEdgesAdded + ctr.bridgesCreated;
    const plas = Math.min(0.99, (growth / Math.max(1, sim.world.age)) * 4);
    const avgMem = clusters.reduce((s, c) => s + c.memoryStrength, 0) / clusters.length;

    vitalWidget?.update(avgAct, plas, avgMem);
    this._setVitalLabels(avgAct, plas, avgMem);
  }

  _setVitalLabels(m, p, r) {
    const set = (id, n) => {
      const el = document.getElementById(id);
      if (el) el.textContent = Math.round(n * 100) + "%";
    };
    set("vitalMetVal", m);
    set("vitalPlaVal", p);
    set("vitalResVal", r);
  }
}
