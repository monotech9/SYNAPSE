/**
 * A11yStatusUpdater — Barrierefreiheits-Status-Meldung
 *
 * Schreibt eine Text-Beschreibung des Simulationszustands für
 * Screenreader ins #a11yStatus Element.
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { GROWTH_LABELS } from "../../constants/growthLabels.js";

export class A11yStatusUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim } = ctx;
    const el = document.getElementById("a11yStatus");
    if (!el) return;

    const w = sim.world;
    const nc = sim.totalNodeCount();
    const stage = GROWTH_LABELS[w.growthStage] || w.growthStage;
    const t = Math.floor(w.age);
    const m = Math.floor(t / 60), s = t % 60;
    el.textContent = `Neuro Nexus. Stadium: ${stage}. ${nc} Neuronen, ${w.edges.length} Verbindungen. Alter: ${m} Minuten ${s} Sekunden.`;
  }
}
