/**
 * StageLabelUpdater — Resonance-Label + Growth-Stage-Anzeige
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { GROWTH_LABELS } from "../../constants/growthLabels.js";

export class StageLabelUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim, els } = ctx;
    if (els.resonanceLabel) {
      els.resonanceLabel.textContent = GROWTH_LABELS[sim.world.growthStage] || "GENESIS";
    }
  }
}
