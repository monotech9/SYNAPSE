/**
 * GlanceBarUpdater — Glance-Bar Werte (Stage, Nodes, Edges, Age, Cluster, FPS)
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { GROWTH_LABELS } from "../../constants/growthLabels.js";

export class GlanceBarUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim, els, telemetry } = ctx;
    const w = sim.world;

    if (els.glanceStage)   els.glanceStage.textContent = GROWTH_LABELS[w.growthStage] || "GENESIS";
    if (els.glanceNodes)   els.glanceNodes.textContent = sim.totalNodeCount();
    if (els.glanceEdges)   els.glanceEdges.textContent = w.edges.length;
    if (els.glanceAge)     els.glanceAge.textContent = Math.round(w.age) + "s";
    if (els.glanceCluster) {
      const cl = (w.clusters || []).length;
      els.glanceCluster.textContent = cl > 0 ? cl : "—";
    }
    if (els.glanceFps) {
      const fps = telemetry ? Math.round(telemetry.fps || 0) : (w._lastFps ? Math.round(w._lastFps) : "—");
      els.glanceFps.textContent = fps;
    }
  }
}
