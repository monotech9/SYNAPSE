/**
 * EnergyModelUpdater — Energie-Modell (GDD §9)
 *
 * Energie-Bar mit dynamischem Farbverlauf (rot → gelb → grün).
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class EnergyModelUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim } = ctx;
    const energySnap = sim?.energyModel?.getSnapshot();
    if (!energySnap) return;

    const energyPct = energySnap.energy * 100;

    // Consciousness panel bar
    const energyBar = document.getElementById("consciousEnergy");
    if (energyBar) {
      energyBar.style.width = energyPct.toFixed(0) + "%";
      energyBar.style.background = energyPct < 20
        ? "linear-gradient(90deg,#ef4444,#f87171)"
        : energyPct < 40
        ? "linear-gradient(90deg,#f59e0b,#fbbf24)"
        : "linear-gradient(90deg,#10b981,#34d399)";
    }
    const energyVal = document.getElementById("consciousEnergyVal");
    if (energyVal) energyVal.textContent = energyPct.toFixed(0) + "%";

    // NOVA card value
    const novaEnergy = document.getElementById("novaEnergy");
    if (novaEnergy) {
      novaEnergy.textContent = energyPct.toFixed(0) + "%";
      novaEnergy.style.color = energyPct < 20 ? "#ef4444" : energyPct < 40 ? "#fbbf24" : "#34d399";
    }
  }
}
