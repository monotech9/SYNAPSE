/**
 * MenuStatsUpdater — Menü-Statistiken und Achievements
 *
 * Wird nur aktualisiert, wenn das Menü geöffnet ist.
 * Aktualisiert: menuStage, menuNodes, menuEdges, menuAge, menuClusters,
 * menuEpoch + Achievement-Items.
 */

import { BaseUpdater } from "../BaseUpdater.js";
import { GROWTH_LABELS } from "../../constants/growthLabels.js";

export class MenuStatsUpdater extends BaseUpdater {
  /**
   * @param {Set} unlockedEpochs — Set der freigeschalteten Epoch-Stadien
   */
  constructor(unlockedEpochs) {
    super(0);
    this._unlockedEpochs = unlockedEpochs;
  }

  _doUpdate(ctx) {
    const { sim, els } = ctx;
    const w = sim.world;

    if (els.menuStage)     els.menuStage.textContent = GROWTH_LABELS[w.growthStage] || w.growthStage;
    if (els.menuNodes)     els.menuNodes.textContent = sim.totalNodeCount();
    if (els.menuEdges)     els.menuEdges.textContent = w.edges.length;
    if (els.menuAge)       els.menuAge.textContent = Math.round(w.age) + "s";
    if (els.menuClusters)  els.menuClusters.textContent = w.clusters.length;
    if (els.menuEpoch)     els.menuEpoch.textContent = GROWTH_LABELS[w.growthStage] || w.growthStage;

    this._updateAchievements(els);
  }

  _updateAchievements(els) {
    const container = els.epochAchievements;
    if (!container) return;
    const stage = this._unlockedEpochs;
    container.querySelectorAll(".epoch-ach-item").forEach(item => {
      if (stage.has(item.dataset.stage)) item.classList.add("is-unlocked");
    });
  }
}
