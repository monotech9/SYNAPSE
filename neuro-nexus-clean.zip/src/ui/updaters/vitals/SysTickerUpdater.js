/**
 * SysTickerUpdater — System-Ticker-Nachricht im Bottom Dock
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class SysTickerUpdater extends BaseUpdater {
  constructor() {
    super(1000); // 1× pro Sekunde
  }

  _doUpdate(ctx) {
    const { sim } = ctx;
    const el = document.getElementById("sysTickerMsg");
    if (!el) return;
    const world = sim.world;
    const nodes = world.clusters?.reduce((s, c) => s + (c.nodes?.length || 0), 0) || 0;
    const edges = world.edges?.length || 0;
    const age   = Math.round(world.age || 0);
    el.textContent = `NEXUS_CORE: OK · N:${nodes} · S:${edges} · AGE:${age}s`;
  }
}
