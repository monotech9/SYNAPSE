/**
 * EchoMemoryUpdater — Echo Memory Anzeige (GDD §6 M3)
 *
 * Aktualisiert: echoBadge, echoActiveCount, echoStrongest,
 * echoPatternTotal, novaEchoCount, echoMemoryList.
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class EchoMemoryUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim } = ctx;
    const echoSnap = sim?.echoMemory?.getSnapshot();
    if (!echoSnap) return;

    const echoBadge = document.getElementById("echoBadge");
    if (echoBadge) echoBadge.textContent = echoSnap.activeCount;

    const echoActiveEl = document.getElementById("echoActiveCount");
    if (echoActiveEl) echoActiveEl.textContent = echoSnap.activeCount;

    const echoStrongEl = document.getElementById("echoStrongest");
    if (echoStrongEl) echoStrongEl.textContent = (echoSnap.strongestStrength * 100).toFixed(0) + "%";

    const echoPatternEl = document.getElementById("echoPatternTotal");
    if (echoPatternEl) echoPatternEl.textContent = echoSnap.patternHistory;

    const novaEchoEl = document.getElementById("novaEchoCount");
    if (novaEchoEl) novaEchoEl.textContent = echoSnap.activeCount;

    // Echo list (top 3)
    const echoListEl = document.getElementById("echoMemoryList");
    if (echoListEl) {
      const echos = sim.echoMemory.getActiveEchos().slice(0, 3);
      echoListEl.innerHTML = echos.map(e => {
        const pct = (e.strength * 100).toFixed(0);
        const emotion = e.pattern.emotion || "?";
        return `<div class="echo-item">
          <span class="echo-item__emotion">${emotion}</span>
          <div class="echo-item__bar"><div class="echo-item__fill" style="width:${pct}%"></div></div>
          <span class="echo-item__strength">${pct}%</span>
        </div>`;
      }).join("") || '<div class="echo-empty">Keine aktiven Echos</div>';
    }
  }
}
