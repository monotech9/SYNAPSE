/**
 * MemoryRingsUpdater — Dendritische Speicher-Ringe (SVG)
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class MemoryRingsUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim, widgets } = ctx;
    const clusters = sim.world.clusters.filter(c => c.state !== "dormant");
    widgets?.ringsWidget?.update(clusters);
  }
}
