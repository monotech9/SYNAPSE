/**
 * widgets/index.js — Barrel-Export für widgets-Updater
 */

export * from './GaugeWidgetUpdater.js';
export * from './HeatmapWidgetUpdater.js';
export * from './PhaseArcWidgetUpdater.js';
