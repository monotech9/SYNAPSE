/**
 * PhaseArcWidgetUpdater — Phasen-Transition Arc
 *
 * Aktualisiert den Phasen-Fortschritt und die Phasen-Labels.
 */

import { BaseUpdater } from "../BaseUpdater.js";

const LABELS_CURR = ["GENESIS", "KNOSPUNG", "AKTIVIERUNG", "REIFUNG", "KONVERGENZ"];
const LABELS_NEXT = ["KNOSPUNG", "AKTIVIERUNG", "REIFUNG", "KONVERGENZ", "—"];

export class PhaseArcWidgetUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim, widgets } = ctx;
    const phaseArcWidget = widgets?.phaseArcWidget;
    if (!phaseArcWidget) return;

    const stage = sim.world.growthStage || 0;
    const STAGE_COUNT = 5;
    const progress = Math.min(1, (stage + 0.5) / STAGE_COUNT);
    phaseArcWidget.setProgress(progress);

    const curr = document.getElementById("phaseArcCurrent");
    const next = document.getElementById("phaseArcNext");
    if (curr) curr.textContent = LABELS_CURR[Math.min(stage, LABELS_CURR.length - 1)];
    if (next) next.textContent = LABELS_NEXT[Math.min(stage, LABELS_NEXT.length - 1)];
  }
}
