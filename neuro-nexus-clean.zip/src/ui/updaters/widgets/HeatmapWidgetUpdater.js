/**
 * HeatmapWidgetUpdater — Aktivitäts-Heatmap
 *
 * Schiebt alle 5s einen neuen Aktivitätswert in den HeatmapWidget.
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class HeatmapWidgetUpdater extends BaseUpdater {
  constructor() {
    super(5000); // alle 5 Sekunden
  }

  _doUpdate(ctx) {
    const { sim, widgets } = ctx;
    const heatmapWidget = widgets?.heatmapWidget;
    if (!heatmapWidget) return;

    const world = sim.world;
    const clusters = (world.clusters || []).filter(c => c.state !== "dormant");
    const activity = clusters.length
      ? clusters.reduce((s, c) => s + (c.activityMemory || 0), 0) / clusters.length
      : 0;
    heatmapWidget.pushActivity(activity);
  }
}
