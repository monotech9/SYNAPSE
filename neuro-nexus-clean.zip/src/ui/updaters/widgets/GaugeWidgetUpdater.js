/**
 * GaugeWidgetUpdater — System-Auslastung (CPU/MEM/NET) Gauges
 *
 * Berechnet Werte aus Sim-Daten und aktualisiert den GaugeWidget.
 */

import { BaseUpdater } from "../BaseUpdater.js";

export class GaugeWidgetUpdater extends BaseUpdater {
  constructor() { super(0); }

  _doUpdate(ctx) {
    const { sim, widgets, telemetry } = ctx;
    const gaugeWidget = widgets?.gaugeWidget;
    if (!gaugeWidget) return;

    const world = sim.world;
    const clusterCount = (world.clusters || []).length;

    const cpuVal = Math.min(1, (world.pulses?.length || 0) / 80);
    const memVal = clusterCount > 0
      ? Math.min(1, world.clusters.reduce((s, c) => s + (c.memoryStrength || 0), 0) / clusterCount)
      : 0.1;
    const netVal = clusterCount > 0
      ? Math.min(1, world.clusters.reduce((s, c) => s + (c.activityMemory || 0), 0) / clusterCount)
      : 0.1;

    gaugeWidget.update(cpuVal, memVal, netVal);
  }
}
