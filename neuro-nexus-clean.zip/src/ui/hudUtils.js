/**
 * hudUtils.js — Gemeinsame DOM-Helper für alle HUD-Updater
 *
 * Kleine Funktionen, die von vielen Updatern verwendet werden.
 * Zentral hier, damit jeder Updater sie importieren kann.
 */

/**
 * Setzt den Text eines DOM-Elements per ID.
 * @param {string} id — DOM-ID
 * @param {string} text — neuer Text-Inhalt
 */
export function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

/**
 * Setzt die Balkenbreite + Wert-Anzeige eines Progress-Bars.
 * @param {string} id — Basis-ID des Bars (ohne "Val"-Suffix)
 * @param {number} pct — Prozentwert (0–100)
 */
export function setBarWidth(id, pct) {
  const el = document.getElementById(id);
  if (el) el.style.width = pct.toFixed(0) + "%";
  const valEl = document.getElementById(id + "Val");
  if (valEl) valEl.textContent = pct.toFixed(0) + "%";
}

/**
 * Setzt das NOVA-State-Label.
 * @param {string} text — State-Text
 * @param {string} [color] — optionale Farbe
 */
export function setNovaState(text, color) {
  const el = document.getElementById("novaStateLabel");
  if (el) {
    el.textContent = text;
    if (color) el.style.color = color;
  }
}

/**
 * Setzt den Text eines Elements aus dem els-Map (statt per getElementById).
 * @param {Object} els — DOM-Element-Map
 * @param {string} key — Key in els
 * @param {string} text — neuer Text
 */
export function setElText(els, key, text) {
  const el = els[key];
  if (el) el.textContent = text;
}

/**
 * Setzt Balkenbreite + Wert aus dem els-Map.
 * @param {Object} els — DOM-Element-Map
 * @param {string} id — Basis-ID (ohne "Bar"/"Val" Suffix)
 * @param {number} val — Wert 0–1 (wird mit 50 multipliziert für 0–50%)
 */
export function setElBar(els, id, val) {
  const bar = els[id + "Bar"];
  const txt = els[id + "Val"];
  const pct = Math.min(100, Math.max(0, val * 50));
  if (bar) bar.style.width = `${pct}%`;
  if (txt) txt.textContent = val.toFixed(2);
}

/**
 * Sicheres parseFloat mit Fallback.
 */
export function safeNum(v, fallback = 0) {
  return (typeof v === "number" && isFinite(v)) ? v : fallback;
}

/**
 * Clamp-Helfer.
 */
export function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}
