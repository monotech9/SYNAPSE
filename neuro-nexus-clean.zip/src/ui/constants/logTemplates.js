/**
 * logTemplates.js — HTML-Templates für Log-Einträge
 *
 * Jede Funktion gibt einen HTML-String zurück, der im EpochLogWidget
 * angezeigt wird. Farbklassen wie log-hl-neuron sind in hud.css definiert.
 */

export const LOG = {
  nodeAdded:     (c) => `<span class="log-hl-neuron">NEURON:</span> Neue Zelle in ${c.cluster}.`,
  edgeAdded:     (c) => `<span class="log-hl-synapse">SYNAPSE:</span> Pfad #0x${c.id} etabliert.`,
  bridgeCreated: ()  => `<span class="log-hl-bridge">BRIDGE:</span> Inter-cluster-Link aktiv.`,
  stageChanged:  (c) => `<span class="log-hl-stage">EVOLUTION:</span> Stadium → ${c.stage}.`,
  pulseSpike:    (c) => `<span class="log-hl-pulse">RESONANZ:</span> ${c.count} Pulse simultan.`,
  memoryFlash:   (c) => `<span class="log-hl-memory">MEMORY:</span> Spur in ${c.cluster} verstärkt.`,
  impulse:       ()  => `<span class="log-hl-pulse">IMPULS:</span> Signal injiziert.`,
};
