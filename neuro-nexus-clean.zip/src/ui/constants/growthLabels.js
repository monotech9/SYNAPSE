/**
 * growthLabels.js — Wachstums-Stadien und Cluster-Typ-Labels
 */

export const GROWTH_LABELS = {
  genesis:        "GENESIS",
  activation:     "AKTIVIERUNG",
  growth:         "WACHSTUM",
  budding:        "KNOSPUNG",
  network:        "NETZWERK",
  constellation:  "KONSTELL."
};

export const CLUSTER_LABELS = {
  genesis:     "Genesis-Core",
  exploration: "Exploration",
  stable:      "Stabiler Cl.",
  memory:      "Gedächtnis",
  relay:       "Relay-Hub"
};
