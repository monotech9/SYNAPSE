/**
 * archetypeData.js — DNA-Archetypen: Icons, Farben und deutsche Namen
 *
 * GDD §3-4: Persönlichkeits-Archetypen des Netzwerks.
 */

// Archetyp → Icon + Farbe
export const ARCHETYPE_ICONS = {
  pioneer:    { icon: "▲", color: "#34d399" },
  bridge:     { icon: "◆", color: "#60a5fa" },
  wind:       { icon: "◊", color: "#38bdf8" },
  lighthouse: { icon: "★", color: "#fbbf24" },
  flame:      { icon: "✦", color: "#f87171" },
  heart:      { icon: "♥", color: "#f9a8d4" },
  bolt:       { icon: "⚡", color: "#facc15" },
  stone:      { icon: "■", color: "#64748b" },
  nomad:      { icon: "○", color: "#22d3ee" },
  sage:       { icon: "◐", color: "#818cf8" },
  guardian:   { icon: "▼", color: "#2dd4bf" },
  seeker:     { icon: "?", color: "#a78bfa" },
};

// Archetyp → Name auf Deutsch
export const ARCHETYPE_NAMES_DE = {
  pioneer:    "Pionier",
  bridge:     "Brücke",
  wind:       "Wind",
  lighthouse: "Leuchtturm",
  flame:      "Flamme",
  heart:      "Herz",
  bolt:       "Blitz",
  stone:      "Fels",
  nomad:      "Nomade",
  sage:       "Sage",
  guardian:   "Hüter",
  seeker:     "Sucher",
};

// Hilfsfunktion: Archetyp-Metadaten abrufen (icon + color)
export function getArchetypeMeta(archId) {
  return ARCHETYPE_ICONS[archId] || { icon: "◆", color: "#a78bfa" };
}

// Hilfsfunktion: Archetyp-Name (Deutsch) abrufen
export function getArchetypeNameDe(archId, fallbackName) {
  return ARCHETYPE_NAMES_DE[archId] || fallbackName || archId;
}
