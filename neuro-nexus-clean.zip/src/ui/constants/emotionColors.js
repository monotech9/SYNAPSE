/**
 * emotionColors.js — Farb-Mappings für Emotionen und Mood-States
 *
 * Zentrale Definition aller Emotion→Farbe und Mood→Farbe Mappings.
 * Nur hier ändern, alle Updater greifen auf diese Konstanten zu.
 */

// Emotion → Farbe (OCC-Modell, 14 Emotionen)
export const EMOTION_COLORS = {
  joy:            "#ffd166",
  hope:           "#7fffaa",
  pride:          "#ff9e5e",
  love:           "#ff6b9d",
  wonder:         "#c478ff",
  calm:           "#66ffdb",
  satisfaction:   "#a8e6cf",
  curiosity:      "#48ffa3",
  distress:       "#6a7a8a",
  fear:           "#ff7878",
  disappointment: "#8a7a6a",
  shame:          "#9a6a8a",
  dislike:        "#7a8a6a",
  tension:        "#ffaa44",
};

// MoodStateMachine → Farbe (8 Stimmungen, GDD §5)
export const MOOD_STATE_COLORS = {
  calm:        "#38bdf8",   // Ruhig — cyan
  excited:     "#fbbf24",   // Aufgeregt — amber
  tense:       "#f59e0b",   // Angespannt — orange
  sad:         "#818cf8",   // Traurig — indigo
  absent:      "#475569",   // Abwesend — slate
  focused:     "#34d399",   // Fokussiert — green
  confused:    "#ec4899",   // Verwirrt — pink
  harmonious:  "#a78bfa",   // Harmonisch — violet
};

// MoodStateMachine → Label (Deutsch)
export const MOOD_STATE_LABELS_DE = {
  calm:        "Ruhig",
  excited:     "Aufgeregt",
  tense:       "Angespannt",
  sad:         "Traurig",
  absent:      "Abwesend",
  focused:     "Fokussiert",
  confused:    "Verwirrt",
  harmonious:  "Harmonisch",
};
