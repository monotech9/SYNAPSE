/**
 * constants/index.js — Re-Export aller Konstanten-Module
 *
 * Einziger Import-Punkt für alle HUD-Konstanten.
 * Import-Syntax: import { EMOTION_COLORS, GROWTH_LABELS, ... } from "../constants/index.js";
 */

export { EMOTION_COLORS, MOOD_STATE_COLORS, MOOD_STATE_LABELS_DE } from "./emotionColors.js";
export { DRIVE_COLORS } from "./driveColors.js";
export { ARCHETYPE_ICONS, ARCHETYPE_NAMES_DE, getArchetypeMeta, getArchetypeNameDe } from "./archetypeData.js";
export { GROWTH_LABELS, CLUSTER_LABELS } from "./growthLabels.js";
export { LOG } from "./logTemplates.js";
export { maybeAIThought, SLEEP_MESSAGES } from "./aiThoughts.js";
export { TOOLTIP_DATA } from "./tooltipData.js";
export { SLEEP_INDICATOR_MAP } from "./sleepStates.js";
