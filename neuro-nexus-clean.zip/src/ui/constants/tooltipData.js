/**
 * tooltipData.js — Fachbegriffe und ihre Erklärungen für das Tooltip-System
 */

export const TOOLTIP_DATA = {
  "Prädiktionsfehler": {
    title: "Prädiktionsfehler",
    body: "Differenz zwischen erwartetem und tatsächlichem Signal. Hohe Werte treiben Lernen und Plastizität, aber auch Stress."
  },
  "Freie Energie": {
    title: "Freie Energie",
    body: "Maß für die Überraschung des Systems. Niedrig = das Netzwerk hat ein stabiles Modell seiner Welt. Hoch = Unvorhersehbarkeit."
  },
  "Phasenraum": {
    title: "Phasenraum",
    body: "Visualisierung des Systemzustands. Position = aktueller Zustand, Trajektorie = wie sich das System über Zeit entwickelt."
  },
  "Metabol.": {
    title: "Metabolismus",
    body: "Energetischer Stoffwechsel des Netzwerks. Hohe Werte = aktives Wachstum, niedrige = Ruhe oder Erschöpfung."
  },
  "Plastiz.": {
    title: "Plastizität",
    body: "Fähigkeit des Netzwerks, neue Verbindungen zu bilden. Hohe Plastizität ermöglicht schnellere Synapsenbildung."
  },
  "Resonanz": {
    title: "Resonanz",
    body: "Wie stark das Netzwerk auf externe Signale reagiert. Hohe Resonanz = empfindlich für Impulse."
  },
  "Kohärenz": {
    title: "Kohärenz",
    body: "Grad der synchronen Aktivität im Netzwerk. Bei hoher Kohärenz feuern viele Neuronen gemeinsam — ein Indikator für integrierte Verarbeitung."
  },
  "Bewusstsein": {
    title: "Bewusstseinsindex",
    body: "Zusammensetzung aus Kohärenz, Integration und Metainformation. Experimenteller Indikator für emergente Bewusstseinszustände."
  },
  "Topologie": {
    title: "Netzwerk-Topologie",
    body: "Strukturelle Anordnung der Cluster und Verbindungen. Das Radar zeigt die räumliche Verteilung aktiver Cluster."
  },
  "Emotion": {
    title: "Emotionsmatrix",
    body: "OCC-basiertes Appraisal-System mit 14 Emotionen. Emotionen modulieren Wachstum, Aufmerksamkeit und Schlaf."
  },
  "Schlaf": {
    title: "Schlafzyklus",
    body: "NREM: Konsolidierung starker Erinnerungen (Hebbian Replay) + synaptisches Downscaling. REM: Generative Träume bilden neue Assoziationen."
  }
};
