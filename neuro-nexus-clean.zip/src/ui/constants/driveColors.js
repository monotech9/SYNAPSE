/**
 * driveColors.js — Farb-Mapping für intrinsische Drives (GDD §8)
 */

export const DRIVE_COLORS = {
  curiosity:   "rgba(80,220,255,0.8)",
  competence:  "rgba(72,255,163,0.7)",
  autonomy:    "rgba(255,200,80,0.8)",
  coherence:   "rgba(140,100,220,0.7)",
  homeostasis: "rgba(255,140,100,0.7)",
};
