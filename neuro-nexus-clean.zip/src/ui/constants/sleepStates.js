/**
 * sleepStates.js — Schlaf-Indikator State-Mapping
 *
 * Mappt Schlaf-Phasen auf CSS-Klassen und Display-Labels.
 */

export const SLEEP_INDICATOR_MAP = {
  WAKE:      { cls: "sleep-indicator--wake",   label: "WAKE" },
  NREM:      { cls: "sleep-indicator--nrem",   label: "NREM" },
  REM:       { cls: "sleep-indicator--rem",    label: "REM" },
  WAKING_UP: { cls: "sleep-indicator--waking", label: "WAKING" },
};
