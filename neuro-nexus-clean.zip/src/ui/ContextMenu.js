/**
 * ContextMenu
 * 
 * Right-click context menu system for canvas and UI elements.
 * Provides contextual actions without cluttering the interface.
 * 
 * Features:
 * - Dynamic menu items based on target
 * - Submenu support
 * - Keyboard navigation
 * - Icons & descriptions
 * - Callbacks on selection
 */

export class ContextMenu {
  constructor(canvas, options = {}) {
    this.canvas = canvas;
    this.isOpen = false;
    this.x = 0;
    this.y = 0;
    this.menuItems = [];

    this.config = {
      maxWidth: options.maxWidth ?? 250,
      offset: options.offset ?? 5,
    };

    this.listeners = new Map();
    this._createMenuElement();
    this._attachEventListeners();
  }

  /**
   * Create menu DOM element
   */
  _createMenuElement() {
    this.menu = document.createElement('div');
    this.menu.className = 'context-menu glass-panel';
    this.menu.style.position = 'fixed';
    this.menu.style.display = 'none';
    this.menu.style.zIndex = '10000';
    this.menu.style.minWidth = '150px';
    this.menu.style.maxWidth = `${this.config.maxWidth}px`;
    this.menu.style.borderRadius = '4px';
    this.menu.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.3)';
    this.menu.setAttribute('role', 'menu');

    document.body.appendChild(this.menu);
  }

  /**
   * Attach event listeners
   */
  _attachEventListeners() {
    this.canvas.addEventListener('contextmenu', (e) => this._onContextMenu(e));
    document.addEventListener('click', () => this.close());
    document.addEventListener('keydown', (e) => this._onKeyDown(e));
  }

  /**
   * Handle right-click
   */
  _onContextMenu(event) {
    event.preventDefault();
    event.stopPropagation();

    this.x = event.clientX;
    this.y = event.clientY;

    const target = event.target;
    this._buildMenu(target);
    this.open();
  }

  /**
   * Build menu items based on target
   */
  _buildMenu(target) {
    this.menuItems = [];

    // Determine target type
    const nodeId = target.getAttribute('data-node-id');
    const clusterId = target.getAttribute('data-cluster-id');
    const isNode = target.classList.contains('node');
    const isCluster = target.classList.contains('cluster');

    // Add items based on context
    if (isNode && nodeId) {
      this._addNodeMenuItems(nodeId, target);
    } else if (isCluster && clusterId) {
      this._addClusterMenuItems(clusterId, target);
    } else {
      this._addCanvasMenuItems(this.x, this.y);
    }

    this._renderMenu();
  }

  /**
   * Add node context menu items
   */
  _addNodeMenuItems(nodeId, element) {
    this.menuItems = [
      {
        icon: '🔍',
        label: 'Inspect',
        callback: () => this._emit('inspect-node', { nodeId }),
      },
      {
        icon: '⚡',
        label: 'Send Impulse',
        callback: () => this._emit('impulse-to-node', { nodeId }),
      },
      { separator: true },
      {
        icon: '📍',
        label: 'Track Node',
        callback: () => this._emit('focus-node', { nodeId }),
      },
      { separator: true },
      {
        icon: '🗑️',
        label: 'Delete Node',
        callback: () => {
          if (confirm('Delete this node?')) {
            this._emit('delete-node', { nodeId });
          }
        },
        dangerous: true,
      },
    ];
  }

  /**
   * Add cluster context menu items
   */
  _addClusterMenuItems(clusterId, element) {
    this.menuItems = [
      {
        icon: '📊',
        label: 'Cluster Stats',
        callback: () => this._emit('cluster-stats', { clusterId }),
      },
      {
        icon: '🎯',
        label: 'Focus Cluster',
        callback: () => this._emit('focus-cluster', { clusterId }),
      },
      { separator: true },
      {
        icon: '🎨',
        label: 'Change Color',
        submenu: [
          {
            label: '🔴 Red',
            callback: () => this._emit('recolor-cluster', { clusterId, color: 'red' }),
          },
          {
            label: '🟢 Green',
            callback: () => this._emit('recolor-cluster', { clusterId, color: 'green' }),
          },
          {
            label: '🔵 Blue',
            callback: () => this._emit('recolor-cluster', { clusterId, color: 'blue' }),
          },
        ],
      },
    ];
  }

  /**
   * Add canvas context menu items
   */
  _addCanvasMenuItems(x, y) {
    this.menuItems = [
      {
        icon: '➕',
        label: 'Add Neuron',
        callback: () => this._emit('add-neuron', { x, y }),
      },
      {
        icon: '⚡',
        label: 'Add Impulse',
        callback: () => this._emit('add-impulse', { x, y }),
      },
      { separator: true },
      {
        icon: '👁️',
        label: 'Focus Here',
        callback: () => this._emit('focus-point', { x, y }),
      },
      {
        icon: '↺',
        label: 'Reset View',
        callback: () => this._emit('reset-view'),
      },
    ];
  }

  /**
   * Render menu items to DOM
   */
  _renderMenu() {
    this.menu.innerHTML = '';

    for (const item of this.menuItems) {
      if (item.separator) {
        const sep = document.createElement('div');
        sep.className = 'context-menu-separator';
        sep.style.height = '1px';
        sep.style.backgroundColor = 'rgba(80, 180, 255, 0.1)';
        sep.style.margin = '4px 0';
        this.menu.appendChild(sep);
        continue;
      }

      const itemEl = document.createElement('div');
      itemEl.className = 'context-menu-item';
      itemEl.setAttribute('role', 'menuitem');
      itemEl.style.padding = '8px 12px';
      itemEl.style.cursor = 'pointer';
      itemEl.style.display = 'flex';
      itemEl.style.alignItems = 'center';
      itemEl.style.gap = '8px';
      itemEl.style.fontSize = '13px';
      itemEl.style.userSelect = 'none';
      itemEl.style.transition = 'background 0.2s';

      if (item.dangerous) {
        itemEl.style.color = '#ff6b6b';
      }

      // Icon
      if (item.icon) {
        const icon = document.createElement('span');
        icon.style.fontSize = '14px';
        itemEl.appendChild(icon);
        icon.textContent = item.icon;
      }

      // Label
      const label = document.createElement('span');
      label.textContent = item.label;
      label.style.flex = '1';
      itemEl.appendChild(label);

      // Submenu indicator
      if (item.submenu) {
        const arrow = document.createElement('span');
        arrow.textContent = '▶';
        arrow.style.fontSize = '10px';
        arrow.style.opacity = '0.5';
        itemEl.appendChild(arrow);
      }

      // Hover effect
      itemEl.addEventListener('mouseenter', () => {
        itemEl.style.background = 'rgba(80, 180, 255, 0.15)';
      });

      itemEl.addEventListener('mouseleave', () => {
        itemEl.style.background = 'transparent';
      });

      // Click handler
      itemEl.addEventListener('click', () => {
        if (item.submenu) {
          this._showSubmenu(item.submenu, itemEl);
        } else {
          item.callback?.();
          this.close();
        }
      });

      this.menu.appendChild(itemEl);
    }
  }

  /**
   * Show submenu
   */
  _showSubmenu(items, parentEl) {
    const submenu = document.createElement('div');
    submenu.className = 'context-submenu glass-panel';
    submenu.style.position = 'fixed';
    submenu.style.display = 'flex';
    submenu.style.flexDirection = 'column';
    submenu.style.gap = '4px';
    submenu.style.zIndex = '10001';
    submenu.style.minWidth = '150px';

    const parentRect = parentEl.getBoundingClientRect();
    submenu.style.left = `${parentRect.right + 5}px`;
    submenu.style.top = `${parentRect.top}px`;

    for (const item of items) {
      const itemEl = document.createElement('div');
      itemEl.className = 'context-submenu-item';
      itemEl.style.padding = '8px 12px';
      itemEl.style.cursor = 'pointer';
      itemEl.style.fontSize = '13px';
      itemEl.textContent = item.label;

      itemEl.addEventListener('mouseenter', () => {
        itemEl.style.background = 'rgba(80, 180, 255, 0.15)';
      });

      itemEl.addEventListener('mouseleave', () => {
        itemEl.style.background = 'transparent';
      });

      itemEl.addEventListener('click', () => {
        item.callback?.();
        submenu.remove();
        this.close();
      });

      submenu.appendChild(itemEl);
    }

    document.body.appendChild(submenu);

    // Close submenu on click elsewhere
    const closeSubmenu = () => {
      submenu.remove();
      document.removeEventListener('click', closeSubmenu);
    };

    setTimeout(() => {
      document.addEventListener('click', closeSubmenu);
    }, 100);
  }

  /**
   * Handle keyboard navigation
   */
  _onKeyDown(event) {
    if (!this.isOpen) return;

    if (event.key === 'Escape') {
      this.close();
    }

    if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
      event.preventDefault();
      // Implement keyboard navigation if needed
    }
  }

  /**
   * Open menu at stored position
   */
  open() {
    this.menu.style.display = 'flex';
    this.menu.style.flexDirection = 'column';
    this.menu.style.left = `${this.x}px`;
    this.menu.style.top = `${this.y}px`;

    // Adjust if menu goes off-screen
    const rect = this.menu.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
      this.menu.style.left = `${window.innerWidth - rect.width - 10}px`;
    }
    if (rect.bottom > window.innerHeight) {
      this.menu.style.top = `${window.innerHeight - rect.height - 10}px`;
    }

    this.isOpen = true;
  }

  /**
   * Close menu
   */
  close() {
    this.menu.style.display = 'none';
    this.isOpen = false;
  }

  /**
   * Register event listener
   */
  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event).add(callback);
    return () => this.listeners.get(event).delete(callback);
  }

  /**
   * Emit event
   */
  _emit(event, data) {
    const callbacks = this.listeners.get(event);
    if (callbacks) {
      callbacks.forEach((cb) => cb(data));
    }
  }

  /**
   * Destroy context menu
   */
  destroy() {
    this.menu.remove();
    this.listeners.clear();
  }
}

