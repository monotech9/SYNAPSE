/**
 * main.js — Einziger Einstiegspunkt
 *
 * Normale Simulation:  index.html
 * Debug-Modus:         index.html?debug=true
 *   Aktiviert DiagnosticsRecorder, DebugOverlay, DebugControls
 *   + frischer Start (kein Persist-Loading)
 */
import { createNeuroNexusApp } from "./app.js";

const params = new URLSearchParams(location.search);
const isDebug = params.get("debug") === "true" || params.get("debug") === "1";

// Globaler Error-Handler: HUD sichtbar machen auch bei Bootstrap-Crash
window.addEventListener("error", (e) => {
  // Harmlose Browser-Warnung ignorieren: tritt auf, wenn ein ResizeObserver-
  // Callback nicht innerhalb eines Frames abschließt (z.B. weil er selbst
  // ein Resize/Layout auslöst). Kein echter Fehler, kein Stacktrace nötig.
  const msg = (e.error && e.error.message) || e.message || "";
  if (msg.includes("ResizeObserver loop")) return;

  console.error("[Neuro Nexus] Uncaught error:", e.error || e.message);
  const wrapper = document.querySelector(".hud-wrapper");
  if (wrapper) wrapper.classList.add("is-ready");
  const dt = document.getElementById("drawerToggle");
  if (dt) dt.classList.add("is-ready");
});

function safeBoot() {
  try {
    createNeuroNexusApp();
  } catch (bootErr) {
    console.error("[Neuro Nexus] Bootstrap crash:", bootErr);
    // HUD trotzdem sichtbar machen
    const wrapper = document.querySelector(".hud-wrapper");
    if (wrapper) wrapper.classList.add("is-ready");
    const dt = document.getElementById("drawerToggle");
    if (dt) dt.classList.add("is-ready");
  }
}

if (isDebug) {
  // Debug-Modus: Lade Debug-Module dynamisch
  import("./debug-bootstrap.js").then(({ bootstrapDebug }) => {
    bootstrapDebug();
  }).catch(err => {
    console.error("[Neuro Nexus] Debug-Modus konnte nicht geladen werden:", err);
    // Fallback: normale Simulation
    safeBoot();
  });
} else {
  safeBoot();
}
