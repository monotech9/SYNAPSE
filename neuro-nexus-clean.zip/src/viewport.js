
import { CONFIG } from "./config.js";
export function readViewport() {
  const viewport = window.visualViewport;

  return {
    width: Math.max(1, Math.floor(viewport ? viewport.width : window.innerWidth)),
    height: Math.max(1, Math.floor(viewport ? viewport.height : window.innerHeight)),
    dpr: Math.min(window.devicePixelRatio || 1, CONFIG.maxDevicePixelRatio)
  };
}

export function resizeCanvas(canvas, context, viewport) {
  canvas.width = Math.round(viewport.width * viewport.dpr);
  canvas.height = Math.round(viewport.height * viewport.dpr);
  canvas.style.width = `${viewport.width}px`;
  canvas.style.height = `${viewport.height}px`;

  context.setTransform(viewport.dpr, 0, 0, viewport.dpr, 0, 0);
  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = "high";
}
