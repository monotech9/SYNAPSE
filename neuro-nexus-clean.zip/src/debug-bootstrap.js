/**
 * debug-bootstrap.js — Dynamisch geladen wenn ?debug=true
 *
 * Setzt Debug-Flags, startet App mit Debug-Hooks,
 * initialisiert DebugControls, DebugOverlay, DiagnosticsRecorder.
 */
import { createNeuroNexusApp } from "./app.js";
import { resetPersistentState } from "./persistence.js";
import { DebugControls } from "./diagnostics/DebugControls.js";
import { DebugOverlay } from "./diagnostics/DebugOverlay.js";
import { DiagnosticsRecorder } from "./diagnostics/DiagnosticsRecorder.js";

export function bootstrapDebug() {
  // Debug-Flags
  window.NEURO_NEXUS_DEBUG_LAB       = true;
  window.NEURO_NEXUS_DEBUG_FRESH_BOOT = true;
  window.NEURO_NEXUS_FORCE_FRESH_START = true;
  window.NEURO_NEXUS_DEBUG_NO_PERSIST = true;
  window.NEURO_NEXUS_SKIP_SAVE       = true;

  // Debug-CSS dynamisch laden
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = "./src/styles/debug.css";
  document.head.appendChild(link);

  function forceRuntimeReset(createdApp) {
    try { resetPersistentState(); } catch (_) {}
    createdApp.simulation.hardResetRuntime();
    createdApp.resize();
  }

  let diagnostics = null;
  let debugOverlay = null;

  const app = createNeuroNexusApp({
    afterCreate(createdApp) {
      forceRuntimeReset(createdApp);

      diagnostics = new DiagnosticsRecorder(createdApp.simulation);
      debugOverlay = new DebugOverlay(createdApp.simulation);
      new DebugControls({
        onReset: () => {
          forceRuntimeReset(createdApp);
          diagnostics?.resetLocalState?.();
          debugOverlay?.refresh?.(performance.now());
        },
        onFreshRecording: () => {
          forceRuntimeReset(createdApp);
          diagnostics?.resetLocalState?.();
          diagnostics?.start();
        }
      });

      // Snapshot-Export Button
      const exportBtn = document.createElement("button");
      exportBtn.textContent = "\ud83d\udcf8 Snapshot exportieren";
      exportBtn.style.cssText = [
        "position:fixed", "bottom:16px", "right:16px", "z-index:1000",
        "padding:8px 16px", "font-size:13px", "font-weight:500",
        "border:1px solid rgba(100,180,255,0.4)", "border-radius:8px",
        "background:rgba(20,40,80,0.85)", "color:rgba(200,230,255,0.95)",
        "cursor:pointer", "backdrop-filter:blur(8px)", "transition:all 0.2s ease"
      ].join(";");
      exportBtn.onmouseenter = () => {
        exportBtn.style.background = "rgba(30,60,120,0.95)";
        exportBtn.style.borderColor = "rgba(150,200,255,0.7)";
      };
      exportBtn.onmouseleave = () => {
        exportBtn.style.background = "rgba(20,40,80,0.85)";
        exportBtn.style.borderColor = "rgba(100,180,255,0.4)";
      };
      exportBtn.onclick = () => window.NeuroNexusDebug.exportSnapshot();
      document.body.appendChild(exportBtn);

      window.NeuroNexusDebug = {
        app: createdApp,
        simulation: createdApp.simulation,
        diagnostics, overlay: debugOverlay,
        resetNetwork() { forceRuntimeReset(createdApp); diagnostics?.resetLocalState?.(); },
        resetAndRecord() { forceRuntimeReset(createdApp); diagnostics?.resetLocalState?.(); diagnostics?.start(); },
        startRecording() { diagnostics.start(); },
        stopRecording()  { diagnostics.stop("manual"); },
        exportSnapshot() {
          try {
            const canvas = createdApp.canvas;
            const link = document.createElement("a");
            link.download = `neuro-nexus-${Date.now()}.png`;
            link.href = canvas.toDataURL("image/png");
            link.click();
          } catch (e) { console.warn("PNG-Export fehlgeschlagen:", e); }
          try {
            const snapshot = createdApp.simulation.getCompactSnapshot(performance.now() / 1000);
            const fullState = {
              snapshot, identity: createdApp.simulation.identity,
              personality: createdApp.simulation.personality,
              growth: createdApp.simulation.serializeGrowthState(),
              diagnosticCounters: createdApp.simulation.diagnosticCounters,
              timestamp: new Date().toISOString()
            };
            const blob = new Blob([JSON.stringify(fullState, null, 2)], { type: "application/json" });
            const link = document.createElement("a");
            link.download = `neuro-nexus-${Date.now()}.json`;
            link.href = URL.createObjectURL(blob);
            link.click();
            setTimeout(() => URL.revokeObjectURL(link.href), 1000);
          } catch (e) { console.warn("JSON-Export fehlgeschlagen:", e); }
        }
      };

      const params = new URLSearchParams(location.search);
      if (params.get("record") === "1") {
        setTimeout(() => diagnostics.start(), 500);
      }
    },
    onFrame({ now, frameMs, timeSeconds }) {
      diagnostics?.update(timeSeconds);
      debugOverlay?.tick(now, frameMs);
    }
  });

  window.NeuroNexusApp = app;
  console.info("[Neuro Nexus] Debug-Modus aktiv — Diagnostics geladen.");
}
