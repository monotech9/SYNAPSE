export const NETWORK_NAMES = Object.freeze([
  "AURORA",
  "LYRA",
  "NOVA",
  "ELARA",
  "VEGA",
  "SOLEN",
  "MIRA",
  "ORION",
  "NYX",
  "LUMEN",
  "AION",
  "SOMA",
  "IRIS",
  "ECHO",
  "NOEMA",
  "VANTA"
]);

export const MEMORY_EVENT_LABELS = Object.freeze({
  firstTrace: "erste Spur",
  strongTrace: "fester Pfad",
  autonomousPulse: "Eigenimpuls",
  denseBridge: "ferne Brücke",
  firstBud: "erste Knospe",
  clusterStabilized: "neue Region",
  growthPause: "stille Reife",
  deepResponse: "tiefe Antwort",
  scar: "Narbe"
});
