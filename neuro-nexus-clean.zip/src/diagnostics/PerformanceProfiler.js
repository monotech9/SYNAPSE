/**
 * PerformanceProfiler
 * 
 * Tracks and reports performance metrics for all simulation systems.
 * Enables identification of bottlenecks and optimization opportunities.
 * 
 * Features:
 * - Per-system timing
 * - Frame-by-frame profiling
 * - Aggregated statistics (min, max, avg, p95, p99)
 * - Real-time dashboard
 * - Export to JSON
 */

export class PerformanceProfiler {
  constructor(config = {}) {
    this.enabled = config.enabled ?? true;
    this.maxHistorySize = config.maxHistorySize ?? 300; // ~5 seconds at 60fps
    this.sampleRate = config.sampleRate ?? 1.0; // 0-1

    this.marks = new Map(); // Map<string, number[]> — per-system timings
    this.frameTimings = []; // Array of frame-level aggregates
    this.currentFrameStart = null;

    this.systemMetrics = new Map(); // Detailed stats per system
    this.listeners = new Set();
  }

  /**
   * Mark the start of a measurement
   */
  mark(label) {
    if (!this.enabled || Math.random() > this.sampleRate) return;

    const now = performance.now();
    if (!this.marks.has(label)) {
      this.marks.set(label, []);
    }

    // Store as marker with timestamp to compute duration later
    if (!this.marks.get(label)._starts) {
      this.marks.get(label)._starts = new Map();
    }
    this.marks.get(label)._starts.set(`${Date.now()}-${Math.random()}`, now);
  }

  /**
   * Measure elapsed time since last mark()
   */
  measure(label) {
    if (!this.enabled) return null;

    const now = performance.now();
    const timings = this.marks.get(label);

    if (!timings || !timings._starts || timings._starts.size === 0) {
      return null;
    }

    const startKey = Array.from(timings._starts.keys())[0];
    const startTime = timings._starts.get(startKey);
    const duration = now - startTime;

    timings._starts.delete(startKey);
    timings.push(duration);

    // Keep history bounded
    if (timings.length > this.maxHistorySize) {
      timings.shift();
    }

    return duration;
  }

  /**
   * Wrap a function with automatic profiling
   */
  profile(label, fn) {
    return (...args) => {
      if (!this.enabled) return fn(...args);

      this.mark(label);
      try {
        const result = fn(...args);
        // Handle async
        if (result instanceof Promise) {
          return result.finally(() => {
            this.measure(label);
          });
        }
        this.measure(label);
        return result;
      } catch (error) {
        this.measure(label);
        throw error;
      }
    };
  }

  /**
   * Compute detailed statistics for a label
   */
  getStats(label) {
    const timings = this.marks.get(label);
    if (!timings || timings.length === 0) {
      return null;
    }

    const sorted = [...timings].sort((a, b) => a - b);
    const sum = sorted.reduce((a, b) => a + b, 0);
    const avg = sum / sorted.length;
    const min = sorted[0];
    const max = sorted[sorted.length - 1];

    // Percentiles
    const getPercentile = (p) => {
      const idx = Math.ceil((p / 100) * sorted.length) - 1;
      return sorted[Math.max(0, idx)];
    };

    return {
      label,
      count: sorted.length,
      min,
      max,
      avg,
      median: getPercentile(50),
      p95: getPercentile(95),
      p99: getPercentile(99),
      total: sum,
    };
  }

  /**
   * Report all statistics as a table
   */
  report() {
    const stats = Array.from(this.marks.keys())
      .map((label) => this.getStats(label))
      .filter((s) => s !== null)
      .sort((a, b) => b.avg - a.avg); // Slowest first

    console.group('⏱️ NeuroNexus Performance Report');
    console.table(
      stats.map((s) => ({
        System: s.label,
        Count: s.count,
        'Avg (ms)': s.avg.toFixed(3),
        'Min (ms)': s.min.toFixed(3),
        'Max (ms)': s.max.toFixed(3),
        'P95 (ms)': s.p95.toFixed(3),
        'P99 (ms)': s.p99.toFixed(3),
        'Total (ms)': s.total.toFixed(2),
      }))
    );
    console.groupEnd();

    return stats;
  }

  /**
   * Frame-level snapshot
   */
  snapshotFrame() {
    if (!this.enabled) return;

    const frameStats = Array.from(this.marks.keys()).map((label) => ({
      label,
      avg: this.getStats(label)?.avg ?? 0,
    }));

    this.frameTimings.push({
      timestamp: performance.now(),
      systems: frameStats,
      totalTime: frameStats.reduce((sum, s) => sum + s.avg, 0),
    });

    if (this.frameTimings.length > this.maxHistorySize) {
      this.frameTimings.shift();
    }

    this.listeners.forEach((listener) => listener(frameStats));
  }

  /**
   * Export metrics as JSON
   */
  export() {
    const exported = {
      timestamp: new Date().toISOString(),
      systems: Array.from(this.marks.keys()).map((label) => this.getStats(label)),
      frameHistory: this.frameTimings,
    };

    const json = JSON.stringify(exported, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `neuro-nexus-profile-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);

    return exported;
  }

  /**
   * Listen to frame updates
   */
  onFrame(callback) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  /**
   * Reset all metrics
   */
  reset() {
    this.marks.clear();
    this.frameTimings = [];
  }

  /**
   * Get current frame rate estimate
   */
  getFrameRate() {
    if (this.frameTimings.length < 2) return 0;

    const last = this.frameTimings[this.frameTimings.length - 1];
    const prev = this.frameTimings[Math.max(0, this.frameTimings.length - 60)];
    const deltaMs = last.timestamp - prev.timestamp;
    const frames = this.frameTimings.length - Math.max(0, this.frameTimings.length - 60);

    return deltaMs > 0 ? Math.round((frames / deltaMs) * 1000) : 0;
  }
}

/**
 * Global profiler singleton
 */
let profilerInstance = null;

export function getProfiler() {
  if (!profilerInstance) {
    profilerInstance = new PerformanceProfiler();
  }
  return profilerInstance;
}

export function initProfiler(config) {
  if (profilerInstance) {
    console.warn('PerformanceProfiler already initialized');
    return profilerInstance;
  }
  profilerInstance = new PerformanceProfiler(config);
  return profilerInstance;
}
