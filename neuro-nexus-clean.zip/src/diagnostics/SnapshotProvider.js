import { CONFIG } from "../config.js";
import { serializeIdentity } from "../simulation/identity.js";
import { serializeMemoryState } from "../simulation/memory.js";
import { cloneDiagnosticCounters } from "./DiagnosticsRecorder.js";
import { clamp, average} from "../utils/math.js";

/**
 * SnapshotProvider — erstellt diagnostische Schnappschüsse des
 * Simulationszustands für Debug-UI und Test-Runs.
 *
 * Folgt demselben Pattern wie die System-Module:
 * erhält die Simulation im Konstruktor.
 */
export class SnapshotProvider {
  constructor(simulation) {
    this.simulation = simulation;
  }

  get world() { return this.simulation.world; }
  get personality() { return this.simulation.personality; }
  get memory() { return this.simulation.memory; }
  get identity() { return this.simulation.identity; }
  get persistentState() { return this.simulation.persistentState; }
  get diagnosticCounters() { return this.simulation.diagnosticCounters; }

  getDiagnosticSnapshot(elapsedSeconds = 0) {
    const world = this.world;
    const edges = world.edges;
    const internalEdges = edges.filter((edge) => edge.a.cluster === edge.b.cluster);
    const bridgeEdges = edges.filter((edge) => edge.bridge);
    const tracedEdges = edges.filter((edge) => (edge.identityTrace || 0) > 0.08);
    const activeEdges = edges.filter((edge) => ((edge.a.activation + edge.b.activation) * 0.5) > 0.22 || (edge.visualActivity || 0) > 0.18);
    const currentStrongestTrace = Math.max(0, ...edges.map((edge) => edge.identityTrace || 0));
    const averageScreenCoverage = estimateScreenCoverage(this.simulation);
    const visibleActivationScore = average(world.clusters.map((cluster) => cluster.activityMemory + cluster.memoryStrength * 0.65)) + average(edges.map((edge) => edge.visualActivity || 0)) * 0.45;

    return {
      t: roundDiagnostic(elapsedSeconds, 2),
      age: roundDiagnostic(world.age, 2),
      growthStage: world.growthStage,
      previousGrowthStage: world.previousGrowthStage,
      maturity: roundDiagnostic(world.maturity, 4),
      identity: serializeIdentity(this.identity),
      personality: serializeDiagnosticPersonality(this.personality),
      interactionCount: Number(this.persistentState.interactionCount || 0),
      clusterCount: world.clusters.length,
      totalNodes: this.simulation.totalNodeCount(),
      totalEdges: edges.length,
      internalEdges: internalEdges.length,
      bridgeEdges: bridgeEdges.length,
      tracedEdges: tracedEdges.length,
      activeEdges: activeEdges.length,
      currentStrongestTrace: roundDiagnostic(currentStrongestTrace, 4),
      averageScreenCoverage: roundDiagnostic(averageScreenCoverage, 4),
      visibleActivationScore: roundDiagnostic(visibleActivationScore, 4),
      pulses: world.pulses.length,
      injectedWaves: world.injectedWaves.length,
      timers: {
        growth: roundDiagnostic(world.growthTimer, 2),
        connectionGrowth: roundDiagnostic(world.connectionGrowthTimer, 2),
        spontaneous: roundDiagnostic(world.spontaneousTimer, 2),
        ambient: roundDiagnostic(world.ambientActivityTimer, 2),
        path: roundDiagnostic(world.pathSignalTimer, 2)
      },
      edgeStats: {
        averageWeight: roundDiagnostic(average(edges.map((edge) => edge.weight)), 4),
        averageMemory: roundDiagnostic(average(edges.map((edge) => edge.memory)), 4),
        averageTrace: roundDiagnostic(average(edges.map((edge) => edge.identityTrace || 0)), 4),
        strongestTrace: roundDiagnostic(currentStrongestTrace, 4),
        averageBridgeWeight: roundDiagnostic(average(bridgeEdges.map((edge) => edge.weight)), 4),
        averageVisualActivity: roundDiagnostic(average(edges.map((edge) => edge.visualActivity || 0)), 4),
        preferredPathEdges: edges.filter((edge) => (edge.identityTrace || 0) > Math.max(0.14, currentStrongestTrace * 0.66) || (edge.pathPulseGlow || 0) > 0.08).length
      },
      memory: serializeMemoryState(this.memory),
      counters: cloneDiagnosticCounters(this.diagnosticCounters),
      clusters: world.clusters.map((cluster) => this.getDiagnosticClusterSnapshot(cluster)),
      relationship: this.simulation.relationshipLayer?.getSnapshot() ?? null,
      spontaneity: this.simulation.spontaneityEngine?.getSnapshot() ?? null,
      moodFeedback: this.simulation.networkMoodBridge?.getSnapshot() ?? null,
    };
  }

  getDiagnosticClusterSnapshot(cluster) {
    const internalEdges = this.world.edges.filter((edge) => edge.a.cluster === cluster && edge.b.cluster === cluster);
    const bridgeEdges = this.world.edges.filter((edge) => edge.bridge && (edge.a.cluster === cluster || edge.b.cluster === cluster));
    const activations = cluster.nodes.map((node) => node.activation);
    const traces = internalEdges.map((edge) => edge.identityTrace || 0);

    return {
      id: cluster.id,
      role: cluster.role,
      type: cluster.type,
      state: cluster.state,
      parentId: cluster.parentId,
      nodes: cluster.nodes.length,
      internalEdges: internalEdges.length,
      bridgeEdges: bridgeEdges.length,
      birthProgress: roundDiagnostic(cluster.birthProgress, 4),
      maturity: roundDiagnostic(cluster.maturity, 4),
      density: roundDiagnostic(cluster.density, 4),
      stability: roundDiagnostic(cluster.stability, 4),
      stress: roundDiagnostic(cluster.stress, 4),
      saturation: roundDiagnostic(cluster.saturation, 4),
      expansionPressure: roundDiagnostic(cluster.expansionPressure, 4),
      memoryStrength: roundDiagnostic(cluster.memoryStrength, 4),
      localActivity: roundDiagnostic(cluster.localActivity, 4),
      recentActivity: roundDiagnostic(cluster.recentActivity, 4),
      activityMemory: roundDiagnostic(cluster.activityMemory, 4),
      bridgeStrength: roundDiagnostic(cluster.bridgeStrength, 4),
      softNodeLimit: cluster.softNodeLimit,
      hardNodeLimit: cluster.hardNodeLimit,
      growthBias: roundDiagnostic(cluster.growthBias, 4),
      bridgeBias: roundDiagnostic(cluster.bridgeBias, 4),
      retentionBias: roundDiagnostic(cluster.retentionBias, 4),
      plasticityBias: roundDiagnostic(cluster.plasticityBias, 4),
      budCooldown: roundDiagnostic(cluster.budCooldown, 2),
      dormantTimer: roundDiagnostic(cluster.dormantTimer, 2),
      averageActivation: roundDiagnostic(average(activations), 4),
      maxActivation: roundDiagnostic(Math.max(0, ...activations), 4),
      averageEdgeWeight: roundDiagnostic(average(internalEdges.map((edge) => edge.weight)), 4),
      strongestTrace: roundDiagnostic(Math.max(0, ...traces), 4),
      averageTrace: roundDiagnostic(average(traces), 4),
      averageVisualActivity: roundDiagnostic(average(internalEdges.map((edge) => edge.visualActivity || 0)), 4),
      screenBounds: estimateClusterBounds(this.simulation, cluster)
    };
  }

  /**
   * Kompakter Snapshot für den 120s-Test — enthält nur das Wesentliche,
   * kein vollständiges Cluster-Dump, keine rohen Kanten-Arrays.
   * Ideal zum Kopieren/Teilen aus dem Debug-UI.
   */
  getCompactSnapshot(elapsedSeconds = 0) {
    const world = this.world;
    const edges = world.edges;
    const tracedEdges = edges.filter((e) => (e.identityTrace || 0) > 0.08);
    const strongestTrace = Math.max(0, ...edges.map((e) => e.identityTrace || 0));
    const refractoryHits = edges.reduce((n, e) => n + ((e.recentPulseCount || 0) >= CONFIG.edgeRefractoryMaxPulses ? 1 : 0), 0);

    return {
      v: 2,
      t: Math.round(elapsedSeconds),
      age: Math.round(world.age * 10) / 10,
      stage: world.growthStage,
      profile: this.personality.profile,
      clusters: world.clusters.map((c) => ({
        id: c.id,
        role: c.role,
        state: c.state,
        nodes: c.nodes.length,
        stability: Math.round(c.stability * 100) / 100,
        stress: Math.round(c.stress * 100) / 100
      })),
      edges: edges.length,
      tracedEdges: tracedEdges.length,
      strongestTrace: Math.round(strongestTrace * 1000) / 1000,
      pulses: world.pulses.length,
      refractoryHits,
      memory: {
        events: this.memory.events.slice(-6).map((e) => `${e.label} @${e.age}`),
        autonomousMoments: this.memory.autonomousMoments,
        scarCount: this.memory.scarCount
      },
      dirty: world.dirty
    };
  }
}

// ─── Module-level diagnostic helpers ────────────────────────────────

function estimateScreenCoverage(simulation) {
  const world = simulation.world;
  if (!world.clusters.length || world.width <= 0 || world.height <= 0) return 0;

  const bounds = world.clusters.map((cluster) => estimateClusterBounds(simulation, cluster));
  const minX = Math.min(...bounds.map((box) => box.left));
  const maxX = Math.max(...bounds.map((box) => box.right));
  const minY = Math.min(...bounds.map((box) => box.top));
  const maxY = Math.max(...bounds.map((box) => box.bottom));
  const coverageX = clamp((maxX - minX) / world.width, 0, 1);
  const coverageY = clamp((maxY - minY) / world.height, 0, 1);
  return (coverageX + coverageY) * 0.5;
}

function estimateClusterBounds(simulation, cluster) {
  const world = simulation.world;
  const center = cluster.center(world.currentTime || performance.now() / 1000);
  const radius = cluster.pixelRadius * simulation.camera.scale;
  const x = world.centerX + (center.x - world.centerX) * simulation.camera.scale + simulation.camera.offsetX;
  const y = world.centerY + (center.y - world.centerY) * simulation.camera.scale + simulation.camera.offsetY;

  return {
    left: roundDiagnostic(x - radius, 1),
    right: roundDiagnostic(x + radius, 1),
    top: roundDiagnostic(y - radius, 1),
    bottom: roundDiagnostic(y + radius, 1),
    width: roundDiagnostic(radius * 2, 1),
    height: roundDiagnostic(radius * 2, 1)
  };
}

function serializeDiagnosticPersonality(personality) {
  const result = {};

  for (const [key, value] of Object.entries(personality)) {
    result[key] = typeof value === "number" ? roundDiagnostic(value, 4) : value;
  }

  return result;
}
function roundDiagnostic(value, decimals = 3) {
  const factor = 10 ** decimals;
  return Math.round(Number(value || 0) * factor) / factor;
}
