export class DebugControls {
  constructor(options = {}) {
    this.onReset = options.onReset || null;
    this.onFreshRecording = options.onFreshRecording || null;
    this.onSnapshot = options.onSnapshot || null;
    this.createControls();
  }

  createControls() {
    const root = document.createElement("div");
    root.className = "debug-reset";
    root.innerHTML = `
      <button class="debug-reset__button" type="button" data-reset>Reset</button>
      <button class="debug-reset__button debug-reset__button--fresh" type="button" data-fresh>Reset + 120s</button>
      <button class="debug-reset__button debug-reset__button--snapshot" type="button" data-snapshot>📋 Snapshot</button>
    `;

    document.body.append(root);

    root.querySelector("[data-reset]").addEventListener("click", () => this.confirmAndReset(false));
    root.querySelector("[data-fresh]").addEventListener("click", () => this.confirmAndReset(true));
    root.querySelector("[data-snapshot]").addEventListener("click", () => this.copySnapshot());
  }

  copySnapshot() {
    const sim = window.NeuroNexusDebug?.simulation;
    if (!sim) {
      alert("Simulation nicht verfügbar.");
      return;
    }
    const data = sim.getCompactSnapshot();
    const text = JSON.stringify(data, null, 2);

    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        this._flashButton("[data-snapshot]", "✅ Kopiert!");
      }).catch(() => this._showSnapshotFallback(text));
    } else {
      this._showSnapshotFallback(text);
    }

    if (typeof this.onSnapshot === "function") this.onSnapshot(data);
  }

  _flashButton(selector, label) {
    const btn = document.querySelector(selector);
    if (!btn) return;
    const original = btn.textContent;
    btn.textContent = label;
    setTimeout(() => { btn.textContent = original; }, 1800);
  }

  _showSnapshotFallback(text) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.cssText = "position:fixed;top:10px;left:10px;right:10px;height:60vh;z-index:9999;font-size:11px;";
    document.body.appendChild(ta);
    ta.select();
    setTimeout(() => ta.remove(), 8000);
  }

  confirmAndReset(autoRecord) {
    const message = autoRecord
      ? "Netz komplett zurücksetzen und nach dem Reload automatisch 120s Diagnose starten?"
      : "Netz komplett zurücksetzen und neu beim Genesis Core starten?";

    if (!confirm(message)) return;

    if (autoRecord) {
      if (typeof this.onFreshRecording === "function") this.onFreshRecording();
      else if (window.NeuroNexusDebug?.resetAndRecord) window.NeuroNexusDebug.resetAndRecord();
      return;
    }

    if (typeof this.onReset === "function") this.onReset();
    else if (window.NeuroNexusDebug?.resetNetwork) window.NeuroNexusDebug.resetNetwork();
  }
}
