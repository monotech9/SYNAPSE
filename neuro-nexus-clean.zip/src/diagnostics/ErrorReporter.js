/**
 * ErrorReporter
 * 
 * Centralized error tracking, classification, and reporting.
 * Enables debugging, analytics, and graceful error recovery.
 * 
 * Features:
 * - Structured error logging
 * - Severity classification
 * - Error context tracking
 * - Recovery suggestions
 * - Remote error reporting (optional)
 * - Error deduplication
 */

export class ErrorReporter {
  constructor(config = {}) {
    this.enabled = config.enabled ?? true;
    this.maxErrors = config.maxErrors ?? 500;
    this.reportToBackend = config.reportToBackend ?? null; // URL or callback
    this.sendStackTraces = config.sendStackTraces ?? false;

    this.errors = [];
    this.listeners = new Set();
    this.errorCounts = new Map(); // For deduplication
    this.recoveryStrategies = new Map();

    // Register default recovery strategies
    this._initDefaultStrategies();
  }

  /**
   * Report an error
   */
  report(error, context = {}) {
    if (!this.enabled) return;

    const errorReport = this._createReport(error, context);

    // Deduplicate similar errors
    const errorHash = this._hashError(error);
    const existingCount = this.errorCounts.get(errorHash) ?? 0;

    if (existingCount > 5) {
      // Suppress repetitive errors
      this.errorCounts.set(errorHash, existingCount + 1);
      return;
    }

    this.errorCounts.set(errorHash, existingCount + 1);

    // Store
    this.errors.push(errorReport);
    if (this.errors.length > this.maxErrors) {
      this.errors.shift();
    }

    // Classify severity
    const severity = this._classifySeverity(error);

    // Log
    this._log(severity, errorReport);

    // Notify listeners
    this.listeners.forEach((cb) => cb(errorReport, severity));

    // Send to backend if critical
    if (severity === 'critical' && this.reportToBackend) {
      this._sendToBackend(errorReport);
    }

    // Suggest recovery
    const strategy = this.recoveryStrategies.get(severity);
    if (strategy) {
      strategy(errorReport);
    }

    return errorReport;
  }

  /**
   * Create structured error report
   */
  _createReport(error, context) {
    return {
      id: `err-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      timestamp: new Date().toISOString(),
      message: error.message ?? String(error),
      stack: error.stack ?? '',
      context: {
        ...context,
        userAgent: navigator.userAgent,
        url: window.location.href,
      },
      type: error.constructor.name,
    };
  }

  /**
   * Hash error for deduplication
   */
  _hashError(error) {
    const str = `${error.message}-${error.stack?.split('\n')[1] ?? ''}`;
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return hash.toString();
  }

  /**
   * Classify error severity
   */
  _classifySeverity(error) {
    const msg = error.message.toLowerCase();

    // Critical errors
    if (msg.includes('worker') || msg.includes('fatal') || msg.includes('crash')) {
      return 'critical';
    }

    // Warnings
    if (msg.includes('memory') || msg.includes('deprecated') || msg.includes('warn')) {
      return 'warning';
    }

    // Info
    if (msg.includes('info') || msg.includes('debug')) {
      return 'info';
    }

    // Default: error
    return 'error';
  }

  /**
   * Log error with appropriate level
   */
  _log(severity, report) {
    const prefix = {
      critical: '🚨',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️',
    }[severity] ?? '?';

    const logFn = {
      critical: console.error,
      error: console.error,
      warning: console.warn,
      info: console.info,
    }[severity] ?? console.log;

    logFn(
      `${prefix} [${severity.toUpperCase()}] ${report.message}`,
      report.context,
      this.sendStackTraces ? report.stack : ''
    );
  }

  /**
   * Send error to backend
   */
  _sendToBackend(report) {
    if (typeof this.reportToBackend === 'function') {
      try {
        this.reportToBackend(report);
      } catch (e) {
        console.error('Failed to send error report to backend:', e);
      }
    } else if (typeof this.reportToBackend === 'string') {
      // POST to URL
      fetch(this.reportToBackend, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(report),
      }).catch((e) => console.error('Failed to POST error report:', e));
    }
  }

  /**
   * Initialize default recovery strategies
   */
  _initDefaultStrategies() {
    // Critical errors: pause simulation
    this.recoveryStrategies.set('critical', (report) => {
      console.error('Critical error detected. Consider restarting simulation.');
      // Could dispatch event to pause simulation
      window.dispatchEvent(
        new CustomEvent('neuro:critical-error', { detail: report })
      );
    });

    // Errors: log but continue
    this.recoveryStrategies.set('error', (report) => {
      console.error('Error logged:', report.id);
    });

    // Warnings: minimal action
    this.recoveryStrategies.set('warning', (report) => {
      // Could show in HUD
    });
  }

  /**
   * Listen to error reports
   */
  onError(callback) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  /**
   * Get errors filtered by severity
   */
  getErrorsBySeverity(severity) {
    return this.errors.filter((e) => this._classifySeverity(e) === severity);
  }

  /**
   * Get recent errors
   */
  getRecentErrors(count = 10) {
    return this.errors.slice(-count);
  }

  /**
   * Clear all errors
   */
  clear() {
    this.errors = [];
    this.errorCounts.clear();
  }

  /**
   * Export error log
   */
  export() {
    const json = JSON.stringify(
      {
        timestamp: new Date().toISOString(),
        errors: this.errors,
        statistics: {
          totalErrors: this.errors.length,
          bySeverity: {
            critical: this.getErrorsBySeverity('critical').length,
            error: this.getErrorsBySeverity('error').length,
            warning: this.getErrorsBySeverity('warning').length,
            info: this.getErrorsBySeverity('info').length,
          },
        },
      },
      null,
      2
    );

    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `neuro-nexus-errors-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  /**
   * Report with minimal info
   */
  warn(message, context) {
    this.report(new Error(message), { ...context, isWarning: true });
  }

  /**
   * Report with debug info
   */
  debug(message, context) {
    if (process.env.NODE_ENV !== 'production') {
      this.report(new Error(`[DEBUG] ${message}`), context);
    }
  }
}

/**
 * Global error reporter singleton
 */
let reporterInstance = null;

export function getErrorReporter() {
  if (!reporterInstance) {
    reporterInstance = new ErrorReporter();
  }
  return reporterInstance;
}

export function initErrorReporter(config) {
  if (reporterInstance) {
    console.warn('ErrorReporter already initialized');
    return reporterInstance;
  }
  reporterInstance = new ErrorReporter(config);
  return reporterInstance;
}
