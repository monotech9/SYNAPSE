import { resetPersistentState } from "../persistence.js";

const DEFAULT_DURATION_SECONDS = 120;
const DEFAULT_SAMPLE_INTERVAL_SECONDS = 1;
const MAX_TEXTAREA_CHARS = 260000;

// ─── Diagnostic counters (factory + clone) ──────────────────────────
//
// Die Zähler werden während der Simulation von verschiedenen Systemen
// (PulseEngine, NetworkBuilder, GrowthSystem, …) inkrementiert und
// am Ende von DiagnosticsRecorder im Bericht ausgegeben.

/**
 * Erzeugt ein frisches Zähler-Objekt mit allen Defaults.
 * @returns {object} diagnostic counters
 */
export function createDiagnosticCounters() {
  return {
    signalsInjected: 0,
    pulsesSpawned: 0,
    spontaneousSignals: 0,
    nodesAdded: 0,
    internalEdgesAdded: 0,
    bridgesCreated: 0,
    budsCreated: 0,
    growthIntents: {},
    growthActions: {},
    lastGrowthIntent: null,
    lastGrowthChanged: false,
    visibleBirthEvents: 0,
    visibleStageEvents: 0,
    visibleWaveEvents: 0,
    ambientPulseEvents: 0,
    preferredPathPulseEvents: 0,
    supportPulseEvents: 0,
    bridgePulseEvents: 0
  };
}

/**
 * Erzeugt eine tiefe Kopie der Zähler (für Snapshots).
 * @param {object} counters
 * @returns {object}
 */
export function cloneDiagnosticCounters(counters) {
  return JSON.parse(JSON.stringify(counters));
}

export class DiagnosticsRecorder {
  constructor(simulation, options = {}) {
    this.simulation = simulation;
    this.durationSeconds = options.durationSeconds || DEFAULT_DURATION_SECONDS;
    this.sampleIntervalSeconds = options.sampleIntervalSeconds || DEFAULT_SAMPLE_INTERVAL_SECONDS;

    this.isRecording = false;
    this.startedAtPerformance = 0;
    this.startedAtAge = 0;
    this.nextSampleAt = 0;
    this.samples = [];
    this.report = null;

    this.elements = this.createPanel();
    this.bindEvents();
    this.updatePanelIdle();
  }

  createPanel() {
    const root = document.createElement("section");
    root.className = "diagnostics";
    root.setAttribute("aria-label", "Neuro Nexus Diagnose Recorder");

    root.innerHTML = `
      <button class="diagnostics__toggle" type="button" aria-expanded="false">DIAG</button>
      <div class="diagnostics__panel" hidden>
        <div class="diagnostics__header">
          <div>
            <div class="diagnostics__title">2-Minuten Diagnose</div>
            <div class="diagnostics__subtitle">zeichnet Wachstum, Cluster, Pulse und Identity-Daten auf</div>
          </div>
        </div>

        <div class="diagnostics__status" data-status>Bereit</div>
        <div class="diagnostics__bar" aria-hidden="true"><div class="diagnostics__bar-fill" data-bar></div></div>

        <div class="diagnostics__actions">
          <button class="diagnostics__button" type="button" data-start>120s aufnehmen</button>
          <button class="diagnostics__button diagnostics__button--ghost" type="button" data-stop disabled>Stop</button>
        </div>

        <div class="diagnostics__actions diagnostics__actions--secondary">
          <button class="diagnostics__button diagnostics__button--ghost" type="button" data-copy disabled>Kopieren</button>
          <button class="diagnostics__button diagnostics__button--ghost" type="button" data-download disabled>JSON laden</button>
        </div>

        <div class="diagnostics__actions diagnostics__actions--secondary">
          <button class="diagnostics__button diagnostics__button--ghost" type="button" data-reset>Reset</button>
          <button class="diagnostics__button diagnostics__button--ghost" type="button" data-fresh-record>Reset + 120s</button>
        </div>

        <textarea class="diagnostics__output" data-output readonly placeholder="Nach der Aufnahme erscheint hier die JSON-Diagnose. Auf iOS kannst du sie markieren/kopieren oder als Datei laden."></textarea>
      </div>
    `;

    document.body.append(root);

    return {
      root,
      toggle: root.querySelector(".diagnostics__toggle"),
      panel: root.querySelector(".diagnostics__panel"),
      status: root.querySelector("[data-status]"),
      bar: root.querySelector("[data-bar]"),
      start: root.querySelector("[data-start]"),
      stop: root.querySelector("[data-stop]"),
      copy: root.querySelector("[data-copy]"),
      download: root.querySelector("[data-download]"),
      reset: root.querySelector("[data-reset]"),
      freshRecord: root.querySelector("[data-fresh-record]"),
      output: root.querySelector("[data-output]")
    };
  }

  bindEvents() {
    this.elements.toggle.addEventListener("click", () => this.togglePanel());
    this.elements.start.addEventListener("click", () => this.start());
    this.elements.stop.addEventListener("click", () => this.stop("manual"));
    this.elements.copy.addEventListener("click", () => this.copyReport());
    this.elements.download.addEventListener("click", () => this.downloadReport());
    this.elements.reset.addEventListener("click", () => this.resetNetwork(false));
    this.elements.freshRecord.addEventListener("click", () => this.resetNetwork(true));
  }

  togglePanel(forceOpen = null) {
    const shouldOpen = forceOpen ?? this.elements.panel.hidden;
    this.elements.panel.hidden = !shouldOpen;
    this.elements.toggle.setAttribute("aria-expanded", String(shouldOpen));
    this.elements.root.classList.toggle("is-open", shouldOpen);
  }

  resetNetwork(autoRecord) {
    const message = autoRecord
      ? "Netz komplett zurücksetzen und danach automatisch 120s Diagnose starten?"
      : "Netz komplett zurücksetzen und beim Genesis Core neu starten?";

    if (!confirm(message)) return;

    try { resetPersistentState(); } catch (_) {}
    if (typeof this.simulation.hardResetRuntime === "function") {
      this.simulation.hardResetRuntime();
    }
    this.resetLocalState();

    if (autoRecord) {
      this.start();
    } else {
      this.updatePanelIdle();
      this.togglePanel(true);
    }
  }

  resetLocalState() {
    if (this.isRecording) this.stop("reset");
    this.isRecording = false;
    this.startedAtPerformance = 0;
    this.startedAtAge = 0;
    this.nextSampleAt = 0;
    this.samples = [];
    this.report = null;
    this.elements.output.value = "";
    this.elements.copy.disabled = true;
    this.elements.download.disabled = true;
    this.elements.start.disabled = false;
    this.elements.stop.disabled = true;
    this.elements.bar.style.width = "0%";
  }

  start() {
    this.isRecording = true;
    this.startedAtPerformance = performance.now() / 1000;
    this.startedAtAge = this.simulation.world.age;
    this.nextSampleAt = 0;
    this.samples = [];
    this.report = null;

    this.captureSample(0);
    this.togglePanel(true);
    this.elements.start.disabled = true;
    this.elements.stop.disabled = false;
    this.elements.copy.disabled = true;
    this.elements.download.disabled = true;
    this.elements.output.value = "";
    this.setStatus("Aufnahme läuft · 120s", 0);
  }

  update(timeSeconds) {
    if (!this.isRecording) return;

    const elapsed = Math.max(0, timeSeconds - this.startedAtPerformance);

    if (elapsed >= this.nextSampleAt) {
      this.captureSample(elapsed);
      this.nextSampleAt += this.sampleIntervalSeconds;
    }

    this.setStatus(`Aufnahme läuft · ${Math.max(0, Math.ceil(this.durationSeconds - elapsed))}s`, elapsed / this.durationSeconds);

    if (elapsed >= this.durationSeconds) {
      this.stop("complete");
    }
  }

  captureSample(elapsedSeconds) {
    const snapshot = this.simulation.getDiagnosticSnapshot(elapsedSeconds);
    this.samples.push(snapshot);
  }

  stop(reason) {
    if (!this.isRecording && this.report) return;

    this.isRecording = false;
    this.elements.start.disabled = false;
    this.elements.stop.disabled = true;

    const elapsed = Math.max(0, performance.now() / 1000 - this.startedAtPerformance);
    const finalSample = this.simulation.getDiagnosticSnapshot(elapsed);
    this.samples.push(finalSample);
    this.report = this.createReport(reason, elapsed, finalSample);

    const json = JSON.stringify(this.report, null, 2);
    this.elements.output.value = json.length > MAX_TEXTAREA_CHARS
      ? `${json.slice(0, MAX_TEXTAREA_CHARS)}\n\n/* Ausgabe gekürzt. Bitte über „JSON laden“ die vollständige Datei exportieren. */`
      : json;

    this.elements.copy.disabled = false;
    this.elements.download.disabled = false;
    this.setStatus(reason === "complete" ? "Aufnahme fertig · JSON bereit" : "Aufnahme gestoppt · JSON bereit", 1);
    this.togglePanel(true);
  }

  createReport(reason, elapsedSeconds, finalSample) {
    const firstSample = this.samples[0] || finalSample;
    const stageTransitions = collectTransitions(this.samples, "growthStage");
    const clusterCountTransitions = collectTransitions(this.samples, "clusterCount");
    const eventTimeline = collectMemoryEvents(this.samples);

    return {
      schema: "neuro-nexus-diagnostics.v1",
      recordedAt: new Date().toISOString(),
      reason,
      durationSeconds: round(elapsedSeconds, 2),
      sampleIntervalSeconds: this.sampleIntervalSeconds,
      sampleCount: this.samples.length,
      environment: {
        userAgent: navigator.userAgent,
        viewport: {
          width: window.innerWidth,
          height: window.innerHeight,
          devicePixelRatio: window.devicePixelRatio || 1
        }
      },
      identity: finalSample.identity,
      personality: finalSample.personality,
      start: summarizeSample(firstSample),
      end: summarizeSample(finalSample),
      delta: {
        age: round(finalSample.age - firstSample.age, 2),
        nodes: finalSample.totalNodes - firstSample.totalNodes,
        edges: finalSample.totalEdges - firstSample.totalEdges,
        clusters: finalSample.clusterCount - firstSample.clusterCount,
        bridgeEdges: finalSample.bridgeEdges - firstSample.bridgeEdges,
        memoryEvents: finalSample.memory.events.length - firstSample.memory.events.length,
        autonomousMoments: finalSample.memory.autonomousMoments - firstSample.memory.autonomousMoments
      },
      transitions: {
        growthStage: stageTransitions,
        clusterCount: clusterCountTransitions
      },
      events: eventTimeline,
      counters: finalSample.counters,
      samples: this.samples
    };
  }

  async copyReport() {
    if (!this.report) return;

    const text = JSON.stringify(this.report, null, 2);

    try {
      if (!navigator.clipboard?.writeText) throw new Error("Clipboard API unavailable");
      await navigator.clipboard.writeText(text);
      this.setStatus("JSON kopiert", 1);
    } catch {
      this.elements.output.focus();
      this.elements.output.select();
      this.setStatus("Kopieren blockiert · Textfeld ist markiert", 1);
    }
  }

  downloadReport() {
    if (!this.report) return;

    const text = JSON.stringify(this.report, null, 2);
    const blob = new Blob([text], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    const safeName = String(this.report.identity?.name || "network").toLowerCase().replace(/[^a-z0-9-]+/gi, "-");

    anchor.href = url;
    anchor.download = `neuro-nexus-diagnostics-${safeName}-${Date.now()}.json`;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();

    setTimeout(() => URL.revokeObjectURL(url), 2000);
    this.setStatus("JSON-Download gestartet", 1);
  }

  setStatus(text, progress) {
    this.elements.status.textContent = text;
    this.elements.bar.style.transform = `scaleX(${Math.max(0, Math.min(progress, 1))})`;
  }

  updatePanelIdle() {
    this.setStatus("Bereit · 120 Sekunden aufnehmen", 0);
  }
}

function summarizeSample(sample) {
  return {
    age: sample.age,
    growthStage: sample.growthStage,
    clusterCount: sample.clusterCount,
    totalNodes: sample.totalNodes,
    totalEdges: sample.totalEdges,
    bridgeEdges: sample.bridgeEdges,
    strongestTrace: sample.memory.strongestTrace,
    autonomousMoments: sample.memory.autonomousMoments,
    clusters: sample.clusters.map((cluster) => ({
      id: cluster.id,
      role: cluster.role,
      state: cluster.state,
      nodes: cluster.nodes,
      edges: cluster.internalEdges,
      bridges: cluster.bridgeEdges,
      density: cluster.density,
      stability: cluster.stability,
      saturation: cluster.saturation,
      expansionPressure: cluster.expansionPressure,
      memoryStrength: cluster.memoryStrength,
      screenBounds: cluster.screenBounds
    }))
  };
}

function collectTransitions(samples, key) {
  const transitions = [];
  let previous = null;

  for (const sample of samples) {
    const value = sample[key];
    if (value === previous) continue;
    transitions.push({ t: sample.t, age: sample.age, value });
    previous = value;
  }

  return transitions;
}

function collectMemoryEvents(samples) {
  const byKey = new Map();

  for (const sample of samples) {
    for (const event of sample.memory.events) {
      const key = `${event.type}:${event.age}`;
      if (!byKey.has(key)) {
        byKey.set(key, event);
      }
    }
  }

  return Array.from(byKey.values()).sort((a, b) => a.age - b.age);
}

function round(value, decimals = 3) {
  const factor = 10 ** decimals;
  return Math.round((Number(value) || 0) * factor) / factor;
}
