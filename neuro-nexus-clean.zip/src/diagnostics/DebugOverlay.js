const MAX_LOG_ENTRIES = 6;
const UPDATE_HZ = 4;

export class DebugOverlay {
  constructor(simulation) {
    this.simulation = simulation;
    this.enabled = true;
    this.frameMsEMA = 16.7;
    this.log = [];
    this.lastUpdate = -Infinity;
    this.panel = this.createPanel();
    this.refresh(0);
  }

  createPanel() {
    const panel = document.createElement("div");
    panel.className = "nn-debug-overlay";
    panel.setAttribute("aria-hidden", "true");
    document.body.append(panel);
    return panel;
  }

  enable() {
    this.enabled = true;
    this.panel.classList.remove("is-hidden");
  }

  disable() {
    this.enabled = false;
    this.panel.classList.add("is-hidden");
  }

  toggle() {
    this.enabled ? this.disable() : this.enable();
  }

  logEvent(label, data = null) {
    const entry = {
      t: this.simulation.world.age.toFixed(1),
      label,
      data
    };

    this.log.push(entry);
    if (this.log.length > MAX_LOG_ENTRIES) this.log.shift();
  }

  tick(now, frameMs) {
    if (!this.enabled) return;
    this.frameMsEMA += (frameMs - this.frameMsEMA) * 0.08;
    this.refresh(now);
  }

  refresh(now) {
    if (now - this.lastUpdate < 1000 / UPDATE_HZ) return;
    this.lastUpdate = now;
    this.panel.textContent = this.buildText();
  }

  buildText() {
    const snapshot = this.simulation.getDiagnosticSnapshot(0);
    const fps = (1000 / Math.max(1, this.frameMsEMA)).toFixed(1);
    const frameMs = this.frameMsEMA.toFixed(2);
    const clusters = snapshot.clusters
      .map((cluster) => {
        return `${cluster.role.slice(0, 4)}:${cluster.state.slice(0, 4)} n=${cluster.nodes} s=${cluster.saturation.toFixed(2)} p=${cluster.expansionPressure.toFixed(2)}`;
      })
      .join("\n");

    const logLines = this.log.map((entry) => {
      const detail = entry.data
        ? ` ${Object.entries(entry.data).map(([key, value]) => `${key}=${value}`).join(" ")}`
        : "";
      return `  ${entry.t}s ${entry.label}${detail}`;
    }).join("\n");

    return [
      "NEURO NEXUS debug v2",
      "────────────────────────",
      `${fps} fps  ${frameMs} ms/f  age=${snapshot.age}s`,
      `stage=${snapshot.growthStage}`,
      `nodes=${snapshot.totalNodes} edges=${snapshot.totalEdges} clusters=${snapshot.clusterCount}`,
      `pulses=${snapshot.counters.pulsesSpawned} ambient=${snapshot.counters.ambientPulseEvents || 0} path=${snapshot.counters.preferredPathPulseEvents || 0} support=${snapshot.counters.supportPulseEvents || 0}`,
      `bridge=${snapshot.counters.bridgePulseEvents || 0} waves=${snapshot.counters.visibleWaveEvents} births=${snapshot.counters.visibleBirthEvents}`,
      `trace=${snapshot.currentStrongestTrace} coverage=${snapshot.averageScreenCoverage}`,
      "",
      clusters ? `clusters:\n${clusters}` : "",
      logLines ? `events:\n${logLines}` : ""
    ].filter(Boolean).join("\n");
  }
}
