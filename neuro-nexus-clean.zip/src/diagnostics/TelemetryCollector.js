/**
 * TelemetryCollector — sammelt Echtzeit-Telemetrie über Simulation und Rendering.
 *
 * Verfolgt:
 *  - Sim-TPS (Simulation Ticks per Second)
 *  - Render-FPS (Frames per Second)
 *  - Worker-Latenz (falls Worker aktiv)
 *  - Node/Edge/Cluster-Counts
 *  - Durchschnittliche Aktivität
 *  - Speicherverbrauch (falls performance.memory verfügbar)
 *  - Event-Histogramm (Ring-Buffer der letzten 60 Samples)
 *
 * Zeigt eine Live-Telemetrie-Panel im UI an (toggle über Button).
 * Optional: Text-Timeline für Activity/Growth/Memory.
 */

const SAMPLE_INTERVAL_MS = 1000; // 1 Sample pro Sekunde
const MAX_SAMPLES = 120;          // 2 Minuten History
const PANEL_UPDATE_INTERVAL_MS = 500; // UI-Update alle 500ms

export class TelemetryCollector {
  constructor(simulation, simLoop) {
    this.simulation = simulation;
    this.simLoop = simLoop;

    // Ring-Buffer
    this.samples = [];
    this.maxSamples = MAX_SAMPLES;

    // Timing
    this._lastSampleTime = 0;
    this._frameCount = 0;
    this._lastFrameCount = 0;
    this._lastTickcount = 0;
    this._lastUiUpdate = 0;

    // Aktuelle Werte
    this.current = {
      fps: 0,
      tps: 0,
      simHz: simLoop?.hz || 30,
      nodeCount: 0,
      edgeCount: 0,
      clusterCount: 0,
      pulseCount: 0,
      bridgeCount: 0,
      avgActivity: 0,
      avgMemory: 0,
      growthStage: "",
      age: 0,
      memoryUsed: 0,
      simAccumulator: 0,
      simStepsLastSec: 0,
      connectionsPerMin: 0,
    };

    // UI
    this.elements = null;
    this._mounted = false;
  }

  mountPanel() {
    if (this._mounted) return;

    const root = document.createElement("section");
    root.className = "telemetry";
    root.id = "telemetryRoot";
    root.setAttribute("aria-label", "Neuro Nexus Telemetrie");
    root.innerHTML = `
      <button class="telemetry__toggle" type="button" aria-expanded="false">TELEMETRY</button>
      <div class="telemetry__panel" hidden>
        <div class="telemetry__grid">
          <div class="telemetry__stat" data-stat="fps"><span class="telemetry__label">FPS</span><span class="telemetry__value">—</span></div>
          <div class="telemetry__stat" data-stat="tps"><span class="telemetry__label">Sim TPS</span><span class="telemetry__value">—</span></div>
          <div class="telemetry__stat" data-stat="nodes"><span class="telemetry__label">Nodes</span><span class="telemetry__value">—</span></div>
          <div class="telemetry__stat" data-stat="edges"><span class="telemetry__label">Edges</span><span class="telemetry__value">—</span></div>
          <div class="telemetry__stat" data-stat="clusters"><span class="telemetry__label">Clusters</span><span class="telemetry__value">—</span></div>
          <div class="telemetry__stat" data-stat="activity"><span class="telemetry__label">Avg Activity</span><span class="telemetry__value">—</span></div>
          <div class="telemetry__stat" data-stat="memory"><span class="telemetry__label">Avg Memory</span><span class="telemetry__value">—</span></div>
          <div class="telemetry__stat" data-stat="age"><span class="telemetry__label">Age</span><span class="telemetry__value">—</span></div>
          <div class="telemetry__stat" data-stat="cpm"><span class="telemetry__label">Conn/min</span><span class="telemetry__value">—</span></div>
          <div class="telemetry__stat" data-stat="mem"><span class="telemetry__label">JS Heap</span><span class="telemetry__value">—</span></div>
        </div>
        <div class="telemetry__timelines">
          <div class="telemetry__timeline" data-timeline="activity">
            <span class="telemetry__timeline-label">Activity</span>
            <div class="telemetry__timeline-bars"></div>
          </div>
          <div class="telemetry__timeline" data-timeline="growth">
            <span class="telemetry__timeline-label">Growth</span>
            <div class="telemetry__timeline-bars"></div>
          </div>
          <div class="telemetry__timeline" data-timeline="memory">
            <span class="telemetry__timeline-label">Memory</span>
            <div class="telemetry__timeline-bars"></div>
          </div>
        </div>
      </div>
    `;

    document.body.append(root);

    this.elements = {
      root,
      toggle: root.querySelector(".telemetry__toggle"),
      panel: root.querySelector(".telemetry__panel"),
      stats: {
        fps: root.querySelector('[data-stat="fps"] .telemetry__value'),
        tps: root.querySelector('[data-stat="tps"] .telemetry__value'),
        nodes: root.querySelector('[data-stat="nodes"] .telemetry__value'),
        edges: root.querySelector('[data-stat="edges"] .telemetry__value'),
        clusters: root.querySelector('[data-stat="clusters"] .telemetry__value'),
        activity: root.querySelector('[data-stat="activity"] .telemetry__value'),
        memory: root.querySelector('[data-stat="memory"] .telemetry__value'),
        age: root.querySelector('[data-stat="age"] .telemetry__value'),
        cpm: root.querySelector('[data-stat="cpm"] .telemetry__value'),
        mem: root.querySelector('[data-stat="mem"] .telemetry__value'),
      },
      timelines: {
        activity: root.querySelector('[data-timeline="activity"] .telemetry__timeline-bars'),
        growth: root.querySelector('[data-timeline="growth"] .telemetry__timeline-bars'),
        memory: root.querySelector('[data-timeline="memory"] .telemetry__timeline-bars'),
      }
    };

    this.elements.toggle.addEventListener("click", () => {
      const isOpen = !this.elements.panel.hidden;
      this.elements.panel.hidden = isOpen;
      this.elements.toggle.setAttribute("aria-expanded", String(!isOpen));
      this.elements.root.classList.toggle("is-open", !isOpen);
    });

    this._mounted = true;
  }

  /**
   * Wird jeden Render-Frame aufgerufen.
   * Sammelt Timing-Daten und aktualisiert periodisch Samples + UI.
   */
  onFrame(now, frameMs) {
    this._frameCount++;

    // Sample jede Sekunde
    if (now - this._lastSampleTime >= SAMPLE_INTERVAL_MS) {
      this._collectSample(now);
      this._lastSampleTime = now;
    }

    // UI-Update alle 500ms
    if (this._mounted && now - this._lastUiUpdate >= PANEL_UPDATE_INTERVAL_MS) {
      this._updatePanel();
      this._lastUiUpdate = now;
    }
  }

  _collectSample(now) {
    const world = this.simulation.world;
    const sim = this.simulation;

    // FPS = Frames seit letztem Sample
    const fps = this._frameCount - this._lastFrameCount;
    this._lastFrameCount = this._frameCount;

    // TPS = Ticks seit letztem Sample
    const tps = (this.simLoop?.tickCount || 0) - this._lastTickcount;
    this._lastTickcount = this.simLoop?.tickCount || 0;

    // Counts
    const nodeCount = sim.totalNodeCount();
    const edgeCount = world.edges.length;
    const clusterCount = world.clusters.length;
    const pulseCount = world.pulses.length;
    const bridgeCount = world.bridgeEdges.length;

    // Average activity across all clusters
    const avgActivity = clusterCount > 0
      ? world.clusters.reduce((s, c) => s + c.activityMemory, 0) / clusterCount
      : 0;

    // Average memory strength
    const avgMemory = clusterCount > 0
      ? world.clusters.reduce((s, c) => s + c.memoryStrength, 0) / clusterCount
      : 0;

    // Memory usage (Chrome only)
    let memoryUsed = 0;
    if (typeof performance !== "undefined" && performance.memory) {
      memoryUsed = performance.memory.usedJSHeapSize / (1024 * 1024);
    }

    // Connections per minute (from diagnostic counters)
    const counters = sim.diagnosticCounters;
    const connectionsPerMin = (counters.internalEdgesAdded + counters.bridgesCreated) > 0
      ? Math.round(((counters.internalEdgesAdded + counters.bridgesCreated) / Math.max(1, world.age)) * 60)
      : 0;

    // Growth stage as numeric (0=genesis → higher = more evolved)
    const stageOrder = ["genesis", "activation", "exploration", "constellation", "resonance"];
    const growthNumeric = stageOrder.indexOf(world.growthStage) / Math.max(1, stageOrder.length - 1);

    const sample = {
      t: now / 1000,
      age: world.age,
      fps,
      tps,
      nodeCount,
      edgeCount,
      clusterCount,
      pulseCount,
      bridgeCount,
      avgActivity,
      avgMemory,
      growthStage: world.growthStage,
      growthNumeric,
      memoryUsed,
      connectionsPerMin,
      simAccumulator: this.simLoop?.accumulator || 0,
      simStepsLastSec: tps,
    };

    this.samples.push(sample);
    if (this.samples.length > this.maxSamples) {
      this.samples.shift();
    }

    // Update current
    this.current = { ...sample };
  }

  _updatePanel() {
    const e = this.elements;
    const c = this.current;
    if (!e || !c) return;

    const s = e.stats;
    if (!s) return;

    s.fps.textContent = c.fps.toFixed(0);
    s.tps.textContent = c.tps.toFixed(0) + "/" + (this.simLoop?.hz || 30);
    s.nodes.textContent = c.nodeCount;
    s.edges.textContent = c.edgeCount;
    s.clusters.textContent = c.clusterCount;
    s.activity.textContent = (c.avgActivity * 100).toFixed(1) + "%";
    s.memory.textContent = (c.avgMemory * 100).toFixed(1) + "%";
    s.age.textContent = c.age.toFixed(0) + "s";
    s.cpm.textContent = c.connectionsPerMin;
    s.mem.textContent = c.memoryUsed > 0 ? c.memoryUsed.toFixed(1) + " MB" : "n/a";

    this._renderTimeline("activity", s => s.avgActivity);
    this._renderTimeline("growth", s => s.growthNumeric);
    this._renderTimeline("memory", s => s.avgMemory);
  }

  _renderTimeline(name, valueFn) {
    const container = this.elements.timelines[name];
    if (!container) return;

    const samples = this.samples;
    if (samples.length < 2) return;

    // Normalize to 0..1
    const values = samples.map(valueFn);
    const max = Math.max(0.01, ...values);

    // Render as inline-block bars
    const bars = values.map(v => {
      const h = Math.max(2, (v / max) * 100);
      return `<div class="telemetry__bar" style="height:${h}%"></div>`;
    }).join("");

    container.innerHTML = bars;
  }

  /**
   * Gibt alle Samples als Array zurück (für Export oder Debug).
   */
  getSamples() {
    return [...this.samples];
  }

  /**
   * Gibt eine kompakte Zusammenfassung als Text zurück.
   */
  getSummary() {
    const c = this.current;
    return [
      `FPS: ${c.fps.toFixed(0)} | TPS: ${c.tps}/${this.simLoop?.hz || 30}`,
      `Nodes: ${c.nodeCount} | Edges: ${c.edgeCount} | Clusters: ${c.clusterCount}`,
      `Activity: ${(c.avgActivity * 100).toFixed(1)}% | Memory: ${(c.avgMemory * 100).toFixed(1)}%`,
      `Stage: ${c.growthStage} | Age: ${c.age.toFixed(0)}s`,
      `Conn/min: ${c.connectionsPerMin} | Heap: ${c.memoryUsed.toFixed(1)}MB`,
    ].join("\n");
  }
}
