import { GestureRecognizer } from "./GestureRecognizer.js";

const NODE_DRAG_RADIUS = 45;

/**
 * PointerController — mappt GestureRecognizer-Events auf Simulation-Calls.
 *
 * Dies ist der dünnen Orchestrator-Layer: er kennt die Simulation,
 * aber keine Pointer-Event-Details. Die Gesturkennung liegt im
 * GestureRecognizer.
 */
export class PointerController {
  constructor(canvas, simulation) {
    this.canvas = canvas;
    this.simulation = simulation;

    this.recognizer = new GestureRecognizer(canvas, {
      onContextmenu: (point) => this._onContextmenu(point),

      onQueryNodeDrag: (point) => this._queryNodeDrag(point),
      onNodeDragStart: (node, point) => this._onNodeDragStart(node, point),
      onNodeDragMove: (point) => this._onNodeDragMove(point),
      onNodeDragEnd: (point, startNode) => this._onNodeDragEnd(point, startNode),
      onNodeDragCancel: () => this._onNodeDragCancel(),

      onPan: (dx, dy, startOffset) => this._onPan(dx, dy, startOffset),
      onPanReanchor: () => {},

      onPinchStart: (center) => this._onPinchStart(center),
      onPinchMove: (center, distance, startDistance) => this._onPinchMove(center, distance, startDistance),

      onTap: (point) => this._onTap(point),
      onDoubleTap: (point) => this._onDoubleTap(point),

      onPointerUpCleanup: () => this.simulation.clampCameraOffset()
    });
  }

  destroy() {
    this.recognizer.destroy();
  }

  // --- Context menu (right-click / long-press) ---

  _onContextmenu(point) {
    this.simulation.pruneArea?.(point.x, point.y);
  }

  // --- Node dragging (drag from one node to another to create a bridge) ---

  _queryNodeDrag(point) {
    if (!this.simulation.findNearestNode) return null;
    const nearest = this.simulation.findNearestNode(point.x, point.y);
    if (nearest && nearest.distance < NODE_DRAG_RADIUS / this.simulation.camera.scale) {
      return nearest.node;
    }
    return null;
  }

  _onNodeDragStart(node, point) {
    this.simulation.world.activeDragLine = { startNode: node, currentPoint: point };
  }

  _onNodeDragMove(point) {
    if (this.simulation.world.activeDragLine) {
      this.simulation.world.activeDragLine.currentPoint = point;
    }
  }

  _onNodeDragEnd(point, startNode) {
    if (!this.simulation.findNearestNode) return;
    const nearest = this.simulation.findNearestNode(point.x, point.y);
    if (nearest && nearest.node !== startNode && nearest.distance < NODE_DRAG_RADIUS / this.simulation.camera.scale) {
      this.simulation.forceBridge?.(startNode, nearest.node);
    }
  }

  _onNodeDragCancel() {
    this.simulation.world.activeDragLine = null;
  }

  // --- Pan (only when zoomed in) ---

  _onPan(dx, dy, startOffset) {
    if (this.simulation.camera.targetScale <= 1.03) return;
    this.simulation.camera.targetOffsetX = startOffset.x + dx;
    this.simulation.camera.targetOffsetY = startOffset.y + dy;
    this.simulation.clampCameraOffset();
  }

  // --- Pinch zoom ---

  _onPinchStart(center) {
    const { state } = this.recognizer;
    state.pinchStartScale = this.simulation.camera.targetScale;
    state.pinchStartOffset = {
      x: this.simulation.camera.targetOffsetX,
      y: this.simulation.camera.targetOffsetY
    };
    // Also re-anchor pan start offset for smooth transition
    state.panStartOffset = {
      x: this.simulation.camera.targetOffsetX,
      y: this.simulation.camera.targetOffsetY
    };
  }

  _onPinchMove(center, distance, startDistance) {
    const { state } = this.recognizer;
    const nextScale = state.pinchStartScale * (distance / startDistance);

    this.simulation.camera.targetOffsetX =
      state.pinchStartOffset.x + (center.x - state.pinchStartCenter.x);
    this.simulation.camera.targetOffsetY =
      state.pinchStartOffset.y + (center.y - state.pinchStartCenter.y);

    this.simulation.zoomAt(center, nextScale);
  }

  // --- Tap / Double tap ---

  _onTap(point) {
    this.simulation.injectSignal(point.x, point.y);
    if (this.simulation.audio?.enabled) {
      this.simulation.audio.playPointerInteraction(0.5);
    }
  }

  _onDoubleTap(point) {
    this.simulation.addManualNode?.(point.x, point.y);
    if (this.simulation.audio?.enabled) {
      this.simulation.audio.playPointerInteraction(0.8);
    }
  }
}
