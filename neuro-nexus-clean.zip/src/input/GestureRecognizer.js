import { CONFIG } from "../config.js";

/**
 * GestureRecognizer — wandelt rohe Pointer-Events in semantische Gestures um.
 *
 * Erkennt: Pan, Pinch-Zoom, Tap, Double-Tap, Node-Drag, Contextmenu.
 * Emitiert Callbacks, die der PointerController auf Simulation-Calls mappt.
 *
 * State Machine:
 *   idle → pointerdown → tracking (1 finger: pan/tap/drag, 2 fingers: pinch)
 *   pinch endet → zurück zu 1-finger pan (mit neuem Referenzpunkt)
 *   pointerup → tap-Check → idle
 */
export class GestureRecognizer {
  constructor(canvas, callbacks = {}) {
    this.canvas = canvas;
    this.callbacks = callbacks;

    this.state = {
      pointers: new Map(),
      isPinching: false,
      pinchStartDistance: 1,
      pinchStartScale: 1,
      pinchStartCenter: { x: 0, y: 0 },
      pinchStartOffset: { x: 0, y: 0 },
      panPointerId: null,
      panStartPoint: { x: 0, y: 0 },
      panStartOffset: { x: 0, y: 0 },
      tapMoved: false,
      isDraggingNode: false,
      dragStartNode: null,
      lastTapTime: 0,
      lastTapPoint: { x: 0, y: 0 }
    };

    this.onPointerDown = this.onPointerDown.bind(this);
    this.onPointerMove = this.onPointerMove.bind(this);
    this.onPointerUp = this.onPointerUp.bind(this);
    this.onContextmenu = this.onContextmenu.bind(this);

    this.attach();
  }

  attach() {
    this.canvas.addEventListener("pointerdown", this.onPointerDown, { passive: false });
    this.canvas.addEventListener("pointermove", this.onPointerMove, { passive: false });
    this.canvas.addEventListener("pointerup", this.onPointerUp, { passive: false });
    this.canvas.addEventListener("pointercancel", this.onPointerUp, { passive: false });
    this.canvas.addEventListener("contextmenu", this.onContextmenu);
  }

  destroy() {
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerup", this.onPointerUp);
    this.canvas.removeEventListener("pointercancel", this.onPointerUp);
    this.canvas.removeEventListener("contextmenu", this.onContextmenu);
  }

  // --- Coordinate helpers ---

  getPoint(event) {
    const rect = this.canvas.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  static distance(a, b) {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  static center(a, b) {
    return { x: (a.x + b.x) * 0.5, y: (a.y + b.y) * 0.5 };
  }

  // --- Event handlers ---

  onContextmenu(event) {
    event.preventDefault();
    const point = this.getPoint(event);
    this.callbacks.onContextmenu?.(point);
  }

  onPointerDown(event) {
    event.preventDefault();

    try {
      this.canvas.setPointerCapture(event.pointerId);
    } catch {
      // Einige Browser erlauben Pointer Capture nicht in jedem Zustand.
    }

    const point = this.getPoint(event);
    const { state } = this;

    state.pointers.set(event.pointerId, point);

    if (state.pointers.size === 1) {
      this._beginSingleTouch(point);
    }

    if (state.pointers.size === 2) {
      this._beginPinch();
    }
  }

  onPointerMove(event) {
    event.preventDefault();

    const { state } = this;
    if (!state.pointers.has(event.pointerId)) return;

    const point = this.getPoint(event);
    state.pointers.set(event.pointerId, point);

    if (state.pointers.size === 2) {
      this._handlePinchMove();
      return;
    }

    if (state.pointers.size === 1 && state.panPointerId === event.pointerId) {
      this._handleSingleTouchMove(point);
    }
  }

  onPointerUp(event) {
    event.preventDefault();

    const point = this.getPoint(event);
    const { state } = this;
    const wasSinglePointer = state.pointers.size === 1;
    const wasTap = wasSinglePointer && !state.tapMoved && !state.isPinching;

    state.pointers.delete(event.pointerId);

    // Node drag end
    if (state.isDraggingNode) {
      if (state.tapMoved) {
        this.callbacks.onNodeDragEnd?.(point, state.dragStartNode);
      }
      state.isDraggingNode = false;
      state.dragStartNode = null;
      this.callbacks.onNodeDragCancel?.();
    } else if (wasTap) {
      this._handleTap(point);
    }

    // Pinch cleanup
    if (state.pointers.size < 2) {
      state.isPinching = false;
    }

    // Transition from 2→1 finger: re-anchor pan on remaining pointer
    if (state.pointers.size === 1) {
      const [remainingId, remainingPoint] = Array.from(state.pointers.entries())[0];
      state.panPointerId = remainingId;
      state.panStartPoint = remainingPoint;
      state.tapMoved = true; // suppress tap after pinch
      this.callbacks.onPanReanchor?.(remainingPoint);
    }

    if (state.pointers.size === 0) {
      state.panPointerId = null;
    }

    this.callbacks.onPointerUpCleanup?.();
  }

  // --- Gesture begin/move handlers ---

  _beginSingleTouch(point) {
    const { state } = this;
    state.panPointerId = state.pointers.keys().next().value;
    state.panStartPoint = point;
    state.panStartOffset = { x: 0, y: 0 }; // filled by controller via callback
    state.tapMoved = false;

    // Ask controller if we should start a node drag
    const dragTarget = this.callbacks.onQueryNodeDrag?.(point);
    if (dragTarget) {
      state.isDraggingNode = true;
      state.dragStartNode = dragTarget;
      this.callbacks.onNodeDragStart?.(dragTarget, point);
    } else {
      state.isDraggingNode = false;
      state.dragStartNode = null;
    }
  }

  _beginPinch() {
    const { state } = this;
    const points = Array.from(state.pointers.values());
    const center = GestureRecognizer.center(points[0], points[1]);

    state.isPinching = true;
    state.pinchStartDistance = Math.max(1, GestureRecognizer.distance(points[0], points[1]));
    state.pinchStartCenter = center;
    state.pinchStartOffset = { x: 0, y: 0 }; // filled by controller
    state.pinchStartScale = 1; // filled by controller
    state.tapMoved = true;

    this.callbacks.onPinchStart?.(center, state.pinchStartDistance);
  }

  _handlePinchMove() {
    const { state } = this;
    const points = Array.from(state.pointers.values());
    const distance = Math.max(1, GestureRecognizer.distance(points[0], points[1]));
    const center = GestureRecognizer.center(points[0], points[1]);

    this.callbacks.onPinchMove?.(center, distance, state.pinchStartDistance);
    state.tapMoved = true;
  }

  _handleSingleTouchMove(point) {
    const { state } = this;
    const dx = point.x - state.panStartPoint.x;
    const dy = point.y - state.panStartPoint.y;

    if (Math.hypot(dx, dy) > CONFIG.tapMoveTolerance) {
      state.tapMoved = true;
    }

    if (state.isDraggingNode) {
      this.callbacks.onNodeDragMove?.(point);
    } else {
      this.callbacks.onPan?.(dx, dy, state.panStartOffset);
    }
  }

  _handleTap(point) {
    const { state } = this;
    const now = performance.now();

    if (now - state.lastTapTime < 350) {
      // Double tap
      this.callbacks.onDoubleTap?.(point);
      state.lastTapTime = 0;
    } else {
      this.callbacks.onTap?.(point);
      state.lastTapTime = now;
    }
  }
}
