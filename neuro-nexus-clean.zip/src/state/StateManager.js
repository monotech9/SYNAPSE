/**
 * StateManager
 * 
 * Centralized state management with Redux-like pattern.
 * Enables time-travel debugging, state snapshots, and predictable mutations.
 * 
 * Features:
 * - Single source of truth
 * - Action dispatching
 * - Time-travel debugging (undo/redo)
 * - Selectors
 * - Middleware support
 * - State snapshots
 * - Subscription system
 */

export class StateManager {
  constructor(initialState = {}) {
    this.state = { ...initialState };
    this.history = [{ timestamp: Date.now(), state: { ...initialState } }];
    this.currentHistoryIndex = 0;
    this.maxHistory = 100;

    this.listeners = new Set();
    this.middleware = [];
    this.reducers = new Map();

    this.isReplaying = false;
  }

  /**
   * Get current state
   */
  getState() {
    return { ...this.state };
  }

  /**
   * Get state at specific history index
   */
  getStateAtIndex(index) {
    if (index < 0 || index >= this.history.length) return null;
    return { ...this.history[index].state };
  }

  /**
   * Subscribe to state changes
   */
  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /**
   * Dispatch an action
   */
  dispatch(action) {
    if (!action.type) {
      throw new Error('Action must have a type property');
    }

    // Run through middleware (before)
    for (const mw of this.middleware) {
      if (mw.before) {
        action = mw.before(action, this.state) ?? action;
      }
    }

    // Apply reducer
    const reducer = this.reducers.get(action.type);
    if (reducer) {
      this.state = reducer(this.state, action) ?? this.state;
    }

    // Run through middleware (after)
    for (const mw of this.middleware) {
      if (mw.after) {
        mw.after(action, this.state);
      }
    }

    // Record in history (truncate future if we're not at the end)
    if (this.currentHistoryIndex < this.history.length - 1) {
      this.history = this.history.slice(0, this.currentHistoryIndex + 1);
    }

    this.history.push({
      timestamp: Date.now(),
      action: { ...action },
      state: { ...this.state },
    });

    if (this.history.length > this.maxHistory) {
      this.history.shift();
    } else {
      this.currentHistoryIndex++;
    }

    // Notify listeners
    this._notify(action);
  }

  /**
   * Register a reducer for an action type
   */
  addReducer(type, reducerFn) {
    this.reducers.set(type, reducerFn);
  }

  /**
   * Register a reducer with namespace (convenience)
   */
  addReducers(namespace, reducerMap) {
    for (const [key, fn] of Object.entries(reducerMap)) {
      this.addReducer(`${namespace}/${key}`, fn);
    }
  }

  /**
   * Register middleware
   */
  use(middleware) {
    this.middleware.push(middleware);
  }

  /**
   * Undo to previous state
   */
  undo() {
    if (this.currentHistoryIndex > 0) {
      this.currentHistoryIndex--;
      this.state = { ...this.history[this.currentHistoryIndex].state };
      this._notify({ type: 'UNDO' });
      return true;
    }
    return false;
  }

  /**
   * Redo to next state
   */
  redo() {
    if (this.currentHistoryIndex < this.history.length - 1) {
      this.currentHistoryIndex++;
      this.state = { ...this.history[this.currentHistoryIndex].state };
      this._notify({ type: 'REDO' });
      return true;
    }
    return false;
  }

  /**
   * Get history metadata
   */
  getHistory() {
    return this.history.map((entry, idx) => ({
      index: idx,
      timestamp: entry.timestamp,
      action: entry.action,
      isCurrent: idx === this.currentHistoryIndex,
    }));
  }

  /**
   * Reset to a specific history point
   */
  resetToIndex(index) {
    if (index < 0 || index >= this.history.length) return false;
    this.currentHistoryIndex = index;
    this.state = { ...this.history[index].state };
    this._notify({ type: 'RESET_TO_INDEX', payload: { index } });
    return true;
  }

  /**
   * Create a selector function
   */
  select(selector) {
    return () => selector(this.state);
  }

  /**
   * Get a slice of state
   */
  getSlice(path) {
    const parts = path.split('.');
    let value = this.state;

    for (const part of parts) {
      if (value && typeof value === 'object') {
        value = value[part];
      } else {
        return undefined;
      }
    }

    return value;
  }

  /**
   * Create a state snapshot
   */
  snapshot(name) {
    return {
      name,
      timestamp: Date.now(),
      state: { ...this.state },
      historyIndex: this.currentHistoryIndex,
    };
  }

  /**
   * Restore from a snapshot
   */
  restoreSnapshot(snapshot) {
    this.state = { ...snapshot.state };
    this.currentHistoryIndex = snapshot.historyIndex;
    this._notify({ type: 'RESTORE_SNAPSHOT', payload: { name: snapshot.name } });
  }

  /**
   * Export state as JSON
   */
  export() {
    return JSON.stringify(
      {
        currentIndex: this.currentHistoryIndex,
        state: this.state,
        history: this.history,
        timestamp: new Date().toISOString(),
      },
      null,
      2
    );
  }

  /**
   * Import state from JSON
   */
  import(json) {
    try {
      const data = JSON.parse(json);
      this.state = data.state;
      this.history = data.history;
      this.currentHistoryIndex = data.currentIndex;
      this._notify({ type: 'IMPORT' });
      return true;
    } catch (e) {
      console.error('Failed to import state:', e);
      return false;
    }
  }

  /**
   * Clear history but keep current state
   */
  clearHistory() {
    this.history = [
      {
        timestamp: Date.now(),
        state: { ...this.state },
      },
    ];
    this.currentHistoryIndex = 0;
  }

  /**
   * Private: notify listeners
   */
  _notify(action) {
    this.listeners.forEach((listener) => {
      try {
        listener({
          state: this.state,
          action,
          history: this.getHistory(),
          canUndo: this.currentHistoryIndex > 0,
          canRedo: this.currentHistoryIndex < this.history.length - 1,
        });
      } catch (e) {
        console.error('Error in state listener:', e);
      }
    });
  }

  /**
   * Get state diff between two indices
   */
  diff(fromIndex, toIndex) {
    const from = this.history[fromIndex]?.state ?? {};
    const to = this.history[toIndex]?.state ?? {};

    const diffs = {};
    const allKeys = new Set([...Object.keys(from), ...Object.keys(to)]);

    for (const key of allKeys) {
      if (JSON.stringify(from[key]) !== JSON.stringify(to[key])) {
        diffs[key] = {
          from: from[key],
          to: to[key],
        };
      }
    }

    return diffs;
  }

  /**
   * Get stats about state mutations
   */
  getStats() {
    return {
      historyLength: this.history.length,
      currentIndex: this.currentHistoryIndex,
      canUndo: this.currentHistoryIndex > 0,
      canRedo: this.currentHistoryIndex < this.history.length - 1,
      stateSize: JSON.stringify(this.state).length,
      reducerCount: this.reducers.size,
      middlewareCount: this.middleware.length,
      listenerCount: this.listeners.size,
    };
  }
}

/**
 * Global state manager singleton
 */
let stateManagerInstance = null;

export function getStateManager() {
  if (!stateManagerInstance) {
    stateManagerInstance = new StateManager();
  }
  return stateManagerInstance;
}

export function initStateManager(initialState) {
  if (stateManagerInstance) {
    console.warn('StateManager already initialized');
    return stateManagerInstance;
  }
  stateManagerInstance = new StateManager(initialState);
  return stateManagerInstance;
}

/**
 * Useful middleware examples
 */

/**
 * Logger middleware
 */
export const loggerMiddleware = {
  before: (action) => {
    console.group(`📤 Action: ${action.type}`);
    console.log('Payload:', action.payload);
    return action;
  },
  after: (action, newState) => {
    console.log('New State:', newState);
    console.groupEnd();
  },
};

/**
 * Persistence middleware - save to localStorage
 */
export function createPersistenceMiddleware(key = 'neuro-nexus.state.v1') {
  return {
    after: (action, state) => {
      try {
        localStorage.setItem(key, JSON.stringify(state));
      } catch (e) {
        console.warn('Failed to persist state:', e);
      }
    },
  };
}

/**
 * Timing middleware - track action duration
 */
export const timingMiddleware = {
  before: (action) => {
    action._startTime = performance.now();
    return action;
  },
  after: (action) => {
    if (action._startTime) {
      const duration = performance.now() - action._startTime;
      if (duration > 16) {
        // > 1 frame at 60fps
        console.warn(
          `⚠️ Slow action: ${action.type} took ${duration.toFixed(2)}ms`
        );
      }
    }
  },
};
