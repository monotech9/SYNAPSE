#!/usr/bin/env python3
"""
Neuro Nexus
Startet einen lokalen Webserver und öffnet das Netzwerk im Browser.
"""

import http.server
import socketserver
import webbrowser
import threading
import os
import sys

# ── Konfiguration ──────────────────────────────────────────────────────────────
PORT = 8080
HOST = "127.0.0.1"  # Zuverlaesslicher auf iOS als "localhost"
GAME_FILE = "index.html"          # Für die saubere Spielansicht
# Debug-Modus: GAME_FILE = "index.html?debug=true"        # Für den Debug-/Test-Modus (auskommentieren)
# ──────────────────────────────────────────────────────────────────────────────


def get_free_port(start: int = PORT) -> int:
    """Sucht den nächsten freien Port ab `start`."""
    import socket
    for port in range(start, start + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((HOST, port))
                return port
            except OSError:
                continue
    raise OSError(f"Kein freier Port im Bereich {start}–{start + 19} gefunden.")


class SilentHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP-Handler ohne Log-Ausgaben in der Konsole."""

    def log_message(self, format, *args):
        pass  # Ausgaben unterdrücken


def open_browser(url: str, delay: float = 0.5):
    """Öffnet den Browser nach einer kurzen Verzögerung."""
    def _open():
        import time
        time.sleep(delay)
        webbrowser.open(url)
    threading.Thread(target=_open, daemon=True).start()


def main():
    # Ins Projektverzeichnis wechseln (damit relative Pfade stimmen)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    port = get_free_port()
    url = f"http://{HOST}:{port}/{GAME_FILE}"

    print("╔══════════════════════════════════════════════╗")
    print("║              Neuro Nexus                     ║")
    print("╠══════════════════════════════════════════════╣")
    print(f"║  Server läuft auf: {url:<26}║")
    print("║  Browser öffnet sich automatisch …          ║")
    print("║  Beenden mit Ctrl+C                         ║")
    print("╚══════════════════════════════════════════════╝")

    open_browser(url)

    with socketserver.TCPServer((HOST, port), SilentHandler) as httpd:
        httpd.allow_reuse_address = True
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n\nServer beendet. Auf Wiedersehen!")
            sys.exit(0)


if __name__ == "__main__":
    main()
