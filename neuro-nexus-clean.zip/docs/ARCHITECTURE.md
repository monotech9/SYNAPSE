# Neuro Nexus — Modulstruktur

Diese Datei gibt einen Überblick über das gesamte Projekt und wie die
Module voneinander abhängen.


## Abhängigkeits-Graph (vereinfacht)

```
index.html
  │
  ├── styles.css          ← Theme-Variablen (:root)
  ├── hud.css             ← @import Aggregator (12 Module)
  │    ├── hud-base.css
  │    ├── hud-widgets.css
  │    ├── hud-sidebar-core.css
  │    ├── hud-sidebar-features.css
  │    ├── hud-sidebar-mobile.css
  │    ├── hud-v13-core.css
  │    ├── hud-v13-overlays.css
  │    ├── hud-v13-nova.css
  │    ├── hud-v13-dock.css
  │    ├── hud-v13-protocol.css
  │    └── hud-standalone.css
  │
  └── main.js
       └── app.js
            ├── NeuroSimulation.js (Fassade)
            │    ├── systemFactory.js    ← Zentrale System-Instanziierung
            │    ├── EdgeManager.js
            │    ├── InteractionHandler.js
            │    ├── CameraController.js
            │    ├── SpatialGrid.js
            │    ├── WorkerManager.js → SimulationWorker.js
            │    ├── EventBus.js ← alle Systems subscriben hier
            │    ├── personality.js + dnaArchetypes.js (GDD §3-4)
            │    ├── entities/ (Node, Edge, Cluster)
            │    │
            │    ├── consciousness/ (8 Module)
            │    │    ├── ConsciousnessSystem
            │    │    ├── AttentionSystem
            │    │    ├── GlobalWorkspace
            │    │    ├── PredictionEngine
            │    │    ├── SelfModelEngine
            │    │    ├── MetaCognition
            │    │    ├── IntrinsicMotivation
            │    │    └── ActionExecutor
            │    │
            │    └── systems/ (20+ Module)
            │         ├── EmergenceSystem + EmergenceDetector
            │         │   + emergenceConstants + emergenceMetrics
            │         ├── StoryMappingEngine
            │         │   + storyTemplates + storyTemplateSelector + storyConstants
            │         ├── EmotionEngine + EmotionAppraiser + EmotionModulation
            │         ├── PulseEngine + SignalSystem
            │         ├── GrowthSystem + HeartbeatSystem
            │         ├── SleepCycle + SleepDreamEngine
            │         ├── EpisodicMemory + episodicConstants + episodicFactory
            │         ├── AutobiographicalMemory
            │         ├── NarrativeGenerator + ChapterFactory
            │         ├── ScarSystem + BridgeBuilder
            │         ├── NetworkBuilder + NetworkPruning
            │         └── LifecycleLoop + UpdateLoop + ActivityScheduler
            │
            ├── CanvasRenderer.js
            │    └── layers/ (7 Renderer)
            │
            └── HudPanel.js (Orchestrator, ~170 Zeilen)
                 ├── HudDomMap.js           ← DOM-IDs
                 ├── HudWidgetManager.js    ← Widget-Erstellung
                 │    └── widgets/ (8 Widgets, alle erben BaseWidget)
                 ├── HudFrameLoop.js        ← Render-Loop
                 ├── HudSelfModel.js        ← NOVA narrative → Log
                 ├── HudEventDetector.js    ← Sim-Events → Log
                 ├── HudDataUpdater.js      ← DOM-Updates
                 ├── HudMenuController.js   ← Menü/Reset/Settings
                 ├── HudNavigationController.js ← Drawer/Tabs/Dock
                 ├── HudInteractionController.js ← Trigger/Sleep/Onboarding
                 ├── TooltipSystem.js
                 ├── DataExchange.js
                 └── ConsciousnessHUD.js
```


## EventBus-Kommunikation

Der EventBus (`EventBus.js`) ist das zentrale Pub/Sub-System.
Alle Systems kommunizieren asynchron über Events:

```
Simulation Systems                    HUD / Widgets
─────────────────                    ──────────────
EmergenceDetector                    HudEventDetector
  │ emits "emergence:detected"  ──→  │ logs events
  │ emits "emergence:phaseShift" ──→ │
  │                                   │
StoryMappingEngine                   HudSelfModel
  │ emits "story:event"         ──→  │ logs NOVA text
  │ emits "story:milestone"     ──→  │
  │                                   │
SelfModelEngine                      HudSelfModel
  │ emits "selfmodel:narrative" ──→  │ logs narrative
  │ emits "selfmodel:stateChange"──→ │ logs transition
  │                                   │
SleepCycle                           HudInteractionController
  │ emits "sleep:stateChange"   ──→  │ updates indicator
  │                                   │
PulseEngine                          (intern, keine HUD-Events)
  │ emits "signal:injected"     ──→  │ (nur Trigger-Button)
```

Kein System hat eine direkte Referenz zum HUD.
Alles fließt über den EventBus — das HUD ist ein reiner Konsument.


## CSS-Architektur

hud.css ist ein reiner Aggregator mit `@import`-Anweisungen.
Die Stylesheets sind thematisch aufgeteilt:

| Modul | Zeilen | Inhalt |
|---|---|---|
| hud-base.css | ~394 | Glass, Layout, Header, Menu, Settings |
| hud-widgets.css | ~245 | Widget-Container (Oszilloskop, Vitalität, fMRI) |
| hud-sidebar-core.css | ~228 | Sidebar-Grundstil, Drawer, iOS-Scroll, Layout-Fixes |
| hud-sidebar-features.css | ~384 | Badges, Achievements, Theme, Telemetry, Radar, Phasenraum |
| hud-sidebar-mobile.css | ~150 | Mobile: Bottom Dock, Dual-Console, Dual-Widget-Row |
| hud-v13-core.css | ~379 | Glance-Bar, Tab-Navigation, Kern-Struktur |
| hud-v13-overlays.css | ~141 | Tooltips, Onboarding, Glassmorphism |
| hud-v13-nova.css | ~461 | AI-Thoughts, Sleep-Indikator, Status Card |
| hud-v13-dock.css | ~221 | Dock & Live-Ticker |
| hud-v13-protocol.css | ~792 | Protokoll-Tab & Höhenanpassung |
| hud-standalone.css | ~170 | Gemergte Standalone-Widgets + Inline-Style-Klassen |

Kein CSS-Modul über 800 Zeilen. Ursprünglicher hud-v13.css-Monolith (1964 Zeilen)
in 5 Module aufgespalten, hud-sidebar.css (725 Zeilen) in 3 Module.


## Datei-Größen (Top 10, ohne Tests)

| Datei | Zeilen | Modul |
|---|---|---|
| NeuroSimulation.js | 360 | simulation |
| EpisodicMemory.js | 392 | systems |
| PredictionEngine.js | 382 | consciousness |
| HeartbeatSystem.js | 357 | systems |
| EmergenceDetector.js | 356 | systems |
| EmergenceSystem.js | 349 | systems |
| LifecycleLoop.js | 318 | systems |
| AmbientAudio.js | 313 | audio |
| SleepCycle.js | 311 | systems |
| IntrinsicMotivation.js | 308 | consciousness |

Keine Datei über 400 Zeilen. HUD-Module alle unter 200 Zeilen.
Widget-Module alle unter 280 Zeilen.
