# HUD — Aufbau & Anpassungs-Leitfaden (v14)

Das HUD (Heads-Up Display) von Neuro Nexus ist vollständig modular aufgebaut.
Jede funktionale Einheit — Konstanten, Updater, Controller, Widgets —
lebt in ihrer eigenen Datei. Diese README erklärt, wie alles zusammenhängt
und wie man Anpassungen vornimmt.


## Übersicht: Die HUD-Architektur (v14)

```
src/ui/                              — HUD-Orchestrierung & Module
  HudPanel.js            — Pure Orchestrator: verkabelt alle Module
  HudDomMap.js           — Zentrale DOM-ID-Liste
  HudWidgetManager.js    — Widget-Erstellung & Visibility-Lifecycle
  HudFrameLoop.js        — Render-Loop (verwendet Updater-Registry)
  HudSelfModel.js        — SelfModel-Events → Log
  HudEventDetector.js    — Simulations-Events → Log/Epoch
  TooltipSystem.js       — Fachbegriff-Tooltips
  DataExchange.js        — Save/Load/Export/Import + Toast
  ObserverMode.js        — Beobachtungsmodus
  ResonanceLabel.js      — Schwebendes Cluster-Label
  hudUtils.js            — Gemeinsame DOM-Helper (setText, setBarWidth, ...)
  hudConstants.js        — Thin Facade (re-exportiert constants/)
  ConsciousnessHUD.js    — Thin Facade (re-exportiert updaters/)
  HudDataUpdater.js      — Thin Facade (re-exportiert updaters/)
  HudNavigationController.js — Thin Facade (re-exportiert controllers/)
  HudInteractionController.js — Thin Facade (re-exportiert controllers/)
  HudMenuController.js   — Thin Facade (re-exportiert controllers/)

src/ui/constants/                   — Farb-Mappings, Labels, Templates
  emotionColors.js       — EMOTION_COLORS, MOOD_STATE_COLORS, MOOD_STATE_LABELS_DE
  driveColors.js         — DRIVE_COLORS
  archetypeData.js       — ARCHETYPE_ICONS, ARCHETYPE_NAMES_DE + Helper
  growthLabels.js        — GROWTH_LABELS, CLUSTER_LABELS
  logTemplates.js        — LOG (HTML-Templates für Log-Einträge)
  aiThoughts.js          — AI_THOUGHTS, maybeAIThought, SLEEP_MESSAGES
  tooltipData.js         — TOOLTIP_DATA (Fachbegriff-Erklärungen)
  sleepStates.js         — SLEEP_INDICATOR_MAP
  index.js               — Re-Export aller Konstanten

src/ui/updaters/                    — DOM-Updater (je HUD-Element eine Datei)
  BaseUpdater.js         — Einheitliches Lifecycle-Interface (update, throttle, destroy)
  registry.js            — Sammelt alle Updater, updateAll/updateMenu/destroyUpdaters
  EmotionUpdater.js      — Emotions-Anzeige (dominant, mood, modulation)
  ConsciousnessStateUpdater.js — State-Label, Mood, Narrative, Reflection
  PredictionErrorUpdater.js — Prädiktionsfehler-Bar
  SelfAwarenessUpdater.js — Self-Awareness-Bar
  DriveUpdater.js        — Dominanter Drive + Farbe
  FreeEnergyUpdater.js   — Freie Energie + Self-Confidence
  PhiUpdater.js          — Phi (IIT) + Epistemic Value
  EnergyModelUpdater.js  — Energie-Modell (dynamischer Farbverlauf)
  DopamineUpdater.js     — Dopamin / Reward-System
  CohesionUpdater.js     — Cohesion Core / Identitäts-Stabilität
  DnaArchetypeUpdater.js — DNA-Archetyp + Achsen-Werte
  EchoMemoryUpdater.js   — Echo Memory (Badge, Liste, Werte)
  ActionStatsUpdater.js  — Action-Executor Statistiken
  IgnitionFlashUpdater.js — Ignition-Flash → Oscilloscope Gamma-Spike
  VitalityUpdater.js     — Metabolismus, Plastizität, Resilienz
  MemoryRingsUpdater.js  — Dendritische Speicher-Ringe
  StageLabelUpdater.js   — Resonance-Label / Growth-Stage
  GlanceBarUpdater.js    — Glance-Bar (Stage, Nodes, Edges, Age, FPS)
  A11yStatusUpdater.js   — Barrierefreiheits-Status
  NavPanelUpdater.js     — Dock Nav-Panel Live-Status
  GaugeWidgetUpdater.js  — System-Auslastung (CPU/MEM/NET)
  PhaseArcWidgetUpdater.js — Phasen-Transition Arc
  TelemetryUpdater.js    — Telemetry-Ribbon + Health-Dot (1/s)
  SysTickerUpdater.js    — System-Ticker (1/s)
  HeatmapWidgetUpdater.js — Aktivitäts-Heatmap (5s)
  MenuStatsUpdater.js    — Menü-Statistiken + Achievements

src/ui/controllers/                 — UI-Controller (je Concern eine Datei)
  HudMenu.js             — Hauptmenü (Hamburger, Reset)
  HudSettings.js         — Settings-Pane (Audio, Observer, Theme)
  HudDrawer.js           — Mobile Sidebar (Drawer)
  HudTabSystem.js        — Tab-System in der Sidebar
  HudBottomDock.js       — Bottom-Dock-Navigation
  HudDockNavPanel.js     — Ausklappbares Nav-Panel
  HudTrigger.js          — Trigger-Button (Impuls-Auslösung)
  HudSleepIndicator.js   — Schlafzustand-UI
  HudOnboarding.js       — Onboarding-Overlay (Erststart)

src/widgets/              — Modulare Widget-Klassen (alle erben BaseWidget)
  BaseWidget.js          — Lifecycle-Interface (resize, pause, resume, destroy)
  OscilloscopeWidget     — 3-Kanal EEG (Gamma/Beta/Alpha)
  VitalityWidget         — Metaball/Vitalitäts-Zelle
  FmriWidget             — 8×8 fMRI-Aktivitätsmatrix
  MemoryRingsWidget      — Dendritische Speicher-Ringe (SVG)
  EpochLogWidget         — Evolutions-Log + Text-Feed
  RadarWidget            — Radar mit Cluster-Positionierung
  PhaseSpaceWidget       — Phasenraum-Diagramm
  EmotionWidget          — Emotions-Rad / Mood-Visualisierung
  GaugeWidget            — Arc-Gauge (CPU/MEM/NET)
  HeatmapWidget          — Aktivitäts-Heatmap
  PhaseArcWidget         — Phasen-Transition Arc
  ConnectionWidget       — Verbindungsstärke
  AlertWidget            — System-Alarme
```


## Architektur-Prinzip

```
index.html
  └── main.js
       └── app.js
            └── new HudPanel(sim, telemetry, observer)
                 └── .start()
                      ├── initWidgets()           → HudWidgetManager
                      ├── connectSelfModel()      → HudSelfModel
                      ├── createEventDetector()   → HudEventDetector
                      ├── createFrameLoop()       → HudFrameLoop
                      │    ├── Updater-Registry   → updaters/registry.js
                      │    │    └── 27 Updater-Module (je Element eine Datei)
                      │    └── Canvas-Widget-Taktung (60 FPS / 10 FPS)
                      ├── initOnboarding()        → controllers/HudOnboarding
                      ├── initSleepIndicator()    → controllers/HudSleepIndicator
                      ├── initTrigger()           → controllers/HudTrigger
                      ├── initMenu()              → controllers/HudMenu
                      ├── initSettings()          → controllers/HudSettings
                      ├── initDrawer()            → controllers/HudDrawer
                      ├── setupTabSystem()        → controllers/HudTabSystem
                      ├── setupDockNavPanel()     → controllers/HudDockNavPanel
                      └── setupBottomDock()       → controllers/HudBottomDock
```

`HudPanel` hält **keine eigene Logik** — es instanziiert nur die Module
und übergibt ihnen gegenseitige Referenzen (z.B. `getLogWidget`-Accessor).


## Updater-Registry: Das Herzstück

Alle DOM-Updater sind in `src/ui/updaters/` als einzelne Module organisiert.
Jeder Updater erbt von `BaseUpdater` und hat:

- `update(ctx, now)` — pro Frame (mit individuellem Throttling)
- `init(ctx)` — einmalig (optional)
- `destroy()` — Cleanup

Die **Registry** (`registry.js`) sammelt alle Updater und bietet:
- `createUpdaters(unlockedEpochs)` → erstellt alle Instanzen
- `updateAll(updaters, ctx, now)` → ruft alle auf
- `updateMenu(menuUpdater, ctx, now)` → nur Menu-Stats
- `destroyUpdaters(updaters)` → Cleanup

Der Frame-Loop iteriert über die Registry statt einzelne Funktionen aufzurufen.


## Wie das Frame-Loop funktioniert

`HudFrameLoop.js` treibt pro Frame (`requestAnimationFrame`) alle Widgets an:

| Taktung   | Was                        | Mechanismus          |
|-----------|----------------------------|----------------------|
| Jeder Frame | Oscilloscope, Vitality, Radar, Phasenraum, Emotion | direkt im Frame-Loop |
| ~10 FPS   | fMRI-Aktivitätsmatrix      | lastFmri Timer       |
| 1×/Sekunde | Telemetry, SysTicker       | Updater.throttleMs=1000 |
| 5s        | Heatmap                    | Updater.throttleMs=5000 |
| ~4.5 FPS  | Alle anderen DOM-Updater   | lastDom Timer (220ms) |


## CSS-Struktur

```
hud.css (Aggregator)
  ├── @import hud-base.css     — Glass, Layout, Header, Menu, Settings
  ├── @import hud-widgets.css  — Widget-Container
  ├── @import hud-sidebar.css  — Sidebar, Tabs, Panels, Mobile
  └── @import hud-v13.css      — Glance Bar, Dock, Sleep, v13 Polish
```


---

## Anpassungs-Rezepte

### 1. Ein bestehendes Updater-Modul ändern

Jedes HUD-Element hat seine eigene Datei in `src/ui/updaters/`.
Die `_doUpdate(ctx)`-Methode enthält die gesamte Update-Logik.

**Beispiel: Dopamin-Anzeige ändern**

```js
// src/ui/updaters/DopamineUpdater.js → _doUpdate()
// Ändere Farbe oder Berechnung — keine andere Datei muss angefasst werden
```

### 2. Ein neues HUD-Element hinzufügen

**Schritt 1: Updater-Klasse erstellen**

```js
// src/ui/updaters/MyElementUpdater.js
import { BaseUpdater } from "./BaseUpdater.js";

export class MyElementUpdater extends BaseUpdater {
  constructor() { super(0); } // 0 = gedrosselt durch Frame-Loop

  _doUpdate(ctx) {
    const { sim, els, snap } = ctx;
    // ... deine Update-Logik ...
  }
}
```

**Schritt 2: In Registry registrieren**

```js
// src/ui/updaters/registry.js
import { MyElementUpdater } from "./MyElementUpdater.js";

// In createUpdaters():
const myUpdater = new MyElementUpdater();
// ... zum all-Array hinzufügen
```

**Schritt 3: DOM-Element in index.html + HudDomMap.js**

```html
<!-- index.html -->
<div id="myElementValue">—</div>
```

```js
// src/ui/HudDomMap.js → ids Array:
"myElementValue",
```

Fertig — der Frame-Loop ruft den Updater automatisch auf.

### 3. Ein HUD-Element durch ein anderes ersetzen

1. Neue Updater-Klasse in `src/ui/updaters/` erstellen (oder bestehende kopieren & anpassen)
2. In `registry.js` den Import und Instanziierung austauschen
3. Fertig — kein anderer Code muss geändert werden

### 4. Ein Widget visuell ändern

Jedes Widget hat seine eigene Datei in `src/widgets/`.
Die `draw()`-Methode enthält die gesamte Render-Logik.

### 5. Ein neues Widget hinzufügen

1. Widget-Klasse in `src/widgets/` erstellen (erbt `BaseWidget`)
2. In `HudWidgetManager.js` importieren + instanziieren + zu `allWidgets` hinzufügen
3. In `HudFrameLoop.js` in die passende Taktung einfügen
4. Canvas in `index.html` + ID in `HudDomMap.js` + CSS in `hud-widgets.css`

### 6. Konstanten ändern

Jede Konstanten-Domain hat ihre eigene Datei in `src/ui/constants/`:

| Was ändern | Datei |
|---|---|
| Emotion-Farben | `constants/emotionColors.js` |
| Drive-Farben | `constants/driveColors.js` |
| Archetyp-Icons/Namen | `constants/archetypeData.js` |
| Wachstums-Labels | `constants/growthLabels.js` |
| Log-Templates | `constants/logTemplates.js` |
| KI-Gedanken (NOVA) | `constants/aiThoughts.js` |
| Tooltip-Texte | `constants/tooltipData.js` |
| Schlaf-States | `constants/sleepStates.js` |

### 7. Controller ändern

Jedes UI-Concern hat seine eigene Datei in `src/ui/controllers/`:

| Was ändern | Datei |
|---|---|
| Hauptmenü | `controllers/HudMenu.js` |
| Settings | `controllers/HudSettings.js` |
| Drawer/Sidebar | `controllers/HudDrawer.js` |
| Tab-System | `controllers/HudTabSystem.js` |
| Bottom Dock | `controllers/HudBottomDock.js` |
| Nav-Panel | `controllers/HudDockNavPanel.js` |
| Trigger/Impuls | `controllers/HudTrigger.js` |
| Sleep-Indikator | `controllers/HudSleepIndicator.js` |
| Onboarding | `controllers/HudOnboarding.js` |

### 8. Theme / Farben ändern

Alle Farben sind CSS-Variablen in `styles.css :root`.
Themes werden über `data-theme` Attribut am `<html>` umgeschaltet.


## Abwärtskompatibilität

Die alten Dateien (`hudConstants.js`, `ConsciousnessHUD.js`, `HudDataUpdater.js`,
`HudNavigationController.js`, `HudInteractionController.js`, `HudMenuController.js`)
existieren weiterhin als **Thin Facades** und re-exportieren die neuen Module.
Bestehender Code, der aus diesen Dateien importiert, funktioniert unverändert.


## Debug

Debug-Modus: `?debug=true` in der URL aktiviert DiagnosticsRecorder,
DebugOverlay und DebugControls.

```bash
python3 start.py
# → http://localhost:8080/index.html?debug=true
```


## Quick Reference: Wo finde ich…?

| Ich will… | Datei |
|---|---|
| HUD-Element-Werte ändern | `src/ui/updaters/[ElementName]Updater.js` → `_doUpdate()` |
| Neues HUD-Element hinzufügen | `updaters/registry.js` + neue Updater-Datei |
| HUD-Element ersetzen | `updaters/registry.js` austauschen |
| Widget-Zeichnung ändern | `src/widgets/[WidgetName].js` → `draw()` |
| Frame-Loop Taktung ändern | `HudFrameLoop.js` |
| Menü anpassen | `controllers/HudMenu.js` |
| Drawer/Tabs/Dock anpassen | `controllers/HudDrawer.js` / `HudTabSystem.js` / `HudBottomDock.js` |
| Trigger/Impuls ändern | `controllers/HudTrigger.js` |
| Konstanten ändern | `constants/[domain].js` |
| Farben/Theme ändern | `styles.css :root` |
| DOM-Element hinzufügen | `index.html` + `HudDomMap.js` |
